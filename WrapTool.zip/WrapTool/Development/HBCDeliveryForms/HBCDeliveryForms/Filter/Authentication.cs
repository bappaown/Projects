﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Filters;
using System.Web.Routing;
using HBCDeliveryForms.Common;
using System.Web.Configuration;

namespace HBCDeliveryForms.Filter
{
    public class Authentication : ActionFilterAttribute, IAuthenticationFilter
    {
        public void OnAuthentication(AuthenticationContext filterContext)
        {
            // Check Session is Empty Then set as Result is HttpUnauthorizedResult
            if (string.IsNullOrEmpty(Convert.ToString(filterContext.HttpContext.Session["User"])))
            {
                filterContext.Result = new HttpUnauthorizedResult();
            }
        }

        public void OnAuthenticationChallenge(AuthenticationChallengeContext filterContext)
        {
            if (filterContext.Result == null || filterContext.Result is HttpUnauthorizedResult)
            {
                string URL = string.Empty;
                if (WebConfigurationManager.AppSettings["AuthenticationMode"].ToString().ToLower() == "passport")
                {
                    URL = WebConfigurationManager.AppSettings["CAEGLink"].ToString();
                }
                else if (WebConfigurationManager.AppSettings["AuthenticationMode"].ToString().ToLower() == "form")
                {
                    URL = WebConfigurationManager.AppSettings["LoginLink"].ToString().ToLower();
                }
                filterContext.Result =  new RedirectResult(URL);
            }
        }

    }
}