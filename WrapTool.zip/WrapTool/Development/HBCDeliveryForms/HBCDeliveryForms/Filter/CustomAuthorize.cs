﻿using HBCDeliveryForms.Models;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.Mvc;

namespace HBCDeliveryForms.Filter
{
    public class CustomAuthorize : AuthorizeAttribute
    {
        protected override bool AuthorizeCore(HttpContextBase httpContext)
        {
            if (!string.IsNullOrEmpty(Roles))
            {
                string SessionRole = Convert.ToString(System.Web.HttpContext.Current.Session["Role"]);

                if (SessionRole == Roles)
                {
                    return true;
                }
            }
            return base.AuthorizeCore(httpContext);
        }

    }
}