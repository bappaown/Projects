﻿using HBCDeliveryForms.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HBCDeliveryForms.Filter
{
    public class CustomException : ActionFilterAttribute, IExceptionFilter
    {
        public void OnException(ExceptionContext filterContext)
        {
            //Exception e = filterContext.Exception;

            //filterContext.ExceptionHandled = true;

            //string Controller = filterContext.RouteData.Values["controller"].ToString();
            //string Method = filterContext.RouteData.Values["action"].ToString();
            //ExceptionTrackers.ExceptionTracker(Controller, Method, "Message: "+ e.Message.ToString() + "Stacktrace: "+ e.StackTrace.ToString());

            //filterContext.Result = new ViewResult()
            //{
            //    ViewName = "Error"
            //};

            //filterContext.HttpContext.Response.Clear();


            var controller = filterContext.Controller as Controller;
            controller.Response.StatusCode = (int)System.Net.HttpStatusCode.InternalServerError;
            controller.Response.TrySkipIisCustomErrors = true;
            filterContext.ExceptionHandled = true;

            var controllerName = (string)filterContext.RouteData.Values["controller"];
            var actionName = (string)filterContext.RouteData.Values["action"];
            var exception = filterContext.Exception;
            //need a model to pass exception data to error view
            var model = new HandleErrorInfo(exception, controllerName, actionName);

            var view = new ViewResult();
            view.ViewName = "Error";
            view.ViewData = new ViewDataDictionary();
            view.ViewData.Model = model;

            //copy any view data from original control over to error view
            //so they can be accessible.
            var viewData = controller.ViewData;
            if (viewData != null && viewData.Count > 0)
            {
                viewData.ToList().ForEach(view.ViewData.Add);
            }

            //Allow the error view to display on the same URL the error occurred
            view.ExecuteResult(filterContext);



        }
    }
}