﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HBCDeliveryForms.Common
{
    public class Email
    {
        public string FromEmail { get; set; }

        public string ToEmail { get; set; }

        public string CCAddresses { get; set; }

        public string BCCAddresses { get; set; }

        public string EmailSubject { get; set; }

        public string Body { get; set; }

        public bool IsHTML { get; set; }

        public string AttachmentFilePath { get; set; }
    }
}