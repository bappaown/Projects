﻿using HBCDeliveryForms.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HBCDeliveryForms.Common
{
    public static class ExceptionTrackers
    {
        private static WrapToolEntities db = new WrapToolEntities();
        public static void ExceptionTracker(string ControllerName, string MethodName, string ErrorMessage)
        {
            //ExceptionTracker ExTracker = new ExceptionTracker();
            //ExTracker.Controller = ControllerName;
            //ExTracker.MethodName = MethodName;
            //ExTracker.ErrorMessage = ErrorMessage;
            //ExTracker.ExceptionTime = DateTime.Now;
            //db.ExceptionTrackers.Add(ExTracker);
            //db.SaveChanges();
        }
    }
}