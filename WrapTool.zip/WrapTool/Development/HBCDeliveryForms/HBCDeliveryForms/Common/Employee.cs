﻿using System;
using System.Data;
using System.Linq;
using HBCDeliveryForms.Models;
using HBCDeliveryForms.Common;

public class Employee
{

    public int EmployeeId { get; set; }

    public int CostCenterId { get; set; }

    public int DepartmentId { get; set; }

    public string FirstName { get; set; }

    public string LastName { get; set; }

    public string FullName { get; set; }


    public static Employee GetEmployee(string lan = "")
    {
        Employee objEmp = new Employee();
        WrapToolEntities db = new WrapToolEntities();
        try
        {
            string LANId = lan == "" ? System.Security.Principal.WindowsIdentity.GetCurrent().Name : lan;
            LANId = LANId.Substring(LANId.IndexOf("\\"));
            objEmp.EmployeeId = Convert.ToInt32(LANId.Substring(4));

            //hardcoded -TL
            // objEmp.EmployeeId = 46070;

            //hardcoded -User
            // objEmp.EmployeeId = 58603;

            var EmplyeeDetails = db.Central_Employee_Main.Where(e => e.EmployeeID.Equals(objEmp.EmployeeId)).FirstOrDefault();
            if (EmplyeeDetails != null)
            {
                objEmp.EmployeeId = EmplyeeDetails.EmployeeID;
                objEmp.FirstName = EmplyeeDetails.FirstName;
                objEmp.LastName = EmplyeeDetails.LastName;
                objEmp.FullName = EmplyeeDetails.FirstName + ' ' + EmplyeeDetails.LastName;
                objEmp.DepartmentId = Convert.ToInt32(EmplyeeDetails.DepartmentID);
                objEmp.CostCenterId = Convert.ToInt32(EmplyeeDetails.CostCentreID);
                System.Web.HttpContext.Current.Session["User"] = objEmp;
            }

            var UserRole = db.UserRoles.Where(u => u.EmployeeId == objEmp.EmployeeId).FirstOrDefault();
            if (UserRole != null)
            {
                var Roles = db.RoleMasters.Where(r => r.RoleId == UserRole.RoleId).FirstOrDefault();
                System.Web.HttpContext.Current.Session["Role"] = Roles.Role;
            }

        }
        catch (Exception ex)
        {
        }
        return objEmp;
    }


}
