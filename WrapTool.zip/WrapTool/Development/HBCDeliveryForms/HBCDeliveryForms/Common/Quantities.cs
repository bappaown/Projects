﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HBCDeliveryForms.Common
{
    public class Quantities
    {
        public string Quantity { get; set; }

        public string QuanityText { get; set; }
    }
}