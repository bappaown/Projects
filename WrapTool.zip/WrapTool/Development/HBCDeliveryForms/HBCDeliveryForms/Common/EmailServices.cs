﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Web;
using HBCDeliveryForms.Common;
using System.Web.Configuration;

namespace HBCDeliveryForms.Common
{
    public class EmailServices : ISendEmail
    {
        public bool SendEmail(Email email)
        {
            bool isEmailSent = false;
            MailMessage mailMessage;
            SmtpClient smtpClient;
            Attachment attachment;
            Regex regex;
            Match match;
            regex = new Regex(@"\b[a-zA-Z0-9._]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}\b");
            using (mailMessage = new MailMessage())
            {
                mailMessage.IsBodyHtml = email.IsHTML;
                email.FromEmail = WebConfigurationManager.AppSettings["FromEmail"];
                match = regex.Match(email.FromEmail);
                if (match.Success)
                {
                    mailMessage.From = new MailAddress(email.FromEmail);
                }
                else
                {
                    throw new Exception("Email Error!");
                }

                if (string.IsNullOrEmpty(email.ToEmail))
                {
                    email.ToEmail = WebConfigurationManager.AppSettings["ToEmail"];
                }

                foreach (string toAddress in email.ToEmail.Replace(",", ";").Split(new Char[] { ';' }))
                {
                    match = regex.Match(toAddress);
                    if (match.Success)
                    {
                        mailMessage.To.Add(new MailAddress(toAddress));
                    }
                    else if (!string.IsNullOrEmpty(toAddress.Trim()))
                    {
                        throw new Exception("Email Error!");
                    }
                }

                // Add the bcc email addresses one at a time
                if (!string.IsNullOrEmpty(email.BCCAddresses))
                {
                    foreach (string bccAddresses in email.BCCAddresses.Replace(",", ";").Split(new Char[] { ';' }))
                    {
                        match = regex.Match(bccAddresses);
                        if (match.Success)
                        {
                            mailMessage.Bcc.Add(new MailAddress(bccAddresses));
                        }
                        else if (!string.IsNullOrEmpty(bccAddresses.Trim()))
                        {
                            throw new Exception("Email Error!");
                        }
                    }
                }

                // Add the cc email addresses one at a time
                if (!string.IsNullOrEmpty(email.CCAddresses))
                {
                    foreach (string addresses in email.CCAddresses.Replace(",", ";").Split(new Char[] { ';' }))
                    {
                        match = regex.Match(addresses);
                        if (match.Success)
                        {
                            mailMessage.CC.Add(new MailAddress(addresses));
                        }
                        else if (!string.IsNullOrEmpty(addresses.Trim()))
                        {
                            throw new Exception("Email Error!");
                        }
                    }
                }

                // Set the subject and body
                mailMessage.Subject = email.EmailSubject;
                mailMessage.Body = email.Body;
                mailMessage.IsBodyHtml = email.IsHTML;

                if (!string.IsNullOrEmpty(email.AttachmentFilePath))
                {
                    attachment = new Attachment(email.AttachmentFilePath);
                    mailMessage.Attachments.Add(attachment);
                    attachment = null;
                }

                // Network Credential Settings
                String networkUser = WebConfigurationManager.AppSettings["SMTPServerUserName"];
                String networkPassword = WebConfigurationManager.AppSettings["SMTPServerPassword"];
                NetworkCredential networkCredential = new NetworkCredential(networkUser, networkPassword);
                // Sending the email
                string smtpServerAddress = WebConfigurationManager.AppSettings["SMTPServerAddress"];
                int smtpPort = Convert.ToInt32(WebConfigurationManager.AppSettings["SMTPServerPort"]);

                if (smtpPort > 0)
                {
                    smtpClient = new SmtpClient(smtpServerAddress, smtpPort);
                }
                else
                {
                    smtpClient = new SmtpClient(smtpServerAddress);
                }
                smtpClient.Credentials = networkCredential;
                smtpClient.EnableSsl = Convert.ToBoolean(WebConfigurationManager.AppSettings["SMTPEnableSSL"]);
                try
                {
                    smtpClient.Send(mailMessage);
                    isEmailSent = true;
                }
                catch (SmtpFailedRecipientException ex)
                {
                    throw ex;
                }
                catch (SmtpException ex)
                {
                    throw ex;
                }
                finally
                {
                    mailMessage = null;
                    smtpClient = null;
                    attachment = null;
                    regex = null;
                    match = null;
                }
            }

            return isEmailSent;
        }
    }
}