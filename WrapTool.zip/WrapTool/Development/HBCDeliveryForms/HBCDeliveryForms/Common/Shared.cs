﻿using HBCDeliveryForms.Models;
using iTextSharp.text;
using iTextSharp.text.html.simpleparser;
using iTextSharp.text.pdf;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using Microsoft.Office.Interop.Excel;
using System.Web.Configuration;

namespace HBCDeliveryForms.Common
{
    public class Shared
    {
        private WrapToolEntities db = new WrapToolEntities();

        public string GetBody(string FormName)
        {
            string body = "<html><head></head><body>Hi,<br><br>Please find the " + FormName + " Form.<br><br>Thanks</body></html> ";
            return body;
        }


        public string WriteToExcel(int Type, dynamic Object)
        {
            string DocPath = string.Empty;
            try
            {
                Microsoft.Office.Interop.Excel.Application xlApp = new Microsoft.Office.Interop.Excel.Application();
                Microsoft.Office.Interop.Excel.Workbook xlWorkBook;
                Microsoft.Office.Interop.Excel.Worksheet xlWorkSheet = new Microsoft.Office.Interop.Excel.Worksheet();
                xlApp = new Microsoft.Office.Interop.Excel.Application();
                if (Type == (int)Constant.Template.DamageClaim)
                {
                    xlWorkBook = xlApp.Workbooks.Open(HttpContext.Current.Server.MapPath(@"~/Html/DeliveryDamageClaim.xlsx"));
                    xlWorkSheet = xlWorkBook.Worksheets[1];
                    xlWorkSheet.Cells[8, 2].value = Object.DatePrepared;
                    xlWorkSheet.Cells[10, 2].value = Object.PreparedBy;
                    xlWorkSheet.Cells[12, 2].value = Object.DeliveryProvider;
                    xlWorkSheet.Cells[14, 2].value = Object.Order;
                    xlWorkSheet.Cells[16, 2].value = Object.CustomerName;
                    xlWorkSheet.Cells[17, 2].value = Object.DeliveryDate;
                    xlWorkSheet.Cells[19, 2].value = Object.Address;
                    xlWorkSheet.Cells[21, 2].value = Object.DayPhoneNo;
                    xlWorkSheet.Cells[22, 2].value = Object.EvePhoneNo;
                    xlWorkSheet.Cells[23, 2].value = Object.Cell;
                    xlWorkSheet.Cells[26, 1].value = Object.DamageReported;
                    string path = HttpContext.Current.Server.MapPath(@"~/PDF/DeliveryDamageClaim" + Guid.NewGuid() + ".xlsx");
                    xlWorkBook.SaveAs(path);
                    xlApp.Quit();
                    DocPath = path;
                    // CLEAN UP.
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkBook);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkSheet);
                }
                if (Type == (int)Constant.Template.SpecialDelivery)
                {
                    xlWorkBook = xlApp.Workbooks.Open(HttpContext.Current.Server.MapPath(@"~/Html/SpecialDelivery.xlsx"));
                    xlWorkSheet = xlWorkBook.Worksheets[1];
                    xlWorkSheet.Cells[2, 2].value = Object.DeliveryDate;
                    xlWorkSheet.Cells[2, 6].value = Object.RequestedBy;
                    xlWorkSheet.Cells[3, 2].value = Object.DeliveryTime;
                    xlWorkSheet.Cells[4, 2].value = Object.DeliveryOrder;
                    xlWorkSheet.Cells[4, 6].value = Object.HomePickUpOrder;
                    
                    OLEObjects OleItems = xlWorkSheet.OLEObjects();
                    ((OLEObject)OleItems.Item("TimeStop")).Object.value = Object.TimeStop;
                    ((OLEObject)OleItems.Item("SmallTruck")).Object.value = Object.SmallTruck;
                    ((OLEObject)OleItems.Item("FourManJob")).Object.value = Object.C4ManJob;
                    ((OLEObject)OleItems.Item("OutOfRoute")).Object.value = Object.OutOfRoute;
                    ((OLEObject)OleItems.Item("AddressChange")).Object.value = Object.AddressChange;
                    ((OLEObject)OleItems.Item("HookUp")).Object.value = Object.HookUp;
                    ((OLEObject)OleItems.Item("SalvageRemoval")).Object.value = Object.SalvageRemoval;
                    
                    xlWorkSheet.Cells[14, 2].value = Object.CustomerName;
                    xlWorkSheet.Cells[15, 2].value = Object.NewAddress;
                    xlWorkSheet.Cells[16, 2].value = Object.City;
                    xlWorkSheet.Cells[17, 2].value = Object.PostalCode;
                    xlWorkSheet.Cells[18, 2].value = Object.HomePhone;
                    xlWorkSheet.Cells[19, 2].value = Object.Business;
                    xlWorkSheet.Cells[20, 2].value = Object.CellPhone;
                    xlWorkSheet.Cells[22, 2].value = Object.OldAddress;
                    xlWorkSheet.Cells[23, 2].value = Object.OldCity;
                    xlWorkSheet.Cells[24, 2].value = Object.OldPostalCode;
                    xlWorkSheet.Cells[26, 1].value = Object.DeliveryInfo;
                    int ReasonId = Object.ReasonId;
                    ReasonMaster Reason = db.ReasonMasters.Where(r => r.ReasonId == ReasonId).FirstOrDefault();
                    xlWorkSheet.Cells[6, 4].value = Reason.Reason;
                    string path = HttpContext.Current.Server.MapPath(@"~/PDF/SpecialDelivery" + Guid.NewGuid() + ".xlsx");
                    xlWorkBook.SaveAs(path);
                    xlApp.Quit();
                    DocPath = path;
                    // CLEAN UP.
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkBook);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkSheet);
                }
                if (Type == (int)Constant.Template.Delivery)
                {
                    xlWorkBook = xlApp.Workbooks.Open(HttpContext.Current.Server.MapPath(@"~/Html/MHFDeliveryOrder.xlsx"));
                    xlWorkSheet = xlWorkBook.Worksheets[1];
                    xlWorkSheet.Cells[2, 2].value = Object.DeliveryDate;
                    xlWorkSheet.Cells[2, 6].value = Object.RequestedBy;
                    xlWorkSheet.Cells[3, 2].value = Object.DeliveryTime;
                    xlWorkSheet.Cells[4, 2].value = Object.Banner;
                    xlWorkSheet.Cells[42, 2].value = Object.CustomerName;
                    xlWorkSheet.Cells[56, 1].value = Object.CustomerName;
                    xlWorkSheet.Cells[43, 2].value = Object.Address;
                    xlWorkSheet.Cells[44, 2].value = Object.City;
                    xlWorkSheet.Cells[45, 2].value = Object.PostalCode;
                    xlWorkSheet.Cells[42, 4].value = Object.HomePhone;
                    xlWorkSheet.Cells[43, 4].value = Object.Business;
                    xlWorkSheet.Cells[44, 4].value = Object.CellPhone;
                    xlWorkSheet.Cells[47, 1].value = Object.DeliveryInfo;
                    xlWorkSheet.Cells[50, 3].value = Object.BeddingPlaced;
                    xlWorkSheet.Cells[51, 3].value = Object.PedestalAttched;
                    xlWorkSheet.Cells[52, 3].value = Object.ApplianceLeveled;
                    xlWorkSheet.Cells[53, 3].value = Object.WasherLeakTested;
                    xlWorkSheet.Cells[54, 3].value = Object.RemovedPackaging;
                    int ReasonId = Object.M_ReasonId;
                    ManualReasonMaster Reason = db.ManualReasonMasters.Where(r => r.M_ReasonId == ReasonId).FirstOrDefault();
                    xlWorkSheet.Cells[48, 2].value = Reason.M_Reason;

                    int a = 7;
                    for (int i = 0; i < Object.DeliveryOrdLst.Count; i++)
                    {
                        if (a <= 16)
                        {
                            xlWorkSheet.Cells[a, 1].value = Object.DeliveryOrdLst[i].DeliveryOrder;
                            xlWorkSheet.Cells[a, 2].value = Object.DeliveryOrdLst[i].SkuDescription;
                            xlWorkSheet.Cells[a, 4].value = Object.DeliveryOrdLst[i].Quantity;
                            xlWorkSheet.Cells[a, 5].value = Object.DeliveryOrdLst[i].ProductStatus;
                            xlWorkSheet.Cells[a, 6].value = Object.DeliveryOrdLst[i].MerchandiseLocation;
                        }
                        a++;
                    }

                    int b = 19;
                    for (int i = 0; i < Object.HomepickupList.Count; i++)
                    {
                        if(b <= 28)
                        {
                            xlWorkSheet.Cells[b, 1].value = Object.HomepickupList[i].HomePickupOrder;
                            xlWorkSheet.Cells[b, 2].value = Object.HomepickupList[i].SkuDescription;
                            xlWorkSheet.Cells[b, 4].value = Object.HomepickupList[i].Quantity;
                            xlWorkSheet.Cells[b, 5].value = Object.HomepickupList[i].RMA;
                        }
                        b++;
                    }

                    int c = 31;
                    for (int i = 0; i < Object.PurchasedList.Count; i++)
                    {
                        if (c <= 40)
                        {
                            xlWorkSheet.Cells[c, 1].value = Object.PurchasedList[i].SalvagePurchased;
                            xlWorkSheet.Cells[c, 2].value = Object.PurchasedList[i].BeddingorAppliance;
                            xlWorkSheet.Cells[c, 4].value = Object.PurchasedList[i].Quantity;
                        }
                        c++;
                    }
                    string path = HttpContext.Current.Server.MapPath(@"~/PDF/MHFDeliveryOrder" + Guid.NewGuid() + ".xlsx");
                    xlWorkBook.SaveAs(path);
                    xlApp.Quit();
                    DocPath = path;
                    // CLEAN UP.
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(xlApp);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkBook);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(xlWorkSheet);
                }
            }
            catch (Exception ex)
            {
            }
            return DocPath;
        }

        public void ClearFolder()
        {
            try
            {
                DirectoryInfo dir = new DirectoryInfo((HttpContext.Current.Server.MapPath(@"~/PDF/")));
                foreach (FileInfo fi in dir.GetFiles())
                {
                    fi.IsReadOnly = false;
                    fi.Delete();
                }
            }
            catch(Exception ex)
            {
            }
            
        }

    }
}