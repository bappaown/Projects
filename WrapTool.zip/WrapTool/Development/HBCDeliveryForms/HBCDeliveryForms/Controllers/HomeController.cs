﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using H3GS.Web.Security;
using HBCDeliveryForms.Models;
using HBCDeliveryForms.Filter;
using System.Web.Configuration;
using System.Configuration;
using HBCDeliveryForms.Common;

namespace HBCDeliveryForms.Controllers
{
    [CustomException]
    public class HomeController : Controller
    {
        private WrapToolEntities db = new WrapToolEntities();

        [Authentication]
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult GetLogin()
        {
            try
            {
                Employee objEmp = new Employee();
                H3GS.Web.Security.PassportAuthentication.SignIn();
                objEmp.EmployeeId = PassportIdentity.Current.Employee.EmployeeId;
                objEmp.FirstName = PassportIdentity.Current.Employee.FirstName;
                objEmp.LastName = PassportIdentity.Current.Employee.LastName;
                objEmp.FullName = PassportIdentity.Current.Employee.FullName;
                objEmp.DepartmentId = Convert.ToInt32(PassportIdentity.Current.Employee.DepartmentId);
                objEmp.CostCenterId = Convert.ToInt32(PassportIdentity.Current.Employee.CostCentreId);
                System.Web.HttpContext.Current.Session["User"] = objEmp;

                //Check User Role
                var UserRole = db.UserRoles.Where(u => u.EmployeeId == objEmp.EmployeeId).FirstOrDefault();
                if (UserRole != null)
                {
                    var Roles = db.RoleMasters.Where(r => r.RoleId == UserRole.RoleId).FirstOrDefault();
                    System.Web.HttpContext.Current.Session["Role"] = Roles.Role;
                }
            }
            catch (Exception ex)
            {

            }
            return View("Index");
        }

        public ActionResult Login()
        {
            string URL = string.Empty;
            if (WebConfigurationManager.AppSettings["AuthenticationMode"].ToString().ToLower() == "passport")
            {
                URL = WebConfigurationManager.AppSettings["CAEGLink"].ToString();
            }
            else if (WebConfigurationManager.AppSettings["AuthenticationMode"].ToString().ToLower() == "form")
            {
                URL = WebConfigurationManager.AppSettings["LoginLink"].ToString().ToLower();
            }
            return Redirect(URL);
        }

        public ActionResult Logout()
        {
            System.Web.HttpContext.Current.Session.Clear();
            System.Web.HttpContext.Current.Session.Abandon();
            HttpCookie myCookie = new HttpCookie(".ASDPASSAUTH");
            myCookie.Expires = DateTime.Now.AddDays(-1);
            Response.Cookies.Add(myCookie);
            return View();
        }

    }
}