﻿using ClosedXML.Excel;
using HBCDeliveryForms.Common;
using HBCDeliveryForms.Filter;
using HBCDeliveryForms.Models;
using OfficeOpenXml;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace HBCDeliveryForms.Controllers
{
    [Authentication]
    [CustomException]
    [CustomAuthorize(Roles = "Admin")]
    public class ReportController : Controller
    {
        private WrapToolEntities db = new WrapToolEntities();

        // GET: Report
        public ActionResult Index()
        {
            FormReport Report = GetReportObject();
            return View(Report);
        }

        private FormReport GetReportObject()
        {
            FormReport Report = new FormReport();
            Report.FromDate = new DateTime(DateTime.Now.Year, DateTime.Now.Month, 1).Date;
            Report.ToDate = DateTime.Now.Date;
            return Report;
        }

        [HttpPost]
        public ActionResult Index(FormReport formtype, FormCollection collection)
        {
            string buttonName = collection["Submitbtn"].ToString();
            int FormId = formtype.FormId;
            string sysFormat = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
            if (sysFormat == "dd-MM-yyyy")
            {
                formtype.FromDate = Convert.ToDateTime(collection["FromDate"].Split('-')[1] + "-" + collection["FromDate"].Split('-')[0] + "-" + collection["FromDate"].Split('-')[2]);
                formtype.ToDate = Convert.ToDateTime(collection["ToDate"].Split('-')[1] + "-" + collection["ToDate"].Split('-')[0] + "-" + collection["ToDate"].Split('-')[2]);
            }
            if (sysFormat == "yyyy-MM-dd")
            {
                formtype.FromDate = Convert.ToDateTime(collection["FromDate"].Split('-')[1] + "-" + collection["FromDate"].Split('-')[2] + "-" + collection["FromDate"].Split('-')[0]);
                formtype.ToDate = Convert.ToDateTime(collection["ToDate"].Split('-')[1] + "-" + collection["ToDate"].Split('-')[2] + "-" + collection["ToDate"].Split('-')[0]);
            }
            ModelState.Clear();
            TryValidateModel(formtype);

            try
            {
                List<GetFormWiseReport_Result> LstReportResult = db.GetFormWiseReport(formtype.FormId, formtype.FromDate, formtype.ToDate).ToList();
                if (buttonName == "Submit")
                {
                    ViewBag.LstResult = LstReportResult;
                }
                else
                {
                    ViewBag.LstResult = LstReportResult;
                    //LstReportResult = db.GetFormWiseReport(formtype.FormId, formtype.FromDate, formtype.ToDate).ToList();
                    DataTable dt = ToDataTable(LstReportResult);
                    if (dt != null && dt.Rows.Count > 0)
                    {
                        string File = "Report" + "_" + Guid.NewGuid() + ".xls";
                        Response.Clear();
                        Response.Buffer = true;
                        Response.AddHeader("content-disposition", "attachment;filename=" + File);
                        Response.Charset = "";
                        Response.ContentType = "application/vnd.ms-excel";
                        StringWriter sw = new StringWriter();
                        HtmlTextWriter hw = new HtmlTextWriter(sw);
                        DataGrid dgGrid = new DataGrid();
                        dgGrid.DataSource = dt;
                        dgGrid.DataBind();
                        dgGrid.RenderControl(hw);
                        Response.Write(sw.ToString());
                        Response.End();
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return View(formtype);
        }


        public static DataTable ToDataTable<T>(List<T> items)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);
            //Get all the properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name);
            }
            foreach (T item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }
    }
}