﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Data.Entity.Core.Objects;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using HBCDeliveryForms.Models;

namespace HBCDeliveryForms.Controllers
{
    public class EmailController : Controller
    {
        EmailContext db = new EmailContext();
        //EmailViewModel[] emailModelArray = null;

        public EmailViewModel[] EmailData = new EmailViewModel[1]; //{ get; set; }

        // GET: Email
        public ActionResult Index()
        {
            EmailViewModel model = new EmailViewModel();
            model.FormId = 1;
            model.FormType = "SDA";
            DataSet result = db.GetAllEmailDetails(model);
            DataTable dataTable = result.Tables[0];
            
            List<EmailViewModel> emailData = new List<EmailViewModel>();
            foreach (DataRow item in dataTable.Rows)
            {
                EmailViewModel emailViewModel = new EmailViewModel();
                emailViewModel.FormId = Convert.ToInt32(item.ItemArray[1].ToString());
                emailViewModel.FormType = item.ItemArray[2].ToString();
                emailViewModel.ToEmail = item.ItemArray[3].ToString();
                emailViewModel.CCEmail = item.ItemArray[4].ToString();
                emailViewModel.BCCEmail = item.ItemArray[5].ToString();
                emailViewModel.IsActive = Convert.ToInt32(item.ItemArray[6].ToString()) == 0 ? false : true;
                emailViewModel.CreatedDate = (DateTime)(item.ItemArray[7]);
                emailViewModel.CreatedBy = Convert.ToInt32(item.ItemArray[8].ToString());
                emailViewModel.ModifiedDate = (DateTime)(item.ItemArray[9]);
                emailViewModel.ModifiedBy = Convert.ToInt32(item.ItemArray[10].ToString());
                emailData.Add(emailViewModel);
            }
            ViewBag.EmailList = emailData;
            return View();
        }

        // GET: Email/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: Email/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Email/Create
        [HttpPost]
        public ActionResult Create(FormCollection collection)
        {
            try
            {
                // TODO: Add insert logic here
                string[] formTypes = collection["FormType"].Split(',');
                string[] toEmails = collection["ToEmail"].Split(',');
                string[] ccEmails = collection["CCEmail"].Split(',');
                string[] bccEmails = collection["BCCEmail"].Split(',');
                string[] strIsActive = collection["IsActive"].Split(',');

                for(int i=0; i<formTypes.Length; i++)
                {
                    EmailViewModel emailViewModel = new EmailViewModel();
                    //emailViewModel.FormId = Convert.ToInt32(collection["lblFormId1"].ToString());
                    emailViewModel.FormType = formTypes[i].ToString();
                    emailViewModel.ToEmail = toEmails[i].ToString();
                    emailViewModel.CCEmail = ccEmails[i].ToString();
                    emailViewModel.BCCEmail = bccEmails[i].ToString();
                    bool isActive = false;
                    if (strIsActive[i*2].ToString().StartsWith("true"))
                    {
                        isActive = true;
                    }
                    emailViewModel.IsActive = isActive;
                    emailViewModel.ModifiedDate = DateTime.Now;
                    emailViewModel.ModifiedBy = ((Employee)System.Web.HttpContext.Current.Session["User"]).EmployeeId;

                    int result = db.UpdateEmailDetails(emailViewModel);
                }
                
                //EmailViewModel emailViewModel = new EmailViewModel();
                ////emailViewModel.FormId = Convert.ToInt32(collection["lblFormId1"].ToString());
                //emailViewModel.FormType = collection["FormType"].ToString();
                //emailViewModel.ToEmail = collection["ToEmail"].ToString();
                //emailViewModel.CCEmail = collection["CCEmail"].ToString();
                //emailViewModel.BCCEmail = collection["BCCEmail"].ToString();
                //bool isActive = false;
                //if(collection["IsActive"].ToString().StartsWith("true"))
                //{
                //    isActive = true;
                //}
                //emailViewModel.IsActive = isActive;
                //emailViewModel.ModifiedDate = DateTime.Now;
                //emailViewModel.ModifiedBy = ((Employee)System.Web.HttpContext.Current.Session["User"]).EmployeeId;

                //DataSet result = db.UpdateEmailDetails(emailViewModel);

                return RedirectToAction("Index");
            }
            catch(Exception ex)
            {
                ViewBag.TempMessage = "There was an error processing your request.";
                
            }
            return View();
        }

        // GET: Email/Edit/5
        public ActionResult Edit(int id)
        {
            try
            {
                // TODO: Add insert logic here
                DataSet result = db.GetEmailDetails(id);
                DataTable dataTable = result.Tables[0];
                EmailViewModel emailViewModel = new EmailViewModel();
                if (dataTable.Rows.Count > 0)
                {
                    DataRow item = dataTable.Rows[0];

                    emailViewModel.FormId = Convert.ToInt32(item.ItemArray[1].ToString());
                    emailViewModel.FormType = item.ItemArray[2].ToString();
                    emailViewModel.ToEmail = item.ItemArray[3].ToString();
                    emailViewModel.CCEmail = item.ItemArray[4].ToString();
                    emailViewModel.BCCEmail = item.ItemArray[5].ToString();
                    emailViewModel.IsActive = Convert.ToInt32(item.ItemArray[6].ToString()) == 0 ? false : true;
                    emailViewModel.CreatedDate = (DateTime)(item.ItemArray[7]);
                    emailViewModel.CreatedBy = Convert.ToInt32(item.ItemArray[8].ToString());
                    emailViewModel.ModifiedDate = (DateTime)(item.ItemArray[9]);
                    emailViewModel.ModifiedBy = Convert.ToInt32(item.ItemArray[10].ToString());
                }
                
                ViewBag.EmailDetails = emailViewModel;
                return View(emailViewModel);
               
            }
            catch (Exception ex)
            {
                ViewBag.TempMessage = "There was an error processing your request.";
                //return View();
            }
            return View();
        }

        // POST: Email/Edit/5
        [HttpPost]
        public ActionResult Edit(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add update logic here
                EmailViewModel emailViewModel = new EmailViewModel();
                if (collection.Count > 0)
                {
                    emailViewModel.FormId = id; 
                    emailViewModel.FormType = collection["FormType"].ToString();
                    emailViewModel.ToEmail = collection["ToEmail"].ToString();
                    emailViewModel.CCEmail = collection["CCEmail"].ToString();
                    emailViewModel.BCCEmail = collection["BCCEmail"].ToString();
                    emailViewModel.IsActive = collection["IsActive"].ToString().StartsWith("true") ? true : false;
                    emailViewModel.ModifiedDate = DateTime.Now;
                    emailViewModel.ModifiedBy = ((Employee)System.Web.HttpContext.Current.Session["User"]).EmployeeId;
                }
                ViewBag.EmailDetails = emailViewModel;
                db.UpdateEmailDetails(emailViewModel);
                //return View(emailViewModel);
                return RedirectToAction("Index");

            }
            catch
            {
                ViewBag.TempMessage = "There was an error processing your request.";
            }
            return View("Index");
        }

        // GET: Email/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: Email/Delete/5
        [HttpPost]
        public ActionResult Delete(int id, FormCollection collection)
        {
            try
            {
                // TODO: Add delete logic here

                return RedirectToAction("Index");
            }
            catch
            {
                return View();
            }
        }
    }
}
