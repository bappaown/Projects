﻿using ExcelDataReader;
using HBCDeliveryForms.Filter;
using HBCDeliveryForms.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Validation;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;


namespace HBCDeliveryForms.Controllers
{
    [Authentication]
    [CustomException]
    [CustomAuthorize(Roles = "Admin")]
    public class UploadController : Controller
    {

        // GET: Upload
        public ActionResult Index()
        {
            List<SelectListItem> LocationList = GetLocations();
            ViewBag.locations = LocationList;
            var model = new List<EmailMaster>();
            model = GetEmailList();
            return View(model);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Index(HttpPostedFileBase upload, FormCollection frm)
        {
            string button = frm["btn1"].ToString();

            string newmail = frm["newemailid"].ToString().Trim().Count() > 0 ? frm["newemailid"].ToString() : "";
            string newlocation = frm["newlocation"].ToString().Trim().Count() > 0 ? frm["newlocation"].ToString() : "";
            string ddllocation = frm["hdnddllocations"].ToString().Trim().Count() > 0 ? frm["hdnddllocations"].ToString() : "";
            string locationId = frm["hdnlocationId"].ToString().Trim().Count() > 0 ? frm["hdnlocationId"].ToString() : "";
            string hdnItemId = frm["hdnItemId"].ToString().Trim().Count() > 0 ? frm["hdnItemId"].ToString() : "";
            
            if (ModelState.IsValid)
            {
                if (!string.IsNullOrWhiteSpace(newlocation) && !string.IsNullOrWhiteSpace(ddllocation))
                {
                    SetErrorMessage("You can only add either New location or Existing location");
                }
                else
                {
                    
                    List<SelectListItem> LocationList = GetLocations();
                    ViewBag.locations = LocationList;

                    if (button == "Upload")
                    {
                        if (upload != null && upload.ContentLength > 0)
                        {
                            #region new file upload

                            Stream stream = upload.InputStream;

                            IExcelDataReader reader = null;

                            if (upload.FileName.EndsWith(".xls"))
                            {
                                reader = ExcelReaderFactory.CreateBinaryReader(stream);
                            }
                            else if (upload.FileName.EndsWith(".xlsx"))
                            {
                                reader = ExcelReaderFactory.CreateOpenXmlReader(stream);
                            }
                            else
                            {
                                SetErrorMessage("This file format is not supported");
                                //return View();
                                return RedirectToAction("Index");
                            }

                            var result = reader.AsDataSet(new ExcelDataSetConfiguration()
                            {
                                ConfigureDataTable = (_) => new ExcelDataTableConfiguration()
                                {
                                    UseHeaderRow = true
                                }
                            });

                            reader.Close();
                            DataTable filtereddata = ProcessData(result.Tables[0]);
                            List<EmailMaster> list = CastIntoObject(filtereddata);
                            if(list.Count > 0)
                            {
                                bool isSuccessful = BulkSave(list);
                                if (isSuccessful) // pass data from database to view instead of filterdata
                                {
                                    SetMessage("Data inserted Successfully");
                                    return View(GetEmailList());
                                }
                                else
                                {
                                    SetErrorMessage("Something went wrong");
                                }
                            }
                            else
                            {
                                SetErrorMessage("Please choose correct file to upload data");
                            }
                        }
                        else
                        {
                            SetErrorMessage("Please Upload Your file");
                        }
                        #endregion
                    }
                    else
                    {

                        #region new location email update 
                        if (frm["newemailid"] == "" && frm["newlocation"] == "")
                        {
                            SetErrorMessage("Please fill Data to proceed.");
                        }
                        else
                        {
                            bool isok = false;
                            //if (locationId != "0" && newmail != "" && ddllocation != "")

                            if (newmail != "" && ddllocation != "" && hdnItemId == "" )
                            {
                                // if there is value in new mail and locationdropdown and new location id is 0
                                // insert in email master
                                isok = InsertnewEmailId(newmail, ddllocation);

                            }
                            else if (newlocation != "" && newmail != "")
                            {
                                // if new location and new mail is 
                                // insert in location master and email master
                                isok = InsertnewLocation(newlocation);
                                isok = InsertnewEmailId(newmail, newlocation);

                            }
                            else if (locationId != "0" && newmail != "")
                            {
                                // if location id is not zero update email master table
                                isok = UpdateEmailId(locationId, newmail, hdnItemId);
                            }
                            else if (newlocation != "")
                            {
                                // insert in location master
                                isok = InsertnewLocation(newlocation);

                            }
                            else
                            {
                                SetErrorMessage(" Something Went Wrong");

                            }
                        }
                        #endregion
                    }
                }
               
            }
            //return View(GetEmailList());
            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Reset(HttpPostedFileBase upload, FormCollection frm)
        {
            try
            { 
                if (ModelState.IsValid)
                {
                    return RedirectToAction("Index");
                }
            }catch(Exception ex)
            {

            }
            return View("Index");
        }


        public ActionResult Delete(int Id)
        {
            using (var _WTEntities = new WrapToolEntities())
            {
                EmailMaster _mailmaster = _WTEntities.EmailMasters.SingleOrDefault(b => b.Id == Id);
                if (_mailmaster != null)
                {
                    _mailmaster.IsActive = false;
                    _WTEntities.Entry(_mailmaster).State = EntityState.Modified;
                    _WTEntities.SaveChanges();
                    SetMessage("Record deleted successfully.");
                }
            }
            return RedirectToAction("Index");
        }


        public ActionResult DownloadFile()
        {
            string path = AppDomain.CurrentDomain.BaseDirectory + "Html/";
            byte[] fileBytes = System.IO.File.ReadAllBytes(path + "Sample.xlsx");
            string fileName = "Sample.xlsx";
            return File(fileBytes, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }




        #region private methods

        private bool InsertnewLocation(string newlocation)
        {
            bool issuccess = false;
            //  insert in location master
            using (var _WTEntities = new WrapToolEntities())
            {

                LocationMaster _newlocation = new LocationMaster();
                _newlocation.Location = newlocation.ToString();
                _WTEntities.LocationMasters.Add(_newlocation);
                try
                {
                    _WTEntities.SaveChanges();
                    issuccess = true;
                    //  ModelState.AddModelError("File", "New Location inserted");
                    SetMessage("New Location inserted Successfully");
                }
                catch (DbEntityValidationException dbEx)
                {

                }

            }
            return issuccess;
        }

        private bool InsertnewEmailId(string newmail, string ddllocation)
        {
            bool issuccess = false;
            // insert in email master
            using (var _WTEntities = new WrapToolEntities())
            {

                EmailMaster _newemail = new EmailMaster();
                _newemail.EmailId = newmail.ToString();
                _newemail.LocationId = GetLocationId(ddllocation.Trim().ToString());
                _newemail.IsActive = true;
                _WTEntities.EmailMasters.Add(_newemail);
                try
                {
                    _WTEntities.SaveChanges();
                    issuccess = true;
                    SetMessage("New Email Address inserted Successfully.");
                }
                catch (DbEntityValidationException dbEx)
                {

                }
            }
            // insert in email master


            return issuccess;
        }

        private bool UpdateEmailId(string locationId, string newmail,string ItemId)
        {
            bool issuccess = false;
            // update email master table
            using (var _WTEntities = new WrapToolEntities())
            {
                int locId = 0;
                if(!string.IsNullOrWhiteSpace(locationId))
                {
                    locId = Convert.ToInt32(locationId.Trim());
                }
                
                int item = Convert.ToInt32(ItemId.Trim());
                //EmailMaster _mailmaster = _WTEntities.EmailMasters.SingleOrDefault(b => b.Id == locId);
                EmailMaster _mailmaster = _WTEntities.EmailMasters.SingleOrDefault(b => b.Id == item);
                if (_mailmaster != null)
                {
                    _mailmaster.EmailId = newmail;
                    if(locId > 0)
                    {
                        _mailmaster.LocationId = locId;
                    }                    
                    _WTEntities.Entry(_mailmaster).State = EntityState.Modified;
                    _WTEntities.SaveChanges();
                    issuccess = true;
                    SetMessage("Email Address Updated Successfully.");
                }
            }
            return issuccess;
        }
        public bool CheckDuplicateRecords(IEnumerable<EmailMaster> _listToBeinserted, IEnumerable<EmailMaster> _listOfExiting)
        {

            var newItems = _listToBeinserted.Except(_listOfExiting).ToList();
            if (newItems.Count < 0)
                return true;
            else
            {
                SetMessage("File has duplicate records"); return false;
            }
        }


        private bool BulkSave(IEnumerable<EmailMaster> _listToBeinserted)
        {
            bool issaved = false;
            IEnumerable<EmailMaster> _listOfExiting = GetEmailList();


            //   var hasduplicate = _listToBeinserted.Count() == _listOfExiting.Count() &&_listToBeinserted.Except(_listOfExiting).Any();
            bool hasduplicate = CheckDuplicateRecords(_listToBeinserted.Select(x => new EmailMaster { LocationId = x.LocationId, EmailId = x.EmailId }), _listOfExiting.Select(x => new EmailMaster { LocationId = x.LocationId, EmailId = x.EmailId }));

            if (!hasduplicate)
            {

                using (var _WTEntities = new WrapToolEntities())
                {
                    foreach (var item in _listToBeinserted)
                    {
                        EmailMaster _mailmaster1 = new EmailMaster();

                        _mailmaster1.EmailId = item.EmailId;
                        _mailmaster1.LocationId = item.LocationId;
                        _mailmaster1.IsActive = true;
                        _WTEntities.EmailMasters.Add(_mailmaster1);
                    }
                    try
                    {
                        _WTEntities.SaveChanges();
                        issaved = true;

                    }
                    catch (DbEntityValidationException dbEx)
                    {
                    }
                }
            }
            else
            {
                // has duplicate records
            }

            return issaved;

        }

        private List<EmailMaster> CastIntoObject(DataTable dt)
        {

            var convertedList = (from rw in dt.AsEnumerable()
                                 select new EmailMaster()
                                 {
                                     LocationId = Convert.ToInt32(rw[0]),
                                     EmailId = Convert.ToString(rw[2])
                                 }).ToList();

            return convertedList;
        }

        private DataTable ProcessData(DataTable table)
        {
            // keeping 2 col
            foreach (var column in table.Columns.Cast<DataColumn>().ToArray())
            {
                if (column.Caption.ToLower().Contains("PROVINCE & RESOURCE POOL".ToLower()) || column.Caption.ToLower() == "EMAIL ADDRESS".ToLower()) continue;
                else table.Columns.Remove(column);
            }
            table.AcceptChanges();
            var rowsToDelete = new List<DataRow>();
            if (!table.Columns.Contains("PROVINCE & RESOURCE POOL"))
            {
                foreach (DataRow dr in table.Rows)
                {
                    rowsToDelete.Add(dr);
                }
            }
            rowsToDelete.ForEach( d => table.Rows.Remove(d));
            table.AcceptChanges();
            // filling values in location
            for (int h = 0; h < table.Rows.Count; h++)
            {
                if (table.Rows[h].IsNull(0) == true)
                {
                    table.Rows[h][0] = table.Rows[h - 1][0].ToString();
                    // adding new row and splitting location name stating with number
                }
            }
            table.AcceptChanges();
            // deleting null
            for (int h = 0; h < table.Rows.Count; h++)
            {

                if (table.Rows[h][1] == System.DBNull.Value || table.Rows[h][1].ToString() == "" || table.Rows[h][1] == null || table.Rows[h][1].ToString().Contains("-"))
                {
                    table.Rows.Remove(table.Rows[h]);
                }

            }
            table.AcceptChanges();
            for (int h = 0; h < table.Rows.Count; h++)
            {

                if (table.Rows[h][1] == System.DBNull.Value || table.Rows[h][1].ToString() == " " || table.Rows[h][1] == null || table.Rows[h][1].ToString().Contains("-"))
                {
                    table.Rows.Remove(table.Rows[h]);
                }

            }
            table.AcceptChanges();
            var x = table.AsEnumerable();
            DataTable dt = new DataTable();
            dt.Columns.Add("LocationId", typeof(int));
            dt.Columns.Add("Location", typeof(string));
            dt.Columns.Add("Email", typeof(string));

            foreach (var a in x)
            {
                dt.Rows.Add(GetLocationId(a.ItemArray[0].ToString()), a.ItemArray[0].ToString(), a.ItemArray[1].ToString());
            }


            return dt;

        }
        private void SetMessage(string message)
        {
            List<string> messages = TempData["Messages"] as List<string> ?? new List<string>();
            messages.Add(message);
            TempData["Messages"] = messages[0];
        }
        private void SetErrorMessage(string errorMessage)
        {
            List<string> messages = TempData["ErrorMessages"] as List<string> ?? new List<string>();
            messages.Add(errorMessage);
            TempData["ErrorMessages"] = messages[0];
        }

        // get Locationid And fill datatable_with_that_id
        private int GetLocationId(string LocationName)
        {

            using (var _WTEntities = new WrapToolEntities())
            {
                int ret = 0;
                var result = _WTEntities.proc_GetLocationId(LocationName.TrimEnd().ToUpper()).ToList();
                foreach (var cs in result)
                {
                    Console.WriteLine("Course Name: {0}", cs.LName);
                    Console.WriteLine("Course Name: {0}", cs.ID);
                    ret = cs.ID;
                }
                return ret;
            }


        }

        private static List<SelectListItem> GetLocations()
        {
            using (var _WTEntities = new WrapToolEntities())
            {
                List<SelectListItem> locationList = (from p in _WTEntities.LocationMasters.AsEnumerable()
                                                     select new SelectListItem
                                                     {
                                                         Text = p.Location,
                                                         Value = p.LocationId.ToString()
                                                     }).ToList();


                //Add Default Item at First Position.
                locationList.Insert(0, new SelectListItem { Text = "--Select --", Value = "" });
                return locationList;
            }
        }

        private static List<EmailMaster> GetEmailList()
        {
            using (var _WTEntities = new WrapToolEntities())
            {
                List<EmailMaster> EmailList = (from p in _WTEntities.EmailMasters.AsEnumerable().Where(l => l.IsActive == true)
                                               select new EmailMaster
                                               {
                                                   Id = p.Id,
                                                   EmailId = p.EmailId,
                                                   LocationId = p.LocationId,
                                                   LocationName = GetLocationNamebyId(p.LocationId)
                                               }).ToList();
                return EmailList;
            }

        }
        private static string GetLocationNamebyId(int? LocationId)
        {
            string locationname = "NA";
            if (LocationId != null && LocationId != 0)
            {
                using (var _WTEntities = new WrapToolEntities())
                {
                    locationname = _WTEntities.LocationMasters.AsEnumerable().Where(c => c.LocationId == LocationId).Select(x => x.Location).First();
                    return locationname;
                }
            }
            return locationname;
        }


        #endregion
    }
}