﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using HBCDeliveryForms.Models;

namespace HBCDeliveryForms.Controllers
{
    public class LoginController : Controller
    {
        private WrapToolEntities db = new WrapToolEntities();

        // GET: Login
        public ActionResult Index()
        {
            ViewBag.ErrorMessage = (TempData["error"] == null) ? "" : TempData["error"].ToString();

            return View();
        }

        public ActionResult Submit(FormCollection collection)
        {
            try
            {
                //Authenticate User
                EmailContext context = new EmailContext();
                string userid = collection["userid"];
                string password = collection["password"];
                DataSet dsEmp = context.GetAuthenticate(userid, password);

                if (dsEmp.Tables[0].Rows.Count > 0)
                {
                    Employee objEmp = new Employee();
                    objEmp.EmployeeId = Convert.ToInt32(dsEmp.Tables[0].Rows[0]["EmployeeId"].ToString());
                    objEmp.FirstName = dsEmp.Tables[0].Rows[0]["FirstName"].ToString();
                    objEmp.LastName = dsEmp.Tables[0].Rows[0]["LastName"].ToString();
                    objEmp.FullName = dsEmp.Tables[0].Rows[0]["FullName"].ToString();
                    objEmp.DepartmentId = Convert.ToInt32(dsEmp.Tables[0].Rows[0]["DepartmentId"].ToString());
                    objEmp.CostCenterId = Convert.ToInt32(dsEmp.Tables[0].Rows[0]["CostCenterId"].ToString());
                    System.Web.HttpContext.Current.Session["User"] = objEmp;

                    //Check User Role
                    var UserRole = db.UserRoles.Where(u => u.EmployeeId == objEmp.EmployeeId).FirstOrDefault();
                    if (UserRole != null)
                    {
                        var Roles = db.RoleMasters.Where(r => r.RoleId == UserRole.RoleId).FirstOrDefault();
                        System.Web.HttpContext.Current.Session["Role"] = Roles.Role;
                    }

                    return RedirectToAction("Index", "Home");
                }
            }
            catch (Exception ex)
            {

            }

            TempData["error"] = "Invalid userid or password.";

            return RedirectToAction("Index");
        }
    }
}