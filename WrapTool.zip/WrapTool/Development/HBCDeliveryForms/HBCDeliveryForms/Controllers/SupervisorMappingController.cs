﻿using HBCDeliveryForms.Common;
using HBCDeliveryForms.Filter;
using HBCDeliveryForms.Models;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HBCDeliveryForms.Controllers
{
    [Authentication]
    [CustomException]
    [CustomAuthorize(Roles = "Admin")]
    public class SupervisorMappingController : Controller
    {
        private WrapToolEntities db = new WrapToolEntities();

        // GET: SupervisorMapping
        public ActionResult Index()
        {
            try
            {
                ViewBag.EmployeeList = db.GetAdvisorList();
                var SupervisorMappingList = from s in db.SupervisorMappings
                                            join e in db.Central_Employee_Main
                                            on s.EmpoyeeId equals e.EmployeeID
                                            where s.isActive == true
                                            select new Supervisor { ID = s.ID, FirstName = e.FirstName, LastName = e.LastName, EmployeeID = e.EmployeeID };
                List<Supervisor> objList = SupervisorMappingList.ToList();
                ViewBag.SupervisorMappingList = objList;
            }
            catch (Exception ex)
            {
            }

            return View();
        }

        [HttpPost]
        public ActionResult Create(SupervisorMapping Mapping, int reset = 0)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    if(reset > 0)
                    {
                        return Reset(Mapping);
                    }

                    SupervisorMapping ExistingMapping = db.SupervisorMappings.Where(s => s.EmpoyeeId == Mapping.EmpoyeeId && s.isActive == true).FirstOrDefault();
                    if (ExistingMapping == null)
                    {
                        Mapping.isActive = true;
                        Mapping.CreatedDate = DateTime.Now;
                        db.SupervisorMappings.Add(Mapping);
                        db.SaveChanges();
                        TempData["Message"] = "User is Successfully Mapped!!!";
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        TempData["Message"] = "User is Already Mapped!!!";
                        return RedirectToAction("Index");
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return View("Index");
        }

        [HttpPost]
        public ActionResult Reset(SupervisorMapping Mapping)
        {
            try
            {
                if (ModelState.IsValid)
                {
                        return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
            }
            return View("Index");
        }

        public ActionResult Edit(int id)
        {
            SupervisorMapping Mapping = new SupervisorMapping();
            try
            {
                Mapping = db.SupervisorMappings.Where(s => s.ID == id).FirstOrDefault();
                ViewBag.EmployeeList = db.GetAdvisorList();
            }
            catch (Exception ex)
            {
            }
            return View(Mapping);
        }


        [HttpPost]
        public ActionResult Update(SupervisorMapping Mapping)
        {
            SupervisorMapping objMapping = new SupervisorMapping();
            try
            {
                if (ModelState.IsValid)
                {
                    objMapping = db.SupervisorMappings.Where(s => s.ID == Mapping.ID).FirstOrDefault();
                    objMapping.ModifiedDate = DateTime.Now;
                    objMapping.isSupervisor = Mapping.isSupervisor;
                    db.Entry(objMapping).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
            }
            return View("Index");
        }


        public ActionResult Delete(int Id)
        {
            SupervisorMapping objMapping = new SupervisorMapping();
            try
            {
                objMapping = db.SupervisorMappings.Where(s => s.ID == Id).FirstOrDefault();
                objMapping.isActive = false;
                db.Entry(objMapping).State = EntityState.Modified;
                db.SaveChanges();
                TempData["Message"] = "Record deleted successfully!!!";
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
            }
            return View("Index");
        }

    }
}