﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HBCDeliveryForms.Models;
using HBCDeliveryForms.Common;
using HBCDeliveryForms.Filter;
using System.Web.Configuration;

namespace HBCDeliveryForms.Controllers
{
    [Authentication]
    [CustomException]
    public class DamageClaimsController : Controller
    {
        private WrapToolEntities db = new WrapToolEntities();
        Employee user;

        [HttpGet]
        public ActionResult Index()
        {
            List<LocationMaster> LstLocation = null;
            user = (Employee)System.Web.HttpContext.Current.Session["User"];
            DeliveryDamageClaim damageClaim = GetDeliveryDamageClaimObject();
            try
            {
                LstLocation = db.LocationMasters.ToList();
                ViewBag.LstLocation = LstLocation;
                var query = (from dd in db.DeliveryDamageClaims
                             join e in db.Central_Employee_Main on dd.CreatedBy equals e.EmployeeID
                             where e.BossID == user.EmployeeId && dd.IsActive == true && dd.isEmailSent == false && dd.isCallback == false
                             select dd).OrderByDescending(d => d.CreatedDate);
                ViewBag.LstDamageClaim = query.ToList().Distinct();

                List<DeliveryDamageClaim> Lstmydamageclaim = db.DeliveryDamageClaims.Where(d => d.IsActive == true && d.CreatedBy == user.EmployeeId && (d.isEmailSent == false && d.isCallback == true)).OrderByDescending(d => d.CreatedDate).ToList();
                ViewBag.Lstmydamageclaim = Lstmydamageclaim;

                ViewBag.EmployeeList = db.GetAdvisorList();
            }
            catch (Exception ex)
            {
            }
            return View(damageClaim);
        }


        private DeliveryDamageClaim GetDeliveryDamageClaimObject()
        {
            DeliveryDamageClaim claimObject = new DeliveryDamageClaim();
            claimObject.DatePrepared = DateTime.Now;
            claimObject.PreparedBy = user.FullName;
            return claimObject;
        }


        [HttpPost]
        public ActionResult Create(DeliveryDamageClaim damageClaim, FormCollection collection, int reset = 0)
        {
            try
            {
                string sysFormat = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
                if (sysFormat == "dd-MM-yyyy")
                {
                    damageClaim.DatePrepared = Convert.ToDateTime(collection["DatePrepared"].Split('-')[1] + "-" + collection["DatePrepared"].Split('-')[0] + "-" + collection["DatePrepared"].Split('-')[2]);
                    damageClaim.DeliveryDate = Convert.ToDateTime(collection["DeliveryDate"].Split('-')[1] + "-" + collection["DeliveryDate"].Split('-')[0] + "-" + collection["DeliveryDate"].Split('-')[2]);
                }
                if (sysFormat == "yyyy-MM-dd")
                {
                    damageClaim.DatePrepared = Convert.ToDateTime(collection["DatePrepared"].Split('-')[1] + "-" + collection["DatePrepared"].Split('-')[2] + "-" + collection["DatePrepared"].Split('-')[0]);
                    damageClaim.DeliveryDate = Convert.ToDateTime(collection["DeliveryDate"].Split('-')[1] + "-" + collection["DeliveryDate"].Split('-')[2] + "-" + collection["DeliveryDate"].Split('-')[0]);
                }
                ModelState.Clear();
                TryValidateModel(damageClaim);

                if (ModelState.IsValid)
                {
                    if (reset > 0)
                    {
                        return Reset(damageClaim);
                    }

                    user = (Employee)System.Web.HttpContext.Current.Session["User"];
                    damageClaim.CreatedBy = user.EmployeeId;
                    damageClaim.CreatedDate = DateTime.Now;
                    damageClaim.IsActive = true;
                    damageClaim.isEmailSent = false;
                    damageClaim.isCallback = false;

                    //Check if user is Teamlead or Supervisor
                    var EmpList = db.Central_Employee_Main.Where(e => e.BossID == damageClaim.CreatedBy && e.Status == true).ToList();
                    SupervisorMapping Mapping = db.SupervisorMappings.Where(s => s.EmpoyeeId == damageClaim.CreatedBy && s.isSupervisor == true && s.isActive == true).FirstOrDefault();
                    if (EmpList.Count > 0 || Mapping != null)
                    {
                        //    int LocationId = Convert.ToInt32(damageClaim.LocationId);
                        //    bool EmailSent = SendEmail(LocationId, damageClaim);
                        bool EmailSent = SendExceptionEmail(damageClaim);
                        if (EmailSent)
                        {
                            damageClaim.isEmailSent = true;
                            TempData["Message"] = "Email Sent Successfully !!!";
                        }
                        else
                        {
                            TempData["Message"] = "Form Submitted Successfully !!!";
                        }
                    }
                    else
                    {
                        TempData["Message"] = "Form Submitted Successfully !!!";
                    }
                    db.DeliveryDamageClaims.Add(damageClaim);
                    db.SaveChanges();

                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
            }
            return View("Index", damageClaim);
        }

        [HttpPost]
        public ActionResult Reset(DeliveryDamageClaim damageClaim)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
            }
            return View("Index", damageClaim);
        }


        public ActionResult Edit(int id)
        {
            List<LocationMaster> LstLocation = null;
            DeliveryDamageClaim damageclaim = new DeliveryDamageClaim();
            try
            {
                LstLocation = db.LocationMasters.ToList();
                ViewBag.LstLocation = LstLocation;
                damageclaim = db.DeliveryDamageClaims.Where(d => d.DDCId == id).FirstOrDefault();
            }
            catch (Exception ex)
            {
            }
            return View(damageclaim);
        }

        public ActionResult MyEdit(int id)
        {
            List<LocationMaster> LstLocation = null;
            DeliveryDamageClaim damageclaim = new DeliveryDamageClaim();
            try
            {
                LstLocation = db.LocationMasters.ToList();
                ViewBag.LstLocation = LstLocation;
                damageclaim = db.DeliveryDamageClaims.Where(d => d.DDCId == id).FirstOrDefault();
            }
            catch (Exception ex)
            {
            }
            return View(damageclaim);
        }


        [HttpPost]
        public ActionResult Update(DeliveryDamageClaim damageClaim, FormCollection collection)
        {
            string buttonName = (collection["Submit"] == null) ? "Submit" : collection["Submit"].ToString();
            DeliveryDamageClaim claim = new DeliveryDamageClaim();

            try
            {
                string sysFormat = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
                if (sysFormat == "dd-MM-yyyy")
                {
                    damageClaim.DatePrepared = Convert.ToDateTime(collection["DatePrepared"].Split('-')[1] + "-" + collection["DatePrepared"].Split('-')[0] + "-" + collection["DatePrepared"].Split('-')[2]);
                    damageClaim.DeliveryDate = Convert.ToDateTime(collection["DeliveryDate"].Split('-')[1] + "-" + collection["DeliveryDate"].Split('-')[0] + "-" + collection["DeliveryDate"].Split('-')[2]);
                }
                if (sysFormat == "yyyy-MM-dd")
                {
                    damageClaim.DatePrepared = Convert.ToDateTime(collection["DatePrepared"].Split('-')[1] + "-" + collection["DatePrepared"].Split('-')[2] + "-" + collection["DatePrepared"].Split('-')[0]);
                    damageClaim.DeliveryDate = Convert.ToDateTime(collection["DeliveryDate"].Split('-')[1] + "-" + collection["DeliveryDate"].Split('-')[2] + "-" + collection["DeliveryDate"].Split('-')[0]);
                }
                ModelState.Clear();
                TryValidateModel(damageClaim);

                if (ModelState.IsValid)
                {
                    claim = db.DeliveryDamageClaims.Where(d => d.DDCId == damageClaim.DDCId).FirstOrDefault();
                    user = (Employee)System.Web.HttpContext.Current.Session["User"];

                    if (buttonName == "Send to Agent")
                    {
                        claim.isCallback = true;
                    }
                    claim.ModifiedBy = user.EmployeeId;
                    claim.ModifiedDate = DateTime.Now;
                    claim.DatePrepared = damageClaim.DatePrepared;
                    claim.PreparedBy = damageClaim.PreparedBy;
                    claim.DeliveryProvider = damageClaim.DeliveryProvider;
                    claim.Order = damageClaim.Order;
                    claim.CustomerName = damageClaim.CustomerName;
                    claim.DeliveryDate = damageClaim.DeliveryDate;
                    claim.Address = damageClaim.Address;
                    claim.DayPhoneNo = damageClaim.DayPhoneNo;
                    claim.EvePhoneNo = damageClaim.EvePhoneNo;
                    claim.Cell = damageClaim.Cell;
                    claim.DamageReported = damageClaim.DamageReported;
                    claim.LocationId = damageClaim.LocationId;

                    if (buttonName == "Submit")
                    {
                        var EmpList = db.Central_Employee_Main.Where(e => e.BossID == damageClaim.CreatedBy && e.Status == true).ToList();
                        if (EmpList.Count > 0)
                        {
                            //    int LocationId = Convert.ToInt32(damageClaim.LocationId);
                            //    bool EmailSent = SendEmail(LocationId, claim);
                            bool EmailSent = SendExceptionEmail(claim);
                            if (EmailSent)
                            {
                                claim.isEmailSent = true;
                                TempData["Message"] = "Email Sent Successfully !!!";
                            }
                            else
                            {
                                TempData["Message"] = "Form Submitted Successfully !!!";
                            }
                        }
                        else
                        {
                            TempData["Message"] = "Form Submitted Successfully !!!";
                        }
                    }
                    else
                    {
                        TempData["Message"] = "Form Submitted Back To Agent Successfully !!!";
                    }
                    db.Entry(claim).State = EntityState.Modified;
                    db.SaveChanges();

                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
            }
            return new EmptyResult();
        }


        public bool SendEmail(int LocationId, DeliveryDamageClaim claim)
        {
            bool isEmailSent = false;
            var SendEmail = WebConfigurationManager.AppSettings["SendEmail"];
            if (SendEmail == "true")
            {
                Email email = new Email();
                EmailServices service = new EmailServices();
                Shared Sharedobj = new Shared();
                string docPath = Sharedobj.WriteToExcel((int)Constant.Template.DamageClaim, claim);
                var emailLst = db.EmailMasters.Where(e => e.LocationId == LocationId).Select(e => e.EmailId).ToList();
                email.EmailSubject = "Test Delivery Damaged";
                email.Body = Sharedobj.GetBody("Delivery Damaged");
                email.IsHTML = true;
                email.ToEmail = string.Join(",", emailLst);
                if (!string.IsNullOrEmpty(docPath))
                {
                    email.AttachmentFilePath = docPath;
                }
                isEmailSent = service.SendEmail(email);
                Sharedobj.ClearFolder();
            }
            return isEmailSent;
        }

        public bool SendExceptionEmail(DeliveryDamageClaim claim)
        {
            bool isEmailSent = false;
            var SendEmail = WebConfigurationManager.AppSettings["SendEmail"];
            if (SendEmail == "true")
            {
                Email email = new Email();
                EmailServices service = new EmailServices();
                Shared Sharedobj = new Shared();
                EmailContext context = new EmailContext();
                DataSet emailLst = context.GetEmailDetails(3);
                if (emailLst != null)
                {
                    if (emailLst.Tables[0].Rows.Count > 0)
                    {
                        string docPath = Sharedobj.WriteToExcel((int)Constant.Template.DamageClaim, claim);
                        email.EmailSubject = "Test Delivery Damaged";
                        email.Body = Sharedobj.GetBody("Delivery Damaged");
                        email.IsHTML = true;
                        email.ToEmail = emailLst.Tables[0].Rows[0]["ToEmail"].ToString();
                        email.CCAddresses = emailLst.Tables[0].Rows[0]["CCEmail"].ToString();
                        email.BCCAddresses = emailLst.Tables[0].Rows[0]["BCCEmail"].ToString();
                        if (!string.IsNullOrEmpty(docPath))
                        {
                            email.AttachmentFilePath = docPath;
                        }
                        isEmailSent = service.SendEmail(email);
                        Sharedobj.ClearFolder();
                    }
                }
            }
            return isEmailSent;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
