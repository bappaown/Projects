﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using HBCDeliveryForms.Models;
using HBCDeliveryForms.Common;
using HBCDeliveryForms.Filter;
using System.Web.Configuration;

namespace HBCDeliveryForms.Controllers
{
    [Authentication]
    [CustomException]
    public class DeliveryArrangementsController : Controller
    {
        private WrapToolEntities db = new WrapToolEntities();
        Employee user;

        [HttpGet]
        public ActionResult Index()
        {
            List<ReasonMaster> LstReason = null;
            List<LocationMaster> LstLocation = null;
            user = (Employee)System.Web.HttpContext.Current.Session["User"];
            SpecialDelivery deliveryArrangement = GetDeliveryArrangementobject();
            try
            {
                LstReason = db.ReasonMasters.ToList();
                ViewBag.LstReason = LstReason;
                LstLocation = db.LocationMasters.ToList();
                ViewBag.LstLocation = LstLocation;
                var query = (from sd in db.SpecialDeliveries
                             join e in db.Central_Employee_Main on sd.CreatedBy equals e.EmployeeID
                             where e.BossID == user.EmployeeId && sd.isEmailSent == false && sd.isCallback == false
                             select sd).OrderByDescending(s => s.CreatedDate);
                ViewBag.LstSpecialDelivery = query.ToList().Distinct();

                List<SpecialDelivery> LstMySpecialDelivery = db.SpecialDeliveries.Where(s => s.IsActive == true && s.CreatedBy == user.EmployeeId && (s.isEmailSent == false && s.isCallback == true)).OrderByDescending(s => s.CreatedDate).ToList();
                ViewBag.LstMySpecialDelivery = LstMySpecialDelivery;
            }
            catch (Exception ex)
            {
            }

            return View(deliveryArrangement);
        }

        private SpecialDelivery GetDeliveryArrangementobject()
        {
            SpecialDelivery deliveryArrangement = new SpecialDelivery();
            deliveryArrangement.DeliveryDate = DateTime.Now.Date;
            return deliveryArrangement;
        }

        [HttpPost]
        public ActionResult Create(SpecialDelivery specialDelivery, FormCollection collection, int reset = 0)
        {
            try
            {
                string sysFormat = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
                if (sysFormat == "dd-MM-yyyy")
                {
                    specialDelivery.DeliveryDate = Convert.ToDateTime(collection["DeliveryDate"].Split('-')[1] + "-" + collection["DeliveryDate"].Split('-')[0] + "-" + collection["DeliveryDate"].Split('-')[2]);
                }
                if (sysFormat == "yyyy-MM-dd")
                {
                    specialDelivery.DeliveryDate = Convert.ToDateTime(collection["DeliveryDate"].Split('-')[1] + "-" + collection["DeliveryDate"].Split('-')[2] + "-" + collection["DeliveryDate"].Split('-')[0]);
                }
                ModelState.Clear();
                TryValidateModel(specialDelivery);

                if (ModelState.IsValid)
                {
                    if (reset > 0)
                    {
                        return Reset(specialDelivery);
                    }


                    user = (Employee)System.Web.HttpContext.Current.Session["User"];
                    specialDelivery.CreatedBy = user.EmployeeId;
                    specialDelivery.CreatedDate = DateTime.Now;
                    specialDelivery.IsActive = true;
                    specialDelivery.isEmailSent = false;
                    specialDelivery.isCallback = false;

                    //Check if user is Teamlead or Supervisor
                    var EmpList = db.Central_Employee_Main.Where(e => e.BossID == specialDelivery.CreatedBy && e.Status == true).ToList();
                    SupervisorMapping Mapping = db.SupervisorMappings.Where(s => s.EmpoyeeId == specialDelivery.CreatedBy && s.isSupervisor == true && s.isActive == true).FirstOrDefault();
                    if (EmpList.Count > 0 || Mapping != null)
                    {
                        string Exception = (collection["isException"] == null) ? "false" : collection["isException"].ToString();
                        bool EmailSent;
                        if (Exception == "false")
                        {
                            int LocationId = Convert.ToInt32(specialDelivery.LocationId);
                            EmailSent = SendEmail(LocationId, specialDelivery);
                        }
                        else
                        {
                            EmailSent = SendExceptionEmail(specialDelivery);
                        }

                        if (EmailSent)
                        {
                            specialDelivery.isEmailSent = true;
                            TempData["Message"] = "Email Sent Successfully !!!";
                        }
                        else
                        {
                            TempData["Message"] = "Form Submitted Successfully !!!";
                        }
                    }
                    else
                    {
                        TempData["Message"] = "Form Submitted Successfully !!!";
                    }
                    db.SpecialDeliveries.Add(specialDelivery);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
            }
            return View(specialDelivery);
        }

        [HttpPost]
        public ActionResult Reset(SpecialDelivery specialDelivery)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
            }
            return View(specialDelivery);
        }


        public ActionResult Edit(int id)
        {
            List<LocationMaster> LstLocation = null;
            List<ReasonMaster> LstReason = null;
            SpecialDelivery objDelivery = new SpecialDelivery();
            try
            {
                LstReason = db.ReasonMasters.ToList();
                ViewBag.LstReason = LstReason;
                LstLocation = db.LocationMasters.ToList();
                ViewBag.LstLocation = LstLocation;
                objDelivery = db.SpecialDeliveries.Where(s => s.SDFId == id).FirstOrDefault();
            }
            catch (Exception ex)
            {
            }

            return View(objDelivery);
        }

        public ActionResult MyEdit(int id)
        {
            List<LocationMaster> LstLocation = null;
            List<ReasonMaster> LstReason = null;
            SpecialDelivery objDelivery = new SpecialDelivery();
            try
            {
                LstReason = db.ReasonMasters.ToList();
                ViewBag.LstReason = LstReason;
                LstLocation = db.LocationMasters.ToList();
                ViewBag.LstLocation = LstLocation;
                objDelivery = db.SpecialDeliveries.Where(s => s.SDFId == id).FirstOrDefault();
            }
            catch (Exception ex)
            {
            }

            return View(objDelivery);
        }


        [HttpPost]
        public ActionResult Update(SpecialDelivery delivery, FormCollection collection)
        {
            SpecialDelivery objDelivery = new SpecialDelivery();
            Email email = new Email();
            EmailServices service = new EmailServices();
            Shared Sharedobj = new Shared();
            string buttonName = (collection["Submit"] == null) ? "Submit" : collection["Submit"].ToString();

            string sysFormat = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
            if (sysFormat == "dd-MM-yyyy")
            {
                delivery.DeliveryDate = Convert.ToDateTime(collection["DeliveryDate"].Split('-')[1] + "-" + collection["DeliveryDate"].Split('-')[0] + "-" + collection["DeliveryDate"].Split('-')[2]);
            }
            if (sysFormat == "yyyy-MM-dd")
            {
                delivery.DeliveryDate = Convert.ToDateTime(collection["DeliveryDate"].Split('-')[1] + "-" + collection["DeliveryDate"].Split('-')[2] + "-" + collection["DeliveryDate"].Split('-')[0]);
            }
            ModelState.Clear();
            TryValidateModel(delivery);

            try
            {
                if (ModelState.IsValid)
                {
                    objDelivery = db.SpecialDeliveries.Where(s => s.SDFId == delivery.SDFId).FirstOrDefault();
                    user = (Employee)System.Web.HttpContext.Current.Session["User"];

                    if (buttonName == "Send to Agent")
                    {
                        objDelivery.isCallback = true;
                    }
                    objDelivery.ModifiedBy = user.EmployeeId;
                    objDelivery.ModifiedDate = DateTime.Now;
                    objDelivery.DeliveryDate = delivery.DeliveryDate;
                    objDelivery.DeliveryTime = delivery.DeliveryTime;
                    objDelivery.RequestedBy = delivery.RequestedBy;
                    objDelivery.DeliveryOrder = delivery.DeliveryOrder;
                    objDelivery.HomePickUpOrder = delivery.HomePickUpOrder;
                    objDelivery.TimeStop = delivery.TimeStop;
                    objDelivery.SmallTruck = delivery.SmallTruck;
                    objDelivery.C4ManJob = delivery.C4ManJob;
                    objDelivery.OutOfRoute = delivery.OutOfRoute;
                    objDelivery.AddressChange = delivery.AddressChange;
                    objDelivery.HookUp = delivery.HookUp;
                    objDelivery.SalvageRemoval = delivery.SalvageRemoval;
                    objDelivery.ReasonId = delivery.ReasonId;
                    objDelivery.CustomerName = delivery.CustomerName;
                    objDelivery.NewAddress = delivery.NewAddress;
                    objDelivery.City = delivery.City;
                    objDelivery.PostalCode = delivery.PostalCode;
                    objDelivery.HomePhone = delivery.HomePhone;
                    objDelivery.Business = delivery.Business;
                    objDelivery.CellPhone = delivery.CellPhone;
                    objDelivery.OldAddress = delivery.OldAddress;
                    objDelivery.OldCity = delivery.OldCity;
                    objDelivery.OldPostalCode = delivery.OldPostalCode;
                    objDelivery.DeliveryInfo = delivery.DeliveryInfo;
                    objDelivery.LocationId = delivery.LocationId;
                    if (buttonName == "Submit")
                    {
                        //Email Functionality
                        string Exception = (collection["isException"] == null) ? "false" : collection["isException"].ToString();
                        bool EmailSent;
                        if (Exception == "false")
                        {
                            int LocationId = Convert.ToInt32(objDelivery.LocationId);
                            EmailSent = SendEmail(LocationId, objDelivery);
                        }
                        else
                        {
                            EmailSent = SendExceptionEmail(objDelivery);
                        }

                        if (EmailSent)
                        {
                            objDelivery.isEmailSent = true;
                            TempData["Message"] = "Email Sent Successfully !!!";
                        }
                        else
                        {
                            TempData["Message"] = "Form Submitted Successfully !!!";
                        }
                    }
                    else
                    {
                        TempData["Message"] = "Form Submitted Back To Agent Successfully !!!";
                    }
                    db.Entry(objDelivery).State = EntityState.Modified;
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
            }
            return View(objDelivery);
        }


        public bool SendEmail(int LocationId, SpecialDelivery SPdelivery)
        {
            bool isEmailSent = false;
            var SendEmail = WebConfigurationManager.AppSettings["SendEmail"];
            if (SendEmail == "true")
            {
                Email email = new Email();
                EmailServices service = new EmailServices();
                Shared Sharedobj = new Shared();
                string docPath = Sharedobj.WriteToExcel((int)Constant.Template.SpecialDelivery, SPdelivery);
                var emailLst = db.EmailMasters.Where(e => e.LocationId == LocationId).Select(e => e.EmailId).ToList();
                email.EmailSubject = "Test Special Delivery";
                email.Body = Sharedobj.GetBody("Special Delivery");
                email.IsHTML = true;
                email.ToEmail = string.Join(",", emailLst);
                if (!string.IsNullOrEmpty(docPath))
                {
                    email.AttachmentFilePath = docPath;
                }
                isEmailSent = service.SendEmail(email);
                Sharedobj.ClearFolder();
            }

            return isEmailSent;
        }

        public bool SendExceptionEmail(SpecialDelivery SPdelivery)
        {
            bool isEmailSent = false;
            var SendEmail = WebConfigurationManager.AppSettings["SendEmail"];
            if (SendEmail == "true")
            {
                Email email = new Email();
                EmailServices service = new EmailServices();
                Shared Sharedobj = new Shared();
                EmailContext context = new EmailContext();
                DataSet emailLst = context.GetEmailDetails(1);
                if (emailLst != null)
                {
                    if (emailLst.Tables[0].Rows.Count > 0)
                    {
                        string docPath = Sharedobj.WriteToExcel((int)Constant.Template.SpecialDelivery, SPdelivery);
                        email.EmailSubject = "Test Special Delivery";
                        email.Body = Sharedobj.GetBody("Special Delivery");
                        email.IsHTML = true;
                        email.ToEmail = emailLst.Tables[0].Rows[0]["ToEmail"].ToString();
                        email.CCAddresses = emailLst.Tables[0].Rows[0]["CCEmail"].ToString();
                        email.BCCAddresses = emailLst.Tables[0].Rows[0]["BCCEmail"].ToString();
                        if (!string.IsNullOrEmpty(docPath))
                        {
                            email.AttachmentFilePath = docPath;
                        }
                        isEmailSent = service.SendEmail(email);
                        Sharedobj.ClearFolder();
                    }
                }
            }

            return isEmailSent;
        }


        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
