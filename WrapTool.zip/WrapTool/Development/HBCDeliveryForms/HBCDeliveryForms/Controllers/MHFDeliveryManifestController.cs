﻿using HBCDeliveryForms.Common;
using HBCDeliveryForms.Filter;
using HBCDeliveryForms.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.Mvc;

namespace HBCDeliveryForms.Controllers
{
    [Authentication]
    [CustomException]
    public class MHFDeliveryManifestController : Controller
    {
        private WrapToolEntities db = new WrapToolEntities();
        Employee user;

        [HttpGet]
        public ActionResult Index()
        {
            List<LocationMaster> LstLocation = null;
            List<ManualReasonMaster> Manualresonlst = null;
            MHFDeliveryManifest deliveryManifest = GetDeliveryManifestobject();
            try
            {
                user = (Employee)System.Web.HttpContext.Current.Session["User"];
                LstLocation = db.LocationMasters.ToList();
                ViewBag.LstLocation = LstLocation;
                Manualresonlst = db.ManualReasonMasters.ToList();
                ViewBag.Manualresonlst = Manualresonlst;
                ViewBag.QuantityList = GetQuantityList();

                var query = (from mhd in db.MHFDeliveries
                             join e in db.Central_Employee_Main on mhd.CreatedBy equals e.EmployeeID
                             where e.BossID == user.EmployeeId && mhd.isEmailSent == false && mhd.isCallback == false
                             select mhd).OrderByDescending(m => m.CreatedDate);
                ViewBag.LstMHFDelivery = query.ToList().Distinct();

                List<MHFDelivery> LstMyMHFDelivery = db.MHFDeliveries.Where(m => m.CreatedBy == user.EmployeeId && m.IsActive == true && (m.isEmailSent == false && m.isCallback == true)).OrderByDescending(m => m.CreatedDate).ToList();
                ViewBag.LstMyMHFDelivery = LstMyMHFDelivery;
            }
            catch (Exception ex)
            {
            }
            return View(deliveryManifest);
        }

        private MHFDeliveryManifest GetDeliveryManifestobject()
        {
            MHFDeliveryManifest deliveryManifest = new MHFDeliveryManifest();
            deliveryManifest.DeliveryDate = DateTime.Now.Date;
            return deliveryManifest;
        }

        [HttpPost]
        public ActionResult Create(MHFDeliveryManifest deliveryManifest, FormCollection collection, int reset = 0)
        {
            user = (Employee)System.Web.HttpContext.Current.Session["User"];
            try
            {
                if (reset > 0)
                {
                    return Reset(deliveryManifest);
                }
                MHFDelivery objdelivery = new MHFDelivery();
                string sysFormat = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
                if (sysFormat == "dd-MM-yyyy")
                {
                    deliveryManifest.DeliveryDate = Convert.ToDateTime(collection["DeliveryDate"].Split('-')[1] + "-" + collection["DeliveryDate"].Split('-')[0] + "-" + collection["DeliveryDate"].Split('-')[2]);
                }
                if (sysFormat == "yyyy-MM-dd")
                {
                    deliveryManifest.DeliveryDate = Convert.ToDateTime(collection["DeliveryDate"].Split('-')[1] + "-" + collection["DeliveryDate"].Split('-')[2] + "-" + collection["DeliveryDate"].Split('-')[0]);
                }
                ModelState.Clear();
                TryValidateModel(deliveryManifest);

                if (ModelState.IsValid)
                {
                    objdelivery.DeliveryDate = deliveryManifest.DeliveryDate.Date;
                    objdelivery.DeliveryTime = deliveryManifest.DeliveryTime;
                    objdelivery.RequestedBy = deliveryManifest.RequestedBy;
                    objdelivery.Banner = deliveryManifest.Banner;
                    objdelivery.CustomerName = deliveryManifest.CustomerName;
                    objdelivery.Address = deliveryManifest.Address;
                    objdelivery.City = deliveryManifest.City;
                    objdelivery.PostalCode = deliveryManifest.PostalCode;
                    objdelivery.HomePhone = deliveryManifest.HomePhone;
                    objdelivery.Business = deliveryManifest.Business;
                    objdelivery.CellPhone = deliveryManifest.CellPhone;
                    objdelivery.DeliveryInfo = deliveryManifest.DeliveryInfo;
                    objdelivery.M_ReasonId = deliveryManifest.M_ReasonId;
                    objdelivery.BeddingPlaced = deliveryManifest.BeddingPlaced;
                    objdelivery.PedestalAttched = deliveryManifest.PedestalAttched;
                    objdelivery.ApplianceLeveled = deliveryManifest.ApplianceLeveled;
                    objdelivery.WasherLeakTested = deliveryManifest.WasherLeakTested;
                    objdelivery.RemovedPackaging = deliveryManifest.RemovedPackaging;
                    objdelivery.LocationId = deliveryManifest.LocationId;
                    objdelivery.IsActive = true;
                    objdelivery.isEmailSent = false;
                    objdelivery.isCallback = false;
                    objdelivery.CreatedBy = user.EmployeeId;
                    objdelivery.CreatedDate = DateTime.Now;
                    db.MHFDeliveries.Add(objdelivery);
                    db.SaveChanges();
                    int MHFId = objdelivery.MHFId;
                    if (deliveryManifest.DeliveryOrdLst.Count > 0)
                    {
                        foreach (MHFDeliveryDeliveryOrder DeliveryOrder in deliveryManifest.DeliveryOrdLst)
                        {
                            if (DeliveryOrder.isChecked)
                            {
                                MHFDelivery_DeliveryOrder objDelivery = new MHFDelivery_DeliveryOrder();
                                objDelivery.MHFId = MHFId;
                                objDelivery.DeliveryOrder = DeliveryOrder.DeliveryOrder;
                                objDelivery.SkuDescription = DeliveryOrder.SkuDescription;
                                objDelivery.Quantity = DeliveryOrder.Quantity;
                                objDelivery.ProductStatus = DeliveryOrder.ProductStatus;
                                objDelivery.MerchandiseLocation = DeliveryOrder.MerchandiseLocation;
                                objDelivery.CreatedBy = user.EmployeeId;
                                objDelivery.CreatedDate = DateTime.Now;
                                db.MHFDelivery_DeliveryOrder.Add(objDelivery);
                                db.SaveChanges();
                            }
                        }
                    }
                    if (deliveryManifest.HomepickupList.Count > 0)
                    {
                        foreach (MHFDeliveryHomePickupOrder HomePickupOrder in deliveryManifest.HomepickupList)
                        {
                            if (HomePickupOrder.isChecked)
                            {
                                MHFDelivery_HomePickupOrder objHomePickupOrder = new MHFDelivery_HomePickupOrder();
                                objHomePickupOrder.MHFId = MHFId;
                                objHomePickupOrder.HomePickupOrder = HomePickupOrder.HomePickupOrder;
                                objHomePickupOrder.SkuDescription = HomePickupOrder.SkuDescription;
                                objHomePickupOrder.Quantity = HomePickupOrder.Quantity;
                                objHomePickupOrder.RMA = HomePickupOrder.RMA;
                                objHomePickupOrder.CreatedBy = user.EmployeeId;
                                objHomePickupOrder.CreatedDate = DateTime.Now;
                                db.MHFDelivery_HomePickupOrder.Add(objHomePickupOrder);
                                db.SaveChanges();
                            }
                        }
                    }
                    if (deliveryManifest.PurchasedList.Count > 0)
                    {
                        foreach (MHFDeliverySlavagePurchased SlavagePurchased in deliveryManifest.PurchasedList)
                        {
                            if (SlavagePurchased.isChecked)
                            {
                                MHFDelivery_SlavagePurchased objSlavagePurchased = new MHFDelivery_SlavagePurchased();
                                objSlavagePurchased.MHFId = MHFId;
                                objSlavagePurchased.SalvagePurchased = SlavagePurchased.SalvagePurchased;
                                objSlavagePurchased.Quantity = SlavagePurchased.Quantity;
                                objSlavagePurchased.BeddingorAppliance = SlavagePurchased.BeddingorAppliance;
                                objSlavagePurchased.CreatedBy = user.EmployeeId;
                                objSlavagePurchased.CreatedDate = DateTime.Now;
                                db.MHFDelivery_SlavagePurchased.Add(objSlavagePurchased);
                                db.SaveChanges();
                            }
                        }
                    }

                    // Check if user is Teamlead or Supervisor
                    var EmpList = db.Central_Employee_Main.Where(e => e.BossID == user.EmployeeId && e.Status == true).ToList();
                    SupervisorMapping Mapping = db.SupervisorMappings.Where(s => s.EmpoyeeId == user.EmployeeId && s.isSupervisor == true && s.isActive == true).FirstOrDefault();
                    if (EmpList.Count > 0 || Mapping != null)
                    {
                        string Exception = (collection["isException"] == null) ? "false" : collection["isException"].ToString();
                        bool EmailSent;
                        if (Exception == "false")
                        {
                            int LocationId = Convert.ToInt32(deliveryManifest.LocationId);
                            EmailSent = SendEmail(LocationId, deliveryManifest);
                        }
                        else
                        {
                            EmailSent = SendExceptionEmail(deliveryManifest);
                        }

                        if (EmailSent)
                        {
                            MHFDelivery delivery = db.MHFDeliveries.Where(d => d.MHFId == MHFId).FirstOrDefault();
                            delivery.isEmailSent = true;
                            db.Entry(delivery).State = EntityState.Modified;
                            db.SaveChanges();
                            TempData["Message"] = "Email Sent Successfully !!!";
                        }
                        else
                        {
                            TempData["Message"] = "Form Submitted Successfully !!!";
                        }
                    }
                    else
                    {
                        TempData["Message"] = "Form Submitted Successfully !!!";
                    }

                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
            }
            return View("Index", deliveryManifest);
        }

        [HttpPost]
        public ActionResult Reset(MHFDeliveryManifest deliveryManifest)
        {
            try
            {
                return RedirectToAction("Index");
            }
            catch (Exception ex)
            {
            }
            return View("Index", deliveryManifest);
        }


        public ActionResult Edit(int Id)
        {
            List<LocationMaster> LstLocation = null;
            List<ManualReasonMaster> Manualresonlst = null;
            MHFDeliveryManifest objdeliveryManifest = new MHFDeliveryManifest();
            try
            {
                LstLocation = db.LocationMasters.ToList();
                ViewBag.LstLocation = LstLocation;
                Manualresonlst = db.ManualReasonMasters.ToList();
                ViewBag.Manualresonlst = Manualresonlst;
                ViewBag.QuantityList = GetQuantityList();
                MHFDelivery objdelivery = db.MHFDeliveries.Where(m => m.MHFId == Id).FirstOrDefault();
                List<MHFDelivery_DeliveryOrder> LstDeliveryOrder = db.MHFDelivery_DeliveryOrder.Where(m => m.MHFId == Id).ToList();
                List<MHFDelivery_HomePickupOrder> LstHomePickupOrder = db.MHFDelivery_HomePickupOrder.Where(m => m.MHFId == Id).ToList();
                List<MHFDelivery_SlavagePurchased> LstSlavagePurchased = db.MHFDelivery_SlavagePurchased.Where(m => m.MHFId == Id).ToList();
                objdeliveryManifest.MHFId = objdelivery.MHFId;
                objdeliveryManifest.DeliveryDate = Convert.ToDateTime(objdelivery.DeliveryDate);
                objdeliveryManifest.DeliveryTime = objdelivery.DeliveryTime;
                objdeliveryManifest.RequestedBy = objdelivery.RequestedBy;
                objdeliveryManifest.Banner = objdelivery.Banner;
                objdeliveryManifest.CustomerName = objdelivery.CustomerName;
                objdeliveryManifest.Address = objdelivery.Address;
                objdeliveryManifest.City = objdelivery.City;
                objdeliveryManifest.PostalCode = objdelivery.PostalCode;
                objdeliveryManifest.HomePhone = objdelivery.HomePhone;
                objdeliveryManifest.Business = objdelivery.Business;
                objdeliveryManifest.CellPhone = objdelivery.CellPhone;
                objdeliveryManifest.DeliveryInfo = objdelivery.DeliveryInfo;
                objdeliveryManifest.M_ReasonId = Convert.ToInt32(objdelivery.M_ReasonId);
                objdeliveryManifest.BeddingPlaced = objdelivery.BeddingPlaced;
                objdeliveryManifest.PedestalAttched = objdelivery.PedestalAttched;
                objdeliveryManifest.ApplianceLeveled = objdelivery.ApplianceLeveled;
                objdeliveryManifest.WasherLeakTested = objdelivery.WasherLeakTested;
                objdeliveryManifest.RemovedPackaging = objdelivery.RemovedPackaging;
                objdeliveryManifest.isEmailSent = Convert.ToBoolean(objdelivery.isEmailSent);
                objdeliveryManifest.isCallback = Convert.ToBoolean(objdelivery.isCallback);
                objdeliveryManifest.LocationId = Convert.ToInt32(objdelivery.LocationId);
                if (LstDeliveryOrder.Count > 0)
                {
                    objdeliveryManifest.DeliveryOrdLst = new List<MHFDeliveryDeliveryOrder>();
                    foreach (MHFDelivery_DeliveryOrder DeliveryOrder in LstDeliveryOrder)
                    {
                        MHFDeliveryDeliveryOrder objDeliveryOrder = new MHFDeliveryDeliveryOrder();
                        objDeliveryOrder.isChecked = true;
                        objDeliveryOrder.DeliveryOrder = DeliveryOrder.DeliveryOrder;
                        objDeliveryOrder.SkuDescription = DeliveryOrder.SkuDescription;
                        objDeliveryOrder.Quantity = DeliveryOrder.Quantity;
                        objDeliveryOrder.ProductStatus = DeliveryOrder.ProductStatus;
                        objDeliveryOrder.MerchandiseLocation = DeliveryOrder.MerchandiseLocation;
                        objdeliveryManifest.DeliveryOrdLst.Add(objDeliveryOrder);
                    }
                }
                if (LstHomePickupOrder.Count > 0)
                {
                    objdeliveryManifest.HomepickupList = new List<MHFDeliveryHomePickupOrder>();
                    foreach (MHFDelivery_HomePickupOrder HomePickupOrder in LstHomePickupOrder)
                    {
                        MHFDeliveryHomePickupOrder objHomePickupOrder = new MHFDeliveryHomePickupOrder();
                        objHomePickupOrder.isChecked = true;
                        objHomePickupOrder.HomePickupOrder = HomePickupOrder.HomePickupOrder;
                        objHomePickupOrder.SkuDescription = HomePickupOrder.SkuDescription;
                        objHomePickupOrder.Quantity = HomePickupOrder.Quantity;
                        objHomePickupOrder.RMA = HomePickupOrder.RMA;
                        objdeliveryManifest.HomepickupList.Add(objHomePickupOrder);
                    }
                }
                if (LstSlavagePurchased.Count > 0)
                {
                    objdeliveryManifest.PurchasedList = new List<MHFDeliverySlavagePurchased>();
                    foreach (MHFDelivery_SlavagePurchased SlavagePurchased in LstSlavagePurchased)
                    {
                        MHFDeliverySlavagePurchased objSlavagePurchased = new MHFDeliverySlavagePurchased();
                        objSlavagePurchased.isChecked = true;
                        objSlavagePurchased.SalvagePurchased = SlavagePurchased.SalvagePurchased;
                        objSlavagePurchased.BeddingorAppliance = SlavagePurchased.BeddingorAppliance;
                        objSlavagePurchased.Quantity = SlavagePurchased.Quantity;
                        objdeliveryManifest.PurchasedList.Add(objSlavagePurchased);
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return View(objdeliveryManifest);
        }



        public ActionResult MyEdit(int Id)
        {
            List<LocationMaster> LstLocation = null;
            List<ManualReasonMaster> Manualresonlst = null;
            MHFDeliveryManifest objdeliveryManifest = new MHFDeliveryManifest();
            try
            {
                LstLocation = db.LocationMasters.ToList();
                ViewBag.LstLocation = LstLocation;
                Manualresonlst = db.ManualReasonMasters.ToList();
                ViewBag.Manualresonlst = Manualresonlst;
                ViewBag.QuantityList = GetQuantityList();
                MHFDelivery objdelivery = db.MHFDeliveries.Where(m => m.MHFId == Id).FirstOrDefault();
                List<MHFDelivery_DeliveryOrder> LstDeliveryOrder = db.MHFDelivery_DeliveryOrder.Where(m => m.MHFId == Id).ToList();
                List<MHFDelivery_HomePickupOrder> LstHomePickupOrder = db.MHFDelivery_HomePickupOrder.Where(m => m.MHFId == Id).ToList();
                List<MHFDelivery_SlavagePurchased> LstSlavagePurchased = db.MHFDelivery_SlavagePurchased.Where(m => m.MHFId == Id).ToList();
                objdeliveryManifest.MHFId = objdelivery.MHFId;
                objdeliveryManifest.DeliveryDate = Convert.ToDateTime(objdelivery.DeliveryDate);
                objdeliveryManifest.DeliveryTime = objdelivery.DeliveryTime;
                objdeliveryManifest.RequestedBy = objdelivery.RequestedBy;
                objdeliveryManifest.Banner = objdelivery.Banner;
                objdeliveryManifest.CustomerName = objdelivery.CustomerName;
                objdeliveryManifest.Address = objdelivery.Address;
                objdeliveryManifest.City = objdelivery.City;
                objdeliveryManifest.PostalCode = objdelivery.PostalCode;
                objdeliveryManifest.HomePhone = objdelivery.HomePhone;
                objdeliveryManifest.Business = objdelivery.Business;
                objdeliveryManifest.CellPhone = objdelivery.CellPhone;
                objdeliveryManifest.DeliveryInfo = objdelivery.DeliveryInfo;
                objdeliveryManifest.M_ReasonId = Convert.ToInt32(objdelivery.M_ReasonId);
                objdeliveryManifest.BeddingPlaced = objdelivery.BeddingPlaced;
                objdeliveryManifest.PedestalAttched = objdelivery.PedestalAttched;
                objdeliveryManifest.ApplianceLeveled = objdelivery.ApplianceLeveled;
                objdeliveryManifest.WasherLeakTested = objdelivery.WasherLeakTested;
                objdeliveryManifest.RemovedPackaging = objdelivery.RemovedPackaging;
                objdeliveryManifest.isEmailSent = Convert.ToBoolean(objdelivery.isEmailSent);
                objdeliveryManifest.isCallback = Convert.ToBoolean(objdelivery.isCallback);
                objdeliveryManifest.LocationId = Convert.ToInt32(objdelivery.LocationId);
                if (LstDeliveryOrder.Count > 0)
                {
                    objdeliveryManifest.DeliveryOrdLst = new List<MHFDeliveryDeliveryOrder>();
                    foreach (MHFDelivery_DeliveryOrder DeliveryOrder in LstDeliveryOrder)
                    {
                        MHFDeliveryDeliveryOrder objDeliveryOrder = new MHFDeliveryDeliveryOrder();
                        objDeliveryOrder.isChecked = true;
                        objDeliveryOrder.DeliveryOrder = DeliveryOrder.DeliveryOrder;
                        objDeliveryOrder.SkuDescription = DeliveryOrder.SkuDescription;
                        objDeliveryOrder.Quantity = DeliveryOrder.Quantity;
                        objDeliveryOrder.ProductStatus = DeliveryOrder.ProductStatus;
                        objDeliveryOrder.MerchandiseLocation = DeliveryOrder.MerchandiseLocation;
                        objdeliveryManifest.DeliveryOrdLst.Add(objDeliveryOrder);
                    }
                }
                if (LstHomePickupOrder.Count > 0)
                {
                    objdeliveryManifest.HomepickupList = new List<MHFDeliveryHomePickupOrder>();
                    foreach (MHFDelivery_HomePickupOrder HomePickupOrder in LstHomePickupOrder)
                    {
                        MHFDeliveryHomePickupOrder objHomePickupOrder = new MHFDeliveryHomePickupOrder();
                        objHomePickupOrder.isChecked = true;
                        objHomePickupOrder.HomePickupOrder = HomePickupOrder.HomePickupOrder;
                        objHomePickupOrder.SkuDescription = HomePickupOrder.SkuDescription;
                        objHomePickupOrder.Quantity = HomePickupOrder.Quantity;
                        objHomePickupOrder.RMA = HomePickupOrder.RMA;
                        objdeliveryManifest.HomepickupList.Add(objHomePickupOrder);
                    }
                }
                if (LstSlavagePurchased.Count > 0)
                {
                    objdeliveryManifest.PurchasedList = new List<MHFDeliverySlavagePurchased>();
                    foreach (MHFDelivery_SlavagePurchased SlavagePurchased in LstSlavagePurchased)
                    {
                        MHFDeliverySlavagePurchased objSlavagePurchased = new MHFDeliverySlavagePurchased();
                        objSlavagePurchased.isChecked = true;
                        objSlavagePurchased.SalvagePurchased = SlavagePurchased.SalvagePurchased;
                        objSlavagePurchased.BeddingorAppliance = SlavagePurchased.BeddingorAppliance;
                        objSlavagePurchased.Quantity = SlavagePurchased.Quantity;
                        objdeliveryManifest.PurchasedList.Add(objSlavagePurchased);
                    }
                }

            }
            catch (Exception ex)
            {
            }
            return View(objdeliveryManifest);
        }


        public ActionResult Update(MHFDeliveryManifest deliveryManifest, FormCollection collection)
        {
            user = (Employee)System.Web.HttpContext.Current.Session["User"];
            string buttonName = (collection["Submit"] == null) ? "Submit" : collection["Submit"].ToString();

            string sysFormat = System.Globalization.CultureInfo.CurrentCulture.DateTimeFormat.ShortDatePattern;
            if (sysFormat == "dd-MM-yyyy")
            {
                deliveryManifest.DeliveryDate = Convert.ToDateTime(collection["DeliveryDate"].Split('-')[1] + "-" + collection["DeliveryDate"].Split('-')[0] + "-" + collection["DeliveryDate"].Split('-')[2]);
            }
            if (sysFormat == "yyyy-MM-dd")
            {
                deliveryManifest.DeliveryDate = Convert.ToDateTime(collection["DeliveryDate"].Split('-')[1] + "-" + collection["DeliveryDate"].Split('-')[2] + "-" + collection["DeliveryDate"].Split('-')[0]);
            }
            ModelState.Clear();
            TryValidateModel(deliveryManifest);

            try
            {
                if (ModelState.IsValid)
                {
                    MHFDelivery objdelivery = db.MHFDeliveries.Where(m => m.MHFId == deliveryManifest.MHFId).FirstOrDefault();
                    if (buttonName == "Send to Agent")
                    {
                        objdelivery.isCallback = true;
                    }
                    else
                    {
                        objdelivery.isCallback = false;
                    }
                    objdelivery.DeliveryDate = deliveryManifest.DeliveryDate.Date;
                    objdelivery.DeliveryTime = deliveryManifest.DeliveryTime;
                    objdelivery.RequestedBy = deliveryManifest.RequestedBy;
                    objdelivery.Banner = deliveryManifest.Banner;
                    objdelivery.CustomerName = deliveryManifest.CustomerName;
                    objdelivery.Address = deliveryManifest.Address;
                    objdelivery.City = deliveryManifest.City;
                    objdelivery.PostalCode = deliveryManifest.PostalCode;
                    objdelivery.HomePhone = deliveryManifest.HomePhone;
                    objdelivery.Business = deliveryManifest.Business;
                    objdelivery.CellPhone = deliveryManifest.CellPhone;
                    objdelivery.DeliveryInfo = deliveryManifest.DeliveryInfo;
                    objdelivery.M_ReasonId = deliveryManifest.M_ReasonId;
                    objdelivery.BeddingPlaced = deliveryManifest.BeddingPlaced;
                    objdelivery.PedestalAttched = deliveryManifest.PedestalAttched;
                    objdelivery.ApplianceLeveled = deliveryManifest.ApplianceLeveled;
                    objdelivery.WasherLeakTested = deliveryManifest.WasherLeakTested;
                    objdelivery.RemovedPackaging = deliveryManifest.RemovedPackaging;
                    objdelivery.LocationId = deliveryManifest.LocationId;
                    objdelivery.IsActive = true;
                    objdelivery.isEmailSent = false;
                    objdelivery.ModifiedBy = user.EmployeeId;
                    objdelivery.ModifiedDate = DateTime.Now;
                    db.Entry(objdelivery).State = EntityState.Modified;
                    if (deliveryManifest.DeliveryOrdLst.Count > 0)
                    {
                        List<MHFDelivery_DeliveryOrder> MDeliveryOrder = db.MHFDelivery_DeliveryOrder.Where(m => m.MHFId == deliveryManifest.MHFId).ToList();
                        foreach (MHFDelivery_DeliveryOrder order in MDeliveryOrder)
                        {
                            db.MHFDelivery_DeliveryOrder.Remove(order);
                        }
                        foreach (MHFDeliveryDeliveryOrder DeliveryOrder in deliveryManifest.DeliveryOrdLst)
                        {
                            if (DeliveryOrder.isChecked)
                            {
                                MHFDelivery_DeliveryOrder objDelivery = new MHFDelivery_DeliveryOrder();
                                objDelivery.MHFId = MDeliveryOrder[0].MHFId;
                                objDelivery.DeliveryOrder = DeliveryOrder.DeliveryOrder;
                                objDelivery.SkuDescription = DeliveryOrder.SkuDescription;
                                objDelivery.Quantity = DeliveryOrder.Quantity;
                                objDelivery.ProductStatus = DeliveryOrder.ProductStatus;
                                objDelivery.MerchandiseLocation = DeliveryOrder.MerchandiseLocation;
                                objDelivery.CreatedBy = MDeliveryOrder[0].CreatedBy;
                                objDelivery.CreatedDate = MDeliveryOrder[0].CreatedDate;
                                objDelivery.ModifiedBy = user.EmployeeId;
                                objDelivery.ModifiedDate = DateTime.Now;
                                db.MHFDelivery_DeliveryOrder.Add(objDelivery);
                            }
                        }
                    }

                    if (deliveryManifest.HomepickupList.Count > 0)
                    {
                        List<MHFDelivery_HomePickupOrder> MHomePickupOrder = db.MHFDelivery_HomePickupOrder.Where(m => m.MHFId == deliveryManifest.MHFId).ToList();
                        foreach (MHFDelivery_HomePickupOrder order in MHomePickupOrder)
                        {
                            db.MHFDelivery_HomePickupOrder.Remove(order);
                        }
                        foreach (MHFDeliveryHomePickupOrder HomePickupOrder in deliveryManifest.HomepickupList)
                        {
                            if (HomePickupOrder.isChecked)
                            {
                                MHFDelivery_HomePickupOrder objHomePickupOrder = new MHFDelivery_HomePickupOrder();
                                objHomePickupOrder.MHFId = MHomePickupOrder[0].MHFId;
                                objHomePickupOrder.HomePickupOrder = HomePickupOrder.HomePickupOrder;
                                objHomePickupOrder.SkuDescription = HomePickupOrder.SkuDescription;
                                objHomePickupOrder.Quantity = HomePickupOrder.Quantity;
                                objHomePickupOrder.RMA = HomePickupOrder.RMA;
                                objHomePickupOrder.CreatedBy = MHomePickupOrder[0].CreatedBy;
                                objHomePickupOrder.CreatedDate = MHomePickupOrder[0].CreatedDate;
                                objHomePickupOrder.ModifiedBy = user.EmployeeId;
                                objHomePickupOrder.ModifiedDate = DateTime.Now;
                                db.MHFDelivery_HomePickupOrder.Add(objHomePickupOrder);
                            }
                        }

                    }

                    if (deliveryManifest.PurchasedList.Count > 0)
                    {
                        List<MHFDelivery_SlavagePurchased> MSlavagePurchased = db.MHFDelivery_SlavagePurchased.Where(m => m.MHFId == deliveryManifest.MHFId).ToList();
                        foreach (MHFDelivery_SlavagePurchased Purchased in MSlavagePurchased)
                        {
                            db.MHFDelivery_SlavagePurchased.Remove(Purchased);
                        }
                        foreach (MHFDeliverySlavagePurchased SlavagePurchased in deliveryManifest.PurchasedList)
                        {
                            if (SlavagePurchased.isChecked)
                            {
                                MHFDelivery_SlavagePurchased objSlavagePurchased = new MHFDelivery_SlavagePurchased();
                                objSlavagePurchased.MHFId = MSlavagePurchased[0].MHFId;
                                objSlavagePurchased.SalvagePurchased = SlavagePurchased.SalvagePurchased;
                                objSlavagePurchased.Quantity = SlavagePurchased.Quantity;
                                objSlavagePurchased.BeddingorAppliance = SlavagePurchased.BeddingorAppliance;
                                objSlavagePurchased.CreatedBy = MSlavagePurchased[0].CreatedBy;
                                objSlavagePurchased.CreatedDate = MSlavagePurchased[0].CreatedDate;
                                objSlavagePurchased.ModifiedBy = user.EmployeeId;
                                objSlavagePurchased.ModifiedDate = DateTime.Now;
                                db.MHFDelivery_SlavagePurchased.Add(objSlavagePurchased);
                            }
                        }
                    }

                    if (buttonName == "Submit")
                    {
                        string Exception = (collection["isException"] == null) ? "false" : collection["isException"].ToString();
                        bool EmailSent;
                        if (Exception == "false")
                        {
                            int LocationId = Convert.ToInt32(deliveryManifest.LocationId);
                            EmailSent = SendEmail(LocationId, deliveryManifest);
                        }
                        else
                        {
                            EmailSent = SendExceptionEmail(deliveryManifest);
                        }

                        if (EmailSent)
                        {
                            deliveryManifest.isEmailSent = true;
                            TempData["Message"] = "Email Sent Successfully !!!";
                        }
                        else
                        {
                            TempData["Message"] = "Form Submitted Successfully !!!";
                        }
                    }
                    else
                    {
                        TempData["Message"] = "Form Submitted Back To Agent Successfully !!!";
                    }
                    db.SaveChanges();

                    return RedirectToAction("Index");
                }
            }
            catch (Exception ex)
            {
            }
            return View("Index");
        }



        public bool SendEmail(int LocationId, MHFDeliveryManifest deliveryManifest)
        {
            bool isEmailSent = false;
            var SendEmail = WebConfigurationManager.AppSettings["SendEmail"];
            if (SendEmail == "true")
            {
                Email email = new Email();
                EmailServices service = new EmailServices();
                Shared Sharedobj = new Shared();
                string docPath = Sharedobj.WriteToExcel((int)Constant.Template.Delivery, deliveryManifest);
                var emailLst = db.EmailMasters.Where(e => e.LocationId == LocationId).Select(e => e.EmailId).ToList();
                email.EmailSubject = "Test MFHDelivery Manifest form";
                email.Body = Sharedobj.GetBody("MFHDelivery Manifest");
                email.IsHTML = true;
                email.ToEmail = string.Join(",", emailLst);
                if (!string.IsNullOrEmpty(docPath))
                {
                    email.AttachmentFilePath = docPath;
                }
                isEmailSent = service.SendEmail(email);
                Sharedobj.ClearFolder();
            }
            return isEmailSent;
        }

        public bool SendExceptionEmail(MHFDeliveryManifest deliveryManifest)
        {
            bool isEmailSent = false;
            var SendEmail = WebConfigurationManager.AppSettings["SendEmail"];
            if (SendEmail == "true")
            {
                Email email = new Email();
                EmailServices service = new EmailServices();
                Shared Sharedobj = new Shared();
                EmailContext context = new EmailContext();
                DataSet emailLst = context.GetEmailDetails(2);
                if (emailLst != null)
                {
                    if (emailLst.Tables[0].Rows.Count > 0)
                    {
                        string docPath = Sharedobj.WriteToExcel((int)Constant.Template.Delivery, deliveryManifest);
                        email.EmailSubject = "Test MFHDelivery Manifest form";
                        email.Body = Sharedobj.GetBody("MFHDelivery Manifest");
                        email.IsHTML = true;
                        email.ToEmail = emailLst.Tables[0].Rows[0]["ToEmail"].ToString();
                        email.CCAddresses = emailLst.Tables[0].Rows[0]["CCEmail"].ToString();
                        email.BCCAddresses = emailLst.Tables[0].Rows[0]["BCCEmail"].ToString();
                        if (!string.IsNullOrEmpty(docPath))
                        {
                            email.AttachmentFilePath = docPath;
                        }
                        isEmailSent = service.SendEmail(email);
                        Sharedobj.ClearFolder();
                    }
                }
            }
            return isEmailSent;
        }


        public List<Quantities> GetQuantityList()
        {
            List<Quantities> QuantityList = new List<Quantities>()
            {
                new Quantities() { QuanityText="1", Quantity="1" },
                new Quantities() { QuanityText="2", Quantity="2" },
                new Quantities() { QuanityText="3", Quantity="3" },
                new Quantities() { QuanityText="4", Quantity="4" },
                new Quantities() { QuanityText="5", Quantity="5" },
                new Quantities() { QuanityText="6", Quantity="6" },
                new Quantities() { QuanityText="7", Quantity="7" },
                new Quantities() { QuanityText="8", Quantity="8" },
                new Quantities() { QuanityText="9", Quantity="9" },
                new Quantities() { QuanityText="10", Quantity="10" },
                new Quantities() { QuanityText="11", Quantity="11" },
                new Quantities() { QuanityText="12", Quantity="12" },
                new Quantities() { QuanityText="13", Quantity="13" },
                new Quantities() { QuanityText="14", Quantity="14" },
                new Quantities() { QuanityText="15", Quantity="15" },
                new Quantities() { QuanityText="16", Quantity="16" },
                new Quantities() { QuanityText="17", Quantity="17" },
                new Quantities() { QuanityText="18", Quantity="18" },
                new Quantities() { QuanityText="19", Quantity="19" },
                new Quantities() { QuanityText="20", Quantity="20" }
            };

            return QuantityList;
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }

    }
}
