﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HBCDeliveryForms.Models
{
    public class MHFDeliveryManifest
    {
        
        public int MHFId { get; set; }
        public DateTime DeliveryDate { get; set; }
        public string DeliveryTime { get; set; }
        public string RequestedBy { get; set; }
        public string Banner { get; set; }
        public string CustomerName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public string PostalCode { get; set; }
        [Required(ErrorMessage = "This field is required.")]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid phone number")]
        public string HomePhone { get; set; }
        [Required(ErrorMessage = "This field is required.")]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid phone number")]
        public string Business { get; set; }
        [Required(ErrorMessage = "This field is required.")]
        [DataType(DataType.PhoneNumber)]
        [RegularExpression(@"^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$", ErrorMessage = "Not a valid phone number")]
        public string CellPhone { get; set; }
        [Required(ErrorMessage = "This field is required.")]
        public string DeliveryInfo { get; set; }
        public string BeddingPlaced { get; set; }
        public string PedestalAttched { get; set; }
        public string ApplianceLeveled { get; set; }
        public string WasherLeakTested { get; set; }
        public string RemovedPackaging { get; set; }
        public int LocationId { get; set; }
        public int M_ReasonId { get; set; }
        public bool isEmailSent { get; set; }
        public bool isCallback { get; set; }

        public List<MHFDeliveryDeliveryOrder> DeliveryOrdLst { get; set; }
        public List<MHFDeliveryHomePickupOrder> HomepickupList { get; set; }
        public List<MHFDeliverySlavagePurchased> PurchasedList { get; set; }

    }

    public class MHFDeliveryDeliveryOrder
    {
        public bool isChecked { get; set; }
        [Required(ErrorMessage = "This field is required.")]
        public string DeliveryOrder { get; set; }
        [Required(ErrorMessage = "This field is required.")]
        public string SkuDescription { get; set; }
        public Nullable<int> Quantity { get; set; }
        [Required(ErrorMessage = "This field is required.")]
        public string ProductStatus { get; set; }
        public string MerchandiseLocation { get; set; }
    }

    public class MHFDeliveryHomePickupOrder
    {
        public bool isChecked { get; set; }
        [Required(ErrorMessage = "This field is required.")]
        public string HomePickupOrder { get; set; }
        [Required(ErrorMessage = "This field is required.")]
        public string SkuDescription { get; set; }
        public string Quantity { get; set; }
        [Required(ErrorMessage = "This field is required.")]
        public string RMA { get; set; }
    }

    public class MHFDeliverySlavagePurchased
    {
        public bool isChecked { get; set; }
        [Required(ErrorMessage = "This field is required.")]
        public string SalvagePurchased { get; set; }
        [Required(ErrorMessage = "This field is required.")]
        public string BeddingorAppliance { get; set; }
        public string Quantity { get; set; }
    }




}