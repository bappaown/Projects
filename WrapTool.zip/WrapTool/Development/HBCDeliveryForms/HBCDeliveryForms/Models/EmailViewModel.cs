﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Web;

namespace HBCDeliveryForms.Models
{
    [Table("EmailDetails")]
    public class EmailViewModel
    {
        [Display(Name = "Form Id")]
        public int FormId { get; set; }

        [Display(Name = "Form Type")]
        public string FormType { get; set; }
        
        [Display(Name = "To Email")]
        //[EmailAddress(ErrorMessage = "Invalid Email Address")]
        [RegularExpression(@"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*([;,]\s*\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*)*", ErrorMessage = "Invalid Email Address")]
        public string ToEmail { get; set; }

        [Display(Name = "CC Email")]
        [RegularExpression(@"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*([;,]\s*\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*)*", ErrorMessage = "Invalid Email Address")]
        public string CCEmail { get; set; }

        [Display(Name = "BCC Email")]
        [RegularExpression(@"\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*([;,]\s*\w+([-+.]\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*)*", ErrorMessage = "Invalid Email Address")]
        public string BCCEmail { get; set; }

        [Display(Name = "Is Active")]
        public bool IsActive { get; set; }

        [Display(Name = "Created Date")]
        public DateTime CreatedDate { get; set; }

        [Display(Name = "Created By")]
        public int CreatedBy { get; set; }

        [Display(Name = "Modified Date")]
        public DateTime ModifiedDate { get; set; }

        [Display(Name = "Modified By")]
        public int ModifiedBy { get; set; }
    }
}