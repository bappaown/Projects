﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Core.Objects;
using System.Data.Entity.Infrastructure;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace HBCDeliveryForms.Models
{
    public class EmailContext : DbContext
    {
        public DbSet<EmailViewModel> EmailDetails { get; set; }
        WrapToolEntities entities = new WrapToolEntities();

        public EmailContext() : base("name=WrapToolEntities")
        {

        }

        public DbSet<EmailViewModel> GetEmailDetails()
        {
            DbSet<EmailViewModel> result = null;

            return result;
        }

        //public ObjectResult<EmailViewModel> GetEmailDetailsFromDB(EmailViewModel emailViewModel)
        public DataSet GetAllEmailDetails(EmailViewModel emailViewModel)
        {
            String query = String.Format("Select * from EmailDetails");
            SqlConnection connection = (SqlConnection)this.Database.Connection;
            SqlCommand command = new SqlCommand(query, connection);

            this.Database.Connection.Open();

            SqlDataAdapter dataAdapter = new SqlDataAdapter();
            DataSet objDataset = new DataSet();
            dataAdapter.SelectCommand = command;
            dataAdapter.Fill(objDataset);

            this.Database.Connection.Close();
            return objDataset;
        }

        public DataSet GetEmailDetails(int formId)
        {
            String query = String.Format("Select * from EmailDetails where formID = " + formId);
            SqlConnection connection = (SqlConnection)this.Database.Connection;
            SqlCommand command = new SqlCommand(query, connection);

            this.Database.Connection.Open();

            SqlDataAdapter dataAdapter = new SqlDataAdapter();
            DataSet objDataset = new DataSet();
            dataAdapter.SelectCommand = command;
            dataAdapter.Fill(objDataset);

            this.Database.Connection.Close();
            return objDataset;
        }
        public int UpdateEmailDetails(EmailViewModel emailViewModel)
        {
            String query = "Update EmailDetails SET ToEmail = '" + emailViewModel.ToEmail + "', CCEmail= '" + emailViewModel.CCEmail + "', BCCEmail = '" + emailViewModel.BCCEmail + "', IsActive= " + (emailViewModel.IsActive ? 1 : 0) + ", ModifiedBy= " + emailViewModel.ModifiedBy + ", ModifiedDate = CURRENT_TIMESTAMP where FormType='" + emailViewModel.FormType + "'";
            SqlConnection connection = (SqlConnection)this.Database.Connection;
            SqlCommand command = new SqlCommand(query, connection);

            this.Database.Connection.Open();

            int result = command.ExecuteNonQuery();
            this.Database.Connection.Close();
            return result;
        }

        public DataSet GetAuthenticate(string userid, string password)
        {
            DataSet ds = new DataSet();
            using (SqlConnection conn = (SqlConnection)this.Database.Connection)
            {
                //SqlConnection conn = (SqlConnection)this.Database.Connection;
                SqlCommand sqlComm = new SqlCommand("proc_GetAuthenticate", conn);
                sqlComm.Parameters.AddWithValue("@UserID", userid);
                sqlComm.Parameters.AddWithValue("@Password", password);
                sqlComm.CommandType = CommandType.StoredProcedure;
                SqlDataAdapter da = new SqlDataAdapter();
                da.SelectCommand = sqlComm;
                da.Fill(ds);
            }
            return ds;
        }
    }
}


