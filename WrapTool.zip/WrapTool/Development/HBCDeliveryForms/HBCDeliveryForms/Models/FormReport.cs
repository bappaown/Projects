﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HBCDeliveryForms.Models
{
    public class FormReport
    {
        public int FormId { get; set; }
        public DateTime FromDate { get; set; }
        public DateTime ToDate { get; set; }
    }
}