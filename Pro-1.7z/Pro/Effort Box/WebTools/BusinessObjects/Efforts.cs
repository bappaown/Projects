﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class Efforts
    {
        [DataMember]
        public string service { get; set; }
        [DataMember]
        public string type { get; set; }
        [DataMember]
        public string details { get; set; }       
        [DataMember]
        public string hours { get; set; }
    }
}
