﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class EffortDetails
    {
        [DataMember]
        public string Service { get; set; }
        [DataMember]
        public string Type { get; set; }
        [DataMember]
        public string Details { get; set; }       
        [DataMember]
        public string Hours { get; set; }
        [DataMember]
        public string Date { get; set; }
        [DataMember]
        public string UserId { get; set; }
        [DataMember]
        public string UserName { get; set; }
        [DataMember]
        public string CreateDate { get; set; }
    }
}
