﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class ApplicationDetails
    {
        [DataMember]
        public DateTime CycleStartDate { get; set; }
        [DataMember]
        public DateTime CycleEndDate { get; set; }
        [DataMember]
        public int QuaterId { get; set; }
        [DataMember]
        public bool IsActive { get; set; }
        [DataMember]
        public string QuestionFileName { get; set; }
        [DataMember]
        public byte QuestionFile { get; set; }
    }
}
