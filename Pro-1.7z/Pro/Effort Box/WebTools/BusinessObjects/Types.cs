﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class Types
    {
        [DataMember]
        public int TypeId { get; set; }
        [DataMember]
        public string Type { get; set; }
        [DataMember]
        public string TypeDesciption { get; set; }
    }
}
