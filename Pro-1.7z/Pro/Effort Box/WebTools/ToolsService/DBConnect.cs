﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace ToolsService
{
    public static class DBConnect
    {
        private static string connectionString = System.Configuration.ConfigurationManager.ConnectionStrings["FeedbackConnection"].ToString();

        public static SqlConnection CreateConnection()
        {
            SqlConnection connection = new SqlConnection(connectionString);
            return connection;
        }

    }
}
