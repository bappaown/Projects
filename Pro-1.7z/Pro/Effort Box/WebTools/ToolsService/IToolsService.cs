﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using BusinessObjects;

namespace ToolsService
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IToolsService" in both code and config file together.
    [ServiceContract]
    public interface IToolsService
    {
        [OperationContract]
        bool UploadUsers(List<User> Users);

        [OperationContract]
        bool SubmitUsers(List<User> Users);

        [OperationContract]
        bool UploadProjects(List<Project> Projects);

        [OperationContract]
        bool UploadUserProjects(List<UserProject> UserProjects);

        [OperationContract]
        bool UploadQuestion(List<Question> Questions);

        [OperationContract]
        bool SubmitFeedback(List<Feedback> feedBack);

        [OperationContract]
        List<Category> GetCategories();

        [OperationContract]
        List<Question> GetQuestions();

        [OperationContract]
        bool UpdateQuesttionFile(QuestionFile questionFile);

        [OperationContract]
        List<UserType> GetUserType();

        [OperationContract]
        List<EfficiencyMaster> GetEfficiencyMaster();

        [OperationContract]
        List<AnswerPriorityMaster> GetAnswerPriority();

        [OperationContract]
        List<QuaterDetails> GetQuaterDetail();

        [OperationContract]
        List<QuestionDetails> GetQuestionDetails();

        [OperationContract]
        DisplayFeedbackReport GetFeedbackReport(string userId, int feedYear, int quaterId);

        [OperationContract]
        List<DisplayFeedbackResult> GetFeedbackResult(string ratingfromA, string ratingfromB, string ratingtoB, string ratingfromC, string ratingtoC, string ratingfromD, string topuser, string feedbackYear, string quaterId);

        [OperationContract]
        List<User> GetPeersOfEmpolyee(string userId, string searchBy);

        [OperationContract]
        string GetMaxUniqueCode();

        [OperationContract]
        List<UserDetails> SearchEmployee(string searchEmpName, string userId);

        [OperationContract]
        MasterDataWrapper GetMastarData(string userId);

        [OperationContract]
        bool SubmitProjects(List<Project> Projects);

        [OperationContract]
        bool SubmitUserProjects(List<UserProject> UserProject);

        [OperationContract]
        bool FeedbackCalculation();

        [OperationContract]
        string ValidateUserDetails(string UserMailId);
    }
}
