using System;
using System.Collections.Generic;
using System.Text;
using System.DirectoryServices;
using System.Collections;
using System.Data;
using System.Text.RegularExpressions;

namespace Utility
{
    public class ActiveDs
    {
        private const string SERVERCOMMENT = "Leaf";//unused
        private const string IISHOST = "IIS://LocalHost";//unused

        #region PROPERTIES

        private string m_windowsDomain = string.Empty;
        private string m_DomainName = string.Empty;
        private string m_groupString = string.Empty;
        private string m_CN = string.Empty;

        public string WindowsDomain
        {
            get
            {
                return m_windowsDomain;
            }
            set
            {
                m_windowsDomain = value;
            }
        }
        public string CN
        {
            get
            {
                return m_CN;
            }
            set
            {
                m_CN = value;
            }
        }
        public string Domain
        {
            get
            {
                return m_DomainName;
            }
            set
            {
                m_DomainName = value;
            }
        }
        public string WindowsGroups
        {
            get
            {
                return m_groupString;
            }
            set
            {
                m_groupString = value;
            }
        }

        #endregion PROPERTIES

        #region NOTCALLED METHODS

        public SearchResult GetUserProfile()
        {
            DirectoryEntry DirEntry = new DirectoryEntry("LDAP://" + this.Domain);
            DirectorySearcher Searcher = new DirectorySearcher(DirEntry);
            SearchResult oneresult = null;

            try
            {
                Searcher.Filter = "(&(objectClass=user)(objectCategory=person)(cn=" + this.CN + "))";
                oneresult = Searcher.FindOne();
            }
            catch (Exception exPrf)
            {
                throw exPrf;
            }
            finally
            {
                Searcher.Dispose();
                DirEntry.Close();
            }

            return oneresult;
        }

        public SortedList MembersCollection()
        {

            //Hashtable hTable = new Hashtable();
            SortedList sortList = new SortedList();

            DirectoryEntry x = null;

            try
            {
                LDAP ad = new LDAP();
                ad.ADsPath = "LDAP://" + this.Domain;
                DirectoryEntry dirEntry = ad.GetDirectoryEntrybyLDAPPath();

                foreach (string grp in this.WindowsGroups.Split(Common.SEPARATOR_SEMICOLUMN.ToCharArray()))
                {

                    DirectorySearcher dirSearcher = new DirectorySearcher();
                    dirSearcher.SearchRoot = dirEntry;

                    /*string[] ArrAttribs = new string[] {"name", "SN"};

                    dirSearcher.PropertiesToLoad.AddRange(ArrAttribs);
                    dirSearcher.Sort.PropertyName = "name";
                    dirSearcher.Sort.Direction = SortDirection.Ascending; 
                    */
                    dirSearcher.Filter = "(&(objectClass=group) (cn=" + grp + "))";
                    SearchResultCollection results = dirSearcher.FindAll();

                    if (results.Count > 0)
                    {
                        object members = GroupMembers(results[0].Path);

                        foreach (object member in (IEnumerable)members)
                        {
                            x = new DirectoryEntry(member);
                            string adsName = x.Properties["name"][0].ToString();
                            string adssamAcName = this.WindowsDomain + "\\" + x.Properties["samAccountName"][0].ToString();

                            if (!sortList.ContainsKey(adsName)) { sortList.Add(adsName, adssamAcName); }

                        }

                    }
                }

            }
            catch (Exception dsEx)
            {
                throw dsEx;
            }
            return sortList;
        }

        private object GroupMembers(string adsPath)
        {
            LDAP ad = new LDAP();
            ad.ADsPath = adsPath;

            DirectoryEntry group = ad.GetDirectoryEntrybyLDAPPath();
            object members = group.Invoke("Members", null);

            return members;
        }

        // Get physical path from Virtual Directory..
        private static string MetabasePath()
        {
            return IISHOST + "/W3SVC/" + GetIISSiteName();

        }
        private static string GetIISSiteName()
        {
            string adsiPath = IISHOST + "/W3SVC";
            DirectoryEntry entry = new DirectoryEntry(adsiPath);
            foreach (DirectoryEntry site in entry.Children)
            {
                if (site.SchemaClassName == "IIsWebServer" && site.Properties["ServerComment"].Value.ToString().Equals(SERVERCOMMENT))
                {
                    return site.Name;
                }
            }
            return "";
        }
        public static string GetPhysicalPath(string _vdName)
        {

            DirectoryEntry site = new DirectoryEntry(MetabasePath() + "/Root/" + _vdName);

            string _phyPath = string.Empty;

            try
            {
                _phyPath = site.Properties["Path"].Value.ToString();
            }
            catch { }

            return _phyPath;
        }

        #endregion NOTCALLED METHODS

        #region LOAD USER DETAILS IN LIST

        public static List<string> GetUsersDetail(string userName, string domainName)
        {
            return LoadUserDetails(userName, domainName, string.Empty, string.Empty);
        }
        public static List<string> GetUsersDetailByMail(string mailId, string domainName)
        {
            return LoadUserDetailsByMail(mailId, domainName, string.Empty, string.Empty);
        }

        public static List<string> LoadUserDetails(string userName, string adPath, string aduserName, string adPassword)
        {
            if (userName.IndexOf("\\") > -1)
                userName = userName.Substring(userName.IndexOf("\\") + 1);
            List<string> userDetails = null;
            using (DirectorySearcher searcher = new DirectorySearcher())
            {
                userDetails = new List<string>();
                searcher.SearchRoot = ActiveDs.GetDirectoryEntry(adPath, aduserName, adPassword);
                searcher.SearchScope = SearchScope.Subtree;
                searcher.Filter = String.Format("(samaccountname={0})", userName);
                searcher.Filter = String.Format("(samaccountname={0})", userName);

                foreach (SearchResult sResultSet in searcher.FindAll())
                {
                    List<String> propertyCollection = LoadProperties();
                    for (int i = 0; i < propertyCollection.Count; i++)
                    {
                        userDetails.Add(GetProperty(sResultSet, propertyCollection[i]));
                    }
                }
            }

            return userDetails;
        }

        public static List<string> LoadUserDetailsByMail(string mailId, string adPath, string aduserName, string adPassword)
        {
            List<string> userDetails = null;
            using (DirectorySearcher searcher = new DirectorySearcher())
            {
                userDetails = new List<string>();
                searcher.SearchRoot = ActiveDs.GetDirectoryEntry(adPath, aduserName, adPassword);
                searcher.SearchScope = SearchScope.Subtree;
                searcher.Filter = String.Format("(mail={0})", mailId);

                foreach (SearchResult sResultSet in searcher.FindAll())
                {
                    List<String> propertyCollection = LoadProperties();
                    for (int i = 0; i < propertyCollection.Count; i++)
                    {
                        userDetails.Add(GetProperty(sResultSet, propertyCollection[i]));
                    }
                }
            }

            return userDetails;
        }

        public static List<string> SearchUserDetailsByName(string groupName, string adPath, string aduserName, string adPassword, string searchName)
        {
            List<string> userDetails = null;
            string users = string.Empty;
            string userMail = string.Empty;
            string userId = string.Empty;
            SearchResult result;
            using (DirectorySearcher search = new DirectorySearcher(GetDirectoryEntry(adPath, aduserName, aduserName)))
            {
                search.Filter = String.Format("(cn={0})", groupName);
                search.PropertiesToLoad.Add("member");
                result = search.FindOne();

                if (result != null)
                {
                    userDetails = new List<string>();
                    for (int counter = 0; counter < result.Properties["member"].Count; counter++)
                    {
                        string user = (string)result.Properties["member"][counter];
                        string searchedUser = string.Empty;
                        string userName = string.Empty;
                        if (user.IndexOf("OU") > -1 && user.Length > 0)
                        {
                            int _retCN = user.IndexOf("OU", 0, user.Length);
                            string _gCName = user.Substring(0, _retCN);
                            string[] arInfo = new string[2];
                            char[] splitter = { '=' };
                            arInfo = _gCName.Split(splitter);
                            string _groupName = arInfo[1].Replace("\\", "");
                            searchedUser = "(cn=" + _groupName.Remove(_groupName.Length - 1, 1) + ")";
                            userName = searchedUser.Replace("(contracted)", "").Trim();
                        }
                        int Counter = Regex.Matches(userName.ToLower(), searchName.ToLower()).Count;
                        if (Counter > 0)
                        {
                            using (DirectorySearcher searcher = new DirectorySearcher())
                            {
                                searcher.SearchRoot = ActiveDs.GetDirectoryEntry(adPath, aduserName, adPassword);
                                searcher.SearchScope = SearchScope.Subtree;
                                searcher.Filter = searchedUser;// String.Format("(cn={0})", users);
                                string UserId = string.Empty;
                                string UserName = string.Empty;
                                string EMailId = string.Empty;
                                foreach (SearchResult sResultSet in searcher.FindAll())
                                {
                                    string[] arrName = GetProperty(sResultSet, "cn").Split(',');
                                    string firstName = arrName[1];
                                    firstName = firstName.Replace("(contracted)", "").Trim();

                                    UserName = firstName + " " + arrName[0].ToString();
                                    UserId = GetProperty(sResultSet, "samaccountname");
                                    EMailId = GetProperty(sResultSet, "mail"); ;
                                    userDetails.Add(UserName + " [ PMI\\" + UserId + " , " + EMailId + " ]");
                                }
                            }
                        }
                    }
                }

            }

            return userDetails;
        }


        private static List<string> LoadProperties()
        {
            List<string> properties = new List<string>();
            properties.Add("samaccountname");
            properties.Add("cn");
            properties.Add("mail");
            return properties;
        }

        #endregion LOAD USER DETAILS IN LIST

        #region CHECK IF USER BELONGS TO THE GROUP

        public static bool IsADGroupUsers(string groupName, string adPath, string aduserName, string adPassword, string currUser, bool searchSubtree = false)
        {
            bool existUser = false;
            SearchResult result;
            using (DirectorySearcher search = new DirectorySearcher(ActiveDs.GetDirectoryEntry(adPath, aduserName, adPassword)))
            {
                search.Filter = String.Format("(cn={0})", groupName);

                if (searchSubtree)
                {
                    search.SearchScope = SearchScope.Subtree;
                    result = search.FindOne();
                    if (result != null)
                        if (string.Equals(currUser.Replace("PMI\\", ""), GetProperty(result, "samaccountname")))
                            existUser = true;
                }
                else
                {
                    search.PropertiesToLoad.Add("member");
                    result = search.FindOne();
                }

                if (existUser == false && result != null)
                {
                    for (int counter = 0; counter < result.Properties["member"].Count; counter++)
                    {
                        string user = (string)result.Properties["member"][counter];
                        string searchedUser = string.Empty;
                        if (user.IndexOf("OU") > -1 && user.Length > 0)
                        {
                            int _retCN = user.IndexOf("OU", 0, user.Length);
                            string _gCName = user.Substring(0, _retCN);
                            string[] arInfo = new string[2];
                            char[] splitter = { '=' };
                            arInfo = _gCName.Split(splitter);
                            string _groupName = arInfo[1].Replace("\\", "");
                            searchedUser = _groupName.Remove(_groupName.Length - 1, 1);
                        }
                        List<string> lstUserDetail = GetUsersDetail(currUser, adPath);
                        if (lstUserDetail != null && lstUserDetail.Count > 0)
                        {
                            currUser = lstUserDetail[1];
                        }

                        if (currUser == searchedUser)
                            existUser = true;
                        else if (searchedUser != string.Empty && isGroup(searchedUser, adPath, aduserName, adPassword))
                            existUser = ActiveDs.IsADGroupUsers(searchedUser, adPath, aduserName, adPassword, currUser);
                        else
                            existUser = ActiveDs.IsADGroupUsers(searchedUser, adPath, aduserName, adPassword, currUser, true);

                        if (existUser == true)
                            break;
                    }
                }

            }
            return existUser;
        }

        private static bool isGroup(string groupName, string adPath, string aduserName, string adPassword)
        {
            SearchResult result;
            using (DirectorySearcher search = new DirectorySearcher(ActiveDs.GetDirectoryEntry(adPath, aduserName, adPassword)))
            {
                search.Filter = String.Format("(&(objectClass=group)(cn={0}))", groupName);
                search.PropertiesToLoad.Add("member");
                result = search.FindOne();

                if (result != null)
                    return true;
                return false;
            }
        }

        #endregion CHECK IF USER BELONGS TO THE GROUP

        #region FIND ALL USERS DETAILS BELONGING TO A GROUP

        public static DataTable GetADGroupUsers(string groupName, string adPath, string aduserName, string adPassword)
        {
            DataTable dtUserDetails = new DataTable();
            dtUserDetails.Columns.Add(new DataColumn("UserName", typeof(string)));
            dtUserDetails.Columns.Add(new DataColumn("DisplayUsername", typeof(string)));
            dtUserDetails.Columns.Add(new DataColumn("UserId", typeof(string)));
            dtUserDetails.Columns.Add(new DataColumn("EMailId", typeof(string)));

            string users = string.Empty;
            string userMail = string.Empty;
            string userId = string.Empty;
            SearchResult result;
            using (DirectorySearcher search = new DirectorySearcher(GetDirectoryEntry(adPath, aduserName, adPassword)))
            {
                search.Filter = String.Format("(cn={0})", groupName);
                search.PropertiesToLoad.Add("member");
                result = search.FindOne();

                if (result != null)
                {
                    for (int counter = 0; counter < result.Properties["member"].Count; counter++)
                    {
                        string user = (string)result.Properties["member"][counter];
                        string searchedUser = string.Empty;
                        //string userMail = string.Empty;
                        if (user.IndexOf("OU") > -1 && user.Length > 0)
                        {
                            int _retCN = user.IndexOf("OU", 0, user.Length);
                            string _gCName = user.Substring(0, _retCN);
                            string[] arInfo = new string[2];
                            char[] splitter = { '=' };
                            arInfo = _gCName.Split(splitter);
                            string _groupName = arInfo[1].Replace("\\", "");
                            searchedUser = "(cn=" + _groupName.Remove(_groupName.Length - 1, 1) + ")";
                        }
                        users = users + searchedUser;
                    }
                    users = "(|" + users + ")";
                    using (DirectorySearcher searcher = new DirectorySearcher())
                    {
                        searcher.SearchRoot = ActiveDs.GetDirectoryEntry(adPath, aduserName, adPassword);
                        searcher.SearchScope = SearchScope.Subtree;
                        searcher.Filter = users;// String.Format("(cn={0})", users);
                        string userDetails = string.Empty;
                        foreach (SearchResult sResultSet in searcher.FindAll())
                        {
                            DataRow dr = dtUserDetails.NewRow();
                            dr["UserName"] = GetProperty(sResultSet, "cn");
                            dr["DisplayUsername"] = GetProperty(sResultSet, "cn").Replace("(contracted)", "").Trim() + " (" + GetProperty(sResultSet, "samaccountname") + ")";
                            dr["UserId"] = GetProperty(sResultSet, "samaccountname");
                            dr["EMailId"] = GetProperty(sResultSet, "mail"); ;
                            dtUserDetails.Rows.Add(dr);
                        }
                    }
                }

            }
            return dtUserDetails;
        }

        #endregion FIND ALL USERS DETAILS BELONGING TO A GROUP

        public static List<string> GetApproversEmailId(string strGroup, string strDomainName, string aduserName, string adPassword)
        {
            DataTable dtUserDetails = GetADGroupUsers(strGroup, strDomainName, aduserName, adPassword);
            List<string> lstMailIds = new List<string>();

            for (int row = 0; row < dtUserDetails.Rows.Count; row++)
            {
                lstMailIds.Add(dtUserDetails.Rows[row]["EMailId"].ToString());
            }
            return lstMailIds;
        }

        #region UTIL METHOD

        public static DirectoryEntry GetDirectoryEntry(string adPath, string aduserName, string adPassword)
        {
            using (DirectoryEntry de = new DirectoryEntry())
            {
                de.Path = adPath.Length > 0 ? adPath : null;
                de.Username = aduserName.Length > 0 ? aduserName : null;
                de.Password = adPassword.Length > 0 ? adPassword : null;
                return de;
            }
        }

        private static string GetProperty(SearchResult searchResult, string PropertyName)
        {
            return searchResult.Properties.Contains(PropertyName) == true ? searchResult.Properties[PropertyName][0].ToString() : string.Empty;
        }

        #endregion UTIL METHOD
    }
}
