using System;
using System.Configuration;
using System.Net.Mail;

namespace Utility
{
    public class Mailer
    {
        public bool SendMail(string mailFrom, string[] mailToList, string mailCC, string mailSubject, string mailBody, string attachmentFile)
        {
            MailMessage msgMail = new MailMessage();
            bool retVal = true;
            try
            {
                bool isMailerInDLlist = false;
                MailAddress MailFrom = new MailAddress(mailFrom);
                msgMail.From = MailFrom;
                for (int index = 0; index < mailToList.Length; index++)
                {
                    msgMail.To.Add(mailToList[index]);
                    if (mailToList[index].ToString().Trim().ToLower() == mailCC.ToLower())
                    {
                        isMailerInDLlist = true;
                    }
                }

                if (isMailerInDLlist == false)
                {
                    msgMail.CC.Add(mailCC);
                }
                msgMail.Subject = mailSubject;
                msgMail.Body = mailBody;

                if (attachmentFile.Length > 0)
                {
                    Attachment attachedFile = new Attachment(attachmentFile);
                    msgMail.Attachments.Add(attachedFile);
                }
                msgMail.IsBodyHtml = true;
                SmtpClient SmtpMail = new SmtpClient(ConfigurationManager.AppSettings["SMTPHost"]);
                SmtpMail.Timeout = 100000;
                SmtpMail.Credentials = System.Net.CredentialCache.DefaultNetworkCredentials; 
                SmtpMail.Send(msgMail);
                retVal = true;
            }
            catch (Exception ex)
            {
                Utility.Common UCommon = new Common();
                UCommon.WriteLog(ex);
                retVal = false;
            }
            finally
            {
                msgMail.Dispose();
            }
            return retVal;
        }
        public bool SendMail(string emailFrom, string[] emailToList, string mailCC, string mailSubject, string mailBody)
        {
            return SendMail(emailFrom, emailToList, mailCC, mailSubject, mailBody, string.Empty);
        }
    }
}