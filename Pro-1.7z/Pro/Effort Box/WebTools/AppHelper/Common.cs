using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Text;
using System.Web;
using System.Web.Configuration;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using Utility;

namespace Utility
{
    public class Common : System.Web.UI.Page
    {
        #region CONSTANTS & VARIABLES

        //constants
        public const string SEPARATOR_SEMICOLUMN = ";";
        public const string SEPARATOR_BACKSLASH = "\\";
        public const string SEPARATOR_COLUMN = ":";

        //variables
        public string strDomainName = string.Empty;
        public string strAdGroups = string.Empty;
        public string UserId = string.Empty;

        #endregion


        public Common()
        {
            strDomainName = ConfigurationManager.AppSettings["ADPath"].ToString();
            strAdGroups = ConfigurationManager.AppSettings["ADGroup"].ToString();
        }

        private void SetGlobalValues()
        {
            strDomainName = ConfigurationManager.AppSettings["ADPath"].ToString();
            strAdGroups = ConfigurationManager.AppSettings["ADGroup"].ToString();

        }

        #region COMMON METHOD


        /// <summary>
        /// convert datatable to JSON , output format List<Dictionary<string, object>> 
        /// </summary>
        /// <param name="table"></param>
        /// <returns>List<Dictionary<string, object>></returns>
        public List<Dictionary<string, object>> DataTableToJson(DataTable table)
        {
            List<Dictionary<string, object>> list = new List<Dictionary<string, object>>();
            foreach (DataRow row in table.Rows)
            {
                Dictionary<string, object> dict = new Dictionary<string, object>();
                foreach (DataColumn col in table.Columns)
                {
                    dict[col.ColumnName] = Convert.ToString(row[col]);
                }
                list.Add(dict);
            }
            return list;
        }

        public string IsUser()
        {
            string cIsUser = "NO";

            if (IsValidUser())
                cIsUser = "YES";
            else
                cIsUser = "NO";

            return cIsUser;
        }

        public bool IsValidUser()
        {
            bool retVal = false;
            if (Session["IsValidUser"] == null)
            {
                foreach (string Addgrp in strAdGroups.Split(';'))
                {
                    //if (!string.IsNullOrEmpty(Addgrp.Trim()))
                    string currUser = HttpContext.Current.User.Identity.Name;
                    currUser = (currUser.IndexOf('-') > 0 ? currUser.Replace("a-", "") : currUser);
                    Session["IsValidUser"] = retVal = ActiveDs.IsADGroupUsers(Addgrp.Trim(), strDomainName, string.Empty, string.Empty, currUser);

                    if (retVal)
                        break;
                }
            }
            else
            {
                retVal = Convert.ToBoolean(Session["IsValidUser"]);
            }

            return retVal;
        }

        public DataTable GetValidUserList()
        {
            return ActiveDs.GetADGroupUsers(strAdGroups, strDomainName, string.Empty, string.Empty);
        }

        public string GenerateUniqueCode(string uniqueCode)
        {
            Int64 strUniqueCode = Convert.ToInt64(uniqueCode) + 1;
            return strUniqueCode.ToString();
        }
        public enum UserTypes
        {
            PEER = 1,
            MANAGER = 2,
            TL = 3,
            ADMIN = 4,
            ALL = 5,
            PMO = 6,
            ARCHITECT = 7,
            LTE = 8
        }



        #endregion COMMON CODE

        #region MASTERPAGE CODE

        public Dictionary<string, object> UserName()
        {
            string strUserId = HttpContext.Current.User.Identity.Name;
            UserId = (strUserId.IndexOf('-') > 0 ? strUserId.Replace("a-", "") : strUserId);
            SetGlobalValues();

            Dictionary<string, object> dicUserDetail = new Dictionary<string, object>();
            if (Session["UserName"] == null)
            {
                string strGroupName = string.Empty;
                if (IsValidUser())
                {
                    strGroupName = strAdGroups;
                }
                else
                {
                    //go to log out page, not an authorised viewer
                }

                Session["UserName"] = GetUserParameters(HttpContext.Current.User.Identity.Name, "FULLNAME");
                Session["UID"] = UserId;
                dicUserDetail.Add("UserName", Session["UserName"]);
            }
            else
            {
                dicUserDetail.Add("UserName", Session["UserName"]);
            }
            return (dicUserDetail);
        }

        public List<string> GetMailIds(string strGroupName)
        {
            List<string> lstMailIds = new List<string>();
            switch (strGroupName)
            {
                case "USERS": strGroupName = strAdGroups; break;
                default: strGroupName = strAdGroups; break;
            }
            if (lstMailIds.Count > 0)
                return lstMailIds;
            else
                return ActiveDs.GetApproversEmailId(strGroupName, strDomainName, string.Empty, string.Empty);
        }

        /// <summary>
        ///  string UserCompleteMailId = UCommon.GetUserParameters(userMailId, "EMAIL");
        ///  string   UserName = UCommon.GetUserParameters(userMailId, "NAME");
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="param"></param>
        /// <returns></returns>
        public string GetUserParameters(string userId, string param)
        {
            userId = (userId.IndexOf('-') > 0 ? userId.Replace("a-", "") : userId);
            List<string> lstUserDetail = ActiveDs.GetUsersDetail(userId, strDomainName);
            string retVal = string.Empty;
            string name = lstUserDetail[1];
            name = name.Substring(name.IndexOf(',') + 1, (name.Length - name.IndexOf(',')) - 1);
            name = name.Replace("(contracted)", "").Trim();

            switch (param)
            {
                case "FULLNAME": retVal = name;
                    break;
                case "EMAIL": retVal = lstUserDetail[2];
                    break;
                case "NAME": retVal = name;
                    break;
                default: retVal = string.Empty;
                    break;
            }
            return retVal;
        }

        public Dictionary<string, string> GetUserParameters(string userId)
        {
            userId = (userId.IndexOf('-') > 0 ? userId.Replace("a-", "") : userId);
            List<string> lstUserDetail = ActiveDs.GetUsersDetail(userId, strDomainName);
            string retVal = string.Empty;
            string name = string.Empty;

            Dictionary<string, string> userDetails = new Dictionary<string, string>();
            if (lstUserDetail != null && lstUserDetail.Count > 0)
            {
                string[] arrName = lstUserDetail[1].Split(',');

                string firstName = arrName[1];
                firstName = firstName.Replace("(contracted)", "").Trim();
                name = firstName + " " + arrName[0].ToString();

                userDetails.Add(userId, name + "|" + lstUserDetail[2]);
            }
            return userDetails;
        }

        public Dictionary<string, string> GetUserParametersByMail(string mailID)
        {
            List<string> lstUserDetail = ActiveDs.GetUsersDetailByMail(mailID, strDomainName);
            string retVal = string.Empty;
            string name = string.Empty;
            Dictionary<string, string> userDetails = new Dictionary<string, string>();
            if (lstUserDetail != null && lstUserDetail.Count > 0)
            {
                string[] arrName = lstUserDetail[1].Split(',');

                string firstName = arrName[1];
                firstName = firstName.Replace("(contracted)", "").Trim();
                name = firstName + " " + arrName[0].ToString();

                userDetails.Add(mailID, name + "|" + lstUserDetail[0]);
            }
            return userDetails;
        }

        public List<string> GetUserParametersByName(string searchName)
        {
            List<string> lstUserDetail = new List<string>();
            List<string> lstUser = new List<string>();
            foreach (string Addgrp in strAdGroups.Split(';'))
            {
                if (!string.IsNullOrEmpty(Addgrp))
                {
                    lstUserDetail = ActiveDs.SearchUserDetailsByName(Addgrp.Trim(), strDomainName, string.Empty, string.Empty, searchName.Trim());
                    if (lstUserDetail != null)
                        lstUser.AddRange(lstUserDetail);
                }
            }

            return lstUser;
        }

        #region ENCRYPTION

        public string GetEncryptedValue(int record)
        {
            return CryptoUtil.EncryptString[Convert.ToString(record)];
        }

        public int GetDecryptedValue(string strRecord)
        {
            return Convert.ToInt32(CryptoUtil.DecryptString[strRecord]);
        }

        #endregion ENCRYPTION

        #region LOGING

        public void WriteLog(Object objError)
        {
            if (ConfigurationManager.AppSettings.Get("EventErrorLog") != null && ConfigurationManager.AppSettings["EventErrorLog"] == "1")
            {
                bool IsException = false;
                Exception ex = null;
                String exMsg = string.Empty;
                if (objError is Exception)
                {
                    IsException = true;
                    ex = (Exception)objError;
                }
                else
                {
                    exMsg = (String)objError;
                }

                String FilePath = "";
                FilePath = System.Configuration.ConfigurationManager.AppSettings["CQTALogFilePath"].ToString() + "\\" + System.Configuration.ConfigurationManager.AppSettings["CQTALogFile"].ToString();
                String UserTime = "[ " + DateTime.Now.ToString() + " ]: " + HttpContext.Current.User.Identity.Name + " --  ";
                FileInfo FI = new FileInfo(FilePath);
                if (FI.Exists)
                {
                    StreamWriter file = new StreamWriter(FilePath, true);
                    file.WriteLine(IsException ? UserTime + ex.ToString() : UserTime + exMsg);
                    file.WriteLine(IsException ? UserTime + ex.Source.ToString() : "");
                    file.Close();
                }
                else
                {
                    StreamWriter SW;
                    SW = File.CreateText(FilePath);
                    SW.WriteLine(IsException ? UserTime + ex.ToString() : UserTime + exMsg);
                    SW.WriteLine(IsException ? UserTime + ex.Source.ToString() : "");
                    SW.Close();
                }
            }
        }

        #endregion LOGING

        public string ReadConfigData(string record)
        {
            return ConfigurationManager.AppSettings[record].ToString();
        }

        #endregion
    }
}
