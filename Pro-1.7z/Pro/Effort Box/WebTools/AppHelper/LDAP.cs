using System;
using System.Collections.Generic;
using System.Text;
using System.DirectoryServices;

namespace Utility
{
    internal class LDAP
    {
        private string m_adsPath = string.Empty;

        public string ADsPath
        {
            get { return m_adsPath; }
            set { m_adsPath = value; }
        }
        public DirectoryEntry GetDirectoryEntrybyLDAPPath()
        {
            DirectoryEntry dirEntry = null;
            try
            {
                dirEntry = new DirectoryEntry(this.ADsPath);
                dirEntry.AuthenticationType = AuthenticationTypes.Secure;
            }
            catch (Exception ldapEx)
            {
                throw ldapEx;
            }
            
            return dirEntry;
        }

    }
}
