using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Security.Cryptography;
using System.Xml;
using System.Text;
using System.IO;
using System.Collections;

/// <summary>
/// Summary description for CryptoUtil
/// </summary>
public class CryptoUtil
{
    private static byte[] key = { };
    private static byte[] IV = { 0x12, 0x34, 0x56, 0x78, 0x90, 0xAB, 0xCD, 0xEF };
    private static string EncryptionKey = ConfigurationManager.AppSettings["EncryptionKey"];
    public byte Mode = 0;
    private string _OriginalString;
    private string _EncryptedString;

    private string DESKey = ConfigurationManager.AppSettings["EncryptionKey"];
    private string DESIV = ConfigurationManager.AppSettings["EncryptionIV"];

    public string this[string parameterName]
    {
        get
        {
            _OriginalString = "";
            _EncryptedString = "";
            if (Mode == 0)
            {
                _EncryptedString = EncryptStringValue(String.Format("{0}", parameterName));
                return String.Format("?ID={0}", _EncryptedString);
            }
            else if (Mode == 1)
            {
                if (!String.IsNullOrEmpty(HttpContext.Current.Request.QueryString["ID"]))
                {
                    _EncryptedString = HttpContext.Current.Request.QueryString["ID"];
                    _OriginalString = DecryptStringValue(_EncryptedString);
                }
                foreach (string _TempQueryString in _OriginalString.Split('&'))
                {
                    string[] _TempName = _TempQueryString.Split('=');
                    if (_TempName[0] == parameterName)
                    {
                        return _TempName[1];
                    }
                }
            }
            else if (Mode == 2)
            {
                _OriginalString = DecryptStringValue(parameterName);
                return _OriginalString;
            }
            else if (Mode == 3)
            {
                _EncryptedString = EncryptStringValue(parameterName);
                return _EncryptedString;
            }

            return String.Empty;
        }
    }

    private CryptoUtil()
    {

    }
    private string DecryptStringValue(string stringToDecrypt)
    {
        stringToDecrypt = stringToDecrypt.Replace(" ", "+");
        byte[] key;
        byte[] IV;

        byte[] inputByteArray;
        try
        {
            key = Convert2ByteArray(DESKey);
            IV = Convert2ByteArray(DESIV);
            int len = stringToDecrypt.Length; inputByteArray = Convert.FromBase64String(stringToDecrypt);
            DESCryptoServiceProvider des = new DESCryptoServiceProvider();
            MemoryStream ms = new MemoryStream();
            CryptoStream cs = new CryptoStream(ms, des.CreateDecryptor(key, IV), CryptoStreamMode.Write);
            cs.Write(inputByteArray, 0, inputByteArray.Length);
            cs.FlushFinalBlock();
            Encoding encoding = Encoding.UTF8; return encoding.GetString(ms.ToArray());
        }
        catch (System.Exception ex)
        {

            throw ex;
        }

    }
    private string EncryptStringValue(string stringToEncrypt)
    {
        byte[] key;
        byte[] IV;
        byte[] inputByteArray;
        try
        {
            key = Convert2ByteArray(DESKey);
            IV = Convert2ByteArray(DESIV);
            inputByteArray = Encoding.UTF8.GetBytes(stringToEncrypt);
            DESCryptoServiceProvider des = new DESCryptoServiceProvider();
            MemoryStream ms = new MemoryStream(); CryptoStream cs = new CryptoStream(ms, des.CreateEncryptor(key, IV), CryptoStreamMode.Write);
            cs.Write(inputByteArray, 0, inputByteArray.Length);
            cs.FlushFinalBlock();
            return Convert.ToBase64String(ms.ToArray());
        }
        catch (System.Exception ex)
        {
            throw ex;
        }
    }

    private byte[] Convert2ByteArray(string strInput)
    {
        int intCounter; char[] arrChar;
        arrChar = strInput.ToCharArray();
        byte[] arrByte = new byte[arrChar.Length];
        for (intCounter = 0; intCounter <= arrByte.Length - 1; intCounter++)
            arrByte[intCounter] = Convert.ToByte(arrChar[intCounter]);
        return arrByte;
    }

    private static CryptoUtil _CryptoUtil = new CryptoUtil();
    public static CryptoUtil Encrypt
    {
        get
        {
            _CryptoUtil.Mode = 0;
            return _CryptoUtil;
        }
    }
    public static CryptoUtil Decrypt
    {
        get
        {
            _CryptoUtil.Mode = 1;
            return _CryptoUtil;
        }
    }
    public static CryptoUtil DecryptString
    {
        get
        {
            _CryptoUtil.Mode = 2;
            return _CryptoUtil;
        }
    }
    public static CryptoUtil EncryptString
    {
        get
        {
            _CryptoUtil.Mode = 3;
            return _CryptoUtil;
        }
    }
}
