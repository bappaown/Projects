﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using BusinessObjects;
using System.Data;
using System.Reflection;

namespace DataLibrary
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "ToolsService" in code, svc and config file together.
    public class ToolsService
    {
        ///// <summary>
        ///// Upload user details
        ///// </summary>
        ///// <param name="Users">Users as List<User></param>
        ///// <returns></returns>
        //public bool UploadUsers(List<User> Users)
        //{
        //    bool uploadStatus = false;
        //    try
        //    {
        //        var objBulk = new BulkUploadData<User>()
        //        {
        //            InternalStore = Users,
        //            TableName = "[dbo].[360_User]",
        //            CommitBatchSize = 1000
        //        };

        //        objBulk.Commit();
        //        uploadStatus = true;
        //        return uploadStatus;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }

        //}

        ///// <summary>
        ///// Submit the users
        ///// </summary>
        ///// <param name="feedBack">feedBack as Feedback</param>
        ///// <returns></returns>
        //public bool SubmitUsers(List<User> Users)
        //{
        //    bool submitUsers = false;
        //    try
        //    {
        //        DataCarrier dataCarrier = new DataCarrier();
        //        foreach (User User in Users)
        //        {
        //            submitUsers = dataCarrier.InsertData("sp_Feedback_SubmitUsers", User, "User");
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return submitUsers;
        //}

        ///// <summary>
        ///// Get the efficiency master
        ///// </summary>
        ///// <returns>List<EfficiencyMaster></returns>
        //public List<EfficiencyMaster> GetEfficiencyMaster()
        //{
        //    List<EfficiencyMaster> efficencyList = new List<EfficiencyMaster>();
        //    try
        //    {
        //        EfficiencyMaster efficiency;
        //        Dictionary<string, string> parameter = new Dictionary<string, string>();
        //        parameter.Add("SelectType", "EFFICIENCY");
        //        DataSet ds = new DataCarrier().GetData("sp_Feedback_GetMasterData", parameter);

        //        if (ds != null && ds.Tables[0].Rows.Count > 0)
        //        {
        //            foreach (DataRow dr in ds.Tables[0].Rows)
        //            {
        //                efficiency = new EfficiencyMaster();
        //                efficiency.Id = Convert.ToInt32(dr["Id"]);
        //                efficiency.Type = dr["Type"].ToString();
        //                efficiency.MinValue = Convert.ToInt32(dr["MinValue"]);
        //                efficiency.MaxValue = Convert.ToInt32(dr["MaxValue"]);

        //                if (!efficencyList.Contains(efficiency))
        //                {
        //                    efficencyList.Add(efficiency);
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return efficencyList;
        //}

        ///// <summary>
        ///// Get the Peers and reportees of employee
        ///// </summary>
        ///// <param name="userId"></param>
        ///// <param name="searchBy"></param>
        ///// <returns></returns>
        //public List<User> GetPeersOfEmpolyee(string userId, string searchBy)
        //{
        //    List<User> users = new List<User>();
        //    try
        //    {
        //        User user;
        //        Dictionary<string, string> parameter = new Dictionary<string, string>();
        //        parameter.Add("UserId", userId);
        //        parameter.Add("SearchBy", searchBy);
        //        DataSet ds = new DataCarrier().GetData("sp_Feedback_GetPeersOfEmployee", parameter);

        //        if (ds != null && ds.Tables[0].Rows.Count > 0)
        //        {
        //            foreach (DataRow dr in ds.Tables[0].Rows)
        //            {
        //                user = new User();
        //                user.UserId = dr["UserId"].ToString();
        //                user.Name = dr["Name"].ToString();
        //                if (!users.Contains(user))
        //                {
        //                    users.Add(user);
        //                }
        //            }
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return users;
        //}

        ///// <summary>
        ///// Get Max Unique Code
        ///// </summary>
        ///// <returns>MaxUniqueCode as string</returns>
        //public string GetMaxUniqueCode()
        //{
        //    string maxUniqueCode = string.Empty;
        //    try
        //    {
        //        DataSet ds = new DataCarrier().GetData("sp_Feedback_GetMaxUniqueCode", null);

        //        if (ds != null && ds.Tables[0].Rows.Count > 0)
        //        {
        //            maxUniqueCode = ds.Tables[0].Rows[0][0].ToString();
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //    return maxUniqueCode;
        //}


        ///// <summary>
        ///// Calculation for generate report
        ///// </summary>
        ///// <param name="questionFile"></param>
        ///// <returns></returns>
        //public bool FeedbackCalculation()
        //{
        //    bool submitStatus = false;
        //    try
        //    {
        //        DataCarrier dataCarrier = new DataCarrier();

        //        submitStatus = dataCarrier.InsertData("sp_Feedback_CalculateRating", null, null);

        //        return submitStatus;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}


        public DataTable ToDataTable<User>(List<User> items)
        {
            DataTable dataTable = new DataTable(typeof(User).Name);
            PropertyInfo[] Props = typeof(User).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (PropertyInfo prop in Props)
            {
                dataTable.Columns.Add(prop.Name);
            }

            foreach (User item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        /// <summary>
        /// Validate user details
        /// </summary>
        /// <param name="questionFile"></param>
        /// <returns></returns>
        public DataSet ValidateUserDetails(string UserId)
        {
            DataSet ds = new DataSet();
            try
            {
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("UserId", UserId);
                ds = new DataCarrier().GetData("sp_Effort_ValidateUserDetails", parameter);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return ds;
        }




        /// <summary>
        /// Get Service List
        /// </summary>
        /// <returns>List<ServiceList></returns>
        public List<Services> GetServiceList()
        {
            List<Services> serviceList = new List<Services>();
            try
            {
                Services service;
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("SelectType", "SERVICE");
                DataSet ds = new DataCarrier().GetData("sp_Effort_GetMasterData", parameter);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        service = new Services();
                        service.ServiceId = Convert.ToInt32(dr["ServiceId"]);
                        service.ServiceName = dr["ServiceName"].ToString();
                        service.ServiceDescription = dr["ServiceDescription"].ToString();
                        service.FMS = Convert.ToBoolean(dr["FMS"].ToString());
                        if (!serviceList.Contains(service))
                        {
                            serviceList.Add(service);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return serviceList;
        }

        /// <summary>
        /// Get Type List
        /// </summary>
        /// <returns>List<TypeList></returns>
        public List<Types> GetTypeList()
        {
            List<Types> typeList = new List<Types>();
            try
            {
                Types type;
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("SelectType", "TYPE");
                DataSet ds = new DataCarrier().GetData("sp_Effort_GetMasterData", parameter);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        type = new Types();
                        type.TypeId = Convert.ToInt32(dr["TypeId"]);
                        type.Type = dr["Type"].ToString();
                        type.TypeDesciption = dr["TypeDesciption"].ToString();
                        if (!typeList.Contains(type))
                        {
                            typeList.Add(type);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return typeList;
        }

        /// <summary>
        /// Submit the user efforts
        /// </summary>
        /// <param name="effort">effort as Efforts</param>
        /// <returns></returns>
        public bool SubmitEffort(List<EffortDetails> EffortDtls)
        {
            bool submitStatus = false;
            try
            {
                DataCarrier dataCarrier = new DataCarrier();
                foreach (EffortDetails efforts in EffortDtls)
                {
                    dataCarrier.InsertData("sp_Effort_SubmitEffort", efforts, "Efforts");
                }
                submitStatus = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return submitStatus;
        }

        /// <summary>
        /// Bulk Upload efforts
        /// </summary>
        /// <param name="effort">effort as Efforts</param>
        /// <returns></returns>
        public bool SubmitEfforts(List<EffortDetails> EffortDtls)
        {
            bool uploadStatus = false;
            try
            {
                var objBulk = new BulkUploadData<EffortDetails>()
                {
                    InternalStore = EffortDtls,
                    TableName = "[dbo].[Effort_EffortDetails]",
                    CommitBatchSize = 1000
                };

                objBulk.Commit();
                uploadStatus = true;
                return uploadStatus;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Delete the user efforts
        /// </summary>
        /// <param name="effort">effort as Efforts</param>
        /// <returns></returns>
        public bool DeleteEffort(string UserId, string Date)
        {
            bool status = false;
            try
            {
                DataCarrier dataCarrier = new DataCarrier();
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("UserId", UserId);
                parameter.Add("Date", Date);
                dataCarrier.InsertData("sp_Effort_DeleteEffort", parameter, "DeleteEffort");

                status = true;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return status;
        }

        /// <summary>
        /// Get the user efforts
        /// </summary>
        /// <param name="effort">effort as Efforts</param>
        /// <returns></returns>
        public List<Efforts> getEffortDetail(string UserId, string Date)
        {
            List<Efforts> effortist = new List<Efforts>();
            Efforts effort;
            try
            {
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("UserId", UserId);
                parameter.Add("Date", Date);
                DataSet ds = new DataCarrier().GetData("sp_Effort_GetEffortDetail", parameter);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        effort = new Efforts();
                        effort.service = ds.Tables[0].Rows[i]["Service"].ToString();
                        effort.type = ds.Tables[0].Rows[i]["Type"].ToString();
                        effort.details = ds.Tables[0].Rows[i]["Details"].ToString();
                        effort.hours = ds.Tables[0].Rows[i]["Hours"].ToString();
                        effortist.Add(effort);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return effortist;
        }

        /// <summary>
        /// Export the user efforts
        /// </summary>
        /// <param name="effort">effort as Efforts</param>
        /// <returns></returns>
        public List<Efforts> setEffortDetail(string UserId, string Date)
        {
            List<Efforts> effortist = new List<Efforts>();
            Efforts effort;
            try
            {
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("UserId", UserId);
                parameter.Add("Date", Date);
                DataSet ds = new DataCarrier().GetData("sp_Effort_SetEffortDetail", parameter);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        effort = new Efforts();
                        effort.service = ds.Tables[0].Rows[i]["Service"].ToString();
                        effort.type = ds.Tables[0].Rows[i]["Type"].ToString();
                        effort.details = ds.Tables[0].Rows[i]["Details"].ToString();
                        effort.hours = ds.Tables[0].Rows[i]["Hours"].ToString();
                        effortist.Add(effort);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return effortist;
        }

        /// <summary>
        /// Export the user efforts
        /// </summary>
        /// <param name="effort">effort as Efforts</param>
        /// <returns></returns>
        public List<EffortDetails> allEffortDetail()
        {
            List<EffortDetails> effortist = new List<EffortDetails>();
            EffortDetails effort;
            try
            {
                DataSet ds = new DataCarrier().GetData("sp_Effort_AllEffortDetail", null);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        effort = new EffortDetails();
                        effort.UserId = ds.Tables[0].Rows[i]["UserId"].ToString();
                        effort.UserName = ds.Tables[0].Rows[i]["UserName"].ToString();
                        effort.Service = ds.Tables[0].Rows[i]["Service"].ToString();
                        effort.Type = ds.Tables[0].Rows[i]["Type"].ToString();
                        effort.Details = ds.Tables[0].Rows[i]["Details"].ToString();
                        effort.Hours = ds.Tables[0].Rows[i]["EffortHours"].ToString();
                        effort.Date = ds.Tables[0].Rows[i]["EffortDate"].ToString();
                        effort.CreateDate = ds.Tables[0].Rows[i]["CreateDate"].ToString();
                        effortist.Add(effort);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return effortist;
        }

        /// <summary>
        /// Export the user efforts
        /// </summary>
        /// <param name="effort">effort as Efforts</param>
        /// <returns></returns>
        public List<EffortDetails> effortDetailReport(string user, string service, string startdate, string enddate)
        {
            List<EffortDetails> effortist = new List<EffortDetails>();
            EffortDetails effort;
            try
            {
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("User", user);
                parameter.Add("Service", service);
                parameter.Add("StartDate", startdate);
                parameter.Add("EndDate", enddate);
                DataSet ds = new DataCarrier().GetData("sp_Effort_EffortDetailReport", parameter);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        effort = new EffortDetails();
                        effort.UserId = ds.Tables[0].Rows[i]["UserId"].ToString();
                        effort.UserName = ds.Tables[0].Rows[i]["UserName"].ToString();
                        effort.Service = ds.Tables[0].Rows[i]["Service"].ToString();
                        effort.Hours = ds.Tables[0].Rows[i]["TotalHours"].ToString();
                        effort.CreateDate = ds.Tables[0].Rows[i]["StartDate"].ToString();
                        effort.Date = ds.Tables[0].Rows[i]["EndDate"].ToString();
                        effortist.Add(effort);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return effortist;
        }

        /// <summary>
        /// Get the user efforts
        /// </summary>
        /// <param name="effort">effort as Efforts</param>
        /// <returns></returns>
        public List<string> getEffortDetail(string searchName)
        {
            List<string> usertist = new List<string>();
            try
            {
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("searchName", searchName);
                DataSet ds = new DataCarrier().GetData("sp_Effort_GetUserList", parameter);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                    {
                        string user = ds.Tables[0].Rows[i]["Name"].ToString() + " [ " + ds.Tables[0].Rows[i]["UserId"].ToString() + " , " + ds.Tables[0].Rows[i]["EmailId"].ToString() + " ]";
                        usertist.Add(user);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return usertist;
        }

    }
}
