﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace DataLibrary
{
    public static class DBConnect
    {
        private static string connectionString = "Server=sqlwls20dev.app.pmi\\DEV;Integrated Security=True; Database=AssessmentDB;Persist Security Info=True";

        public static SqlConnection CreateConnection()
        {
            SqlConnection connection = new SqlConnection(connectionString);
            return connection;
        }

    }
}
