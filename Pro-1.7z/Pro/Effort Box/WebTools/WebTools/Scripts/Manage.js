﻿
angular.module('app', ['smart-table', 'ui.bootstrap']).controller('ManageCtrl', function ($scope, $http, $timeout) {

    $scope.rowCollection = [];
    $scope.UserDetails = null;
    $scope.QuestionHistory = [];

    $scope.isopen = true;
    $scope.oneAtATime = true;

    $scope.quaterList = {};
    $scope.dataLoading = false;
    $scope.quaterLoading = false;
    $scope.questionLoading = false;

    $scope.users = [
                { 'Name': '', 'UserId': '', 'EmailId': '', 'IBMEmailId': '', 'ProjectCode': '', 'ProjectName': '', 'ProjectDesc': '', 'PeopleManagerId': '', 'ManagerId': '',
                    'ProjectLeaderId': '', 'JoiningDate': '', 'ReleaseDate': '', 'UserType': ''
                }
            ];

    $scope.user = {};

    var usrList = ['Pierre', 'Pol', 'Jacques', 'Robert', 'Elisa'],
            mgrList = ['Dupont', 'Germain', 'Delcourt', 'bjip', 'Menez'],
            yrList = ['2015', '2016', '2017', '2018', '2019'],
            qtrList = ['Jan-Mar', 'Apr-Jun', 'Jul-Sep', 'Oct-Dec'];

    $scope.loadQuater = function () {
        $scope.quaterLoading = true;
        $http({
            method: "POST",
            url: "../Admin/ManageApp.aspx/LoadQuaters",
            dataType: 'json',
            data: {},
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d.length > 0) {
                $scope.quaterList = data.d;
                $scope.quaterLoading = false;
            }
            else {
            }
        });
    }

    $scope.loadUserGrid = function (file) {
        $scope.dataLoading = true;
        $http({
            method: "POST",
            url: "../Admin/ManageApp.aspx/ReadData",
            dataType: 'json',
            data: { "file": file.value },
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            $scope.UserDetails = data.d;
            $scope.dataLoading = false;
        });

    };

    $scope.bindQuestionGrid = function () {
        $scope.questionLoading = true;
        $http({
            method: "POST",
            url: "../Admin/ManageApp.aspx/ReadQuestionData",
            dataType: 'json',
            data: {},
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            $scope.QuestionHistory = data.d;
            $scope.questionLoading = false;
        });

    };

    $scope.loadQuestionFile = function (file, fileName) {

        $http({
            method: "POST",
            url: "../Admin/ManageApp.aspx/DownloadQuestion",
            dataType: 'json',
            data: { "file": file, "fileName": fileName },
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            //$scope.UserDetails = data.d;
        });

    };

    $scope.bindQuestionGrid();

    $scope.loadQuestionGrid = function () {
        $scope.dataLoading = true;
        var file = $('#fileQuestion')[0];
        var quaterId = $('#ddlQuater')[0].value;
        $http({
            method: "POST",
            url: "../Admin/ManageApp.aspx/UploadQuestion",
            dataType: 'json',
            data: { "file": file.value, 'quaterId': quaterId },
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d) {
                $scope.dataLoading = false;
                alert("Question Uploaded successfully.");
                window.location.href = window.location.href;
            }
        });

    };

    $scope.uploadUsers = function () {
        $scope.userLoading = true;
        $('#tblUser tbody tr').each(function () {

            $scope.user.Name = $(this).find('#lblName').text();
            $scope.user.UserId = $(this).find('#txtUserId').val();
            $scope.user.EmailId = $(this).find('#txtEmailId').val();
            $scope.user.IBMEmailId = $(this).find('#txtIBMEmailId').val();
            $scope.user.ProjectCode = $(this).find('#txtProjectCode').val();
            $scope.user.ProjectName = $(this).find('#txtProjectName').val();
            $scope.user.ProjectDesc = $(this).find('#txtProjectDesc').val();
            $scope.user.ManagerId = $(this).find('#txtManagerId').val();
            $scope.user.PeopleManagerId = $(this).find('#txtPeopleManagerId').val();
            $scope.user.ProjectLeaderId = $(this).find('#txtProjectLeaderId').val();
            $scope.user.JoiningDate = $(this).find('#txtJoiningDate').val();
            $scope.user.ReleaseDate = $(this).find('#txtReleaseDate').val();
            $scope.user.UserType = $(this).find('#txtUserType').val();
            $scope.users.push($scope.user);
            $scope.user = {};
        });
        $http({
            method: "POST",
            url: "../Admin/ManageApp.aspx/UploadUsers",
            dataType: 'json',
            data: { "users": $scope.users },
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d) {
                $scope.userLoading = false;
                alert('User Uploaded successfully.');
                window.location.href = window.location.href;
            };
        });
    };

    //    //Function to create Random Items for the Data Grid
    //    function createRandomItem() {
    //        var 
    //                firstName = usrList[Math.floor(Math.random() * 4)],
    //                lastName = mgrList[Math.floor(Math.random() * 4)],
    //                age = Math.floor(Math.random() * 100),
    //                email = firstName + lastName + '@whatever.com';

    //        return {
    //            UserName: firstName,
    //            UsrTL: lastName,
    //            UsrPM: lastName,
    //            UsrMailId: email,
    //            SysId: email,
    //            UsrSDate: randomDate(new Date(2012, 0, 1), new Date()).toDateString()
    //        };
    //    }

    //    function createRandomItemQuestions() {
    //        var 
    //                firstName = yrList[Math.floor(Math.random() * 4)],
    //                lastName = qtrList[Math.floor(Math.random() * 4)],
    //                age = '@somepath';

    //        return {
    //            QuestionPath: age,
    //            QuestionQuarter: lastName,
    //            QuestionYear: firstName
    //        };
    //    }

    //    function randomDate(start, end) {
    //        return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
    //    }

    //    //Function to load the initial data for display
    //    $scope.reloadDataMain = function () {
    //        for (var j = 0; j < 30; j++) {
    //            $scope.UserDetails.push(createRandomItem());
    //        }
    //        for (var j = 0; j < 5; j++) {
    //            $scope.QuestionHistory.push(createRandomItemQuestions());
    //        }
    //    };

    //    $scope.reloadDataMain = function () {
    //        var httpRequest = $http({
    //            method: "POST",
    //            url: "../Admin/ManageApp.aspx/IsValidLogin",
    //            dataType: 'json',
    //            data: "{}",
    //            headers: { "Content-Type": "application/json" }
    //        });
    //        httpRequest.success(function (data, status) {
    //            $scope.ddlLoading = false;
    //            $("#aName").text(data.d.UserName);
    //        });
    //    };
    //  $scope.reloadDataMain();

    $scope.loadQuater();

    $scope.reloadDataMain = function () {
        var httpRequest = $http({
            method: "POST",
            url: "../Activity/Feedback.aspx/GetUIData",
            dataType: 'json',
            data: "{}",
            headers: { "Content-Type": "application/json" }
        });
        httpRequest.success(function (data, status) {
            if (data.d.LOGGEDINUSER.UserId == "NORECORDS") {
                alert(data.d.LOGGEDINUSER.EmailId);
                //window.close();
                window.open('','_self').close();
            }
            else {
                $("#loggeduserId").append(" " + data.d.LOGGEDINUSER.Name);
            }
        });
    };
    $scope.reloadDataMain();

    $scope.feedbackCalculation = function () {
        $scope.dataLoad = true;
        $http({
            method: "POST",
            url: "../Admin/ManageApp.aspx/FeedbackCalculation",
            dataType: 'json',
            data: {},
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d) {
                $scope.dataLoad = false;
                alert("Feedback calculation successfully done.");
                window.location.href = window.location.href;
            }
        });

    };
});
