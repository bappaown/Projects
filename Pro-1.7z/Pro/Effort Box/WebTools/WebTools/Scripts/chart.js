﻿function LineChart(wtype, options, divId) {
    var nameIs = "";
    var jsonObj = [];
    for (var i = 0; i < options.length; i++) {
        /*if (i == 0) nameIs = "Visits";
        else if (i == 1) nameIs = "No";
        else if (i == 2) nameIs = "Yes";*/

        nameIs = "Visits";
        jsonObj.push({
            type: wtype,
            name: nameIs,
            lineThickness: 2,
            showInLegend: true,
            dataPoints: options[i]
        });
    }

    var chart = new CanvasJS.Chart(divId, {
        title: {
            text: wtype + " chart",
            fontSize: 30
        },
        animationEnabled: true,
        axisX: {
            gridColor: "Silver",
            tickColor: "silver",
            title: "Axis X Title"
        },
        toolTip: {
            shared: true
        },
        theme: "theme2",
        axisY: {
            gridColor: "Silver",
            tickColor: "silver",
            title: "Axis Y Title"
        },
        legend: {
            verticalAlign: "center",
            horizontalAlign: "right"
        },
        data: jsonObj,
        legend: {
            cursor: "pointer",
            itemclick: function (e) {
                if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
                    e.dataSeries.visible = false;
                }
                else {
                    e.dataSeries.visible = true;
                }
                chart.render();
            }
        }
    });

    chart.render();
}

function PieChart(type, dps1, divId) {
    var chart = new CanvasJS.Chart(divId,
	{
	    theme: "theme2",
	    animation: {
	        animateScale: true
	    },

	    title: {
	        text: ""
	    },
	    data: [
		{
		    type: type,
		    showInLegend: true,
		    toolTipContent: "{y} %",
		    legendText: "{indexLabel}",
		    dataPoints: dps1
		}
		]
	});
    chart.render();
}

function isValidLogin() {
    var flag = false;
    $.ajax({
        type: "POST",
        data: "{}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "../Activity/FeedbackReport.aspx/IsValidLogin",
        async: true,
        success: function (data) {
            $("#chartContainer2").html("testing sync");
        }

    });

    //    var toJson = jQuery.parseJSON(Response);
    //    if (toJson.d[0].Message == 'SUCCESS') {
    //        $("#chartContainer2").html("testing sync");
    //    }

}

function testSysnc() {
   // isValidLogin();
   // LineChartFunc('line');
  //  PieChartFunc('doughnut', "chartContainer3");
   // PieChartFunc('pie', "chartContainer4");
//    $.ajax({
//        type: "POST",
//        data: "{}",
//        dataType: "json",
//        contentType: "application/json; charset=utf-8",
//        url: "../Activity/FeedbackReport.aspx/IsValidLogin2",
//        async: true,
//        success: function (data) {
//            LineChartFunc('line');
//        }

//    });
   
//    $.ajax({
//        type: "POST",
//        data: "{}",
//        dataType: "json",
//        contentType: "application/json; charset=utf-8",
//        url: "../Activity/FeedbackReport.aspx/IsValidLogin3",
//        async: true,
//        success: function (data) {
//            PieChartFunc('doughnut', "chartContainer3");
//        }

//    });
    $.ajax({
        type: "POST",
        data: "{}",
        dataType: "json",
        contentType: "application/json; charset=utf-8",
        url: "../Activity/FeedbackReport.aspx/IsValidLogin2",
        async: true,
        success: function (data) {
            PieChartFunc('pie','', "chartContainer4");
        }

    });



}
