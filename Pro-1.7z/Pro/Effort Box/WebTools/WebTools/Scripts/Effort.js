﻿angular.module('app', ['smart-table', 'ui.bootstrap']).controller('FeedbackReportCtrl', function ($scope, $uibModal, $http, $timeout) {

    $scope.employees = {};
    $scope.showFields = false;
    $scope.showFeedback = false;
    $scope.CalculatedResult = {};
    $scope.cateWiseResult = {};
    $scope.categoryWiseResults = [];

    $scope.quaterList = {};
    $scope.empLoading = false;
    $scope.resultLoading = false;
    $scope.pageLoading = true;
    $scope.userExport = false;

    $scope.serviceList = {};
    $scope.typeList = {};

    $scope.reloadDataMain = function () {
        var httpRequest = $http({
            method: "POST",
            url: "../Activity/Effort.aspx/GetUserData",
            dataType: 'json',
            data: "{}",
            headers: { "Content-Type": "application/json" }
        });
        httpRequest.success(function (data, status) {
            if (data.d.length > 0) {
                $("#loggeduserId").append(" " + data.d[0].Name);
                if (data.d[0].UserType == 'Admin') {
                    $scope.userExport = true;
                }
            }
            else {
                alert("Access denied!!!\nPlease contact to administrator.");
                window.open('', '_self').close();
            }
        });
    };
    $scope.reloadDataMain();

    $scope.loadService = function () {
        $http({
            method: "POST",
            url: "../Activity/Effort.aspx/LoadServices",
            dataType: 'json',
            data: {},
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d.length > 0) {
                $scope.serviceList = data.d;
            }
            else {
            }
        });
    }

    $scope.loadType = function () {
        $http({
            method: "POST",
            url: "../Activity/Effort.aspx/LoadTypes",
            dataType: 'json',
            data: {},
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d.length > 0) {
                $scope.typeList = data.d;
            }
            else {
            }
        });
    }

    $scope.loadService();
    $scope.loadType();
    var serviceId = $scope.selectService;
    var typeId = $scope.selectType;

    $scope.onlyDigits = function () {
        $('#tblEffortOne tbody tr').each(function () {
            $('#txtHours', this).each(function () {
                var hours = $(this).val();
                var value = hours.replace(/[^0-9\.]/g, '');
                var decimalCheck = value.split('.');
                if (!angular.isUndefined(decimalCheck[1])) {
                    decimalCheck[1] = decimalCheck[1].slice(0, 2);
                    value = decimalCheck[0] + '.' + decimalCheck[1];
                }
                $(this).val(value);
                //}
                //                if (isNaN(parseInt(hours))) {
                //                    $(this).val(hours.replace(/[^0-9]/g, ''));
                //                }
                //                else {
                //                    $(this).val(parseInt(hours));
                //                }
            });
        });
    }

    $scope.effort = [{ 'service': '', 'type': '', 'details': '', 'hours': ''}];
    $scope.effortValue = {};

    $scope.efforts = [{ 'service': '', 'type': '', 'details': '', 'hours': ''}];

    $scope.addRow = function () {
        $scope.efforts.push({ 'service': $scope.service, 'type': $scope.type, 'details': $scope.details, 'hours': $scope.hours });
        $scope.service = '';
        $scope.type = '';
        $scope.details = '';
        $scope.hours = '';
    };


    $scope.removeRow = function (index) {
        var comArr = eval($scope.efforts);
        if (comArr.length > 1) {
            $scope.efforts.splice(index, 1);
        }
    };

    $scope.validateResult = function () {
        var isProcess = true;
        var flag = false;
        $('#tblEffortOne tbody tr').each(function (index) {
            var search = $('#ddlService :selected', this).text();
            var type = $('#ddlType :selected', this).text();
            var details = $('#txtDetails', this).val();
            var hours = $('#txtHours', this).val();

            if (index > 1) {
                if (search != "" || type != "" || details != "" || hours != "") {
                    if (search == "") {
                        $('#ddlService', this).css('border', '1px solid red');
                        isProcess = false;
                    }
                    else {
                        $('#ddlService', this).css('border', '1px solid #ccc');
                    }
                    if (type == "") {
                        $('#ddlType', this).css('border', '1px solid red');
                        isProcess = false;
                    }
                    else {
                        $('#ddlType', this).css('border', '1px solid #ccc');
                    }
                    if (details == "") {
                        $('#txtDetails', this).css('border', '1px solid red');
                        isProcess = false;
                    }
                    else {
                        $('#txtDetails', this).css('border', '1px solid #ccc');
                    }
                    if (hours == "") {
                        $('#txtHours', this).css('border', '1px solid red');
                        isProcess = false;
                    }
                    else {
                        $('#txtHours', this).css('border', '1px solid #ccc');
                    }
                }
                else {
                    $('#ddlService', this).css('border', '1px solid #ccc');
                    $('#ddlType', this).css('border', '1px solid #ccc');
                    $('#txtDetails', this).css('border', '1px solid #ccc');
                    $('#txtHours', this).css('border', '1px solid #ccc');
                }
            }

        });
        return isProcess;
    }


    $scope.uploadEfforts = function () {
        var validation = $scope.validateResult();
        if (validation) {
            $scope.userLoading = true;
            $scope.date = $('#trackinDdate').val();
            var $efforts = [{ 'service': '', 'type': '', 'details': '', 'hours': ''}];
            var $effortsValue = {};

            $('#tblEffortOne tbody tr').each(function () {
                var service = [];
                var type = [];
                var details = [];
                var hours = [];
                $('#ddlService :selected', this).each(function () {
                    var d = $(this).val() || $(this).text();
                    d = isNaN(parseInt(d)) ? "" : d
                    service.push(d);
                });
                $('#ddlType :selected', this).each(function () {
                    var d = $(this).val() || $(this).text();
                    d = isNaN(parseInt(d)) ? "" : d
                    type.push(d);
                });
                $('#txtDetails', this).each(function () {
                    var d = $(this).val() || $(this).text();
                    details.push(d);
                });
                $('#txtHours', this).each(function () {
                    var d = $(this).val() || $(this).text();
                    hours.push(d);
                });

                $efforts.splice(0, 1);

                for (var i = 0; i < service.length; i++) {
                    if (service[i] != '' && type[i] != '' && details[i] != '' && hours[i] != '') {
                        $effortsValue.service = service[i];
                        $effortsValue.type = type[i];
                        $effortsValue.details = details[i];
                        $effortsValue.hours = hours[i];
                        $efforts.push($effortsValue);
                        $effortsValue = {};
                    }
                }

                return false;
            });
            $http({
                method: "POST",
                url: "../Activity/Effort.aspx/UploadEfforts",
                dataType: 'json',
                data: { "EffortList": $efforts, "Date": $scope.date },
                headers: { "Content-Type": "application/json" }
            }).success(function (data, status) {
                if (data.d) {
                    $scope.userLoading = false;
                    alert('Data Uploaded successfully.');
                    window.location.href = window.location.href;
                }
                else {
                    $scope.userLoading = false;
                    alert('Problem to Upload Data.');
                };
            });
        }
    }


    $scope.loadEffortDetail = function () {
        $scope.date = $('#trackinDdate').val();
        $http({
            method: "POST",
            url: "../Activity/Effort.aspx/loadEffortDetail",
            dataType: 'json',
            data: { "Date": $scope.date },
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            $scope.efforts = [];
            //            $scope.efforts = [{ 'service': '', 'type': '', 'details': '', 'hours': '' }, ];
            //            $scope.efforts.splice(0, 1);
            if (data.d.length > 0) {
                for (var i = 0; i < data.d.length; i++) {
                    $scope.efforts.push({ 'service': data.d[i].service, 'type': data.d[i].type, 'details': data.d[i].details, 'hours': data.d[i].hours });
                }

                //                while ($scope.efforts.length < 1) {
                //                    $scope.efforts.push({ 'service': '', 'type': '', 'details': '', 'hours': '' });
                //                }
            }
            else {
                while ($scope.efforts.length < 1) {
                    $scope.efforts.push({ 'service': '', 'type': '', 'details': '', 'hours': '' });
                }
            }
        });
    }
    $scope.loadEffortDetail();

    $scope.ExportEffortDetail = function () {
        //$scope.date = $('#trackinDdate').val();
        $http({
            method: "POST",
            url: "../Activity/Effort.aspx/ExportEffortDetail",
            dataType: 'json',
            data: {},
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d.length > 0) {
                window.location.href = data.d
            }
        });
    }


    //-------------------------------------------------

    $scope.loadQuater = function () {
        $http({
            method: "POST",
            url: "../Activity/Effort.aspx/LoadQuaters",
            dataType: 'json',
            data: {},
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d.length > 0) {
                $scope.quaterList = data.d;
            }
            else {
            }
        });
    }

    $scope.showEmployee = function () {
        var searchName = $('#txtEmpName')[0].value;
        $scope.empLoading = true;
        $http({
            method: "POST",
            url: "../Activity/Effort.aspx/SearchEmployee",
            dataType: 'json',
            data: { "searchName": searchName },
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d.length > 0) {
                if (data.d[0].UserId == 'NOTAUTHORISE') {
                    alert('You can not able to see your feedback report.');
                    $scope.showFields = false;
                    $scope.empLoading = false;
                }
                else {
                    $scope.showFields = true;
                    $('#pieChart').hide();
                    $('#tblFeedbackResult').hide();
                    $scope.employees = data.d;
                    $scope.loadQuater();
                    $scope.empLoading = false;
                }
            }
            else {
                $scope.showFields = false;
                alert('No employee found.');
            }
        });

    };

    $scope.showResult = function () {
        var isProcess = true;
        var userId = $scope.selectEmp;
        if (userId == undefined) {
            alert("Please select an employee.");
            isProcess = false;
        }

        var quaterId = $scope.selectQuater;
        if (isProcess) {
            if (quaterId == undefined) {
                alert("Please select quater.");
                isProcess = false;
            }
        }

        if (isProcess) {
            $scope.resultLoading = true;
            $http({
                method: "POST",
                url: "../Activity/Effort.aspx/ShowResult",
                dataType: 'json',
                data: { "userId": userId, "feedbackYear": "2017", "quaterId": quaterId },
                headers: { "Content-Type": "application/json" }
            }).success(function (data, status) {
                if (data.d != null && data.d.CalculatedResult != null) {
                    $scope.CalculatedResult = data.d.CalculatedResult;
                    $scope.showFeedback = true;
                    $scope.categoryWiseResults = [];
                    for (var i = 0; i < data.d.CalculatedResult.length; i++) {
                        $scope.cateWiseResult = {};
                        $scope.cateWiseResult.y = data.d.CalculatedResult[i].Category.Rating;
                        $scope.cateWiseResult.indexLabel = data.d.CalculatedResult[i].Category.CategoryDescription;
                        $scope.categoryWiseResults.push($scope.cateWiseResult);
                    }

                    PieChart('pie', $scope.categoryWiseResults, "pieChart");
                    $('#pieChart').show();
                    $('#tblFeedbackResult').show();
                }
                else {
                    $scope.CalculatedResult = null;
                    $('#pieChart').hide();
                    $('#tblFeedbackResult').hide();
                    $scope.showFeedback = false;
                    alert('No result found.')
                }

                $scope.resultLoading = false;

            });
        }

    };

    $(document).keypress(function (e) {
        if (e.which == 13) {
            //            $scope.showEmployee();
            return false;
        }
    });

    $scope.ExportEffortReport = function () {
        var modalInstance = $uibModal.open({
            animation: $scope.animationsEnabled,
            templateUrl: 'myApproverContent.html',
            controller: 'ModalApproverInstanceCtrl',
            size: 'lg',
            backdrop: 'static',
            resolve: {

            }
        });

        modalInstance.result.then(function (reinitiatedApproverResult) {
            //Put an Alert based on reinitiatedApproverResult
        }, function () {
            //$log.info('Modal dismissed at: ' + new Date());
        });
    };


}).controller('ModalApproverInstanceCtrl', function ($scope, $uibModalInstance, $http, $timeout) {

    $scope.serviceList = {};

    $scope.popupService = function () {
        $http({
            method: "POST",
            url: "../Activity/Effort.aspx/LoadServices",
            dataType: 'json',
            data: {},
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d.length > 0) {
                $scope.serviceList = data.d;
            }
            else {
            }
        });
    }
    $scope.popupService();

    $(document).keypress(function (e) {
        if (e.which == 13) {
            $scope.SearchUser();
            return false;
        }
    });

    $scope.SearchUser = function () {
        var searchName = $('#txtUser').val();
        if (searchName == '') {
            alert('Please enter name.');
            return false;
        }
        $scope.employees = [];
        $http({
            method: "POST",
            url: "../Activity/Effort.aspx/SearchUser",
            dataType: 'json',
            data: { "searchName": searchName },
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d.length > 0) {
                $scope.employees = data.d;
                var loadStatus = false;

                $.each($scope.employees, function (key, value) {
                    var matches = value;
                    $scope.selItemSim = matches;
                    loadStatus = true;
                    return false;
                });

                if (loadStatus) {
                    $("#dvSearch").css("display", "none");
                    $("#dvSelect").css("display", "block");
                }
            }
            else {
                alert('No User found.');
            }
        });

    };

    $scope.clearControl = function (action) {
        if (action == "TEXT") {
            $("#ddlService option[value='']").attr('selected', true);
        }
        else if (action == "OPTION") {
            $scope.hideddl();
            $("#txtUser").val('');
            $scope.selItemSim = '';
        }
    };

    $scope.hideddl = function () {
        $("#dvSearch").css("display", "block");
        //$("#btnSearch").removeAttr("disabled");
        $("#dvSelect").css("display", "none");
        $('.btn-success').removeAttr("disabled");
    };

    $scope.EffortReport = function () {
        var user = $('#ddlusers').val();
        var service = $('#ddlService').val();
        var sdate = $('#startDate').val();
        var edate = $('#endDate').val();

        if (user == '' && service == '') {
            alert('Please provide User or Service.');
            return false;
        }
        if (sdate == '' || edate == '') {
            alert('Please provide missing date.');
            return false;
        }

        $http({
            method: "POST",
            url: "../Activity/Effort.aspx/ExportEffortReport",
            dataType: 'json',
            data: { "user": user, "service": service, "startdate": sdate, "enddate": edate },
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d.length > 0) {
                window.location.href = data.d
                $uibModalInstance.dismiss('cancel');
            }
        });

    };

    $scope.cancel = function () {
        $uibModalInstance.dismiss('cancel');
        //window.open('', '_self').close();
    };

}).directive('calendar2', function () {
    return {
        require: 'ngModel',
        link: function (scope, element, attr, ngModel) {
            $(element).datepicker({
                maxDate: 0,
                dateFormat: 'dd/mm/yy',
                onSelect: function (dateText) {
                    scope.$apply(function () {
                        ngModel.$setViewValue(dateText);
                    });
                }
            });
        }
    };

}).directive('stRatio', function () {
    return {
        link: function (scope, element, attr) {
            var ratio = +(attr.stRatio);
            element.css('width', ratio + '%');
        }
    };

}).directive('setHeight', function ($window) {
    return {
        link: function (scope, element, attrs) {
            element.css('height', ($(window).height() + 50) * 0.6);
        }
    };
});