﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;
using Utility;
using BusinessObjects;
using System.IO;
using System.Text;
using System.Xml;
//using System.Net.Http;
//using System.Web.Http;

namespace WebTools.Activity
{
    public partial class Effort : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [WebMethod]
        public static Dictionary<string, string> IsValidLogin()
        {
            Dictionary<string, string> loginStatus = new Dictionary<string, string>();
            //for (int i = 0; i < 1000; i++)
            //{
            //}
            loginStatus.Add("Message", "SUCCESS");
            return loginStatus;
        }

        [WebMethod]
        public static List<User> GetUserData()
        {
            List<User> userList = new List<User>();
            string strUserId = HttpContext.Current.User.Identity.Name;
            strUserId = (strUserId.IndexOf('-') > 0 ? strUserId.Replace("a-", "") : strUserId);

            if (!string.IsNullOrEmpty(strUserId))
            {
                DataLibrary.ToolsService fbClient = new DataLibrary.ToolsService();
                DataSet ds = fbClient.ValidateUserDetails(strUserId);

                if (new Common().IsValidUser())
                {
                    Dictionary<string, string> dicUserParam = new Common().GetUserParameters(strUserId);
                    if (dicUserParam != null && dicUserParam.Count > 0)
                    {
                        User user = new User();
                        string[] arrNameMailId = dicUserParam[strUserId].ToString().Split('|');
                        user.UserId = strUserId;
                        user.Name = arrNameMailId[0];
                        user.EmailId = arrNameMailId[1];
                        user.IBMEmailId = ds.Tables[0].Rows[0]["IBMEmailId"].ToString();
                        user.UserType = ds.Tables[0].Rows[0]["UserType"].ToString();
                        if (!userList.Contains(user))
                            userList.Add(user);
                    }
                }
                else if (Convert.ToBoolean(ds.Tables[0].Rows[0]["ValidUser"].ToString()))
                {
                    User user = new User();
                    user.UserId = strUserId;
                    user.Name = ds.Tables[0].Rows[0]["Name"].ToString();
                    user.EmailId = ds.Tables[0].Rows[0]["EmailId"].ToString();
                    user.IBMEmailId = ds.Tables[0].Rows[0]["IBMEmailId"].ToString();
                    user.UserType = ds.Tables[0].Rows[0]["UserType"].ToString();
                    if (!userList.Contains(user))
                        userList.Add(user);
                }
            }

            return userList;
        }

        [WebMethod]
        public static List<Services> LoadServices()
        {
            DataLibrary.ToolsService fbClient = new DataLibrary.ToolsService();
            List<Services> serviceList = fbClient.GetServiceList();
            return serviceList;
        }

        [WebMethod]
        public static List<Types> LoadTypes()
        {
            DataLibrary.ToolsService fbClient = new DataLibrary.ToolsService();
            List<Types> typeList = fbClient.GetTypeList();
            return typeList;
        }

        [WebMethod]
        public static bool UploadEfforts(List<Efforts> EffortList, string Date)
        {
            bool uploadStatus = false;
            string strUserId = HttpContext.Current.User.Identity.Name;
            string strUserName = string.Empty;
            strUserId = (strUserId.IndexOf('-') > 0 ? strUserId.Replace("a-", "") : strUserId);

            Dictionary<string, string> dicUserParam = new Common().GetUserParameters(strUserId);
            if (dicUserParam != null && dicUserParam.Count > 0)
            {
                string[] arrName = dicUserParam[strUserId].ToString().Split('|');
                strUserName = arrName[0];
            }

            if (EffortList.Count > 0)
            {
                List<EffortDetails> effortDtls = new List<EffortDetails>();
                EffortDetails efforts = null;
                DataLibrary.ToolsService fbClient = new DataLibrary.ToolsService();

                foreach (Efforts effort in EffortList)
                {
                    if (!string.IsNullOrEmpty(effort.service.Trim()) && !string.IsNullOrEmpty(effort.type.Trim()) && !string.IsNullOrEmpty(effort.details.Trim()) && !string.IsNullOrEmpty(effort.hours.Trim()))
                    {
                        efforts = new EffortDetails();
                        efforts.Service = effort.service;
                        efforts.Type = effort.type;
                        efforts.Details = effort.details;
                        efforts.Hours = effort.hours;
                        efforts.Date = Date;
                        efforts.UserId = strUserId;
                        efforts.UserName = strUserName;
                        efforts.CreateDate = Convert.ToString(DateTime.Now);

                        if (!effortDtls.Contains(efforts))
                            effortDtls.Add(efforts);
                    }
                }
                if (effortDtls.Count > 0)
                {
                    fbClient.DeleteEffort(strUserId, Date);
                    uploadStatus = fbClient.SubmitEfforts(effortDtls);
                }
            }

            return uploadStatus;
        }

        [WebMethod]
        public static List<Efforts> loadEffortDetail(string Date)
        {
            List<Efforts> effortDtls = new List<Efforts>();
            string strUserId = HttpContext.Current.User.Identity.Name;
            strUserId = (strUserId.IndexOf('-') > 0 ? strUserId.Replace("a-", "") : strUserId);
            Date = (!string.IsNullOrEmpty(Date)) ? Date : DateTime.Now.ToString("MM/dd/yyyy");

            if (!string.IsNullOrEmpty(strUserId) && !string.IsNullOrEmpty(Date))
            {
                DataLibrary.ToolsService fbClient = new DataLibrary.ToolsService();
                effortDtls = fbClient.getEffortDetail(strUserId, Date);
            }
            return effortDtls;
        }

        [WebMethod]
        public static List<string> SearchUser(string searchName)
        {
            List<string> userList = new List<string>();
            List<string> lstUser = new List<string>();
            userList = new Common().GetUserParametersByName(searchName);

            DataLibrary.ToolsService fbClient = new DataLibrary.ToolsService();
            lstUser = fbClient.getEffortDetail(searchName);
            if (lstUser != null)
                userList.AddRange(lstUser);

            return userList;
        }

        [WebMethod]
        public static string ExportEffortDetail()
        {
            string fileName = string.Empty;
            XmlDocument _objXmlConfig = new XmlDocument();
            string _strConfigPath = null;
            if (File.Exists("C:\\NWLS_V4.0\\AppServer\\Configurations\\XMLObject.xml"))
            {
                _strConfigPath = "C:\\NWLS_V4.0\\AppServer\\Configurations\\";
            }
            else
            {
                _strConfigPath = "E:\\NWLS_V4.0\\AppServer\\Configurations\\";
            }
            string _strRptConfig = _strConfigPath + "File.Config";
            _objXmlConfig.Load(_strRptConfig);
            string _strTempFilePath = _objXmlConfig.GetElementsByTagName("ReportPath").Item(0).Attributes["value"].Value.ToString();
            List<EffortDetails> effortDtls = new List<EffortDetails>();
            DataTable dt = new DataTable();
            dt.Columns.Add("UserId");
            dt.Columns.Add("UserName");
            dt.Columns.Add("Service");
            dt.Columns.Add("Type");
            dt.Columns.Add("Details");
            dt.Columns.Add("Hours");
            dt.Columns.Add("Date");

            DataLibrary.ToolsService fbClient = new DataLibrary.ToolsService();
            effortDtls = fbClient.allEffortDetail();

            if (effortDtls != null && effortDtls.Count > 0)
            {
                foreach (EffortDetails effort in effortDtls)
                {
                    //string Name = string.Empty;
                    //Dictionary<string, string> dicUserParam = new Common().GetUserParameters(effort.UserId);
                    //if (dicUserParam != null && dicUserParam.Count > 0)
                    //{
                    //    string[] arrNameMailId = dicUserParam[effort.UserId].ToString().Split('|');
                    //    Name = arrNameMailId[0];
                    //}

                    DataRow dr = dt.NewRow();
                    dr["UserId"] = effort.UserId;
                    dr["UserName"] = effort.UserName;
                    dr["Service"] = effort.Service;
                    dr["Type"] = effort.Type;
                    dr["Details"] = effort.Details;
                    dr["Hours"] = effort.Hours;
                    dr["Date"] = effort.Date;
                    dt.Rows.Add(dr);
                }
            }

            if (dt != null && dt.Rows.Count > 0)
            {
                string UserId = HttpContext.Current.User.Identity.Name;
                UserId = (UserId.IndexOf('-') > 0 ? UserId.Replace("PMI\\a-", "") : UserId.Replace("PMI\\", ""));
                fileName = _strTempFilePath + "\\" + "EffortDetails" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xls";
                ExportToExcel(dt, UserId, fileName);
            }

            return fileName;
        }

        public static void ExportToExcel(DataTable table, string UserId, string fileName)
        {
            String excelFileName = fileName;
            FileStream stream = new FileStream(fileName, System.IO.FileMode.Create);
            StreamWriter writer = new StreamWriter(stream);
            writer.WriteLine("<?xml version=\"1.0\"?>");
            writer.WriteLine("<?mso-application progid=\"Excel.Sheet\"?>");
            writer.WriteLine(" <Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\"");
            writer.WriteLine("xmlns:o=\"urn:schemas-microsoft-com:office:office\"");
            writer.WriteLine("xmlns:x=\"urn:schemas-microsoft-com:office:excel\"");
            writer.WriteLine("xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\"");
            writer.WriteLine("xmlns:html=\"http://www.w3.org/TR/REC-html40\">");
            writer.WriteLine("<ExcelWorkbook xmlns=\"urn:schemas-microsoft-com:office:excel\">");
            writer.WriteLine("<WindowHeight>8115</WindowHeight>");
            writer.WriteLine("<WindowWidth>15195</WindowWidth>");
            writer.WriteLine("<WindowTopX>0</WindowTopX>");
            writer.WriteLine("<WindowTopY>60</WindowTopY>");
            writer.WriteLine("<ActiveSheet>0</ActiveSheet>");
            writer.WriteLine("<ProtectStructure>False</ProtectStructure>");
            writer.WriteLine("<ProtectWindows>False</ProtectWindows>");
            writer.WriteLine("</ExcelWorkbook>");
            writer.WriteLine("<Styles>");
            writer.WriteLine("<Style ss:ID=\"s21\">");
            writer.WriteLine("<Alignment ss:Horizontal=\"Center\" ss:Vertical=\"Bottom\"/>");
            writer.WriteLine("<Font ss:FontName=\"Lucida Console\" x:Family=\"Modern\" ss:Bold=\"1\"/>");
            writer.WriteLine("</Style>");
            writer.WriteLine("<Style ss:ID=\"s23\">");
            writer.WriteLine("<Font ss:FontName=\"Lucida Console\" x:Family=\"Modern\"/>");
            writer.WriteLine("</Style>");
            writer.WriteLine("</Styles>");

            if (table != null && table.Rows.Count > 0)
            {
                CreateWorksheetStatic(writer, table, UserId);
            }

            writer.WriteLine("</Workbook>");
            writer.Flush();
            stream.Close();
            //System.Diagnostics.Process.Start(excelFileName);
        }

        private static void CreateWorksheetStatic(StreamWriter writer, DataTable table, string tablename)
        {
            StringBuilder excelWriter = new StringBuilder();
            DataTable columnWidth = new DataTable("COLUMNWIDTH");
            columnWidth.Columns.Add("ColumnName", typeof(string));
            columnWidth.Columns.Add("Width", typeof(int));

            string strWorksheetName = tablename;

            excelWriter.AppendLine("<Worksheet ss:Name=\"" + strWorksheetName + "\">");
            excelWriter.AppendLine("<Table>");
            //------Header
            excelWriter.AppendLine("@#$");
            excelWriter.AppendLine("<Row >");

            for (int intColCounter = 0; intColCounter < table.Columns.Count; ++intColCounter)
            {
                //string colName1 = table.Columns[intColCounter].ColumnName.ToString();
                excelWriter.AppendLine("<Cell ss:StyleID=\"s21\"><Data ss:Type=\"String\">" + table.Columns[intColCounter].ColumnName.ToString().Replace("_", " ") + "</Data></Cell>");
            }

            excelWriter.AppendLine("</Row>");

            //Body
            if (table.Rows.Count > 0)
            {
                Object curObj;
                foreach (DataRow objDataRow in table.Rows)
                {
                    excelWriter.AppendLine("<Row >");
                    for (int intColCounter = 0; intColCounter < table.Columns.Count; ++intColCounter)
                    {
                        string colName2 = table.Columns[intColCounter].ColumnName.ToString();

                        curObj = objDataRow[intColCounter];

                        if (table.Columns[intColCounter].DataType == typeof(System.Int16) ||

                            table.Columns[intColCounter].DataType == typeof(System.Int32) ||

                            table.Columns[intColCounter].DataType == typeof(System.Int64) ||

                            table.Columns[intColCounter].DataType == typeof(System.Decimal) ||

                            table.Columns[intColCounter].DataType == typeof(System.Double))
                        {
                            excelWriter.AppendLine("<Cell ss:StyleID=\"s23\"><Data ss:Type=\"Number\">" + curObj.ToString() + "</Data></Cell>");
                        }
                        else
                        {
                            excelWriter.AppendLine("<Cell ss:StyleID=\"s23\"><Data ss:Type=\"String\">" + curObj.ToString() + "</Data></Cell>");
                        }

                        DataRow[] dRow = columnWidth.Select("ColumnName = '" + table.Columns[intColCounter].ColumnName.ToString() + "'");

                        if (dRow.Length == 0)
                        {
                            columnWidth.Rows.Add(table.Columns[intColCounter].ColumnName.ToString(), curObj.ToString().Trim().Length);
                        }
                        else
                        {
                            //if (int.Parse(dRow[0]["Width"].ToString()) < curObj.ToString().Trim().Length)
                            //{
                            //    dRow[0]["Width"] = curObj.ToString().Trim().Length;
                            //}

                            if (table.Columns[intColCounter].ColumnName.ToString() == "UserName" || table.Columns[intColCounter].ColumnName.ToString() == "Type" || table.Columns[intColCounter].ColumnName.ToString() == "Service")
                            {
                                dRow[0]["Width"] = 25;
                            }
                            else if (table.Columns[intColCounter].ColumnName.ToString() == "Details")
                            {
                                dRow[0]["Width"] = 35;
                            }
                            else if (int.Parse(dRow[0]["Width"].ToString()) < curObj.ToString().Trim().Length)
                            {
                                dRow[0]["Width"] = curObj.ToString().Trim().Length;
                            }
                        }

                    }
                    columnWidth.AcceptChanges();
                    excelWriter.AppendLine("</Row >");
                }
            }

            string colWidth = string.Empty;

            for (int iCount = 0; iCount < columnWidth.Rows.Count; iCount++)
            {
                if (Convert.ToString(columnWidth.Rows[iCount]["ColumnName"]).Trim().Length > int.Parse(Convert.ToString(columnWidth.Rows[iCount]["Width"])))

                    columnWidth.Rows[iCount]["Width"] = Convert.ToString(columnWidth.Rows[iCount]["ColumnName"]).Trim().Length;

                colWidth = colWidth + string.Format("<Column ss:Index=\"{0}\" ss:Width=\"{1}\"/>", iCount + 1, int.Parse(Convert.ToString(columnWidth.Rows[iCount]["Width"])) * 8) + Environment.NewLine;
            }
            //--fixed
            excelWriter.Replace("@#$", colWidth);
            excelWriter.AppendLine("</Table>");
            excelWriter.AppendLine("<WorksheetOptions xmlns=\"urn:schemas-microsoft-com:office:excel\">");
            excelWriter.AppendLine("<ProtectObjects>False</ProtectObjects>");
            excelWriter.AppendLine("<ProtectScenarios>False</ProtectScenarios>");
            excelWriter.AppendLine("</WorksheetOptions>");
            excelWriter.AppendLine("</Worksheet>");
            writer.WriteLine(excelWriter.ToString());
        }

        public static void ExportExcel(DataTable dt, string FileName)
        {
            HttpResponse Response = HttpContext.Current.Response;
            if (dt.Rows.Count > 0)
            {
                Response.Clear();
                Response.ClearContent();
                Response.ContentType = "application/octet-stream";
                Response.AddHeader("Content-Disposition", "attachment; filename=" + FileName + "");
                GridView excel = new GridView();
                excel.DataSource = dt;
                excel.DataBind();
                excel.RenderControl(new HtmlTextWriter(Response.Output));
                Response.Flush();
                Response.End();
                System.Diagnostics.Process.Start(FileName);
            }
        }


        [WebMethod]
        public static string ExportEffortReport(string user, string service, string startdate, string enddate)
        {
            string fileName = string.Empty;
            XmlDocument _objXmlConfig = new XmlDocument();
            string _strConfigPath = null;
            if (File.Exists("C:\\NWLS_V4.0\\AppServer\\Configurations\\XMLObject.xml"))
            {
                _strConfigPath = "C:\\NWLS_V4.0\\AppServer\\Configurations\\";
            }
            else
            {
                _strConfigPath = "E:\\NWLS_V4.0\\AppServer\\Configurations\\";
            }
            string _strRptConfig = _strConfigPath + "File.Config";
            _objXmlConfig.Load(_strRptConfig);
            string _strTempFilePath = _objXmlConfig.GetElementsByTagName("ReportPath").Item(0).Attributes["value"].Value.ToString();
            List<EffortDetails> effortDtls = new List<EffortDetails>();
            DataTable dt = new DataTable();
            dt.Columns.Add("UserId");
            dt.Columns.Add("UserName");
            dt.Columns.Add("Service");
            dt.Columns.Add("TotalHours");
            dt.Columns.Add("StartDate");
            dt.Columns.Add("EndDate");

            if (user != "?")
            {
                string[] arrName = user.Split(',');
                string[] firstName = arrName[0].Split('[');
                user = firstName[1].Trim();
            }
            else
            {
                user = "";
            }

            DataLibrary.ToolsService fbClient = new DataLibrary.ToolsService();
            effortDtls = fbClient.effortDetailReport(user, service, startdate, enddate);

            if (effortDtls != null && effortDtls.Count > 0)
            {
                foreach (EffortDetails effort in effortDtls)
                {
                    //string Name = string.Empty;
                    //Dictionary<string, string> dicUserParam = new Common().GetUserParameters(effort.UserId);
                    //if (dicUserParam != null && dicUserParam.Count > 0)
                    //{
                    //    string[] arrNameMailId = dicUserParam[effort.UserId].ToString().Split('|');
                    //    Name = arrNameMailId[0];
                    //}

                    DataRow dr = dt.NewRow();
                    dr["UserId"] = effort.UserId;
                    dr["UserName"] = effort.UserName;
                    dr["Service"] = effort.Service;
                    dr["TotalHours"] = effort.Hours;
                    dr["StartDate"] = effort.CreateDate;
                    dr["EndDate"] = effort.Date;
                    dt.Rows.Add(dr);
                }
            }

            if (dt != null && dt.Rows.Count > 0)
            {
                string UserId = HttpContext.Current.User.Identity.Name;
                UserId = (UserId.IndexOf('-') > 0 ? UserId.Replace("PMI\\a-", "") : UserId.Replace("PMI\\", ""));
                fileName = _strTempFilePath + "\\" + "EffortReport" + DateTime.Now.ToString("ddMMyyyyHHmmss") + ".xls";
                ExportToExcel(dt, UserId, fileName);
            }

            return fileName;
        }
    }
}
