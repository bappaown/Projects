﻿document.write("<script type='text/javascript' src='canvasjs.min.js'> </script>");

$(document).ready(function () {


});


function LineChart(type,dps1,dps2,dps3){


var chart="";
var options = new Array(dps1,dps2,dps3);

for(var i = 0; i<options.length; i++)
{  
chart+="{type: "+"\"" +type+ "\""+",showInLegend: true,lineThickness: 2,dataPoints: "+options[i]+"},";
}
//chart="["+chart.slice(0,-1)+"]";
chart=chart.slice(0,-1);

alert(chart);
	
var chart = new CanvasJS.Chart("chartContainer", {
				title: {
					text: type + " chart",
					fontSize: 30
				},
				animationEnabled: true,
				axisX: {
					gridColor: "Silver",
					tickColor: "silver",
					title: "Axis X Title"
				},
				toolTip: {
					shared: true
				},
				theme: "theme2",
				axisY: {
					gridColor: "Silver",
					tickColor: "silver",
					title: "Axis Y Title"
				},
				legend: {
					verticalAlign: "center",
					horizontalAlign: "right"
				},
				data:chart
				 ,
				legend: {
					cursor: "pointer",
					itemclick: function (e) {
						if (typeof (e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
							e.dataSeries.visible = false;
						}
						else {
							e.dataSeries.visible = true;
						}
						chart.render();
					}
				}
			});

			chart.render();
		}


function PieChart(type,dps1){
	var chart = new CanvasJS.Chart("chartContainer",
	{
		theme: "theme2",
		title:{
			text: "pie chart"
		},
		data: [
		{
			type: "pie",
			showInLegend: true,
			toolTipContent: "{y} - #percent %",
			legendText: "{indexLabel}",
			dataPoints: dps1
		}
		]
	});
	chart.render();
}

