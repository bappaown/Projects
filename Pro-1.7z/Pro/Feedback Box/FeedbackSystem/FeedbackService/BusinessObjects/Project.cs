﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace BusinessObjects
{
    [DataContract]
    public class Project
    {
        [DataMember]
        public string ProjectCode { get; set; }
        [DataMember]
        public string ProjectName { get; set; }
        [DataMember]
        public string ProjectDescription { get; set; }
        [DataMember]
        public bool IsActive { get; set; }
    }
}
