﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Xml;

namespace BusinessObjects
{
  public  static class Helper
    {
        public static string GetQuaterDetails(int startMonth,int endMonth)
        {
            string quater = string.Empty;
            if (startMonth >= 1 && endMonth <= 3)
                quater = "JAN - MAR";
            if (startMonth >= 4 && endMonth <= 6)
                quater = "APR - JUN";
            if (startMonth >= 7 && endMonth <= 9)
                quater = "JUL - SEP";
            if (startMonth >= 10 && endMonth <= 12)
                quater = "OCT - DEC";

            return quater;
        }

      /// <summary>
      /// Get Calculated Feedback
      /// </summary>
        /// <param name="resultXml">string resultXml</param>
      /// <returns></returns>
        public static List<CalculatedFeedback> GetCalculatedFeedback(string resultXml)
        {
            List<CalculatedFeedback> calFeedbackList = new List<CalculatedFeedback>();
            Category catgory = null;
            List<QuestionAnswered> questionAnsweres =null;
            QuestionAnswered question = null;
            CalculatedFeedback calFeedback = new CalculatedFeedback();

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(resultXml);
            XmlNodeList MyNode = xmlDoc.SelectNodes("Categories");
            
            foreach (XmlNode categoryNode in MyNode[0].ChildNodes)
            {
                calFeedback = new CalculatedFeedback();
                catgory = new Category();
                questionAnsweres = new List<QuestionAnswered>();
                catgory.Id =Convert.ToInt32(categoryNode.Attributes["CategoryId"].Value);
                catgory.Rating = Convert.ToDecimal(categoryNode.Attributes["Rating"].Value);
                catgory.Efficiency = categoryNode.Attributes["Efficiency"].Value;
                catgory.CategoryDescription = categoryNode.Attributes["CategoryDescription"].Value;

                foreach(XmlNode questionNode in categoryNode.ChildNodes)
                {
                    question = new QuestionAnswered();
                    question.QuestionId = Convert.ToInt32(questionNode.Attributes["Question"].Value);
                    question.PersonAnswered = Convert.ToInt32(questionNode.Attributes["PersonAnswered"].Value);
                    question.QuesEfficiency = Convert.ToDecimal(questionNode.Attributes["QuesEfficiency"].Value);
                    question.QuestionDescription = questionNode.Attributes["QuestionDescription"].Value;

                    if (!questionAnsweres.Contains(question))
                        questionAnsweres.Add(question);
                }

                calFeedback.Category = catgory;
                calFeedback.QuestionAnsweredList = questionAnsweres;

                if (!calFeedbackList.Contains(calFeedback))
                {
                    calFeedbackList.Add(calFeedback);
                }
            }

            return calFeedbackList;

        }

    }
}
