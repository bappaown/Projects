﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class User
    {
        [DataMember]
        public string UserId { get; set; }
        [DataMember]
        public string Name { get; set; }
        [DataMember]
        public string EmailId { get; set; }       
        [DataMember]
        public int UserType { get; set; }
        [DataMember]
        public string IBMEmailId { get; set; }
        [DataMember]
        public string PeopleManagerId { get; set; }
    }
}
