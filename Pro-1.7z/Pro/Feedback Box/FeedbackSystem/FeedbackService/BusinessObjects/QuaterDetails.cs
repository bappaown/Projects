﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class QuaterDetails
    {
        [DataMember]
        public int QuaterId { get; set; }
        [DataMember]
        public int StartMonth { get; set; }
        [DataMember]
        public int EndMonth { get; set; }
        [DataMember]
        public bool IsActive { get; set; }
        [DataMember]
        public string QuaterDesc { get; set; }
        [DataMember]
        public int Year { get; set; }
    }
}
