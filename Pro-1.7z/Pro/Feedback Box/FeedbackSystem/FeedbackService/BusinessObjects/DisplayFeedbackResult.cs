﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class DisplayFeedbackResult
    {
        [DataMember]
        public List<DisplayFeedback> DisplayFeedbackA { get; set; }
        [DataMember]
        public List<DisplayFeedback> DisplayFeedbackB { get; set; }
        [DataMember]
        public List<DisplayFeedback> DisplayFeedbackC { get; set; }
        [DataMember]
        public List<DisplayFeedback> DisplayFeedbackD { get; set; }
    }
}
