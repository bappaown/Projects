﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class UserProject
    {
        [DataMember]
        public string UserId { get; set; }
        [DataMember]
        public string ProjectCode { get; set; }
        [DataMember]
        public DateTime? StartDate { get; set; }
        [DataMember]
        public DateTime? EndDate { get; set; }
        [DataMember]
        public string ManagerId { get; set; }
        [DataMember]
        public string UniqueCode { get; set; }
        [DataMember]
        public string ProjectLeaderID { get; set; }
        [DataMember]
        public bool IsActive { get; set; }
    }
}
