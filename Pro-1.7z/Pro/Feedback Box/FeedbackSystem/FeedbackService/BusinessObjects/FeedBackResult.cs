﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class FeedBackResult
    {
        [DataMember]
        public int FeedBackResultID { get; set; }
        [DataMember]
        public string ForUser { get; set; }
        [DataMember]
        public decimal OverallRating { get; set; }
        [DataMember]
        public int FeedbackYear { get; set; }
        [DataMember]
        public int QuaterId { get; set; }
        [DataMember]
        public string ResultXml { get; set; }
    }
}
