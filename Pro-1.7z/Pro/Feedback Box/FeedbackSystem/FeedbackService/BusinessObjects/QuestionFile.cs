﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class QuestionFile
    {
        [DataMember]
        public string FileName { get; set; }
        [DataMember]
        public byte[] File { get; set; }
        [DataMember]
        public int QuaterId { get; set; }
    }
}
