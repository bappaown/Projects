﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessObjects
{
   public class WeightageMaster
    {
       public int Id { get; set; }
       public UserType UserType { get; set; }
       public decimal Value { get; set; }
    }
}
