﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
  public class QuestionAnswered
    {
        [DataMember]
        public int QuestionId { get; set; }
        [DataMember]
        public string QuestionDescription { get; set; }
        [DataMember]
        public bool QuestionActive { get; set; }
        [DataMember]
        public string CreatedBy { get; set; }
        [DataMember]
        public DateTime CreatedDate { get; set; }
        [DataMember]
        public string ProjectCode { get; set; }
        [DataMember]
        public int CategoryId { get; set; }

        [DataMember]
        public int PersonAnswered { get; set; }
        [DataMember]
        public decimal QuesEfficiency { get; set; }
    }
}
