﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class CalculatedFeedback
    {
        [DataMember]
        public Category Category { get; set; }
        [DataMember]
        public List<QuestionAnswered> QuestionAnsweredList { get; set; }
    }
}
