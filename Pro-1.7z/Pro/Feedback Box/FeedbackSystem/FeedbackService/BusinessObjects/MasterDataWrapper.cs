﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class MasterDataWrapper
    {
        [DataMember]
        public QuaterDetails ActiveQuater { get; set; }
        [DataMember]
        public List<Category> Categories { get; set; }
        [DataMember]
        public List<Question> Questions { get; set; }
        [DataMember]
        public User LoogedInUser { get; set; }
        [DataMember]
        public UserType LoogedInUserType { get; set; }
        [DataMember]
        public List<AnswerPriorityMaster> AnswerPriorityList { get; set; }
    }
}
