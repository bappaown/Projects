﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class Feedback
    {
        [DataMember]
        public string FromUser { get; set; }
        [DataMember]
        public string ForUser { get; set; }
        [DataMember]
        public string QuestionAnswered { get; set; }
        [DataMember]
        public string Comments { get; set; }
        [DataMember]
        public DateTime OnDate { get; set; }
        [DataMember]
        public int QuaterId { get; set; }
        [DataMember]
        public int Year { get; set; }
    }
}
