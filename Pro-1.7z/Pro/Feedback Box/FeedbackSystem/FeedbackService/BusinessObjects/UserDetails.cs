﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class UserDetails
    {
        [DataMember]
        public User User { get; set; }
        [DataMember]
        public List<Project> Projects { get; set; }
        [DataMember]
        public UserType UserType { get; set; }
        [DataMember]
        public bool IsFeedbackGiven { get; set; }
    }
}
