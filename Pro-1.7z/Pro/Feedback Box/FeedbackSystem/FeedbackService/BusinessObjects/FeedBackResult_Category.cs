﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace BusinessObjects
{
   public class FeedBackResult_Category
    {
       public int FeedBackResultId { get; set; }
       public Category Category { get; set; }
       public decimal Rating { get; set; }
    }
}
