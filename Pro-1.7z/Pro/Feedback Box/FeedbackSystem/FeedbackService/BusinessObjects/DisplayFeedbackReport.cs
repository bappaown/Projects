﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class DisplayFeedbackReport
    {
        [DataMember]
        public User ForUser { get; set; }
        [DataMember]
        public string OvarallRating { get; set; }
        [DataMember]
        public int QuaterId { get; set; }
        [DataMember]
        public string QuaterDetails { get; set; }
        [DataMember]
        public List<CalculatedFeedback> CalculatedResult { get; set; }
    }
}
