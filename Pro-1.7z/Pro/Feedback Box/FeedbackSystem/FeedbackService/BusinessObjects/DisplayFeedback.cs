﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class DisplayFeedback
    {
        [DataMember]
        public string ForUser { get; set; }
        [DataMember]
        public string ForUserName { get; set; }
        [DataMember]
        public string ForUserType { get; set; }
        [DataMember]
        public string OverallRating { get; set; }
        [DataMember]
        public string PersonAnswered { get; set; }
        [DataMember]
        public string FeedbackYear { get; set; }
        [DataMember]
        public string QuaterId { get; set; }
        [DataMember]
        public string Teaming { get; set; }
        [DataMember]
        public string ClientDelight { get; set; }
        [DataMember]
        public string Upskills { get; set; }
        [DataMember]
        public string Alliance { get; set; }
        [DataMember]
        public string Commercials { get; set; }
        [DataMember]
        public string nWoW { get; set; }
    }
}
