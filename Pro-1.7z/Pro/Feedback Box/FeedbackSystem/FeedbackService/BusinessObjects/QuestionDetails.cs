﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class QuestionDetails
    {
        [DataMember]
        public int QuestionYear { get; set; }
        [DataMember]
        public string QuestionQuarter { get; set; }
        [DataMember]
        public string QuestionFileName { get; set; }
        [DataMember]
        public byte[] QuestionFile { get; set; }
    }
}
