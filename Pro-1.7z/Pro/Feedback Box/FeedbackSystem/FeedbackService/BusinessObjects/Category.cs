﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace BusinessObjects
{
    [DataContract]
    public class Category
    {
        [DataMember]
        public int Id { get; set; }
        [DataMember]
        public string Type { get; set; }
        [DataMember]
        public string CreatedBy { get; set; }
        [DataMember]
        public DateTime CreatedDate { get; set; }

        [DataMember]
        public decimal Rating { get; set; }
        [DataMember]
        public string Efficiency { get; set; }

        [DataMember]
        public string CategoryDescription { get; set; }

    }
}
