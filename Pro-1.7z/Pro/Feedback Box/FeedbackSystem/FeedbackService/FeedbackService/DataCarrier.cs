﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using BusinessObjects;

namespace FeedbackService
{
    public class DataCarrier
    {
        /// <summary>
        /// This method used for fetch data
        /// </summary>
        /// <param name="spName">Store procedure Name</param>
        /// <param name="parameters">parameters as Dictionary<string, string></param>
        /// <returns></returns>
        public DataSet GetData(string spName, Dictionary<string, string> parameters)
        {
            try
            {
                using (SqlConnection sqlCon = DBConnect.CreateConnection())
                {
                    DataSet ds = new DataSet();
                    using (SqlCommand sqlCmd = new SqlCommand(spName, sqlCon))
                    {
                        sqlCmd.CommandTimeout = 300;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        if (parameters != null)
                        {
                            foreach (string paramName in parameters.Keys)
                            {
                                sqlCmd.Parameters.AddWithValue(paramName, parameters[paramName]);
                            }
                        }

                        SqlDataAdapter sqlDa = new SqlDataAdapter();
                        sqlCon.Open();
                        sqlDa.SelectCommand = sqlCmd;
                        sqlDa.Fill(ds);
                    }
                    return ds;
                }
            }
            catch (Exception)
            {
                throw;
            }

        }

        /// <summary>
        /// This method used for fetch data
        /// </summary>
        /// <param name="spName">Store procedure Name</param>
        /// <param name="parameters">parameters as Dictionary<string, string></param>
        /// <returns></returns>
        public bool InsertData(string spName, object paramerters, string objectType)
        {
            bool status = false;
            try
            {
                using (SqlConnection sqlCon = DBConnect.CreateConnection())
                {
                    DataSet ds = new DataSet();
                    SqlCommand sqlCmd = new SqlCommand(spName, sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    if (paramerters != null)
                    {
                        FillCommandParamaters(ref sqlCmd, paramerters, objectType);

                    }
                    sqlCon.Open();
                    sqlCmd.ExecuteNonQuery();
                    status = true;
                    sqlCmd.Dispose();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return status;
        }

        /// <summary>
        /// Fill the command with parameters.
        /// </summary>
        /// <param name="sqlCmd">sqlCmd as SqlCommand</param>
        /// <param name="paramerters">paramerters as Object</param>
        /// <param name="objectType">objectType as sring</param>
        private void FillCommandParamaters(ref SqlCommand sqlCmd, object paramerters, string objectType)
        {
            switch (objectType)
            {
                case "Feedback":
                    Feedback feedBack = (Feedback)paramerters;
                    sqlCmd.Parameters.AddWithValue("FromUser", feedBack.FromUser);
                    sqlCmd.Parameters.AddWithValue("ForUser", feedBack.ForUser);
                    sqlCmd.Parameters.AddWithValue("QuestionAnswered", feedBack.QuestionAnswered);
                    sqlCmd.Parameters.AddWithValue("Comments", feedBack.Comments);
                    sqlCmd.Parameters.AddWithValue("OnDate", feedBack.OnDate);
                    sqlCmd.Parameters.AddWithValue("QuaterId", feedBack.QuaterId);
                    sqlCmd.Parameters.AddWithValue("Year", feedBack.Year);
                    break;
                case "QuestionFile":
                    QuestionFile questionfile = (QuestionFile)paramerters;
                    sqlCmd.Parameters.AddWithValue("FileName", questionfile.FileName);
                    sqlCmd.Parameters.AddWithValue("File", questionfile.File);
                    sqlCmd.Parameters.AddWithValue("QuaterId", questionfile.QuaterId);
                    break;
                case "User":
                    User user = (User)paramerters;
                    sqlCmd.Parameters.AddWithValue("UserId", user.UserId);
                    sqlCmd.Parameters.AddWithValue("Name", user.Name);
                    sqlCmd.Parameters.AddWithValue("EmailId", user.EmailId);
                    sqlCmd.Parameters.AddWithValue("UserType", user.UserType);
                    sqlCmd.Parameters.AddWithValue("IBMEmailId", user.IBMEmailId);
                    sqlCmd.Parameters.AddWithValue("PeopleManagerId", user.PeopleManagerId);
                    break;
                case "Project":
                    Project project = (Project)paramerters;
                    sqlCmd.Parameters.AddWithValue("IsActive", project.IsActive);
                    sqlCmd.Parameters.AddWithValue("ProjectCode", project.ProjectCode);
                    sqlCmd.Parameters.AddWithValue("ProjectDescription", project.ProjectDescription);
                    sqlCmd.Parameters.AddWithValue("ProjectName", project.ProjectName);
                    break;
                case "UserProject":
                    UserProject userproject = (UserProject)paramerters;
                    sqlCmd.Parameters.AddWithValue("EndDate", Convert.ToString(userproject.EndDate));
                    sqlCmd.Parameters.AddWithValue("IsActive", userproject.IsActive);
                    sqlCmd.Parameters.AddWithValue("ManagerId", userproject.ManagerId);
                    sqlCmd.Parameters.AddWithValue("ProjectCode", userproject.ProjectCode);
                    sqlCmd.Parameters.AddWithValue("ProjectLeaderID", userproject.ProjectLeaderID);
                    sqlCmd.Parameters.AddWithValue("StartDate", Convert.ToString(userproject.StartDate));
                    sqlCmd.Parameters.AddWithValue("UniqueCode", userproject.UniqueCode);
                    sqlCmd.Parameters.AddWithValue("UserId", userproject.UserId);
                    break;
                default:
                    break;
            }
        }
    }
}
