﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using BusinessObjects;
using System.Data;
using System.Reflection;

namespace FeedbackService
{
    /// <summary>
    /// This class used as feed back service 
    /// </summary>
    public class FeedbackService : IFeedbackService
    {
        /// <summary>
        /// Upload user details
        /// </summary>
        /// <param name="Users">Users as List<User></param>
        /// <returns></returns>
        public bool UploadUsers(List<User> Users)
        {
            bool uploadStatus = false;
            try
            {
                var objBulk = new BulkUploadData<User>()
                {
                    InternalStore = Users,
                    TableName = "[dbo].[360_User]",
                    CommitBatchSize = 1000
                };

                objBulk.Commit();
                uploadStatus = true;
                return uploadStatus;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Upload project details
        /// </summary>
        /// <param name="Projects">Projects as List<Project></param>
        /// <returns></returns>
        public bool UploadProjects(List<Project> Projects)
        {
            bool uploadStatus = false;
            try
            {
                var objBulk = new BulkUploadData<Project>()
                {
                    InternalStore = Projects,
                    TableName = "[dbo].[360_Project]",
                    CommitBatchSize = 1000
                };

                objBulk.Commit();
                uploadStatus = true;
                return uploadStatus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Upload User Project details
        /// </summary>
        /// <param name="UserProjects">UserProjects as List<UserProject></param>
        /// <returns></returns>
        public bool UploadUserProjects(List<UserProject> UserProjects)
        {
            bool uploadStatus = false;
            try
            {
                var objBulk = new BulkUploadData<UserProject>()
                {
                    InternalStore = UserProjects,
                    TableName = "[dbo].[360_UserProject]",
                    CommitBatchSize = 1000
                };

                objBulk.Commit();
                uploadStatus = true;
                return uploadStatus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Upload User Question
        /// </summary>
        /// <param name="UserProjects">Questions as List<Question></param>
        /// <returns></returns>
        public bool UploadQuestion(List<Question> Questions)
        {
            bool uploadStatus = false;
            try
            {
                var objBulk = new BulkUploadData<Question>()
                {
                    InternalStore = Questions,
                    TableName = "[dbo].[360_Questions]",
                    CommitBatchSize = 1000
                };

                objBulk.Commit();
                uploadStatus = true;
                return uploadStatus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Submit the users
        /// </summary>
        /// <param name="feedBack">feedBack as Feedback</param>
        /// <returns></returns>
        public bool SubmitUsers(List<User> Users)
        {
            bool submitUsers = false;
            try
            {
                DataCarrier dataCarrier = new DataCarrier();
                foreach (User User in Users)
                {
                    submitUsers = dataCarrier.InsertData("sp_Feedback_SubmitUsers", User, "User");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return submitUsers;
        }

        /// <summary>
        /// Submit the Projects
        /// </summary>
        /// <param name="feedBack">feedBack as Feedback</param>
        /// <returns></returns>
        public bool SubmitProjects(List<Project> Projects)
        {
            bool submitProjects = false;
            try
            {
                DataCarrier dataCarrier = new DataCarrier();
                foreach (Project Project in Projects)
                {
                    //submitProjects = dataCarrier.InsertData("sp_Feedback_SubmitProjects", Project, "Project");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return submitProjects;
        }

        /// <summary>
        /// Submit the User Projects
        /// </summary>
        /// <param name="feedBack">feedBack as Feedback</param>
        /// <returns></returns>
        public bool SubmitUserProjects(List<UserProject> UserProject)
        {
            bool submitProjects = false;
            try
            {
                DataCarrier dataCarrier = new DataCarrier();
                foreach (UserProject Projects in UserProject)
                {
                    submitProjects = dataCarrier.InsertData("sp_Feedback_SubmitUserProjects", Projects, "UserProject");
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return submitProjects;
        }


        public DataTable ToDataTable<User>(List<User> items)
        {
            DataTable dataTable = new DataTable(typeof(User).Name);
            PropertyInfo[] Props = typeof(User).GetProperties(BindingFlags.Public | BindingFlags.Instance);

            foreach (PropertyInfo prop in Props)
            {
                dataTable.Columns.Add(prop.Name);
            }

            foreach (User item in items)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }

            return dataTable;
        }

        /// <summary>
        /// Submit the user feedback
        /// </summary>
        /// <param name="feedBack">feedBack as Feedback</param>
        /// <returns></returns>
        public bool SubmitFeedback(List<Feedback> feedBackList)
        {
            bool submitStatus = false;
            try
            {
                DataCarrier dataCarrier = new DataCarrier();
                foreach (Feedback feedBack in feedBackList)
                {
                    dataCarrier.InsertData("sp_Feedback_SubmitFeedback", feedBack, "Feedback");
                }
                submitStatus = true;
                return submitStatus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get Question Category
        /// </summary>
        /// <returns>List<Category></returns>
        public List<Category> GetCategories()
        {
            List<Category> categoryList = new List<Category>();
            try
            {
                Category category;
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("SelectType", "CATEGORY");
                DataSet ds = new DataCarrier().GetData("sp_Feedback_GetMasterData", parameter);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        category = new Category();
                        category.Id = Convert.ToInt32(dr["Id"]);
                        category.Type = dr["Type"].ToString();
                        if (!categoryList.Contains(category))
                        {
                            categoryList.Add(category);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return categoryList;
        }

        /// <summary>
        /// Get Questions
        /// </summary>
        /// <returns>List<Question></returns>
        public List<Question> GetQuestions()
        {
            List<Question> questionList = new List<Question>();
            try
            {
                Question question;
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("SelectType", "QUESTION");
                DataSet ds = new DataCarrier().GetData("sp_Feedback_GetMasterData", parameter);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        question = new Question();
                        question.QuestionId = Convert.ToInt32(dr["QuestionId"]);
                        question.QuestionDescription = dr["QuestionDescription"].ToString();
                        question.CategoryId = Convert.ToInt32(dr["CategoryId"]);
                        question.QuaterId = Convert.ToInt32(dr["QuaterId"]);
                        if (!questionList.Contains(question))
                        {
                            questionList.Add(question);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return questionList;
        }

        /// <summary>
        /// Update question file
        /// </summary>
        /// <param name="questionFile"></param>
        /// <returns></returns>
        public bool UpdateQuesttionFile(QuestionFile questionFile)
        {
            bool submitStatus = false;
            try
            {
                DataCarrier dataCarrier = new DataCarrier();

                dataCarrier.InsertData("sp_Feedback_UpdateQuestionFile", questionFile, "QuestionFile");

                submitStatus = true;
                return submitStatus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get user type
        /// </summary>
        /// <returns>List<UserType></returns>
        public List<UserType> GetUserType()
        {
            List<UserType> userTypeList = new List<UserType>();

            try
            {
                UserType userType;
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("SelectType", "USERTYPE");
                DataSet ds = new DataCarrier().GetData("sp_Feedback_GetMasterData", parameter);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        userType = new UserType();
                        userType.Id = Convert.ToInt32(dr["Id"]);
                        userType.Type = dr["Type"].ToString();
                        if (!userTypeList.Contains(userType))
                        {
                            userTypeList.Add(userType);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return userTypeList;
        }

        /// <summary>
        /// Get the question details
        /// </summary>
        /// <returns>List<QuestionDetails></returns>
        public List<QuestionDetails> GetQuestionDetails()
        {
            List<QuestionDetails> questionList = new List<QuestionDetails>();
            try
            {
                QuestionDetails questions;
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("SelectType", "QUESTIONFILE");
                DataSet ds = new DataCarrier().GetData("sp_Feedback_GetMasterData", parameter);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        questions = new QuestionDetails();
                        string Quarter = Helper.GetQuaterDetails(Convert.ToInt32(dr["StartMonth"]), Convert.ToInt32(dr["EndMonth"]));
                        if (!Convert.IsDBNull(dr["QuestionFile"]))
                        {
                            byte[] file = (byte[])dr["QuestionFile"];
                            questions.QuestionFile = file;
                        }

                        questions.QuestionYear = Convert.ToInt32(dr["Year"]);
                        questions.QuestionQuarter = Quarter;
                        questions.QuestionFileName = dr["QuestionFileName"].ToString();


                        if (!questionList.Contains(questions))
                        {
                            questionList.Add(questions);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return questionList;
        }

        /// <summary>
        /// Get the efficiency master
        /// </summary>
        /// <returns>List<EfficiencyMaster></returns>
        public List<EfficiencyMaster> GetEfficiencyMaster()
        {
            List<EfficiencyMaster> efficencyList = new List<EfficiencyMaster>();
            try
            {
                EfficiencyMaster efficiency;
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("SelectType", "EFFICIENCY");
                DataSet ds = new DataCarrier().GetData("sp_Feedback_GetMasterData", parameter);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        efficiency = new EfficiencyMaster();
                        efficiency.Id = Convert.ToInt32(dr["Id"]);
                        efficiency.Type = dr["Type"].ToString();
                        efficiency.MinValue = Convert.ToInt32(dr["MinValue"]);
                        efficiency.MaxValue = Convert.ToInt32(dr["MaxValue"]);

                        if (!efficencyList.Contains(efficiency))
                        {
                            efficencyList.Add(efficiency);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return efficencyList;
        }

        /// <summary>
        /// Get answer Priority
        /// </summary>
        /// <returns>List<AnswerPriorityMaster></returns>
        public List<AnswerPriorityMaster> GetAnswerPriority()
        {
            List<AnswerPriorityMaster> ansPriorityList = new List<AnswerPriorityMaster>();
            try
            {
                AnswerPriorityMaster ansPriority;
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("SelectType", "ANSWERPRIORITY");
                DataSet ds = new DataCarrier().GetData("sp_Feedback_GetMasterData", parameter);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        ansPriority = new AnswerPriorityMaster();
                        ansPriority.Value = Convert.ToInt32(dr["Value"]);
                        ansPriority.AnswerType = dr["AnswerType"].ToString();

                        if (!ansPriorityList.Contains(ansPriority))
                        {
                            ansPriorityList.Add(ansPriority);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return ansPriorityList;
        }

        /// <summary>
        /// Get Quater Details
        /// </summary>
        /// <returns>List<QuaterDetails></returns>
        public List<QuaterDetails> GetQuaterDetail()
        {
            List<QuaterDetails> quaterList = new List<QuaterDetails>();
            try
            {
                QuaterDetails quater;
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("SelectType", "QUATER");
                DataSet ds = new DataCarrier().GetData("sp_Feedback_GetMasterData", parameter);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        quater = new QuaterDetails();
                        quater.QuaterId = Convert.ToInt32(dr["QuaterId"]);
                        quater.StartMonth = Convert.ToInt32(dr["StartMonth"].ToString());
                        quater.EndMonth = Convert.ToInt32(dr["EndMonth"].ToString());
                        quater.IsActive = Convert.ToBoolean(dr["IsActive"]);
                        quater.QuaterDesc = Helper.GetQuaterDetails(quater.StartMonth, quater.EndMonth);

                        if (!quaterList.Contains(quater))
                        {
                            quaterList.Add(quater);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return quaterList;
        }

        /// <summary>
        /// Fetch feedback report
        /// </summary>
        /// <param name="userId">userId as userId</param>
        /// <param name="feedYear">feedYear as int</param>
        /// <param name="quaterId">quaterId as int</param>
        /// <returns></returns>
        public DisplayFeedbackReport GetFeedbackReport(string userId, int feedYear, int quaterId)
        {
            DisplayFeedbackReport dispFeedBackReport = new DisplayFeedbackReport();
            try
            {
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("UserId", userId);
                parameter.Add("FeedBackYear", feedYear.ToString());
                parameter.Add("QuaterId", quaterId.ToString());
                DataSet ds = new DataCarrier().GetData("sp_Feedback_GetFeedbackResult", parameter);
                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    DataRow dr = ds.Tables[0].Rows[0];

                    User user = new User();
                    user.UserId = userId;
                    user.Name = dr["Name"].ToString();
                    user.EmailId = dr["EmailId"].ToString();
                    dispFeedBackReport.ForUser = user;

                    dispFeedBackReport.OvarallRating = dr["OverallRating"].ToString();
                    dispFeedBackReport.QuaterId = quaterId;
                    dispFeedBackReport.QuaterDetails = Helper.GetQuaterDetails(Convert.ToInt32(dr["QuaterStartMonth"].ToString()), Convert.ToInt32(dr["QuaterEndMonth"].ToString()));
                    dispFeedBackReport.CalculatedResult = Helper.GetCalculatedFeedback(dr["ResultXml"].ToString());
                }

                return dispFeedBackReport;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// Fetch feed back result
        /// </summary>
        /// <param name="ratingfrom">ratingfrom as int</param>
        /// <param name="ratingto">ratingto as int</param>
        /// <param name="topuser">topuser as int</param>
        ///  /// <param name="ratingfrom">topuser as int</param>
        /// <param name="ratingto">feedbackYear as int</param>
        /// <param name="topuser">quaterId as int</param>
        /// <returns></returns>
        public List<DisplayFeedbackResult> GetFeedbackResult(string ratingfromA, string ratingfromB, string ratingtoB, string ratingfromC, string ratingtoC, string ratingfromD, string topuser, string feedbackYear, string quaterId)
        {

            List<DisplayFeedbackResult> dispFeedBackResultList = new List<DisplayFeedbackResult>();
            DisplayFeedbackResult dispFeedBackResult = new DisplayFeedbackResult();
            try
            {
                List<DisplayFeedback> dispFeedBackList;
                DisplayFeedback displayFeedback;
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("RatingFromA", ratingfromA);
                parameter.Add("RatingFromB", ratingfromB);
                parameter.Add("RatingToB", ratingtoB);
                parameter.Add("RatingFromC", ratingfromC);
                parameter.Add("RatingToC", ratingtoC);
                parameter.Add("RatingFromD", ratingfromD);
                parameter.Add("TopUser", topuser);
                parameter.Add("FeedbackYear", feedbackYear);
                parameter.Add("Quater", quaterId);
                DataSet ds = new DataCarrier().GetData("sp_Feedback_GradeRatingCalculation", parameter);
                if (ds != null && ds.Tables.Count > 0)
                {
                    for (int i = 0; i < ds.Tables.Count; i++)
                    {
                        dispFeedBackList = new List<DisplayFeedback>();

                        if (ds.Tables[i].Rows.Count > 0)
                        {
                            foreach (DataRow dr in ds.Tables[i].Rows)
                            {
                                displayFeedback = new DisplayFeedback();
                                displayFeedback.ForUser = dr["ForUser"].ToString();
                                displayFeedback.ForUserName = dr["ForUserName"].ToString();
                                displayFeedback.ForUserType = dr["ForUserType"].ToString();
                                displayFeedback.OverallRating = dr["OverallRating"].ToString();
                                displayFeedback.PersonAnswered = dr["PersonAnswered"].ToString();
                                displayFeedback.FeedbackYear = dr["FeedbackYear"].ToString();
                                displayFeedback.QuaterId = dr["QuaterId"].ToString();
                                displayFeedback.Teaming = dr["Teaming"].ToString();
                                displayFeedback.ClientDelight = dr["Client Delight"].ToString();
                                displayFeedback.Upskills = dr["Upskills"].ToString();
                                displayFeedback.Alliance = dr["Alliance"].ToString();
                                displayFeedback.Commercials = dr["Commercials"].ToString();
                                displayFeedback.nWoW = dr["nWoW"].ToString();

                                dispFeedBackList.Add(displayFeedback);
                            }
                        }
                        if (i == 0)
                        {
                            dispFeedBackResult.DisplayFeedbackA = dispFeedBackList;
                        }
                        else if (i == 1)
                        {
                            dispFeedBackResult.DisplayFeedbackB = dispFeedBackList;
                        }
                        else if (i == 2)
                        {
                            dispFeedBackResult.DisplayFeedbackC = dispFeedBackList;
                        }
                        else if (i == 3)
                        {
                            dispFeedBackResult.DisplayFeedbackD = dispFeedBackList;
                        }

                    }
                    if (!dispFeedBackResultList.Contains(dispFeedBackResult))
                    {
                        dispFeedBackResultList.Add(dispFeedBackResult);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dispFeedBackResultList;
        }

        /// <summary>
        /// Get the Peers and reportees of employee
        /// </summary>
        /// <param name="userId"></param>
        /// <param name="searchBy"></param>
        /// <returns></returns>
        public List<User> GetPeersOfEmpolyee(string userId, string searchBy)
        {
            List<User> users = new List<User>();
            try
            {
                User user;
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("UserId", userId);
                parameter.Add("SearchBy", searchBy);
                DataSet ds = new DataCarrier().GetData("sp_Feedback_GetPeersOfEmployee", parameter);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        user = new User();
                        user.UserId = dr["UserId"].ToString();
                        user.Name = dr["Name"].ToString();
                        if (!users.Contains(user))
                        {
                            users.Add(user);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return users;
        }

        /// <summary>
        /// Get Max Unique Code
        /// </summary>
        /// <returns>MaxUniqueCode as string</returns>
        public string GetMaxUniqueCode()
        {
            string maxUniqueCode = string.Empty;
            try
            {
                DataSet ds = new DataCarrier().GetData("sp_Feedback_GetMaxUniqueCode", null);

                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    maxUniqueCode = ds.Tables[0].Rows[0][0].ToString();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return maxUniqueCode;
        }

        /// <summary>
        /// Search employee by employee name
        /// </summary>
        /// <param name="searchEmpName"></param>
        /// <returns></returns>
        public List<UserDetails> SearchEmployee(string searchEmpName, string userId)
        {
            List<UserDetails> users = new List<UserDetails>();
            try
            {
                UserDetails userDetails;
                List<Project> projectList = new List<Project>();
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("SearchEmpName", searchEmpName);
                parameter.Add("UserId", userId);
                DataSet ds = new DataCarrier().GetData("sp_Feedback_SearchEmployee", parameter);


                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    if (ds.Tables[0].Columns.Contains("NOTAUTHORISE"))
                    {
                        userDetails = new UserDetails();
                        User user = new User();
                        user.UserId = "NOTAUTHORISE";
                        user.Name = ds.Tables[0].Rows[0][0].ToString();
                        userDetails.User = user;
                        users.Add(userDetails);
                    }
                    else
                    {
                        string lastUserId = string.Empty;
                        userDetails = new UserDetails();

                        // Feedback given user list
                        List<User> givenUserList = new List<User>();
                        foreach (DataRow drUser in ds.Tables[1].Rows)
                        {
                            User givenUser = new User();
                            givenUser.UserId = drUser["UserId"].ToString();
                            givenUser.Name = drUser["Name"].ToString();
                            if (!givenUserList.Contains(givenUser))
                                givenUserList.Add(givenUser);
                        }

                        for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                        {
                            DataRow dr = ds.Tables[0].Rows[i];
                            if (lastUserId != dr["UserId"].ToString())
                            {
                                User user = new User();
                                user.UserId = dr["UserId"].ToString();
                                user.Name = dr["Name"].ToString();
                                user.EmailId = dr["EmailId"].ToString();
                                userDetails.User = user;

                                UserType userType = new UserType();
                                userType.Id = Convert.ToInt32(dr["TypeID"].ToString());
                                userType.Type = dr["Type"].ToString();
                                userDetails.UserType = userType;
                            }

                            Project project = new Project();
                            project.ProjectCode = dr["ProjectCode"].ToString();
                            project.ProjectName = dr["ProjectName"].ToString();
                            project.ProjectDescription = dr["ProjectDescription"].ToString();
                            project.IsActive = (dr["IsActive"].ToString() == string.Empty) ? false : Convert.ToBoolean(dr["IsActive"].ToString());

                            if (!projectList.Contains(project))
                            {
                                projectList.Add(project);
                            }

                            lastUserId = dr["UserId"].ToString();
                            if (i == ds.Tables[0].Rows.Count - 1)
                            {
                                userDetails.IsFeedbackGiven = givenUserList.FirstOrDefault(usr => usr.UserId == lastUserId) != null ? true : false;
                                userDetails.Projects = projectList;
                                if (!users.Contains(userDetails))
                                {
                                    users.Add(userDetails);
                                    userDetails = new UserDetails();
                                    projectList = new List<Project>();
                                }
                            }
                            else
                            {
                                if (lastUserId != ds.Tables[0].Rows[i + 1]["UserId"].ToString())
                                {
                                    userDetails.IsFeedbackGiven = givenUserList.FirstOrDefault(usr => usr.UserId == lastUserId) != null ? true : false;
                                    userDetails.Projects = projectList;
                                    if (!users.Contains(userDetails))
                                    {
                                        users.Add(userDetails);
                                        userDetails = new UserDetails();
                                        projectList = new List<Project>();
                                    }
                                }
                            }
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return users;
        }

        public MasterDataWrapper GetMastarData(string userId)
        {
            MasterDataWrapper masterDataWrapper = new MasterDataWrapper();
            try
            {
                Dictionary<string, string> parameter = new Dictionary<string, string>();
                parameter.Add("userId", userId);
                DataSet ds = new DataCarrier().GetData("sp_Feedback_LoadMasterDataAndUserDetail", parameter);
                if (ds != null)
                {

                    //if (ds.Tables[0].Columns.Contains("NORECORDS"))
                    //{
                    //    User user = new User();
                    //    user.UserId = "NORECORDS";
                    //    user.Name = ds.Tables[0].Rows[0][0].ToString();
                    //    masterDataWrapper.LoogedInUser = user;
                    //}
                    //else
                    //{
                    // get active quater
                    if (ds.Tables.Count > 0)
                    {
                        DataRow dr = ds.Tables[0].Rows[0];
                        QuaterDetails activeQuater = new QuaterDetails();
                        activeQuater.QuaterId = Convert.ToInt32(dr["QuaterId"]);
                        activeQuater.StartMonth = Convert.ToInt32(dr["StartMonth"].ToString());
                        activeQuater.EndMonth = Convert.ToInt32(dr["EndMonth"].ToString());
                        activeQuater.IsActive = Convert.ToBoolean(dr["IsActive"]);
                        activeQuater.QuaterDesc = Helper.GetQuaterDetails(activeQuater.StartMonth, activeQuater.EndMonth);
                        activeQuater.Year = Convert.ToInt32(dr["Year"]);
                        masterDataWrapper.ActiveQuater = activeQuater;
                    }

                    // Get category
                    if (ds.Tables.Count > 1)
                    {
                        List<Category> categoryList = new List<Category>();
                        foreach (DataRow dr in ds.Tables[1].Rows)
                        {
                            Category category = new Category();
                            category.Id = Convert.ToInt32(dr["Id"]);
                            category.Type = dr["Type"].ToString();
                            if (!categoryList.Contains(category))
                            {
                                categoryList.Add(category);
                            }
                        }
                        masterDataWrapper.Categories = categoryList;
                    }

                    // Get question
                    if (ds.Tables.Count > 2)
                    {
                        List<Question> questionList = new List<Question>();
                        foreach (DataRow dr in ds.Tables[2].Rows)
                        {
                            Question question = new Question();
                            question.QuestionId = Convert.ToInt32(dr["QuestionId"]);
                            question.QuestionDescription = dr["QuestionDescription"].ToString();
                            question.CategoryId = Convert.ToInt32(dr["CategoryId"]);
                            question.QuaterId = Convert.ToInt32(dr["QuaterId"]);
                            if (!questionList.Contains(question))
                            {
                                questionList.Add(question);
                            }
                        }
                        masterDataWrapper.Questions = questionList;
                    }
                    // Get logged in user details
                    if (ds.Tables.Count > 3 && ds.Tables[3].Rows.Count > 0)
                    {
                        if (ds.Tables[3].Columns.Contains("NORECORDS"))
                        {
                            User user = new User();
                            user.UserId = "NORECORDS";
                            user.Name = string.Empty;
                            user.EmailId = ds.Tables[3].Rows[0][0].ToString();
                            masterDataWrapper.LoogedInUser = user;
                        }
                        else
                        {
                            DataRow drUser = ds.Tables[3].Rows[0];
                            User user = new User();
                            user.UserId = drUser["UserId"].ToString();
                            user.Name = drUser["Name"].ToString();
                            user.EmailId = drUser["EmailId"].ToString();
                            masterDataWrapper.LoogedInUser = user;

                            UserType userType = new UserType();
                            userType.Id = Convert.ToInt32(drUser["TypeID"].ToString());
                            userType.Type = drUser["Type"].ToString();
                            masterDataWrapper.LoogedInUserType = userType;
                        }
                    }

                    // Get Answer Priority 
                    if (ds.Tables.Count > 4)
                    {
                        List<AnswerPriorityMaster> answerPriorityMasterList = new List<AnswerPriorityMaster>();
                        foreach (DataRow dr in ds.Tables[4].Rows)
                        {
                            AnswerPriorityMaster ansPriority = new AnswerPriorityMaster();
                            ansPriority.AnswerType = dr["AnswerType"].ToString();
                            ansPriority.Value = Convert.ToInt32(dr["Value"].ToString());
                            answerPriorityMasterList.Add(ansPriority);
                        }

                        masterDataWrapper.AnswerPriorityList = answerPriorityMasterList;
                    }
                }
                //}
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return masterDataWrapper;
        }

        /// <summary>
        /// Calculation for generate report
        /// </summary>
        /// <param name="questionFile"></param>
        /// <returns></returns>
        public bool FeedbackCalculation()
        {
            bool submitStatus = false;
            try
            {
                DataCarrier dataCarrier = new DataCarrier();

                submitStatus = dataCarrier.InsertData("sp_Feedback_CalculateRating", null, null);

                return submitStatus;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Validate user details
        /// </summary>
        /// <param name="questionFile"></param>
        /// <returns></returns>
        public string ValidateUserDetails(string UserMailId)
        {
            string Status = string.Empty;
            try
            {
               Dictionary<string, string> parameter = new Dictionary<string, string>();
               parameter.Add("UserMailId", UserMailId);
               DataSet ds = new DataCarrier().GetData("sp_Feedback_ValidateUserDetails", parameter);
                if (ds != null)
                {
                    Status = ds.Tables[0].Rows[0][0].ToString();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return Status;
        }

    }
}
