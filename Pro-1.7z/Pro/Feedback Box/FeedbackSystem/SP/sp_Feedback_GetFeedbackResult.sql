USE [WLSRRP]
GO

IF EXISTS(SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_Feedback_GetFeedbackResult]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[sp_Feedback_GetFeedbackResult]
GO 

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Sanjeeb Kr Paul / Rohit Mallick
-- Create date: 28-Dec-2016
-- Description:	Calculate the Rating
-- =============================================
CREATE PROCEDURE sp_Feedback_GetFeedbackResult 
	@UserId Varchar(25),
	@FeedBackYear Int,
	@QuaterId Int
AS
BEGIN
		SELECT u.UserId,u.Name,u.EmailId,ut.[Type] as UserType, feed.FeedbackYear,qd.StartMonth as QuaterStartMonth ,qd.EndMonth as QuaterEndMonth
		,feed.ResultXml,feed.OverallRating
		From [dbo].[360_FeedBackResult] feed INNER JOIN [dbo].[360_UserProject] up ON up.UniqueCode=feed.ForUser
		INNER JOIN [dbo].[360_User] u ON up.UserId=u.UserId 

		INNER JOIN [dbo].[360_UserType] ut ON u.UserType=ut.Id
		INNER JOIN [dbo].[360_QuaterDetails] qd ON qd.QuaterId=feed.QuaterId
		WHERE u.UserId=@UserId
		AND feed.FeedbackYear=@FeedBackYear
	    AND qd.QuaterId=@QuaterId
   
END
GO
