USE [WLSRRP]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Sanjeeb Kr Paul / Rohit Mallick
-- Create date: 28-Dec-2016
-- Description:	Upload the User and Project details
-- =============================================
 
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_Feedback_SubmitFeedback]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[sp_Feedback_SubmitFeedback]
GO 

CREATE PROCEDURE [dbo].[sp_Feedback_SubmitFeedback] 
	@FromUser Varchar(25),
	@ForUser Varchar(25),
	@QuestionAnswered XML,
	@OnDate DateTime,
	@QuaterId Int,
	@Year Int
AS
BEGIN
	
	DECLARE @FromUserUniqueId Varchar(10), @ForUserUniqueId Varchar(10),@FromUserProjectCode Varchar(25)

	SET @FromUserProjectCode=(SELECT Top 1  ProjectCode FROM [dbo].[360_UserProject] WHERE UserId=@FromUser)
	SET @FromUserUniqueId=(SELECT UniqueCode FROM [dbo].[360_UserProject] WHERE UserId=@FromUser AND ProjectCode IN (@FromUserProjectCode))

	SET @ForUserUniqueId=(SELECT UniqueCode FROM [dbo].[360_UserProject] WHERE UserId=@ForUser AND ProjectCode IN (@FromUserProjectCode))
	
	INSERT INTO [dbo].[360_Feedback](FromUser,ForUser,QuestionAnswered,OnDate,QuaterId,[Year]) Values (@FromUserUniqueId,@ForUserUniqueId,@QuestionAnswered,@OnDate,@QuaterId,@Year)
END
GO
