USE [WLSRRP]
GO

/****** Object:  StoredProcedure [dbo].[sp_Feedback_SubmitUsers]    Script Date: 1/25/2017 3:04:14 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Bappaditya Mondal
-- Create date: 25-Jan-2017
-- Description:	Upload and Modify the User Projects
-- =============================================
 
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_Feedback_SubmitUserProjects]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[sp_Feedback_SubmitUserProjects]
GO 




CREATE PROCEDURE [dbo].[sp_Feedback_SubmitUserProjects] 
	@EndDate datetime,
	@IsActive bit,
	@ManagerId varchar(25),
	@ProjectCode varchar(25),
	@ProjectLeaderID varchar(25),
	@StartDate datetime,
	@UniqueCode varchar(10),
	@UserId varchar(25)
AS
BEGIN

		IF EXISTS (SELECT UserId FROM [dbo].[360_UserProject] WHERE UserId=@UserId and ProjectCode=@ProjectCode)
		BEGIN
		UPDATE [dbo].[360_UserProject] SET StartDate=@StartDate,EndDate=@EndDate,ManagerId=@ManagerId,UniqueCode=@UniqueCode,ProjectLeaderID=@ProjectLeaderID,IsActive=@IsActive WHERE UserId=@UserId and ProjectCode=@ProjectCode
		END
		ELSE
		BEGIN
		INSERT INTO [dbo].[360_UserProject](UserId,ProjectCode,StartDate,EndDate,ManagerId,UniqueCode,ProjectLeaderID,IsActive) 
		Values (@UserId,@ProjectCode,@StartDate,@EndDate,@ManagerId,@UniqueCode,@ProjectLeaderID,@IsActive)
		END
END



GO


