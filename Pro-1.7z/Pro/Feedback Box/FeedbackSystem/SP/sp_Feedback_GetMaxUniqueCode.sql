
USE [WLSRRP]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Sanjeeb Kr Paul / Rohit Mallick
-- Create date: 28-Dec-2016
-- Description:	Upload the User and Project details
-- =============================================
 
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_Feedback_GetMaxUniqueCode]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[sp_Feedback_GetMaxUniqueCode]
GO 

CREATE PROCEDURE [dbo].[sp_Feedback_GetMaxUniqueCode] 	
AS
BEGIN
	
	SELECT MAX(UniqueCode) as MaxUniqueCode  FROM [dbo].[360_UserProject]
END
GO

