USE [WLSRRP]
GO
/****** Object:  UserDefinedFunction [dbo].[fn_CalculateAnswerByWeightage]    Script Date: 12/29/2016 7:22:47 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Sanjeeb Paul
-- Create date: 28-Dec-2016
-- Description:	Get Efficiency 
-- =============================================
CREATE FUNCTION [dbo].[fn_Feedback_GetEfficiency]
(
	@Value Int
)
RETURNS Varchar(20)
AS
 BEGIN
	DECLARE @Efficiency VARCHAR(20)
	SET @Efficiency=(SELECT [Type] FROM [360_EfficiencyMaster] WHERE @Value Between MinValue AND MAXValue)
	RETURN @Efficiency
END
