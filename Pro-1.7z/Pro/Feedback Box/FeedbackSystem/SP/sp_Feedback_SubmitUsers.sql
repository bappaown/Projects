USE [WLSRRP]
GO

/****** Object:  StoredProcedure [dbo].[sp_Feedback_SubmitUsers]    Script Date: 1/25/2017 5:15:56 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Bappaditya Mondal
-- Create date: 25-Jan-2017
-- Description:	Upload and Modify the User 
-- =============================================
 
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_Feedback_SubmitUsers]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[sp_Feedback_SubmitUsers]
GO 




CREATE PROCEDURE [dbo].[sp_Feedback_SubmitUsers] 
	@UserId varchar(25),
	@Name varchar(50),
	@EmailId varchar(50),
	@UserType Int
AS
BEGIN

		IF EXISTS (SELECT UserId FROM [dbo].[360_User] WHERE UserId=@UserId)
		BEGIN
		UPDATE [dbo].[360_User] SET Name=@Name,EmailId=@EmailId,UserType=@UserType WHERE UserId=@UserId
		END
		ELSE
		BEGIN
		INSERT INTO [dbo].[360_User](UserId,Name,EmailId,UserType) 
		Values (@UserId,@Name,@EmailId,@UserType)
		END
END




GO


