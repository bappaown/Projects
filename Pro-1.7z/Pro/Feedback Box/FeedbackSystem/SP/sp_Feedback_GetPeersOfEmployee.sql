
USE [WLSRRP]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Sanjeeb Kr Paul / Rohit Mallick
-- Create date: 28-Dec-2016
-- Description:	Upload the User and Project details
-- =============================================
 
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_Feedback_GetPeersOfEmployee]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[sp_Feedback_GetPeersOfEmployee]
GO 

CREATE PROCEDURE [dbo].[sp_Feedback_GetPeersOfEmployee] 	
@UserId VARCHAR(25),
@SearchBy VARCHAR(10)
AS
BEGIN
	
IF UPPER(RTRIM(LTRIM(@SearchBy))) = 'PEERS'
	BEGIN
		SELECT u.UserId,u.Name from [dbo].[360_User] u INNER JOIN
		[dbo].[360_UserProject] up on u.UserId=up.UserId
		WHERE u.[UserType]=(SELECT [UserType] from [dbo].[360_User] WHERE UserId=@UserId)
		AND up.ProjectCode IN (SELECT ProjectCode from [dbo].[360_UserProject] WHERE UserId=@UserId)
		AND u.UserId Not In (@UserId)
	END
ELSE IF UPPER(RTRIM(LTRIM(@SearchBy))) = 'REPOTEE'
	BEGIN
		SELECT u.UserId,u.Name from [dbo].[360_User] u INNER JOIN
		[dbo].[360_UserProject] up on u.UserId=up.UserId
		WHERE u.[UserType]<=(SELECT [UserType] from [dbo].[360_User] WHERE UserId=@UserId)
		AND up.ProjectCode=(SELECT ProjectCode from [dbo].[360_UserProject] WHERE UserId=@UserId)
		AND (up.ManagerId=@UserId OR up.ProjectLeaderId=@UserId)
	END
END
GO

