USE [WLSRRP]
GO

IF EXISTS(SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_Feedback_CalculateRating]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[sp_Feedback_CalculateRating]
GO 

-- =============================================
-- Author:		Sanjeeb Kr Paul / Rohit Mallick
-- Create date: 28-Dec-2016
-- Description:	Calculate the Rating
-- =============================================

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[sp_Feedback_CalculateRating] 	
AS
BEGIN

DECLARE @FromUser Varchar(10),
	@ForUser Varchar(10),
	@ForUserFinal Varchar(10),
	@QuestionAnswered XML,
	@QuaterId Int,
	@Year Int,
	@ResultXML XML,
	@OverallRating decimal(18,2)

DECLARE @FeedBack TABLE (ForUser Varchar(10),FromUser Varchar(10),CategoryId INT, QuestionId INT, AnswerValue INT) 
DECLARE @Answer TABLE (Result XML) 
DECLARE @ResultByQuestion TABLE (ForUser Varchar(10),Category INT,Question INT,QuestionDescription Varchar(50),PersonAnswered INT, TotalAnswerValue Decimal(18,2), QuesEfficiency Decimal(18,2)) 
DECLARE @ResultByCategory TABLE (ForUser Varchar(10),CategoryId INT,CategoryDescription Varchar(20), Rating Decimal(18,2),Efficiency VARCHAR(20)) 
DECLARE @UserInfo TABLE (ForUser Varchar(10),QuaterId INT, [Year] INT) 

-- Declare cursor for calculating rating
DECLARE Cursor_CalculateRating CURSOR FOR  
SELECT  FromUser,ForUser,QuestionAnswered FROM [360_Feedback] ORDER BY ForUser,QuaterId,[Year] 
OPEN Cursor_CalculateRating  
IF @@CURSOR_ROWS >0
BEGIN
	FETCH NEXT FROM Cursor_CalculateRating INTO @FromUser,@ForUser,@QuestionAnswered
	WHILE @@FETCH_STATUS = 0 
	BEGIN
        -- insert the questionanswered xml in Answer table
		DELETE FROM @Answer
		INSERT INTO @Answer(Result) VALUES (@QuestionAnswered)
		
		-- insert
		INSERT INTO @FeedBack
		SELECT @ForUser,@FromUser,
		l.s.value('@Category', 'varchar(10)') as 'CategoryId',
		l.s.value('@Question', 'varchar(10)') as 'QuestionId',
		l.s.value('@Answer', 'varchar(10)') as 'AnswerValue'
		FROM @Answer as a
		OUTER APPLY
		a.Result.nodes('/FeedBack/Result') as l(s)

	FETCH NEXT FROM Cursor_CalculateRating INTO @FromUser,@ForUser,@QuestionAnswered
	END
END
CLOSE Cursor_CalculateRating
DEALLOCATE Cursor_CalculateRating

--Insert result by question
INSERT INTO @ResultByQuestion
SELECT fb.ForUser,fb.CategoryId,fb.QuestionId, q.QuestionDescription ,Count(fb.AnswerValue) as PersonAnswered, Sum(dbo.fn_Feedback_CalculateAnswerByWeightage (fb.FromUser,fb.AnswerValue)) as TotalAnswerValue
,(Sum(dbo.fn_Feedback_CalculateAnswerByWeightage (fb.FromUser,fb.AnswerValue))*100/(5*Count(fb.AnswerValue))) as QuesEfficiency 
FROM @FeedBack fb JOIN [dbo].[360_Questions] q ON q.QuestionId=fb.QuestionId GROUP BY fb.ForUser,fb.CategoryId,fb.QuestionId,q.QuestionDescription


-- Insert result by category
INSERT INTO @ResultByCategory
SELECT rbd.ForUser,rbd.Category,c.[Type] as CategoryDesc
,(Sum(rbd.QuesEfficiency)/Count(rbd.Question)) as CategoryRating ,[dbo].[fn_Feedback_GetEfficiency](Sum(rbd.QuesEfficiency)/Count(rbd.Question)) as Efficiency
FROM @ResultByQuestion rbd JOIN [dbo].[360_Category] c ON c.ID=rbd.Category GROUP BY rbd.ForUser,rbd.Category,c.[Type]


DECLARE Cursor_CalculateOverallRating CURSOR FOR  
SELECT DISTINCT ForUser,QuaterId,[Year] FROM [360_Feedback] order by ForUser,QuaterId,[Year]
OPEN Cursor_CalculateOverallRating 
IF @@CURSOR_ROWS >0
BEGIN 
  FETCH NEXT FROM Cursor_CalculateOverallRating INTO @ForUserFinal,@QuaterId,@Year
  WHILE @@FETCH_STATUS = 0 
  BEGIN

       SET @ResultXML = (SELECT Category.CategoryId,Category.CategoryDescription,Category.Rating ,Category.Efficiency,Question.Question,Question.QuestionDescription,Question.PersonAnswered,Question.TotalAnswerValue, Question.QuesEfficiency 
							FROM @ResultByCategory Category INNER JOIN @ResultByQuestion Question ON Category.CategoryId= Question.Category
							AND Category.ForUser= Question.ForUser
							WHERE Category.ForUser=@ForUserFinal 
							FOR XML AUTO,ROOT('Categories'))
 
	  SET @OverallRating =(SELECT (sum(Rating)/count(CategoryId)) FROM @ResultByCategory WHERE ForUser=@ForUserFinal GROUP BY ForUser )
      INSERT INTO [360_FeedBackResult](ForUser,Overallrating,FeedbackYear,QuaterId,ResultXml) VALUES(@ForUserFinal,@OverallRating,@Year,@QuaterId,@ResultXML)

	  FETCH NEXT FROM Cursor_CalculateOverallRating INTO @ForUserFinal,@QuaterId,@Year
  END
END
 CLOSE Cursor_CalculateOverallRating
 DEALLOCATE Cursor_CalculateOverallRating 

END








