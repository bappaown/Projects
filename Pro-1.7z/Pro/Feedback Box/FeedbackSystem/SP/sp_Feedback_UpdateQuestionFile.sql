USE [WLSRRP]
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- =============================================
-- Author:		Sanjeeb Kr Paul / Rohit Mallick
-- Create date: 28-Dec-2016
-- Description:	Update Question File 
-- =============================================
 
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_Feedback_UpdateQuestionFile]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[sp_Feedback_UpdateQuestionFile]
GO 

CREATE PROCEDURE [dbo].[sp_Feedback_UpdateQuestionFile]
@FileName Varchar(200),
@File varbinary(max),
@QuaterId Int	
AS
BEGIN
	UPDATE [dbo].[360_ApplicationDetails] SET QuestionFileName=@FileName, QuestionFile=@File WHERE QuaterId=@QuaterId
END 
GO
