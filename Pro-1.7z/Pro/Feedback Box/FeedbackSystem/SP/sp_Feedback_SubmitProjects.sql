USE [WLSRRP]
GO

/****** Object:  StoredProcedure [dbo].[sp_Feedback_SubmitProjects]    Script Date: 1/25/2017 5:22:17 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-- =============================================
-- Author:		Bappaditya Mondal
-- Create date: 25-Jan-2017
-- Description:	Upload and Modify the Projects 
-- =============================================
 
IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_Feedback_SubmitProjects]') AND type in (N'P', N'PC'))
DROP PROCEDURE [dbo].[sp_Feedback_SubmitProjects]
GO 





CREATE PROCEDURE [dbo].[sp_Feedback_SubmitProjects] 
	@IsActive bit,
	@ProjectCode varchar(25),
	@ProjectDescription varchar(50),
	@ProjectName varchar(50)
AS
BEGIN

		IF EXISTS (SELECT ProjectName FROM [dbo].[360_Project] WHERE ProjectCode=@ProjectCode)
		BEGIN
		UPDATE [dbo].[360_Project] SET ProjectDescription=@ProjectDescription,IsActive=@IsActive WHERE ProjectCode=@ProjectCode and ProjectName=@ProjectName
		END
		ELSE
		BEGIN
		INSERT INTO [dbo].[360_Project](ProjectCode,ProjectName,ProjectDescription,IsActive) 
		Values (@ProjectCode,@ProjectName,@ProjectDescription,@IsActive)
		END
END




GO


