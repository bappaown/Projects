﻿/// <reference path="XmlHelper.js" />

//USERTYPE = { PEER: 0, TL: 1, PM: 2, PMO: 3 };

angular.module('app', ['smart-table', 'ui.bootstrap']).controller('FeedbackCtrl', function ($scope, $uibModal, $http, $timeout) {

    $scope.pageLoading = true;
    $scope.ShowDiv = true;
    $scope.usrList = [];
    $scope.PageData = [];
    $scope.CatList = [];
    $scope.QuesList = [];
    $scope.UserList = [];
    $scope.useroptionvallist = [];
    $scope.catqueslist = [];
    $scope.optionslist = [];
    $scope.usertype = 0;
    $scope.employees = [];
    $scope.userdetails = [];

    $scope.checkExpiryDate = function () {
        $http({
            method: "POST",
            url: "../Activity/Feedback.aspx/CheckExpiry",
            dataType: 'json',
            data: {},
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d) {
                //window.location.href = 'Error.aspx';

                $scope.hideddl();
                $("#divHeading").css("display", "none");
                $("#divDisplay").css("background", "none");
                $scope.actionmsg = "Sorry, Feedback session is over !!!";
                $scope.FeedbackLst = [];
                return false;
            };
        });
    }
    $scope.checkExpiryDate();

    //FETCH COMPLETE CATEGORY, QUESTION,USERLIST,OPTIONLIST STARTS
    $scope.reloadDataMain = function () {
        var httpRequest = $http({
            method: "POST",
            url: "../Activity/Feedback.aspx/GetUIData",
            dataType: 'json',
            data: "{}",
            headers: { "Content-Type": "application/json" }
        });
        httpRequest.success(function (data, status) {

            localStorage.setItem("BKPCATEGORY", JSON.stringify(data.d.CATEGORY));
            localStorage.setItem("BKPQUESTIONS", JSON.stringify(data.d.QUESTIONS));
            //localStorage.setItem("BKPUSERLIST", JSON.stringify(data.d.USERLIST));
            localStorage.setItem("BKPOPTIONLIST", JSON.stringify(data.d.OPTIONLIST));
            if (data.d.LOGGEDINUSER.UserId == "NORECORDS") {
                $scope.openApprover();
            }
            else {
                localStorage.setItem("BKPLOGGEDINUSER", JSON.stringify(data.d.LOGGEDINUSER));
            }
            localStorage.setItem("BKPUSERTYPE", JSON.stringify(data.d.USERTYPE));
            localStorage.setItem("BKPQUARTER", JSON.stringify(data.d.QUARTER));

            if (window.location.search.split('?').length > 1) {
                $scope.openApprover();
            }
            else {
                $("#loggeduserId").append(" " + data.d.LOGGEDINUSER.Name);
            }

            $scope.FeedYear = data.d.QUARTER.Year;
            $scope.FeedQuarter = data.d.QUARTER.QuaterDesc;

        });
    };
    $scope.reloadDataMain();
    //FETCH COMPLETE CATEGORY, QUESTION,USERLIST,OPTIONLIST ENDS


    //LOAD USER SPECIFIC DATA STARTS
    $scope.LoadUISpecific = function () {
        $scope.optionslist = [];
        $scope.catqueslist = [];

        var bkpcategory = localStorage.getItem("BKPCATEGORY");
        if (bkpcategory) {
            $scope.CatList = JSON.parse(bkpcategory);
        }
        var bkpquestions = localStorage.getItem("BKPQUESTIONS");
        if (bkpquestions) {
            $scope.QuesList = JSON.parse(bkpquestions);
        }
        var bkpoptions = localStorage.getItem("BKPOPTIONLIST");
        if (bkpoptions) {
            $scope.optionslist = JSON.parse(bkpoptions);
        }

        $scope.LoadOptions($scope.optionslist);

        var catId = "";
        $.each($scope.CatList, function (key, value) {
            catId = value.Id;
            $scope.questionslist = [];
            $.each($scope.QuesList, function (key, value) {
                if (catId == value.CategoryId) {
                    var objQ = new Object();
                    objQ = { "questionid": value.QuestionId, "question": value.QuestionDescription };
                    $scope.questionslist.push(objQ);
                }
            });

            var objC = new Object();
            objC = { "categoryid": value.Id, "categoryname": value.Type, "quesoptionlist": $scope.questionslist };
            $scope.catqueslist.push(objC);
        });

        //   $("#btnLoadUI").attr("disabled", "disabled");
        $scope.pageLoading = false;
        $scope.DisplayDetails();
    };
    //LOAD USER SPECIFIC DATA ENDS


    //LOAD OPTIONS STARTS
    $scope.LoadOptions = function (OPTIONLIST) {
        $scope.option1 = OPTIONLIST[0].AnswerType;
        $scope.optionval1 = OPTIONLIST[0].Value;
        $scope.option2 = OPTIONLIST[1].AnswerType;
        $scope.optionval2 = OPTIONLIST[1].Value;
        $scope.option3 = OPTIONLIST[2].AnswerType;
        $scope.optionval3 = OPTIONLIST[2].Value;
        $scope.option4 = OPTIONLIST[3].AnswerType;
        $scope.optionval4 = OPTIONLIST[3].Value;
        //        $scope.option5 = OPTIONLIST[4].AnswerType;
        //        $scope.optionval5 = OPTIONLIST[4].Value;
    };
    //LOAD OPTIONS ENDS


    //LOAD DATA PAGEWISE STARTS
    $scope.LoadUIData = function (OPTIONLIST, USERLIST) {

        $scope.LoadOptions(OPTIONLIST);

        $.each(USERLIST, function (key, value) {
            var objUIOPTData = new Object();
            objUIOPTData = { "userid": value.UserId, "username": value.Name };
            $scope.useroptionvallist.push(objUIOPTData);
        });

        //first time loading
        $scope.SetCategory($scope.GetDescriptions(undefined, undefined, "CATEGORY", undefined));
        $scope.SetQuestion($scope.GetDescriptions(undefined, undefined, "QUESTIONS", undefined));

    };
    //LOAD DATA PAGEWISE STARTS

    //LOAD NEXT CATEGORY and QUESTIONS STARTS
    $scope.Traverse = function (nxtprev) {

        if (nxtprev == "NEXT") {

            var catid = $("#lblcategory").attr("catid");
            var quesid = $("#lblquestion").attr("quesid");

            var retVal = $scope.GetDescriptions(quesid, catid, "QUESTIONS", "NEXT");
            if (retVal == "LASTQUESTION") { return retVal; }
            else if (retVal == "LOADNEWCATEGORY") {
                $scope.SetCategory($scope.GetDescriptions(undefined, parseInt(catid) + 1, "CATEGORY", undefined));
                $scope.SetQuestion($scope.GetDescriptions(parseInt(quesid) + 1, undefined, "QUESTIONS", undefined));
                $scope.ClearFeedbackRadio();
            }
            else {
                $scope.SetQuestion(retVal);
                $scope.ClearFeedbackRadio();
            }
        }
        else {
            $scope.PrevCatQuestions();
        }
    };

    $scope.PrevCatQuestions = function () {

        var catid = $("#lblcategory").attr("catid");
        var quesid = $("#lblquestion").attr("quesid");

        var retVal = $scope.GetDescriptions(quesid, catid, "QUESTIONS", "PREV");
        if (retVal == "FIRSTQUESTION") { return retVal; }
        else if (retVal == "LOADNEWCATEGORY") {
            $scope.SetCategory($scope.GetDescriptions(undefined, parseInt(catid) - 1, "CATEGORY", undefined));
            $scope.SetQuestion($scope.GetDescriptions(parseInt(quesid) - 1, undefined, "QUESTIONS", undefined));
            $scope.ClearFeedbackRadio();
        }
        else {
            $scope.SetCategory(retVal);
            $scope.ClearFeedbackRadio();
        }
    };

    $scope.SetQuestion = function (retVal) {
        if (retVal != "") {
            $scope.questionid = (retVal).split("||")[0];
            $scope.question = (retVal).split("||")[1];
        }
    };

    $scope.SetCategory = function (retVal) {
        if (retVal != "") {
            $scope.categoryid = (retVal).split("||")[0];
            $scope.categoryname = (retVal).split("||")[1];
        }
    };
    //LOAD NEXT CATEGORY and QUESTIONS ENDS


    //CLEAR RADIO BUTTONS ON NEXT/PREV STARTS 
    $scope.ClearFeedbackRadio = function () {
        $('#tblFeedback tbody').find('input[type=radio]:checked').removeAttr('checked');
    };
    //CLEAR RADIO BUTTONS ON NEXT/PREV ENDS

    //SAVE DATA PAGEWISE STARTS
    $scope.SavePageDataGoNext = function (prevnxt) {

        var goPrevNxt = true;
        var feedbackdata = localStorage.getItem("FEEDBACKDATA");
        if (feedbackdata) {
            $scope.PageData = JSON.parse(feedbackdata);
        }

        var catid = $("#lblcategory").attr("catid");
        var quesid = $("#lblquestion").attr("quesid");
        var userid, username, ansval;

        $('#tblFeedback tbody tr').each(function () {
            var isadded = false;
            userid = $(this).find("#lbluser").attr("userid");
            var radioVal = $(this).find("input:checked").val();
            //check any radio button checked or not
            if (radioVal != undefined) {
                ansval = radioVal;

                //check if data exists or need to append
                $.each($scope.PageData, function (key, value) {
                    if (value.userid == userid && value.catid == catid && value.quesid == quesid) {
                        value.queans = ansval;
                        // added to PageData list
                        isadded = true;
                        return false;
                    }
                    else {
                        //not added to PageData list
                        isadded = false;
                    }
                });

                if (!isadded) {
                    //add new record to PageData list
                    var objPageData = new Object();
                    objPageData = { "userid": userid, "catid": catid, "quesid": quesid, "queans": ansval, "name": $scope.searchedusername };
                    $scope.PageData.push(objPageData);
                }
            }
            else {
                localStorage.setItem("FEEDBACKDATA", JSON.stringify($scope.PageData));
                alert("Please provide rating for each user !");
                goPrevNxt = false;
                return false;
            }
        });

        localStorage.setItem("FEEDBACKDATA", JSON.stringify($scope.PageData));

        if (goPrevNxt) {
            $scope.Traverse(prevnxt);
        }
    };
    //SAVE DATA PAGEWISE ENDS

    $scope.GetDescriptions = function (quesid, catid, genfor, nxtprev, userid) {
        var retVal = "";

        if (genfor == "CATEGORY") {
            var bkpcategory = localStorage.getItem("BKPCATEGORY");
            if (bkpcategory) {
                $scope.CatList = JSON.parse(bkpcategory);
                $.each($scope.CatList, function (key, value) {
                    if (catid == undefined) { retVal = (value.Id + "||" + value.Type); return false; }
                    else { if (value.Id == catid) { retVal = (value.Id + "||" + value.Type); return false; } }
                });
            }
            //if not data found code to be done
        }
        else if (genfor == "QUESTIONS") {
            var recmatched = false;
            var bkpquestions = localStorage.getItem("BKPQUESTIONS");
            if (bkpquestions) {
                $scope.QuesList = JSON.parse(bkpquestions);
                $.each($scope.QuesList, function (key, value) {
                    if (quesid == undefined) { retVal = (value.QuestionId + "||" + value.QuestionDescription); return false; }
                    else {
                        if (nxtprev == undefined) {
                            if (value.QuestionId == quesid) {
                                retVal = (value.QuestionId + "||" + value.QuestionDescription); return false;
                            }
                        } else {
                            if (nxtprev == "PREV") {
                                //code when prev clicked 
                                //recmatched true means last record matched que id
                                if (value.QuestionId == quesid || recmatched) {

                                    if (recmatched) {
                                        if (parseInt(value.CategoryId) - 2 == parseInt(catid)) {
                                            //last to last question was from same category,
                                            //as loop is moving forward
                                            retVal = ($scope.QuesList[parseInt(value.QuestionId) - 3].QuestionId + "||" + $scope.QuesList[parseInt(value.QuestionId) - 3].QuestionDescription);
                                            return false;
                                        }
                                        else {
                                            //load new category and then get question details
                                            retVal = "LOADNEWCATEGORY";
                                            return false;
                                        }
                                    }
                                    else if (value.QuestionId == 1) {
                                        //last question
                                        retVal = "FIRSTQUESTION";
                                        return false;
                                    }
                                    recmatched = true;
                                }
                            }
                            else {
                                //code when nxt clicked 
                                //recmatched true means last record matched que id
                                if (value.QuestionId == quesid || recmatched) {

                                    if (recmatched) {
                                        if (value.CategoryId == catid) {
                                            //last question was from same category
                                            retVal = (value.QuestionId + "||" + value.QuestionDescription);
                                            return false;
                                        }
                                        else {
                                            //load new category and then get question details
                                            retVal = "LOADNEWCATEGORY";
                                            return false;
                                        }
                                    }
                                    else if ($scope.QuesList.length == parseInt(value.QuestionId - 1)) {
                                        //last question
                                        retVal = "LASTQUESTION";
                                        return false;
                                    }
                                    recmatched = true;
                                }
                            }
                        }
                    }
                });
            }
            //if not data found code to be done
        }
        else if (genfor == "USERS") {
            var bkpusers = localStorage.getItem("BKPUSERLIST");
            if (bkpusers) {
                $scope.UserList = JSON.parse(bkpusers);
                $.each($scope.UserList, function (key, value) {
                    if (userid == undefined) { retVal = (value.UserId + "||" + value.Name); return false; }
                    else { if (value.UserId == userid) { retVal = (value.UserId + "||" + value.Name); return false; } }
                });
            }
            //if not data found code to be done
        }

        return retVal;
    };


    //class for feedback
    $scope.FeedbackLst = [
                { 'FromUser': '', 'ForUser': '', 'ForUserName': '', 'QuestionAnswered': '', 'QuaterId': '', 'Year': '', 'Comments': ''
                }
            ];

    $scope.Feedback = {};

    //SAVE METHOD STARTS
    $scope.PushFeedbackToServer = function (isspecific) {

        if (!isspecific) {
            $scope.SavePageDataGoNext(undefined);
        }

        var feedbackdata = localStorage.getItem("FEEDBACKDATA");
        if (feedbackdata) {
            var jsonFeedbackData = JSON.parse(feedbackdata);
            // sort $scope.PageData 
            $scope.PageData = jsonFeedbackData.sort(function (a, b) {
                return (a['userid'] > b['userid']) ? 1 : ((a['userid'] < b['userid']) ? -1 : 0);
            });
        }

        var quaterdata;
        if (localStorage.getItem("BKPQUARTER")) {
            quaterdata = JSON.parse(localStorage.getItem("BKPQUARTER"));
        }
        var curruserid = "";
        var comments = "";
        var xmldata = "";
        var dataLength = $scope.PageData.length;
        $.each($scope.PageData, function (key, value) {
            if (curruserid == "" || value.userid == curruserid) {
                if (xmldata == "") {
                    xmldata = "<Result Category=" + "\"" + value.catid + "\"";
                    xmldata += " Question=" + "\"" + value.quesid + "\"";
                    xmldata += " Answer=" + "\"" + value.queans + "\"" + "></Result>";
                } else {
                    xmldata += "<Result Category=" + "\"" + value.catid + "\"";
                    xmldata += " Question=" + "\"" + value.quesid + "\"";
                    xmldata += " Answer=" + "\"" + value.queans + "\"" + "></Result>";
                }

                curruserid = value.userid;
                comments = value.comments;
            }
            else {
                $scope.Feedback.Year = quaterdata.Year;
                $scope.Feedback.ForUser = curruserid;
                $scope.Feedback.ForUserName = value.name;
                $scope.Feedback.FromUser = $('#lblUserId').text().trim();
                $scope.Feedback.QuestionAnswered = "<FeedBack>" + xmldata + "</FeedBack>";
                $scope.Feedback.QuaterId = quaterdata.QuaterId;
                $scope.Feedback.Comments = value.comments;
                $scope.FeedbackLst.push($scope.Feedback);
                $scope.Feedback = {};

                //to be optised with customised method
                xmldata = "";
                xmldata = "<Result Category=" + "\"" + value.catid + "\"";
                xmldata += " Question=" + "\"" + value.quesid + "\"";
                xmldata += " Answer=" + "\"" + value.queans + "\"" + "></Result>";

                curruserid = value.userid;
                comments = value.comments;
            }

            if (key == (dataLength - 1)) {
                $scope.Feedback.Year = quaterdata.Year;
                $scope.Feedback.ForUser = value.userid;
                $scope.Feedback.ForUserName = value.name;
                $scope.Feedback.FromUser = $('#lblUserId').text().trim();
                $scope.Feedback.QuestionAnswered = "<FeedBack>" + xmldata + "</FeedBack>";
                $scope.Feedback.QuaterId = quaterdata.QuaterId;
                $scope.Feedback.Comments = value.comments;
                $scope.FeedbackLst.push($scope.Feedback);
                $scope.Feedback = {};
            }

        });

        var showForUserName = '';

        if ($scope.FeedbackLst.length > 1) {
            showForUserName = $scope.FeedbackLst[1].ForUserName;
        } else {
            showForUserName = $scope.FeedbackLst[0].ForUserName;
        }

        var confirmStatus = confirm("Submit feedback for " + showForUserName + " ?");

        var submitBy = $.trim($('#lblUserId').text());

        if (confirmStatus) {
            // Save feedback data
            $http({
                method: "POST",
                url: "../Activity/Feedback.aspx/SaveFeedback",
                dataType: 'json',
                data: { "feeds": $scope.FeedbackLst, "submitBy": submitBy },
                headers: { "Content-Type": "application/json" }
            }).success(function (data, status) {
                if (data.d) {
                    $scope.hideddl();
                    $scope.actionmsg = "Thanks you for your valuable feedback for " + showForUserName + ".";
                    $scope.FeedbackLst = [];
                    $(".comment").val('');
                    return false;
                };
            });
        } else {
            $scope.actionmsg = "";
            $(".comment").val('');
            $('.btn-success').removeAttr("disabled");
            $scope.FeedbackLst = [];
            $scope.PageData = [];
            localStorage.removeItem("FEEDBACKDATA");
        }
    };
    //SAVE DATA PAGEWISE ENDS


    //SAVE SPECIFIC USER DATA STARTS
    $scope.SavePageDataSpecific = function () {

        var feedbackdata = localStorage.getItem("FEEDBACKDATA");
        if (feedbackdata) {
            $scope.PageData = JSON.parse(feedbackdata);
        }
        else {
            $scope.PageData = [];
        }

        $scope.actionmsg = "Submitting your feedback...";
        $('.btn-success').attr("disabled", "disabled");
        var catid, quesid, userid, username, ansval, comments;
        userid = $("#tblFeedbackOne").attr("feedforid");
        comments = $(".comment").val();

        $('#tblFeedbackOne tbody tr').each(function () {
            var isadded = false;

            $(this).find('table tbody tr').each(function () {
                var tdId = $(this).find("td[id^='Ques_']");
                catid = $(tdId).attr("catid");
                quesid = $(tdId).attr("quesid");

                //working here
                var radioVal = $(this).find("input:checked").val();
                //check any radio button checked or not
                if (radioVal != undefined) {
                    ansval = radioVal;
                }
                else {
                    ansval = 0;
                }

                //add new record to PageData list
                var objPageData = new Object();
                objPageData = { "userid": userid, "catid": catid, "quesid": quesid, "queans": ansval, "name": $scope.searchedusername, "comments": comments };
                $scope.PageData.push(objPageData);

                //dont do anything if any radio not selected
            });


        });

        localStorage.setItem("FEEDBACKDATA", JSON.stringify($scope.PageData));
        $scope.PushFeedbackToServer(true);
    };
    //SAVE SPECIFIC USER DATA ENDS


    //CHECK SEARCH STARTS
    $scope.checkcontent = function (action) {

        if (action == "BLUR") {
            if ($.trim($("#txtEmpName").val()) == "") {
                $("#txtEmpName").val("search");
                $("#btnSearch").attr("disabled", "disabled");
            }
            else {
                $("#btnSearch").removeAttr("disabled");
            }
        }
        else if (action == "MOUSEIN") {
            if ($.trim($("#txtEmpName").val().toLowerCase()) == "search") {
                $("#txtEmpName").val("");
            }
        }
    };

    $scope.SearchEmployee = function () {
        var searchName = $.trim($('#txtEmpName').val());
        var searchBy = $.trim($('#lblUserId').text());
        if (searchName == '') {
            alert('Please enter name.');
            return false;
        }

        $http({
            method: "POST",
            url: "../Activity/Feedback.aspx/SearchEmployee",
            dataType: 'json',
            data: { "searchName": searchName, "searchBy": searchBy },
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d.SEARCHRESULT.length > 0) {
                if (data.d.SEARCHRESULT[0].User.UserId == 'NOTAUTHORISE') {
                    alert(data.d.SEARCHRESULT[0].User.Name);
                }
                else {
                    localStorage.setItem("BKPUSERSDETAILSLIST", JSON.stringify(data.d.SEARCHRESULT));
                    $scope.employees = [];
                    $.each(data.d.SEARCHRESULT, function (key, value) {
                        var objU = new Object();
                        objU = { "UserId": value.User.UserId, "Name": value.User.Name + " [ " + value.User.UserId + " , " + value.User.EmailId + " ]", "IsFeedbackGiven": value.IsFeedbackGiven };
                        $scope.employees.push(objU);
                    });
                    if ($scope.employees.length > 0) {
                        var loadStatus = false;
                        // if single result and for whom feed back already given by the logged in user
                        if ($scope.employees.length == 1 && $scope.employees[0].IsFeedbackGiven) {
                            $.each($scope.employees, function (key, value) {
                                var singleMatch = value;
                                singleMatch.UserId = '' + singleMatch.UserId + '';
                                singleMatch.Name = '' + singleMatch.Name + '';
                                singleMatch.IsFeedbackGiven = '' + singleMatch.IsFeedbackGiven + '';
                                $scope.selItemSim = singleMatch;
                                alert("Feedback already submitted for " + singleMatch.Name);
                                loadStatus = false;
                            });
                        }

                        $.each($scope.employees, function (key, value) {
                            if (!value.IsFeedbackGiven) {
                                var matches = value;
                                matches.UserId = '' + matches.UserId + '';
                                matches.Name = '' + matches.Name + '';
                                matches.IsFeedbackGiven = '' + matches.IsFeedbackGiven + '';
                                $scope.selItemSim = matches;
                                loadStatus = true;
                                return false;
                            }
                        });

                        if (loadStatus) {
                            $("#dvSearch").css("display", "none");
                            $("#dvSelect").css("display", "block");
                            $scope.LoadUISpecific();
                        }
                        else {
                            $scope.DisplayDetails();
                        }
                    }

                    else {
                        alert('No employee found.');
                        $('#txtEmpName').focus();
                    }
                    //$scope.ShowDiv = false;                
                }
            }

            else {
                alert('No employee found.');
                $('#txtEmpName').focus();
            }

        });
    };


    $scope.DisplayDetails = function () {
        $scope.actionmsg = '';
        $scope.userdetailstmp = [];
        $scope.userdetails = [];
        var Uid = $scope.selItemSim.UserId;
        var bkpdetails = localStorage.getItem("BKPUSERSDETAILSLIST");
        if (bkpdetails) {
            $scope.userdetailstmp = JSON.parse(bkpdetails);
            $.each($scope.userdetailstmp, function (key, value) {
                if (value.User.UserId == Uid) {
                    $scope.searchedusername = value.User.Name;
                    $scope.searchedusermail = value.User.EmailId;
                    $scope.searcheduserid = value.User.UserId;

                    $.each(value.Projects, function (key, value) {
                        var objU = new Object();
                        objU = { "ProjectName": value.ProjectName };
                        $scope.userdetails.push(objU);
                    });
                    //  $("#searchDetail").css("display", "block");
                    return false;
                }
            });
        }
    };

    $scope.updateuserlist = function () {
        var userData = localStorage.getItem("BKPUSERSDETAILSLIST");
        var userDataList;
        if (userData) {
            userDataList = JSON.parse(userData);
        }
        $scope.employees = [];

        $.each(userDataList, function (key, value) {
            var objU = new Object();
            objU = { "UserId": value.User.UserId, "Name": value.User.Name + " [ " + value.User.UserId + " , " + value.User.EmailId + " ]", "IsFeedbackGiven": value.IsFeedbackGiven };
            $scope.employees.push(objU);
        });

        var matches = ($.grep($scope.employees, function (e) {
            return e.UserId == ($scope.selItemSim).UserId
        }))[0];

        if (matches.IsFeedbackGiven.toString() == "true") {
            alert("Feedback already submitted for " + matches.Name);
            var userDataList = JSON.parse(userData);
            $.each(userDataList, function (key, value) {
                if (value.IsFeedbackGiven.toString() == "false") {
                    var matched = value.User;
                    matched.UserId = '' + matched.UserId + '';
                    matched.Name = '' + matched.Name + '';
                    matched.IsFeedbackGiven = '' + matched.IsFeedbackGiven + '';
                    $scope.selItemSim = matched;
                    return false;
                }
            });
        }
        else {
            matches.UserId = '' + matches.UserId + '';
            matches.Name = '' + matches.Name + '';
            matches.IsFeedbackGiven = '' + matches.IsFeedbackGiven + '';
            $scope.selItemSim = matches;
        }

        if (!$scope.pageLoading) {
            $scope.PageData = [];
            localStorage.removeItem("FEEDBACKDATA");
            $scope.LoadUISpecific();
        }
    };

    $scope.hideddl = function () {
        $("#dvSearch").css("display", "block");
        $("#btnSearch").removeAttr("disabled");
        $("#dvSelect").css("display", "none");
        $("#txtEmpName").val("search");
        $scope.searchedusername = "";
        $scope.searchedusermail = "";
        $scope.searcheduserid = "";
        $scope.userdetails = [];
        $scope.actionmsg = "";
        $('.btn-success').removeAttr("disabled");
        $scope.pageLoading = true;
        localStorage.removeItem("FEEDBACKDATA");
        $scope.PageData = [];

        //$("#searchDetail").css("display", "none");
        // $scope.ShowDiv = true;
    };
    //CHECK SEARCH ENDS

    $(document).keypress(function (e) {
        if (e.which == 13) {
            if (!($('#lblUserId').text().trim() == '' && window.location.search.split('?').length > 1)) {
                $scope.SearchEmployee();
            }
            return false;
        }
    });

    $scope.openApprover = function () {
        var modalInstance = $uibModal.open({
            animation: $scope.animationsEnabled,
            templateUrl: 'myApproverContent.html',
            controller: 'ModalApproverInstanceCtrl',
            size: 'lg',
            backdrop: 'static',
            resolve: {

            }
        });

        modalInstance.result.then(function (reinitiatedApproverResult) {
            //Put an Alert based on reinitiatedApproverResult
        }, function () {
            //$log.info('Modal dismissed at: ' + new Date());
        });
    };

}).controller('ModalApproverInstanceCtrl', function ($scope, $uibModalInstance, $http, $timeout) {

    $scope.reinitiateWorkFlow = function (UserId) {
        if ($scope.UserId == "" || $scope.UserId == undefined) {
            alert("Please provide your IBM Email Id.");
        }
        else {
            var validate = $scope.UserId.toLowerCase().match(/^[_a-z0-9]+(\.[_a-z0-9]+)*@in.ibm.com/);
            if (validate == null) {
                alert("Please provide a valid IBM Email Id.");
            }
            else {

                var httpRequest = $http({
                    method: "POST",
                    url: "../Activity/Feedback.aspx/ValidateUser",
                    dataType: 'json',
                    data: { "UserMailId": $scope.UserId },
                    headers: { "Content-Type": "application/json" }
                });
                httpRequest.success(function (data, status) {
                    if (data.d == 'Your authentication is done.') {
                        //$scope.User = $scope.UserId;
                        $("#lblUserId").append($scope.UserId);
                        $("#loggeduserId").append(" " + $scope.UserId);
                        $uibModalInstance.dismiss('cancel');
                    }
                    else {
                        alert(data.d);
                    }
                });


            }
        }
    };

    $scope.cancel = function () {
        //$uibModalInstance.dismiss('cancel');
        window.open('', '_self').close();
    };

    //    $(document).keypress(function (e) {
    //        if (e.which == 13) {
    //            $scope.reinitiateWorkFlow($scope.UserId);
    //            return false;
    //        }
    //    });


}).directive('stRatio', function () {
    return {
        link: function (scope, element, attr) {
            var ratio = +(attr.stRatio);
            element.css('width', ratio + '%');
        }
    };

}).directive('setHeight', function ($window) {
    return {
        link: function (scope, element, attrs) {
            element.css('height', ($(window).height() + 50) * 0.6);
        }
    };
});