﻿angular.module('app', ['smart-table', 'ui.bootstrap']).controller('FeedbackReportCtrl', function ($scope, $http, $timeout) {

    $scope.employees = {};
    $scope.showFields = false;
    $scope.showFeedback = false;
    $scope.CalculatedResult = {};
    $scope.cateWiseResult = {};
    $scope.categoryWiseResults = [];

    $scope.quaterList = {};
    $scope.empLoading = false;
    $scope.resultLoading = false;

    $scope.reloadDataMain = function () {
        var httpRequest = $http({
            method: "POST",
            url: "../Activity/Feedback.aspx/GetUIData",
            dataType: 'json',
            data: "{}",
            headers: { "Content-Type": "application/json" }
        });
        httpRequest.success(function (data, status) {
            if (data.d.LOGGEDINUSER.UserId == "NORECORDS") {
                alert(data.d.LOGGEDINUSER.EmailId);
                //window.close();
                window.open('', '_self').close();
            }
            else {
                $("#loggeduserId").append(" " + data.d.LOGGEDINUSER.Name);
            }
        });
    };
    $scope.reloadDataMain();

    $scope.loadQuater = function () {
        $http({
            method: "POST",
            url: "../Activity/FeedbackReport.aspx/LoadQuaters",
            dataType: 'json',
            data: {},
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d.length > 0) {
                $scope.quaterList = data.d;
            }
            else {
            }
        });
    }

    $scope.showEmployee = function () {
        var searchName = $('#txtEmpName')[0].value;
        $scope.empLoading = true;
        $http({
            method: "POST",
            url: "../Activity/FeedbackReport.aspx/SearchEmployee",
            dataType: 'json',
            data: { "searchName": searchName },
            headers: { "Content-Type": "application/json" }
        }).success(function (data, status) {
            if (data.d.length > 0) {
                if (data.d[0].UserId == 'NOTAUTHORISE') {
                    alert('You can not able to see your feedback report.');
                    $scope.showFields = false;
                    $scope.empLoading = false;
                }
                else {
                    $scope.showFields = true;
                    $('#pieChart').hide();
                    $('#tblFeedbackResult').hide();
                    $scope.employees = data.d;
                    $scope.loadQuater();
                    $scope.empLoading = false;
                }
            }
            else {
                $scope.showFields = false;
                alert('No employee found.');
            }
        });

    };

    $scope.showResult = function () {
        var isProcess = true;
        var userId = $scope.selectEmp;
        if (userId == undefined) {
            alert("Please select an employee.");
            isProcess = false;
        }

        var quaterId = $scope.selectQuater;
        if (isProcess) {
            if (quaterId == undefined) {
                alert("Please select quater.");
                isProcess = false;
            }
        }

        if (isProcess) {
            $scope.resultLoading = true;
            $http({
                method: "POST",
                url: "../Activity/FeedbackReport.aspx/ShowResult",
                dataType: 'json',
                data: { "userId": userId, "feedbackYear": "2017", "quaterId": quaterId },
                headers: { "Content-Type": "application/json" }
            }).success(function (data, status) {
                if (data.d != null && data.d.CalculatedResult != null) {
                    $scope.CalculatedResult = data.d.CalculatedResult;
                    $scope.showFeedback = true;
                    $scope.categoryWiseResults = [];
                    for (var i = 0; i < data.d.CalculatedResult.length; i++) {
                        $scope.cateWiseResult = {};
                        $scope.cateWiseResult.y = data.d.CalculatedResult[i].Category.Rating;
                        $scope.cateWiseResult.indexLabel = data.d.CalculatedResult[i].Category.CategoryDescription;
                        $scope.categoryWiseResults.push($scope.cateWiseResult);
                    }

                    PieChart('pie', $scope.categoryWiseResults, "pieChart");
                    $('#pieChart').show();
                    $('#tblFeedbackResult').show();
                }
                else {
                    $scope.CalculatedResult = null;
                    $('#pieChart').hide();
                    $('#tblFeedbackResult').hide();
                    $scope.showFeedback = false;
                    alert('No result found.')
                }

                $scope.resultLoading = false;

            });
        }

    };

    $(document).keypress(function (e) {
        if (e.which == 13) {
            $scope.showEmployee();
            return false;
        }
    });

});