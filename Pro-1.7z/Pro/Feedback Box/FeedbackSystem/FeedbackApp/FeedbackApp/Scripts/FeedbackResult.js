﻿angular.module('app', ['smart-table', 'ui.bootstrap']).controller('FeedbackResultCtrl', function ($scope, $http, $timeout) {

    $scope.employees = {};
    $scope.showFields = false;
    $scope.showFeedback = false;
    $scope.CalculatedResult = {};
    $scope.cateWiseResult = {};
    $scope.categoryWiseResults = [];

    $scope.quaterList = {};
    $scope.empLoading = false;
    $scope.resultLoading = false;
    $scope.FeedYear = '';
    $scope.FeedQuarterId = '';

    $scope.displayFeedbackA = {};
    $scope.displayFeedbackB = {};
    $scope.displayFeedbackC = {};
    $scope.displayFeedbackD = {};

    $scope.reloadDataMain = function () {
        var httpRequest = $http({
            method: "POST",
            url: "../Activity/Feedback.aspx/GetUIData",
            dataType: 'json',
            data: "{}",
            headers: { "Content-Type": "application/json" }
        });
        httpRequest.success(function (data, status) {
            if (data.d.LOGGEDINUSER.UserId == "NORECORDS") {
                alert(data.d.LOGGEDINUSER.EmailId);
                //window.close();
                window.open('', '_self').close();
            }
            else {
                $scope.FeedYear = data.d.QUARTER.Year;
                $scope.FeedQuarter = data.d.QUARTER.QuaterDesc;
                $scope.FeedQuarterId = data.d.QUARTER.QuaterId;
                $("#loggeduserId").append(" " + data.d.LOGGEDINUSER.Name);
            }
        });
    };
    $scope.reloadDataMain();

    $scope.onlyDigits = function () {
        var ratingfromA = $scope.txtFromA;
        var ratingfromB = $scope.txtFromB;
        var ratingtoB = $scope.txtToB;
        var ratingfromC = $scope.txtFromC;
        var ratingtoC = $scope.txtToC;
        var ratingfromD = $scope.txtFromD;

        if (ratingfromA != undefined) {
            $scope.txtFromA = ratingfromA.replace(/[^0-9]/g, '');
        }
        if (ratingfromB != undefined) {
            $scope.txtFromB = ratingfromB.replace(/[^0-9]/g, '');
        }
        if (ratingtoB != undefined) {
            $scope.txtToB = ratingtoB.replace(/[^0-9]/g, '');
        }
        if (ratingfromC != undefined) {
            $scope.txtFromC = ratingfromC.replace(/[^0-9]/g, '');
        }
        if (ratingtoC != undefined) {
            $scope.txtToC = ratingtoC.replace(/[^0-9]/g, '');
        }
        if (ratingfromD != undefined) {
            $scope.txtToD = ratingtoB.replace(/[^0-9]/g, '');
        }

    }

    $scope.showResult = function () {
        var isProcess = true;
        var topuser = parseInt($scope.selectTop);
        var ratingfromA = parseInt($scope.txtFromA);
        var ratingfromB = parseInt($scope.txtFromB);
        var ratingtoB = parseInt($scope.txtToB);
        var ratingfromC = parseInt($scope.txtFromC);
        var ratingtoC = parseInt($scope.txtToC);
        var ratingfromD = parseInt($scope.txtFromD);

        if ($scope.txtFromA == undefined) {
            alert("Please enter greater than range for Grade-A.");
            isProcess = false;
        }

        if ($scope.txtFromB != undefined && $scope.txtToB != undefined) {
            if (ratingfromB > ratingtoB) {
                alert('Please enter a valid range for Grade-B.');
                $scope.txtFromB = '';
                $scope.txtToB = '';
                isProcess = false;
            }
        }
        else if ($scope.txtFromB == undefined && $scope.txtToB == undefined) {
            alert('Please enter a valid range for Grade-B.');
            isProcess = false;
        }
        else {
            if ($scope.txtFromB == undefined) {
                alert("Please enter begin range for Grade-B.");
                isProcess = false;
            }
            if ($scope.txtToB == undefined) {
                alert("Please enter upto range for Grade-B.");
                isProcess = false;
            }
        }

        if ($scope.txtFromC != undefined && $scope.txtToC != undefined) {
            if (ratingfromC > ratingtoC) {
                alert('Please enter a valid range for Grade-C.');
                $scope.txtFromC = '';
                $scope.txtToC = '';
                isProcess = false;
            }
        }
        else if ($scope.txtFromC == undefined && $scope.txtToC == undefined) {
            alert('Please enter a valid range for Grade-C.');
            isProcess = false;
        }
        else {
            if ($scope.txtFromC == undefined) {
                alert("Please enter begin range for Grade-C.");
                isProcess = false;
            }
            if ($scope.txtToC == undefined) {
                alert("Please enter upto range for Grade-C.");
                isProcess = false;
            }
        }

        if ($scope.txtFromD == undefined) {
            alert("Please enter less than range for Grade-D.");
            isProcess = false;
        }

        if ($scope.selectTop == undefined) {
            alert("Please select an option for top rated employee.");
            isProcess = false;
        }

        if (isProcess) {
            $scope.resultLoading = true;
            $http({
                method: "POST",
                url: "../Activity/FeedbackResult.aspx/ShowFeedback",
                dataType: 'json',
                data: { "ratingfromA": ratingfromA, "ratingfromB": ratingfromB, "ratingtoB": ratingtoB, "ratingfromC": ratingfromC, "ratingtoC": ratingtoC, "ratingfromD": ratingfromD, "topuser": topuser, "feedbackYear": $scope.FeedYear, "quaterId": $scope.FeedQuarterId },
                headers: { "Content-Type": "application/json" }
            }).success(function (data, status) {
                if (data.d != null) {
                    $scope.displayFeedbackA = data.d[0].DisplayFeedbackA;
                    $scope.displayFeedbackB = data.d[0].DisplayFeedbackB;
                    $scope.displayFeedbackC = data.d[0].DisplayFeedbackC;
                    $scope.displayFeedbackD = data.d[0].DisplayFeedbackD;
                    //                    localStorage.setItem("GRADE_A", JSON.stringify(data.d[0].DisplayFeedbackA));
                    //                    localStorage.setItem("GRADE_B", JSON.stringify(data.d[0].DisplayFeedbackB));
                    //                    localStorage.setItem("GRADE_C", JSON.stringify(data.d[0].DisplayFeedbackC));
                    //                    localStorage.setItem("GRADE_D", JSON.stringify(data.d[0].DisplayFeedbackD));
                    $scope.showFeedback = true;
                }
                else {
                    $scope.displayFeedbackA = null;
                    $scope.displayFeedbackB = null;
                    $scope.displayFeedbackC = null;
                    $scope.displayFeedbackD = null;
                    $scope.showFeedback = false;
                    alert('No result found.')
                }

                $scope.resultLoading = false;
            });
        }

    };

    $scope.ExportPageData = function () {
        $scope.exportLoading = true;

        //        var gradeA = localStorage.getItem("GRADE_A");
        //        if (gradeA) {
        //            gradeA = JSON.parse(gradeA);
        //        }
        //        var gradeB = localStorage.getItem("GRADE_B");
        //        if (gradeB) {
        //            gradeB = JSON.parse(gradeB);
        //        }
        //        var gradeC = localStorage.getItem("GRADE_C");
        //        if (gradeC) {
        //            gradeC = JSON.parse(gradeC);
        //        }
        //        var gradeD = localStorage.getItem("GRADE_D");
        //        if (gradeD) {
        //            gradeD = JSON.parse(gradeD);
        //        }

        var httpRequest = $http({
            method: "POST",
            url: "../Activity/FeedbackResult.aspx/ExportUIData",
            dataType: 'json',
            data: {},
            headers: { "Content-Type": "application/json" }
        });
        httpRequest.success(function (data, status) {
            if (data.d == false) {
                alert('Problem to load data.');
            }
            $scope.exportLoading = false;
        });
    };


    $(document).keypress(function (e) {
        if (e.which == 13) {
            $scope.showResult();
            return false;
        }
    });

});