﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Web.Script.Serialization;
using System.Collections;
using System.Data;
using System.IO;
using System.Configuration;
using Utility;
using System.Data.OleDb;
//using Microsoft.Office.Interop.Excel;

namespace FeedbackApp.Admin
{
    public partial class ManageApp : Page
    {

        //public static string[] tableName = { "SimDetails", "CQTADetails", "LotDetails", "Reasons", "AcceptReject", "IsApprover", "EncryptedSimId", "NewLot", "ToColor" };
        //public static string[] QLATYPEINSIDE = { "TA", "RS", "NH3", "NO3" };
        //public enum REASONTYPE { ACCEPT = 1, REJECT = 2, RESEND = 3 };

        protected void Page_Load(object sender, EventArgs e)
        {

            //UCommon = new Ibm.Utility.Common();
            //UCommon.UserName();

        }

        public static DataSet ReadToExcel(string path)
        {
            //DataSet ds_Data = new DataSet();
            //OleDbConnection oleCon = new OleDbConnection();

            //string strExcelFile = @"C:\Test.xlsx";
            string strExcelFile = path;
            string ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + strExcelFile + ";Extended Properties=\"Excel 12.0;IMEX=1;HDR=NO;TypeGuessRows=0;ImportMixedTypes=Text\""; ;

            string SpreadSheetName = "";

            OleDbDataAdapter Adapter = new OleDbDataAdapter();
            OleDbConnection conn = new OleDbConnection(ConnectionString);

            string strQuery;
            conn.Open();

            int workSheetNumber = 0;

            DataTable ExcelSheets = conn.GetOleDbSchemaTable(System.Data.OleDb.OleDbSchemaGuid.Tables, new object[] { null, null, null, "TABLE" });

            SpreadSheetName = ExcelSheets.Rows[workSheetNumber]["TABLE_NAME"].ToString();

            strQuery = "select * from [" + SpreadSheetName + "] ";
            OleDbCommand cmd = new OleDbCommand(strQuery, conn);
            Adapter.SelectCommand = cmd;
            DataSet dsExcel = new DataSet();
            Adapter.Fill(dsExcel);
            conn.Close();
            return dsExcel;
        }

        public static DataSet READExcel(string path)
        {
            //Instance reference for Excel Application
            Microsoft.Office.Interop.Excel.Application objXL = null;

            //Workbook refrence
            Microsoft.Office.Interop.Excel.Workbook objWB = null;
            DataSet ds = new DataSet();

            try
            {
                //Instancing Excel using COM services
                objXL = new Microsoft.Office.Interop.Excel.Application();

                //Adding WorkBook
                objWB = objXL.Workbooks.Open(path);

                foreach (Microsoft.Office.Interop.Excel.Worksheet objSHT in objWB.Worksheets)
                {
                    int rows = objSHT.UsedRange.Rows.Count;
                    int cols = objSHT.UsedRange.Columns.Count;
                    DataTable dt = new DataTable();
                    int noofrow = 1;

                    //If 1st Row Contains unique Headers for datatable include this part else remove it
                    //Start
                    for (int c = 1; c <= cols; c++)
                    {
                        string colname = objSHT.Cells[1, c].Text;
                        dt.Columns.Add(colname);
                        noofrow = 2;
                    }

                    //END
                    for (int r = noofrow; r <= rows; r++)
                    {
                        DataRow dr = dt.NewRow();
                        for (int c = 1; c <= cols; c++)
                        {
                            dr[c - 1] = objSHT.Cells[r, c].Text;
                        }
                        dt.Rows.Add(dr);
                    }

                    ds.Tables.Add(dt);

                }

                //Closing workbook
                objWB.Close();

                //Closing excel application
                objXL.Quit();

            }

            catch (Exception ex)
            {
                objWB.Saved = true;

                //Closing work book
                objWB.Close();

                //Closing excel application
                objXL.Quit();

                //Response.Write("Illegal permission");

            }

            return ds;
        }

        public static byte[] ConvertToByte(string path)
        {
            byte[] fileContent = null;

            System.IO.FileStream fs = new System.IO.FileStream(path, System.IO.FileMode.Open, System.IO.FileAccess.Read);
            System.IO.BinaryReader binaryReader = new System.IO.BinaryReader(fs);

            long byteLength = new System.IO.FileInfo(path).Length;
            fileContent = binaryReader.ReadBytes((Int32)byteLength);
            fs.Close();
            fs.Dispose();
            binaryReader.Close();
            return fileContent;
        }



        [WebMethod]
        public static void loadQuestionFile(byte[] file, string fileName)
        {
            File.WriteAllBytes(fileName, file);
            System.Diagnostics.Process.Start(fileName);
        }

        [WebMethod]
        public static List<Dictionary<string, object>> ReadData(string file)
        {
            DataSet dsUser = READExcel(file);

            System.Text.StringBuilder userError = new System.Text.StringBuilder(string.Empty);
            userError.AppendLine("User information not found for the below user's:");
            DataTable dt = new DataTable();
            dt.Columns.Add("Name");
            dt.Columns.Add("UserId");
            dt.Columns.Add("EmailId");
            dt.Columns.Add("IBMEmailId");
            dt.Columns.Add("ProjectCode");
            dt.Columns.Add("ProjectName");
            dt.Columns.Add("ProjectDesc");
            dt.Columns.Add("ManagerId");
            //dt.Columns.Add("ManagerName");
            dt.Columns.Add("ProjectLeaderId");
            //dt.Columns.Add("ProjectLeaderName");
            dt.Columns.Add("PeopleManagerId");
            dt.Columns.Add("JoiningDate");
            dt.Columns.Add("ReleaseDate");
            dt.Columns.Add("UserType");

            foreach (DataRow dr in dsUser.Tables[0].Rows)
            {
                if (!string.IsNullOrEmpty(dr["Name"].ToString()))
                {
                    DataRow drNew = dt.NewRow();
                    string userId = dr["PMI User Id"].ToString();
                    if (!string.IsNullOrEmpty(userId))
                    {
                        Dictionary<string, string> dicUserParam = new Common().GetUserParametersByMail(userId);
                        if (dicUserParam != null && dicUserParam.Count > 0)
                        {
                            string[] arrNameMailId = dicUserParam[userId].ToString().Split('|');
                            drNew["Name"] = arrNameMailId[0];
                            drNew["UserId"] = "PMI\\" + arrNameMailId[1];
                            drNew["EmailId"] = userId;
                        }
                        else
                            userError.AppendLine(userId);
                    }
                    else
                    {
                        drNew["Name"] = dr["Name"].ToString();
                        drNew["UserId"] = dr["IBM Email Id"].ToString();
                    }

                    drNew["IBMEmailId"] = dr["IBM Email Id"].ToString();
                    drNew["ProjectCode"] = dr["PMI Project Code"].ToString();
                    drNew["ProjectName"] = dr["PMI Project Name"].ToString();
                    drNew["ProjectDesc"] = dr["PMI Project Desc"].ToString();
                    drNew["ManagerId"] = dr["PMI Manager Id"].ToString();
                    drNew["ProjectLeaderId"] = dr["PMI Project Leader Id"].ToString();

                    //string managerUserId = dr["PMI Manager Id"].ToString();
                    //if (!string.IsNullOrEmpty(managerUserId))
                    //{
                    //    Dictionary<string, string> dicManagerUserParam = new Common().GetUserParametersByMail(managerUserId);
                    //    if (dicManagerUserParam != null && dicManagerUserParam.Count > 0)
                    //    {
                    //        string[] arrManagerNameMailId = dicManagerUserParam[managerUserId].ToString().Split('|');

                    //        drNew["ManagerId"] = arrManagerNameMailId[1];
                    //        drNew["ManagerName"] = arrManagerNameMailId[0];
                    //    }
                    //    else
                    //        userError.AppendLine(managerUserId);
                    //}

                    //string plUserId = dr["PMI Project Leader Id"].ToString();
                    //if (!string.IsNullOrEmpty(plUserId))
                    //{
                    //    Dictionary<string, string> dicPLUserParam = new Common().GetUserParameters(plUserId);
                    //    if (dicPLUserParam != null && dicPLUserParam.Count > 0)
                    //    {
                    //        string[] arrPLNameMailId = dicPLUserParam[plUserId].ToString().Split('|');

                    //        drNew["ProjectLeaderId"] = arrPLNameMailId[1];
                    //        drNew["ProjectLeaderName"] = arrPLNameMailId[0];
                    //    }
                    //    else
                    //        userError.AppendLine(plUserId);
                    //}

                    drNew["PeopleManagerId"] = dr["People Manager Id"].ToString();
                    drNew["JoiningDate"] = dr["PMI Joining Date"].ToString();
                    drNew["ReleaseDate"] = dr["PMI Release Date"].ToString();
                    drNew["UserType"] = dr["User Type"].ToString();

                    dt.Rows.Add(drNew);
                }
            }

            if (userError.Length > 0)
            {
                string path = @"C:\Logger\FeedbackLog.txt";
                if (!File.Exists(path))
                {
                    File.Create(path);
                }
                TextWriter tw = new StreamWriter(path,true);
                tw.WriteLine(userError.ToString());
                tw.Close();
            }

            List<Dictionary<string, object>> jsonData = new Common().DataTableToJson(dt);

            return jsonData;
        }

        [WebMethod]
        public static bool UploadUsers(List<UserDetails> users)
        {
            bool uploadStatus = false;
            List<FeedbackService.User> userList = new List<FeedbackService.User>();
            List<FeedbackService.Project> projectList = new List<FeedbackService.Project>();
            List<FeedbackService.UserProject> userProjectList = new List<FeedbackService.UserProject>();

            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();

            // Get Usertype
            List<FeedbackService.UserType> userTypes = fbClient.GetUserType();

            string maxUniqueCode = fbClient.GetMaxUniqueCode();
            string uniqueCode = string.Empty;
            if (string.IsNullOrEmpty(maxUniqueCode))
                uniqueCode = "3600000000";
            else
                uniqueCode = maxUniqueCode;

            foreach (UserDetails userDetail in users)
            {
                if (!string.IsNullOrEmpty(userDetail.Name))
                {
                    FeedbackService.User user = new FeedbackService.User();
                    user.UserId = userDetail.UserId;
                    user.Name = userDetail.Name;
                    user.EmailId = userDetail.EmailId;
                    user.IBMEmailId = userDetail.IBMEmailId;
                    user.PeopleManagerId = userDetail.PeopleManagerId;
                    user.UserType = userTypes.FirstOrDefault(ut => ut.Type == userDetail.UserType).Id;

                    if (!userList.Contains(user))
                        userList.Add(user);

                    FeedbackService.Project project = new FeedbackService.Project();
                    project.ProjectCode = userDetail.ProjectCode;
                    project.ProjectName = userDetail.ProjectName;
                    project.ProjectDescription = userDetail.ProjectDesc;
                    project.IsActive = true;

                    if (!projectList.Contains(project))
                        projectList.Add(project);

                    FeedbackService.UserProject userProject = new FeedbackService.UserProject();
                    userProject.ProjectCode = userDetail.ProjectCode;
                    userProject.UserId = userDetail.UserId;

                    if (!string.IsNullOrEmpty(userDetail.JoiningDate))
                        userProject.StartDate = Convert.ToDateTime(userDetail.JoiningDate);

                    userProject.IsActive = true;

                    if (!string.IsNullOrEmpty(userDetail.ReleaseDate))
                    {
                        userProject.EndDate = Convert.ToDateTime(userDetail.ReleaseDate);
                        if (userProject.EndDate > DateTime.Now)
                        {
                            userProject.IsActive = true;
                        }
                        else
                        {
                            userProject.IsActive = false;
                        }
                    }

                    userProject.ManagerId = userDetail.ManagerId;
                    userProject.ProjectLeaderID = userDetail.ProjectLeaderId;

                    userProject.UniqueCode = new Common().GenerateUniqueCode(uniqueCode);
                    uniqueCode = userProject.UniqueCode;
                    if (!userProjectList.Contains(userProject))
                        userProjectList.Add(userProject);
                }
            }
            if (userList.Count > 20)
            {
                uploadStatus = fbClient.UploadUsers(userList);
            }
            else
            {
                uploadStatus = fbClient.SubmitUsers(userList);
            }
            uploadStatus = fbClient.SubmitProjects(projectList);
            uploadStatus = fbClient.SubmitUserProjects(userProjectList);

            return uploadStatus;
        }

        [WebMethod]
        public static List<FeedbackService.QuaterDetails> LoadQuaters()
        {
            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
            List<FeedbackService.QuaterDetails> quaterDetails = fbClient.GetQuaterDetail();
            return quaterDetails;
        }

        [WebMethod]
        public static List<FeedbackService.QuestionDetails> ReadQuestionData()
        {
            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
            // Get Question Details
            List<FeedbackService.QuestionDetails> questions = fbClient.GetQuestionDetails();
            return questions;
        }

        [WebMethod]
        public static bool UploadQuestion(string file, int quaterId)
        {
            DataSet dsUser = READExcel(file);
            List<FeedbackService.Question> questionList = new List<FeedbackService.Question>();

            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
            // Get Usertype
            List<FeedbackService.Category> Category = fbClient.GetCategories();

            questionList = (from DataRow row in dsUser.Tables[0].Rows
                            select new FeedbackService.Question
                            {
                                //QuestionId = 21,
                                QuestionDescription = row["Question Description"].ToString(),
                                QuestionActive = true,
                                CreatedBy = HttpContext.Current.User.Identity.Name,
                                CreatedDate = Convert.ToDateTime(DateTime.Now.ToString()),
                                ProjectCode = row["Project Code"].ToString(),
                                CategoryId = Category.FirstOrDefault(ut => ut.Type == row["Category"].ToString()).Id,
                                QuaterId = quaterId
                            }).ToList();

            byte[] fileContent = ConvertToByte(file);

            FeedbackService.QuestionFile questionFile = new FeedbackService.QuestionFile();
            questionFile.FileName = Path.GetFileName(file);
            questionFile.File = fileContent;
            questionFile.QuaterId = quaterId;

            //FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
            bool status = fbClient.UploadQuestion(questionList);

            status = fbClient.UpdateQuesttionFile(questionFile);

            return status;
        }

        [WebMethod]
        public static Dictionary<string, string> IsValidLogin(string filae)
        {
            DataSet ds = READExcel(filae);
            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
            List<FeedbackService.Category> cat = fbClient.GetCategories();
            Dictionary<string, string> loginStatus = new Dictionary<string, string>();
            for (int i = 0; i < 1000; i++)
            {

            }
            loginStatus.Add("Message", "SUCCESS");
            return loginStatus;

        }

        [WebMethod]
        public static bool FeedbackCalculation()
        {
            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
            bool status = fbClient.FeedbackCalculation();

            return status;
        }

    }

    public class UserDetails
    {
        public string Name { get; set; }
        public string UserId { get; set; }
        public string EmailId { get; set; }
        public string IBMEmailId { get; set; }
        public string ProjectCode { get; set; }
        public string ProjectName { get; set; }
        public string ProjectDesc { get; set; }
        public string PeopleManagerId { get; set; }
        public string ManagerId { get; set; }
        public string ProjectLeaderId { get; set; }
        public string JoiningDate { get; set; }
        public string ReleaseDate { get; set; }
        public string UserType { get; set; }
    }
}
