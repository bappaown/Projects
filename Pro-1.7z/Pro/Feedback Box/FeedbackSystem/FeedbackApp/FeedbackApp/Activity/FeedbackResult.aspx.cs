﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;
using Utility;
using System.ComponentModel;
using System.IO;
using System.Text;

namespace FeedbackApp.Activity
{
    public partial class FeedbackResult : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [WebMethod]
        public static Dictionary<string, string> IsValidLogin()
        {
            Dictionary<string, string> loginStatus = new Dictionary<string, string>();
            for (int i = 0; i < 1000; i++)
            {

            }
            loginStatus.Add("Message", "SUCCESS");
            return loginStatus;

        }

        [WebMethod]
        public static Dictionary<string, string> IsValidLogin2()
        {
            Dictionary<string, string> loginStatus = new Dictionary<string, string>();
            for (int i = 0; i < 10000000; i++)
            {

            }
            loginStatus.Add("Message", "SUCCESS");
            return loginStatus;

        }

        [WebMethod]
        public static Dictionary<string, string> IsValidLogin3()
        {
            Dictionary<string, string> loginStatus = new Dictionary<string, string>();
            for (long i = 0; i < 1000000000; i++)
            {

            };
            loginStatus.Add("Message", "SUCCESS");
            return loginStatus;

        }

        [WebMethod]
        public static List<Dictionary<string, object>> SearchEmployee(string searchName)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Name");
            dt.Columns.Add("UserId");

            string fromUser = HttpContext.Current.User.Identity.Name;
            fromUser = (fromUser.IndexOf('-') > 0 ? fromUser.Replace("a-", "") : fromUser);

            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
            List<FeedbackService.UserDetails> userList = fbClient.SearchEmployee(searchName, fromUser);

            if (userList != null && userList.Count > 0)
            {
                foreach (FeedbackService.UserDetails userDtls in userList)
                {
                    DataRow dr = dt.NewRow();
                    dr["UserId"] = userDtls.User.UserId;
                    dr["Name"] = userDtls.User.Name + " (" + userDtls.User.UserId + ")";
                    dt.Rows.Add(dr);
                }
            }
            List<Dictionary<string, object>> empList = new Common().DataTableToJson(dt);

            return empList;
        }

        [WebMethod]
        public static List<FeedbackService.QuaterDetails> LoadQuaters()
        {
            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
            List<FeedbackService.QuaterDetails> quaterDetails = fbClient.GetQuaterDetail();
            return quaterDetails;
        }

        [WebMethod]
        public static List<FeedbackService.DisplayFeedbackResult> ShowFeedback(string ratingfromA, string ratingfromB, string ratingtoB, string ratingfromC, string ratingtoC, string ratingfromD, string topuser, string feedbackYear, string quaterId)
        {
            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
            List<FeedbackService.DisplayFeedbackResult> feedbackesult = fbClient.GetFeedbackResult(ratingfromA, ratingfromB, ratingtoB, ratingfromC, ratingtoC, ratingfromD, topuser, feedbackYear, quaterId);
            HttpContext.Current.Session["feedback"] = feedbackesult;
            return feedbackesult;
        }

        [WebMethod]
        public static bool ExportUIData()
        {
            bool uploadStatus = false;
            if (HttpContext.Current.Session["feedback"] != null)
            {
                List<FeedbackService.DisplayFeedbackResult> feedbackresult = (List<FeedbackService.DisplayFeedbackResult>)HttpContext.Current.Session["feedback"];
                List<FeedbackService.DisplayFeedback> feedback = new List<FeedbackService.DisplayFeedback>();
                DataTable dataTable = new DataTable();

                PropertyDescriptorCollection props = TypeDescriptor.GetProperties(typeof(FeedbackService.DisplayFeedbackResult));
                object[] values = new object[props.Count - 1];

                DataSet ds = new DataSet();
                DataTable table = new DataTable();
                DataTable dt;

                //for (int i = 1; i < props.Count; ++i)
                //{
                //    PropertyDescriptor prop = props[i];
                //    table.Columns.Add(prop.Name, prop.PropertyType);
                //}
                foreach (FeedbackService.DisplayFeedbackResult item in feedbackresult)
                {
                    for (int i = 0; i < values.Length; ++i)
                    {
                        //values[i] = props[i + 1].GetValue(item);
                        feedback = (List<FeedbackService.DisplayFeedback>)props[i + 1].GetValue(item);

                        //PropertyDescriptorCollection props1 = TypeDescriptor.GetProperties(typeof(FeedbackService.DisplayFeedback));
                        //object[] values1 = new object[props1.Count - 1];
                        dt = new DataTable();
                        dt.Columns.Add("UserId", typeof(string));
                        dt.Columns.Add("Name", typeof(string));
                        dt.Columns.Add("User Type", typeof(string));
                        dt.Columns.Add("OverallRating", typeof(decimal));
                        dt.Columns.Add("Person Answered", typeof(int));
                        dt.Columns.Add("Teaming", typeof(decimal));
                        dt.Columns.Add("Client Delight", typeof(decimal));
                        dt.Columns.Add("Upskills", typeof(decimal));
                        dt.Columns.Add("Alliance", typeof(decimal));
                        dt.Columns.Add("Commercials", typeof(decimal));
                        dt.Columns.Add("nWoW", typeof(decimal));

                        //for (int j = 1; j < props1.Count; ++j)
                        //{
                        //    PropertyDescriptor prop1 = props1[j];
                        //    dt.Columns.Add(prop1.Name, prop1.PropertyType);
                        //}

                        foreach (FeedbackService.DisplayFeedback items in feedback)
                        {
                            //for (int j = 0; j < values1.Length; ++j)
                            //{
                            //values1[j] = props1[j + 1].GetValue(items);
                            DataRow dr = dt.NewRow();
                            dr["UserId"] = items.ForUser;
                            dr["Name"] = items.ForUserName;
                            dr["User Type"] = items.ForUserType;
                            dr["OverallRating"] = items.OverallRating;
                            dr["Person Answered"] = items.PersonAnswered;
                            dr["Teaming"] = items.Teaming;
                            dr["Client Delight"] = items.ClientDelight;
                            dr["Upskills"] = items.Upskills;
                            dr["Alliance"] = items.Alliance;
                            dr["Commercials"] = items.Commercials;
                            dr["nWoW"] = items.nWoW;

                            dt.Rows.Add(dr);
                            //}
                            //dt.Rows.Add(values1);

                        }
                        ds.Tables.Add(dt);
                    }
                }

                if (ds != null)
                    ExportToExcel(ds, "FeedbackResult.xls");

                uploadStatus = true;
            }
            return uploadStatus;
        }

        public static void ExportToExcel(DataSet objFormated, String fileName)
        {
            String excelFileName = fileName;
            FileStream stream = new FileStream(fileName, System.IO.FileMode.Create);
            StreamWriter writer = new StreamWriter(stream);
            writer.WriteLine("<?xml version=\"1.0\"?>");
            writer.WriteLine("<?mso-application progid=\"Excel.Sheet\"?>");
            writer.WriteLine(" <Workbook xmlns=\"urn:schemas-microsoft-com:office:spreadsheet\"");
            writer.WriteLine("xmlns:o=\"urn:schemas-microsoft-com:office:office\"");
            writer.WriteLine("xmlns:x=\"urn:schemas-microsoft-com:office:excel\"");
            writer.WriteLine("xmlns:ss=\"urn:schemas-microsoft-com:office:spreadsheet\"");
            writer.WriteLine("xmlns:html=\"http://www.w3.org/TR/REC-html40\">");
            writer.WriteLine("<ExcelWorkbook xmlns=\"urn:schemas-microsoft-com:office:excel\">");
            writer.WriteLine("<WindowHeight>8115</WindowHeight>");
            writer.WriteLine("<WindowWidth>15195</WindowWidth>");
            writer.WriteLine("<WindowTopX>0</WindowTopX>");
            writer.WriteLine("<WindowTopY>60</WindowTopY>");
            writer.WriteLine("<ActiveSheet>0</ActiveSheet>");
            writer.WriteLine("<ProtectStructure>False</ProtectStructure>");
            writer.WriteLine("<ProtectWindows>False</ProtectWindows>");
            writer.WriteLine("</ExcelWorkbook>");
            writer.WriteLine("<Styles>");
            writer.WriteLine("<Style ss:ID=\"s21\">");
            writer.WriteLine("<Alignment ss:Horizontal=\"Center\" ss:Vertical=\"Bottom\"/>");
            writer.WriteLine("<Font ss:FontName=\"Lucida Console\" x:Family=\"Modern\" ss:Bold=\"1\"/>");
            writer.WriteLine("</Style>");
            writer.WriteLine("<Style ss:ID=\"s23\">");
            writer.WriteLine("<Font ss:FontName=\"Lucida Console\" x:Family=\"Modern\"/>");
            writer.WriteLine("</Style>");
            writer.WriteLine("</Styles>");

            foreach (DataTable table in objFormated.Tables)
            {
                if (table != null && table.Rows.Count > 0)
                {
                    CreateWorksheetStatic(writer, table, table.TableName);
                }
            }

            writer.WriteLine("</Workbook>");
            writer.Flush();
            stream.Close();
            System.Diagnostics.Process.Start(excelFileName);
            //return excelFileName;
        }

        private static void CreateWorksheetStatic(StreamWriter writer, DataTable table, string tablename)
        {
            StringBuilder excelWriter = new StringBuilder();
            DataTable columnWidth = new DataTable("COLUMNWIDTH");
            columnWidth.Columns.Add("ColumnName", typeof(string));
            columnWidth.Columns.Add("Width", typeof(int));

            string strWorksheetName = tablename;
            if (strWorksheetName == "Table1")
            {
                strWorksheetName = "Grade-A";
            }
            else if (strWorksheetName == "Table2")
            {
                strWorksheetName = "Grade-B";
            }
            else if (strWorksheetName == "Table3")
            {
                strWorksheetName = "Grade-C";
            }
            else if (strWorksheetName == "Table4")
            {
                strWorksheetName = "Grade-D";
            }


            excelWriter.AppendLine("<Worksheet ss:Name=\"" + strWorksheetName + "\">");
            excelWriter.AppendLine("<Table>");
            //------Header
            excelWriter.AppendLine("@#$");
            excelWriter.AppendLine("<Row >");

            for (int intColCounter = 0; intColCounter < table.Columns.Count; ++intColCounter)
            {
                //string colName1 = table.Columns[intColCounter].ColumnName.ToString();
                excelWriter.AppendLine("<Cell ss:StyleID=\"s21\"><Data ss:Type=\"String\">" + table.Columns[intColCounter].ColumnName.ToString().Replace("_", " ") + "</Data></Cell>");
            }

            excelWriter.AppendLine("</Row>");

            //Body
            if (table.Rows.Count > 0)
            {
                Object curObj;
                foreach (DataRow objDataRow in table.Rows)
                {
                    excelWriter.AppendLine("<Row >");
                    for (int intColCounter = 0; intColCounter < table.Columns.Count; ++intColCounter)
                    {
                        string colName2 = table.Columns[intColCounter].ColumnName.ToString();
                        //if (colName2 != "REPORT_UPLOAD_ID")
                        //{
                        curObj = objDataRow[intColCounter];

                        if (table.Columns[intColCounter].DataType == typeof(System.Int16) ||

                            table.Columns[intColCounter].DataType == typeof(System.Int32) ||

                            table.Columns[intColCounter].DataType == typeof(System.Int64) ||

                            table.Columns[intColCounter].DataType == typeof(System.Decimal) ||

                            table.Columns[intColCounter].DataType == typeof(System.Double))
                        {
                            excelWriter.AppendLine("<Cell ss:StyleID=\"s23\"><Data ss:Type=\"Number\">" + curObj.ToString() + "</Data></Cell>");
                        }
                        else
                        {
                            excelWriter.AppendLine("<Cell ss:StyleID=\"s23\"><Data ss:Type=\"String\">" + curObj.ToString() + "</Data></Cell>");
                        }

                        DataRow[] dRow = columnWidth.Select("ColumnName = '" + table.Columns[intColCounter].ColumnName.ToString() + "'");

                        if (dRow.Length == 0)
                        {
                            columnWidth.Rows.Add(table.Columns[intColCounter].ColumnName.ToString(), curObj.ToString().Trim().Length);
                        }
                        else
                        {
                            if (int.Parse(dRow[0]["Width"].ToString()) < curObj.ToString().Trim().Length)
                            {
                                dRow[0]["Width"] = curObj.ToString().Trim().Length;
                            }
                        }
                        //}
                    }
                    columnWidth.AcceptChanges();
                    excelWriter.AppendLine("</Row >");
                }
            }

            string colWidth = string.Empty;

            for (int iCount = 0; iCount < columnWidth.Rows.Count; iCount++)
            {
                if (Convert.ToString(columnWidth.Rows[iCount]["ColumnName"]).Trim().Length > int.Parse(Convert.ToString(columnWidth.Rows[iCount]["Width"])))

                    columnWidth.Rows[iCount]["Width"] = Convert.ToString(columnWidth.Rows[iCount]["ColumnName"]).Trim().Length;

                colWidth = colWidth + string.Format("<Column ss:Index=\"{0}\" ss:Width=\"{1}\"/>", iCount + 1, int.Parse(Convert.ToString(columnWidth.Rows[iCount]["Width"])) * 8) + Environment.NewLine;
            }
            //--fixed
            excelWriter.Replace("@#$", colWidth);
            excelWriter.AppendLine("</Table>");
            excelWriter.AppendLine("<WorksheetOptions xmlns=\"urn:schemas-microsoft-com:office:excel\">");
            excelWriter.AppendLine("<ProtectObjects>False</ProtectObjects>");
            excelWriter.AppendLine("<ProtectScenarios>False</ProtectScenarios>");
            excelWriter.AppendLine("</WorksheetOptions>");
            excelWriter.AppendLine("</Worksheet>");
            writer.WriteLine(excelWriter.ToString());
        }
    }
}
