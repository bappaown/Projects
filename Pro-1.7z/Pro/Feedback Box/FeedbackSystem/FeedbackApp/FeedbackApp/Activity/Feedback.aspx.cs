﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;
using System.Collections;
using System.Web.Script.Serialization;
using System.Configuration;
using System.Web.Configuration;
using Utility;

namespace FeedbackApp.Activity
{
    public partial class Feedback : Page
    {
        public static Dictionary<string, object> lstRecords = null;
        public static FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        [WebMethod]
        public static Dictionary<string, object> GetCategories()
        {
            List<FeedbackService.Category> categoryList = fbClient.GetCategories();
            lstRecords = new Dictionary<string, object>();
            lstRecords.Add("CATEGORY", categoryList);
            return lstRecords;
        }

        [WebMethod]
        public static Dictionary<string, object> GetQuestions()
        {
            List<FeedbackService.Question> questionList = fbClient.GetQuestions();
            lstRecords = new Dictionary<string, object>();
            lstRecords.Add("QUESTIONS", questionList);
            return lstRecords;
        }

        /*
        [WebMethod]
        public static Dictionary<string, object> GetUserType()
        {
            List<FeedbackService.User> userList = fbClient.GetUserTypes();
            lstRecords = new Dictionary<string, object>();
            lstRecords.Add("USERTYPE", userList);
            return lstRecords;
        }
         * */

        //[WebMethod]
        //public static Dictionary<string, string> SaveFeedback(string feedbackXml, int feedYear, int quaterId)
        //{
        //    List<FeedbackService.Feedback> feedbackList = GetFeedbacks(feedbackXml, feedYear, quaterId);
        //    bool retVal = fbClient.SubmitFeedback(feedbackList);
        //    Dictionary<string, string> lstRecords = new Dictionary<string, string>();
        //    lstRecords.Add("OUTRESULT", "SUCCESS");
        //    return lstRecords;
        //}

        #region UIDATA

        [WebMethod]
        public static Dictionary<string, object> GetUIData()
        {
            string strUserId = HttpContext.Current.User.Identity.Name;
            strUserId = (strUserId.IndexOf('-') > 0 ? strUserId.Replace("a-", "") : strUserId);

            Dictionary<string, object> dicsUIData = new Dictionary<string, object>();
            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
            FeedbackService.MasterDataWrapper masterData = fbClient.GetMastarData(strUserId);

            if (!string.IsNullOrEmpty(strUserId) && masterData.LoogedInUser.UserId == "NORECORDS")
            {
                Dictionary<string, string> dicUserParam = new Common().GetUserParameters(strUserId);
                if (dicUserParam != null && dicUserParam.Count > 0)
                {
                    List<FeedbackService.User> userList = new List<FeedbackService.User>();
                    FeedbackService.User user = new FeedbackService.User();
                    string[] arrNameMailId = dicUserParam[strUserId].ToString().Split('|');
                    user.UserId = strUserId;
                    user.Name = arrNameMailId[0];
                    user.EmailId = arrNameMailId[1];
                    user.IBMEmailId = string.Empty;
                    user.PeopleManagerId = string.Empty;
                    user.UserType = 1;
                    masterData.LoogedInUser = user;
                    if (!userList.Contains(user))
                        userList.Add(user);
                    fbClient.SubmitUsers(userList);
                }
            }

            dicsUIData.Add("CATEGORY", masterData.Categories);
            dicsUIData.Add("QUESTIONS", masterData.Questions);
            dicsUIData.Add("LOGGEDINUSER", masterData.LoogedInUser);
            dicsUIData.Add("USERTYPE", masterData.LoogedInUserType);
            dicsUIData.Add("QUARTER", masterData.ActiveQuater);
            dicsUIData.Add("OPTIONLIST", masterData.AnswerPriorityList);
            return dicsUIData;
        }

        #endregion UIDATA

        [WebMethod]
        public static bool SaveFeedback(List<FeedbackDetails> feeds, string submitBy)
        {
            List<FeedbackService.Feedback> feedbackList = new List<FeedbackService.Feedback>();
            FeedbackService.Feedback feedBack = null;
            bool uploadStatus = false;
            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();

            string fromUser = HttpContext.Current.User.Identity.Name;
            if (String.IsNullOrEmpty(submitBy))
            {
                fromUser = (fromUser.IndexOf('-') > 0 ? fromUser.Replace("a-", "") : fromUser);
            }
            else
            {
                fromUser = submitBy;
            }

            foreach (FeedbackDetails feedBackDetail in feeds)
            {
                if (!string.IsNullOrEmpty(feedBackDetail.ForUser))
                {
                    feedBack = new FeedbackService.Feedback();
                    feedBack.ForUser = feedBackDetail.ForUser;
                    feedBack.FromUser = (fromUser == "") ? feedBackDetail.FromUser : fromUser;
                    feedBack.QuestionAnswered = feedBackDetail.QuestionAnswered;
                    feedBack.Comments = feedBackDetail.Comments;
                    feedBack.QuaterId = Convert.ToInt32(feedBackDetail.QuaterId);
                    feedBack.Year = Convert.ToInt32(feedBackDetail.Year);
                    feedBack.OnDate = DateTime.Now;

                    if (!feedbackList.Contains(feedBack))
                        feedbackList.Add(feedBack);
                }
            }

            uploadStatus = fbClient.SubmitFeedback(feedbackList);

            return uploadStatus;
        }


        [WebMethod]
        public static Dictionary<string, object> SearchEmployee(string searchName, string searchBy)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Name");
            dt.Columns.Add("UserId");

            string fromUser = HttpContext.Current.User.Identity.Name;
            if (String.IsNullOrEmpty(searchBy))
            {
                fromUser = (fromUser.IndexOf('-') > 0 ? fromUser.Replace("a-", "") : fromUser);
            }
            else
            {
                fromUser = searchBy;
            }

            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
            List<FeedbackService.UserDetails> usersdetailList = fbClient.SearchEmployee(searchName, fromUser);
            Dictionary<string, object> dicsUsersList = new Dictionary<string, object>();

            dicsUsersList.Add("SEARCHRESULT", usersdetailList);
            return dicsUsersList;
        }

        [WebMethod]
        public static string ValidateUser(string UserMailId)
        {
            string status = string.Empty;
            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
            status = fbClient.ValidateUserDetails(UserMailId);

            return status;
        }

        [WebMethod]
        public static bool CheckExpiry()
        {
            bool expiry = false;
            string expiryDate = ConfigurationManager.AppSettings["ExpiryDate"].ToString();
            if (expiryDate != "" && Convert.ToDateTime(expiryDate) < DateTime.Now)
            {
                expiry = true;
            }
            return expiry;
        }

    }

    public class FeedbackDetails
    {
        public string FromUser { get; set; }
        public string ForUser { get; set; }
        public string ForUserName { get; set; }
        public string QuestionAnswered { get; set; }
        public string QuaterId { get; set; }
        public string Year { get; set; }
        public string Comments { get; set; }
    }
}