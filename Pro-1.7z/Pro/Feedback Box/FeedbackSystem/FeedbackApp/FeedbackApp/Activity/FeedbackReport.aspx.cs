﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Services;
using System.Data;
using Utility;

namespace FeedbackApp.Activity
{
    public partial class FeedbackReport : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        [WebMethod]
        public static Dictionary<string, string> IsValidLogin()
        {
            Dictionary<string, string> loginStatus = new Dictionary<string, string>();
            for (int i = 0; i < 1000; i++)
            {

            }
            loginStatus.Add("Message", "SUCCESS");
            return loginStatus;

        }

        [WebMethod]
        public static Dictionary<string, string> IsValidLogin2()
        {
            Dictionary<string, string> loginStatus = new Dictionary<string, string>();
            for (int i = 0; i < 10000000; i++)
            {

            }
            loginStatus.Add("Message", "SUCCESS");
            return loginStatus;

        }

        [WebMethod]
        public static Dictionary<string, string> IsValidLogin3()
        {
            Dictionary<string, string> loginStatus = new Dictionary<string, string>();
            for (long i = 0; i < 1000000000; i++)
            {

            };
            loginStatus.Add("Message", "SUCCESS");
            return loginStatus;

        }

        [WebMethod]
        public static List<Dictionary<string, object>> SearchEmployee(string searchName)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("Name");
            dt.Columns.Add("UserId");

            string fromUser = HttpContext.Current.User.Identity.Name;
            fromUser = (fromUser.IndexOf('-') > 0 ? fromUser.Replace("a-", "") : fromUser);

            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
            List<FeedbackService.UserDetails> userList = fbClient.SearchEmployee(searchName, fromUser);

            if (userList != null && userList.Count > 0)
            {
                foreach (FeedbackService.UserDetails userDtls in userList)
                {
                    DataRow dr = dt.NewRow();
                    dr["UserId"] = userDtls.User.UserId;
                    dr["Name"] = userDtls.User.Name + " (" + userDtls.User.UserId + ")";
                    dt.Rows.Add(dr);
                }
            }
            List<Dictionary<string, object>> empList = new Common().DataTableToJson(dt);

            return empList;
        }

        [WebMethod]
        public static List<FeedbackService.QuaterDetails> LoadQuaters()
        {
            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
            List<FeedbackService.QuaterDetails> quaterDetails = fbClient.GetQuaterDetail();
            return quaterDetails;
        }

        [WebMethod]
        public static FeedbackService.DisplayFeedbackReport showResult(string userId, int feedbackYear, int quaterId)
        {
            FeedbackService.FeedbackServiceClient fbClient = new FeedbackService.FeedbackServiceClient();
            FeedbackService.DisplayFeedbackReport feedbackesult = fbClient.GetFeedbackReport(userId, feedbackYear, quaterId);
            return feedbackesult;
        }
    }
}
