﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using System.Data.SqlClient;
using EVO_Upgrade.Filter;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class ManageDataController : Controller
    {
        EvoSuperAdminGlobalControls objGlobalControl = new EvoSuperAdminGlobalControls();
        private static string controlType = string.Empty;
        DataSet dsMain;
        int CtrlId;
        string ParentName, ChildName;

        // GET: ManageData
        public ActionResult Index()
        {
            try
            {
                ViewBag.CostCentre = FillCostCentres();
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("ManageData - Load: " + ex.Message);
            }

            return View();
        }

        public ActionResult BindDropdowns(string ControlType)
        {
            string js = string.Empty;
            DataSet ds = new DataSet();
            controlType = ControlType;

            objGlobalControl.ControlType = ControlType;
            ds = objGlobalControl.GetAllGlobalControls();

            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindSkillSets(int CostCentre)
        {
            string js = string.Empty;
            DataSet ds = new DataSet();

            objGlobalControl.CostCentreId = CostCentre;
            ds = objGlobalControl.GetCostCentresSkillsets();

            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetData(int ControlId, int CostCentre, string SkillSets)
        {
            string js = string.Empty;
            DataTable dt = new DataTable();

            CtrlId = ControlId;
            objGlobalControl.ControlId = CtrlId;
            objGlobalControl.SkillSetId = SkillSets;
            objGlobalControl.CostCentreId = CostCentre;

            dsMain = objGlobalControl.GetControlDetails();

            if (dsMain.Tables[0].Rows.Count > 0)
            {
                int ParentId = int.Parse(dsMain.Tables[0].Rows[0]["DependentControlId"].ToString());
                string ctrlName = dsMain.Tables[0].Rows[0]["ControlName"].ToString();

                if (ParentId > 0)
                {
                    DataSet dsPrnt;
                    objGlobalControl.ControlId = ParentId;
                    dsPrnt = objGlobalControl.GetControlDetails();
                    dt = FillData(dsPrnt, "Parent", false);
                }
                else
                {
                    objGlobalControl.ControlId = CtrlId;
                    dt = FillData(dsMain, "Child", false);
                }
            }

            if (dt.Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(dt);
            }

            var data = new { Parent = ParentName, Child = ChildName, Message = TempData["error"], ControlValue = js };

            return Json(data, JsonRequestBehavior.AllowGet);
        }

        [NonAction]
        private DataTable FillData(DataSet dsParent, string type, bool isFromParent)
        {
            DataTable dt = new DataTable();
            try
            {
                if (dsParent.Tables[0].Rows.Count > 0)
                {
                    string ctrlParentName = dsParent.Tables[0].Rows[0]["ControlName"].ToString();
                    int ctrlParentId = int.Parse(dsParent.Tables[0].Rows[0]["ControlId"].ToString());

                    DataSet dsParentData;
                    dsParentData = objGlobalControl.GetSelectedControlData();
                    if (!isFromParent)
                    {
                        ParentName = ctrlParentName;

                        if (controlType == "DropDown")
                        {
                            if (type == "Parent")
                            {
                                if (dsParentData.Tables[0].Rows.Count > 0)
                                {
                                    dt = dsParentData.Tables[0];

                                    objGlobalControl.ControlId = CtrlId;
                                    FillData(dsMain, "Child", true);
                                }
                                else
                                {
                                    TempData["error"] = "No data found in parent control " + ctrlParentName + ". Please select parent control and fill up data first.";
                                }
                            }
                            else
                            {
                                if (dsParentData.Tables[0].Rows.Count > 0)
                                {
                                    dt = dsParentData.Tables[0];
                                }
                                else
                                {
                                    TempData["error"] = "No data found in control " + ctrlParentName + ". Please fill up.";
                                }
                            }
                        }
                        else if (controlType == "ListBox")
                        {
                            if (type == "Parent")
                            {
                                if (dsParentData.Tables[0].Rows.Count > 0)
                                {
                                    dt = dsParentData.Tables[0];

                                    objGlobalControl.ControlId = CtrlId;
                                    FillData(dsMain, "Child", true);
                                }
                                else
                                {
                                    TempData["error"] = "No data found in parent control " + ctrlParentName + ". Please select parent control and fill up data first.";
                                }
                            }
                            else
                            {
                                if (dsParentData.Tables[0].Rows.Count > 0)
                                {
                                    dt = dsParentData.Tables[0];
                                }
                                else
                                {
                                    TempData["error"] = "No data found in control " + ctrlParentName + ". Please fill up.";
                                }
                            }
                        }
                    }
                    else
                    {
                        ChildName = ctrlParentName;
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "FillData: " + ex.Message;
                ErrorLogger.logger.Error("ManageData - FillData: " + ex.Message);
            }

            return dt;
        }

        [NonAction]
        private IDictionary<int, string> FillCostCentres()
        {
            IDictionary<int, string> myList = new Dictionary<int, string>();
            try
            {
                DataSet ds = new DataSet();
                ds = objGlobalControl.GetCostCentres();

                if (ds.Tables[0].Rows.Count > 0)
                {
                    myList = ds.Tables[0].AsEnumerable().ToDictionary<DataRow, int, string>(row => Convert.ToInt32(row[0].ToString()), row => row[1].ToString());
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Fill CostCentre: " + ex.Message;
                ErrorLogger.logger.Error("ManageData - Fill CostCentre: " + ex.Message);
            }

            return myList;
        }

        public ActionResult BindChildData(int ParentId, int CostCentre, string SkillSets)
        {
            string js = string.Empty;
            DataSet ds = new DataSet();

            objGlobalControl.CostCentreId = CostCentre;
            objGlobalControl.SkillSetId = SkillSets;
            objGlobalControl.DependentControlId = ParentId;
            ds = objGlobalControl.GetChildGlobalControlData();

            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Submit(ManageData model, string submitButton)
        {
            switch (submitButton)
            {
                case "Add":
                    return (AddData(model));
                case "Update":
                    return (UpdateData(model));
                case "Delete":
                    return DeleteData(model);
            }

            return RedirectToAction("Index");
        }

        public ActionResult AddData(ManageData model)
        {
            EvoGeneral objEvoGeneral = new EvoGeneral();
            try
            {
                if (ModelState.IsValid)
                {
                    string SkillSetString = "";
                    foreach (int skill in model.SkillSets)
                    {
                        SkillSetString += skill + ",";
                    }

                    objGlobalControl.ControlId = model.Control;
                    objGlobalControl.ControlName = model.ListItem.Trim();
                    objGlobalControl.CostCentreId = model.CostCentre;
                    objGlobalControl.SkillSetId = SkillSetString;
                    objGlobalControl.DependentControlId = model.ParentData;
                    objGlobalControl.UserLogin = objEvoGeneral.userName;

                    if (objGlobalControl.InsertGlobalControlData())
                    {
                        TempData["error"] = "Data Added successfully.";
                    }
                    else
                    {
                        TempData["error"] = "Data already exists.";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Could not add data. " + ex.Message;
                ErrorLogger.logger.Error("ManageData - Could not add data. " + ex.Message);
            }

            return RedirectToAction("Index");
        }

        public ActionResult UpdateData(ManageData model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    objGlobalControl.ControlId = model.Control;
                    objGlobalControl.ControlName = model.ListItem.Trim();
                    objGlobalControl.DataStoreId = model.ChildData;
                    objGlobalControl.CostCentreId = model.CostCentre;

                    if (objGlobalControl.UpdateGlobalControlData())
                    {
                        TempData["error"] = "Data Updated Successfully.";
                    }
                    else
                    {
                        TempData["error"] = "Option already exists.";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Could not update data. " + ex.Message;
                ErrorLogger.logger.Error("ManageData - Could not update data. " + ex.Message);
            }

            return RedirectToAction("Index");
        }

        public ActionResult DeleteData(ManageData model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    string SkillSetString = "";
                    foreach (int skill in model.SkillSets)
                    {
                        SkillSetString += skill + ",";
                    }

                    objGlobalControl.ControlId = model.ChildData;
                    objGlobalControl.SkillSetId = SkillSetString;

                    if (objGlobalControl.DeleteGlobalControlData())
                    {
                        TempData["error"] = "Data Deleted Successfully";
                    }
                    else
                    {
                        TempData["error"] = "Data could not be deleted";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Could not delete data. " + ex.Message;
                ErrorLogger.logger.Error("ManageData - Could not delete data. " + ex.Message);
            }

            return RedirectToAction("Index");
        }
    }
}