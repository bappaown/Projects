﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using System.Web.UI.WebControls;
using System.Xml;
using Newtonsoft.Json;

namespace EVO_Upgrade.Controllers
{
    public class DesignManagementController : Controller
    {

        public DesignManagementController()
        {
            EvoGeneral objEvoGeneral = new EvoGeneral();
            EvoMain objEvoMain = new EvoMain();
            EvoAdminUsersRights ObjUserRights = new EvoAdminUsersRights();

            if (objEvoGeneral.userName != "")
            {
                ObjUserRights.UserID = objEvoGeneral.RetrieveUserID(objEvoGeneral.userName);
                ObjUserRights.FormId = int.Parse(ManageSession.FormID.ToString());
                ObjUserRights.VersionId = int.Parse(ManageSession.VersionID.ToString());

                Boolean IsValid = ObjUserRights.ValidateAdminManageUser();

                if (!IsValid)
                {
                    RedirectToAction("Unauthorized", "Home");
                }
            }
            else
            {
                RedirectToAction("Login", "Home");
            }
        }

        // GET: DesignManagement
        public ActionResult Index()
        {
            TempData["FormIDHidden"] = ManageSession.FormID.ToString();
            TempData["FormNameHidden"] = ManageSession.FormName;
            TempData["FormEndNameHidden"] = ManageSession.FormName;
            TempData["VersionIDHidden"] = ManageSession.VersionID.ToString();
            TempData["CategoryIDHidden"] = ManageSession.CategoryID.ToString();
            TempData["FileModeHidden"] = "";
            TempData.Keep();

            //BindCustomCostCentre();
            BindGlobalCostCentre();
            BindGlobalSkillSet();

            //DeleteButton.Style.Add("display", "none");

            DataSet basicControlDataSet = new DataSet();
            basicControlDataSet = DesignManagement.GetBasicControls();

            List<DataRow> basicControllist = basicControlDataSet.Tables[0].AsEnumerable().ToList();
            ViewBag.BasicTools = basicControllist;

            //for (int controlCount = 0; controlCount < basicControlDataSet.Tables[0].Rows.Count; controlCount++)
            //{
            //TableRow controlRow = new TableRow();
            //TableCell controlCell = new TableCell();
            //controlCell.Attributes.Add("runat", "server");
            //controlCell.Attributes.Add("onclick", "Create" + basicControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "();");
            //controlCell.Text = "" + basicControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "";
            //controlCell.Style.Add("cursor", "hand");
            //controlCell.ToolTip = "Add " + controlCell.Text;
            //controlRow.Controls.Add(controlCell);
            //}

            DataSet customControlDataSet = new DataSet();
            customControlDataSet = DesignManagement.GetCustomControls();

            List<DataRow> customControllist = customControlDataSet.Tables[0].AsEnumerable().ToList();
            ViewBag.CustomTools = customControllist;

            //for (int controlCount = 0; controlCount < customControlDataSet.Tables[0].Rows.Count; controlCount++)
            //{
            //    TableRow customRow = new TableRow();
            //    TableCell customCell = new TableCell();
            //    customCell.Attributes.Add("runat", "server");
            //    customCell.Attributes.Add("onclick", "Create" + customControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "();");
            //    customCell.Text = "" + customControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "";
            //    if (customCell.Text == "CC2Employees")
            //    {
            //        customCell.Style.Add("display", "none");
            //    }
            //    if (customCell.Text == "CC1Employees")
            //    {
            //        customCell.Text = "Employee DropDown";
            //    }
            //    if (customCell.Text == "CC3Employees")
            //    {
            //        customCell.Text = "Employee's Manager DropDown";
            //    }
            //    customCell.Style.Add("cursor", "hand");
            //    customCell.ToolTip = "Add " + customCell.Text;
            //    customRow.Controls.Add(customCell);
            //}



            string dependentIDS = "";
            DataSet globalChildControlDataSet = new DataSet();
            globalChildControlDataSet = DesignManagement.GetGlobalChildControls();

            for (int count = 0; count < globalChildControlDataSet.Tables[0].Rows.Count; count++)
            {
                dependentIDS += globalChildControlDataSet.Tables[0].Rows[count]["DependentControlID"].ToString() + ",";
            }

            if (dependentIDS != "")
            {
                DataSet globalMControlDataSet = new DataSet();
                globalMControlDataSet = DesignManagement.GetGlobalMControls(dependentIDS);
                globalMControlDataSet.Tables[0].Columns.Add(new DataColumn("ControlValue", typeof(string)));
                globalMControlDataSet.Tables[0].Columns.Add(new DataColumn("depctrlid", typeof(string)));
                globalMControlDataSet.Tables[0].Columns.Add(new DataColumn("ctrlid", typeof(string)));

                for (int controlCount = 0; controlCount < globalMControlDataSet.Tables[0].Rows.Count; controlCount++)
                {
                    for (int globCount = 0; globCount < globalChildControlDataSet.Tables[0].Rows.Count; globCount++)
                    {
                        if (globalChildControlDataSet.Tables[0].Rows[globCount]["DependentControlID"].ToString() == globalMControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString())
                        {
                            globalMControlDataSet.Tables[0].Rows[controlCount]["ControlValue"] = "" + globalMControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "/" + globalChildControlDataSet.Tables[0].Rows[globCount]["ChildControlName"].ToString() + "";
                            globalMControlDataSet.Tables[0].Rows[controlCount]["depctrlid"] = globalChildControlDataSet.Tables[0].Rows[globCount]["ControlID"].ToString();
                        }
                    }
                    globalMControlDataSet.Tables[0].Rows[controlCount]["ctrlid"] = globalMControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString();
                }

                List<DataRow> globalMControllist = globalMControlDataSet.Tables[0].AsEnumerable().ToList();
                ViewBag.GlobalTools = globalMControllist;

                //for (int controlCount = 0; controlCount < globalMControlDataSet.Tables[0].Rows.Count; controlCount++)
                //{
                //    TableRow globalRow = new TableRow();
                //    TableCell globalCell = new TableCell();
                //    globalCell.Attributes.Add("runat", "server");
                //    globalCell.Attributes.Add("onclick", "CreateMultipleGlobal(this);");
                //    for (int globCount = 0; globCount < globalChildControlDataSet.Tables[0].Rows.Count; globCount++)
                //    {
                //        if (globalChildControlDataSet.Tables[0].Rows[globCount]["DependentControlID"].ToString() == globalMControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString())
                //        {
                //            globalCell.Text = "" + globalMControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "/" + globalChildControlDataSet.Tables[0].Rows[globCount]["ChildControlName"].ToString() + "";
                //            globalCell.Attributes.Add("depctrlid", globalChildControlDataSet.Tables[0].Rows[globCount]["ControlID"].ToString());
                //        }
                //    }
                //    globalCell.Style.Add("cursor", "hand");
                //    globalCell.Attributes.Add("ctrlid", globalMControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString());
                //    globalCell.ToolTip = "Add " + globalCell.Text;
                //    globalRow.Controls.Add(globalCell);
                //}
            }

            DataSet globalSControlDataSet = new DataSet();
            globalSControlDataSet = DesignManagement.GetGlobalSControls();

            List<DataRow> globalSControl = globalSControlDataSet.Tables[0].AsEnumerable().ToList();
            ViewBag.GlobalControl = globalSControl;


            //if (globalSControlDataSet.Tables.Count > 0)
            //{
            //    for (int controlCount = 0; controlCount < globalSControlDataSet.Tables[0].Rows.Count; controlCount++)
            //    {
            //        Table GlobalToolsListView = new Table();
            //        TableRow globalRow = new TableRow();
            //        TableCell globalCell = new TableCell();
            //        globalCell.Attributes.Add("runat", "server");
            //        globalCell.Attributes.Add("onclick", "CreateSingleGlobal(this);");
            //        globalCell.Text = "" + globalSControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "";
            //        globalCell.Style.Add("cursor", "hand");
            //        globalCell.Attributes.Add("ctrlid", globalSControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString());
            //        globalCell.Attributes.Add("runat", "server");
            //        globalCell.ToolTip = "Add " + globalCell.Text;
            //        globalRow.Controls.Add(globalCell);
            //        GlobalToolsListView.Rows.Add(globalRow);
            //        //ViewBag.GlobalTools = GlobalToolsListView;
            //    }
            //}


            ////Code to select the form id from query string --> and get the XML file path and VersionName for that form.
            XmlDocument xExistingXMLDoc = new XmlDocument();
            DataSet getFormXMLDataset = new DataSet();
            if (TempData["FileModeHidden"].ToString() == "EDITMODE")
            {
                getFormXMLDataset = DesignManagement.GetFormXMLPathForModify(int.Parse(TempData["FormIDHidden"].ToString()), int.Parse(TempData["VersionIDHidden"].ToString()));

            }
            else
            {
                getFormXMLDataset = DesignManagement.GetFormXMLPath(int.Parse(TempData["FormIDHidden"].ToString()));
            }

            try
            {
                if (getFormXMLDataset.Tables[0].Rows[0]["VersionName"].ToString() != "No Version")
                {
                    string title = "";
                    string controlId = "";
                    string controlType = "";
                    string fieldId = "";
                    string xpos = "";
                    string ypos = "";
                    string width = "";
                    string isRequired = "";
                    string dependency = "";
                    string dependentId = "";
                    string dependentCtrlId = "";
                    string isWrap = "";
                    string preWrap = "";
                    string postWrap = "";
                    string prevRef = "";
                    string queryPattern = "Contains";
                    string textMode = "";
                    string isType = "";
                    int maxLength = 0;
                    string height = "";
                    int dropDownCount = 0;
                    int listBoxCount = 0;
                    int checkBoxCount = 0;
                    int radioButtonCount = 0;
                    int textBoxCount = 0;
                    int labelCount = 0;
                    int customCount = 0;
                    int globalCount = 0;
                    string globalCountString = "";
                    string IsHide = "";
                    string skillSet = "";
                    string skillSetValues = "";

                    string costCentre = "";
                    string costCentreValues = "";

                    xExistingXMLDoc.Load(Server.MapPath("~/XML/" + getFormXMLDataset.Tables[0].Rows[0]["XMLFile"]));
                    TempData["FileModeHidden"] = "EDITMODE";
                    TempData["FormNameHidden"] = getFormXMLDataset.Tables[0].Rows[0]["XMLFile"].ToString();
                    TempData["ReadXMLHidden"] = xExistingXMLDoc.InnerXml;
                    TempData.Keep();

                    for (int xmlCount = 0; xmlCount < xExistingXMLDoc.ChildNodes[1].ChildNodes.Count; xmlCount++)
                    {
                        XmlNode xmlNode = (XmlNode)xExistingXMLDoc.ChildNodes[1].ChildNodes[xmlCount];
                        if (xmlNode.Name == "TextBox")
                        {
                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;


                            if (fieldId.Contains("cctxt_"))
                            {
                                textBoxCount = Convert.ToInt32(fieldId.Replace("cctxt_", "").Replace("TextBox", "").ToString());
                            }
                            else
                            {

                                if (fieldId.Replace("txt_", "").Replace("TextBox", "").ToString() != "")
                                {
                                    textBoxCount = Convert.ToInt32(fieldId.Replace("txt_", "").Replace("TextBox", "").ToString());
                                }
                                else
                                {
                                    textBoxCount = 0;
                                }
                            }
                            TempData["textBoxCountHidden"] = textBoxCount.ToString();
                            TempData.Keep();

                            xpos = xmlNode.ChildNodes[5].InnerText;
                            ypos = xmlNode.ChildNodes[6].InnerText;
                            width = xmlNode.ChildNodes[7].InnerText;
                            isRequired = xmlNode.ChildNodes[8].InnerText;
                            isWrap = xmlNode.ChildNodes[10].InnerText;
                            preWrap = xmlNode.ChildNodes[11].InnerText;
                            postWrap = xmlNode.ChildNodes[12].InnerText;
                            textMode = xmlNode.ChildNodes[13].InnerText;
                            isType = xmlNode.ChildNodes[14].InnerText;
                            maxLength = Convert.ToInt32(xmlNode.ChildNodes[15].InnerText);
                            if (xmlNode.ChildNodes[20] != null)
                            {
                                height = xmlNode.ChildNodes[20].InnerText;
                            }
                            else
                            {
                                height = "50";
                            }
                            if (xmlNode.ChildNodes[21] != null)
                            {
                                IsHide = xmlNode.ChildNodes[21].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }
                            var DesignDiv = "";
                            DesignDiv += "<table id='txt_" + textBoxCount + "TextBoxTable' title='" + title + "' type='TextBox' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:" + height + "px; background-color:White; width:" + width + "px;top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)' controlid='1' controltype='basic' dependency='False' isrequired='" + isRequired + "' ismanageable='False' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False'  maxlength='" + maxLength + "' textmode='" + textMode + "' istype='" + isType + "' IsHide='" + IsHide + "'>";
                            DesignDiv += "<tr ><td style='cursor:none;white-space:nowrap;' align='center'>" + title + "</td>";
                            DesignDiv += "<td align='center'><input id='txt_" + textBoxCount + "TextBox' title='" + title + "' style='z-index:-1;width:150px;cursor:none' type='text'/></td></tr></table>";
                            ViewBag.DesignDiv = DesignDiv;
                        }
                        if (xmlNode.Name == "TextBox1")
                        {
                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;


                            if (fieldId.Contains("cctxt_"))
                            {
                                textBoxCount = Convert.ToInt32(fieldId.Replace("cctxt_", "").Replace("TextBox", "").ToString());
                            }
                            else
                            {

                                if (fieldId.Replace("txt_", "").Replace("TextBox", "").ToString() != "")
                                {
                                    textBoxCount = Convert.ToInt32(fieldId.Replace("txt_", "").Replace("TextBox", "").ToString());
                                }
                                else
                                {
                                    textBoxCount = 0;
                                }
                            }
                            TempData["textBoxCountHidden"] = textBoxCount.ToString();
                            TempData.Keep();

                            xpos = xmlNode.ChildNodes[5].InnerText;
                            ypos = xmlNode.ChildNodes[6].InnerText;
                            width = xmlNode.ChildNodes[7].InnerText;
                            isRequired = xmlNode.ChildNodes[8].InnerText;
                            isWrap = xmlNode.ChildNodes[10].InnerText;
                            preWrap = xmlNode.ChildNodes[11].InnerText;
                            postWrap = xmlNode.ChildNodes[12].InnerText;
                            textMode = xmlNode.ChildNodes[13].InnerText;
                            isType = xmlNode.ChildNodes[14].InnerText;
                            maxLength = Convert.ToInt32(xmlNode.ChildNodes[15].InnerText);
                            if (xmlNode.ChildNodes[20] != null)
                            {
                                height = xmlNode.ChildNodes[20].InnerText;
                            }
                            else
                            {
                                height = "50";
                            }
                            if (xmlNode.ChildNodes[21] != null)
                            {
                                IsHide = xmlNode.ChildNodes[21].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }
                            var DesignDiv = "";
                            DesignDiv += "<table id='txt_" + textBoxCount + "TextBoxTable' title='" + title + "' type='TextBox' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:" + height + "px; background-color:White; width:" + width + "px;top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)' controlid='1' controltype='basic' dependency='False' isrequired='" + isRequired + "' ismanageable='False' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False'  maxlength='" + maxLength + "' textmode='" + textMode + "' istype='" + isType + "' IsHide='" + IsHide + "'>";
                            DesignDiv += "<tr ><td style='cursor:none;white-space:nowrap;' align='center'>" + title + "</td>";
                            DesignDiv += "<td align='center'><input id='txt_" + textBoxCount + "TextBox' title='" + title + "' style='z-index:-1;width:150px;cursor:none' type='text'/></td></tr></table>";
                            ViewBag.DesignDiv = DesignDiv;
                        }
                        if (xmlNode.Name == "DropDownList")
                        {
                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;

                            if (fieldId.Replace("ddl_", "").Replace("DropDown", "").ToString() != "")
                            {
                                dropDownCount = Convert.ToInt32(fieldId.Replace("ddl_", "").Replace("DropDown", "").ToString());
                            }
                            else
                            {
                                dropDownCount = 0;
                            }


                            dependentId = xmlNode.ChildNodes[5].InnerText;
                            xpos = xmlNode.ChildNodes[6].InnerText;
                            ypos = xmlNode.ChildNodes[7].InnerText;
                            width = xmlNode.ChildNodes[8].InnerText;
                            isRequired = xmlNode.ChildNodes[9].InnerText;
                            dependency = xmlNode.ChildNodes[12].InnerText;
                            isWrap = xmlNode.ChildNodes[13].InnerText;
                            preWrap = xmlNode.ChildNodes[14].InnerText;
                            postWrap = xmlNode.ChildNodes[15].InnerText;
                            prevRef = xmlNode.ChildNodes[16].InnerText;
                            if (xmlNode.ChildNodes[21] != null)
                            {
                                IsHide = xmlNode.ChildNodes[21].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }

                            TempData["dropDownCountHidden"] = dropDownCount.ToString();
                            TempData["DropDownArray"] += title + ",";
                            TempData["DropDownIDArray"] += fieldId + ",";
                            TempData.Keep();

                            var DesignDiv = "";
                            DesignDiv += "<table id='ddl_" + dropDownCount + "DropDownTable' title='" + title + "' type='DropDown' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; width:200px; top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)' controlid='2' controltype='basic' dependency='" + dependency + "' dependentid='" + dependentId + "' prevref='" + prevRef + "' isrequired='" + isRequired + "' ismanageable='False' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False' IsQueryPattern='" + queryPattern + "' IsHide='" + IsHide + "'>";
                            DesignDiv += "<tr><td style='cursor:none;' align='center'>" + title + "</td>";
                            DesignDiv += "<td align='center'><img id='ddl_" + dropDownCount + "DropDown' title='" + title + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/></td></tr></table>";
                            ViewBag.DesignDiv = DesignDiv;

                        }
                        if (xmlNode.Name == "ListBox")
                        {
                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;


                            if (fieldId.Replace("lb_", "").Replace("ListBox", "").ToString() != "")
                            {
                                listBoxCount = Convert.ToInt32(fieldId.Replace("lb_", "").Replace("ListBox", "").ToString());
                            }
                            else
                            {
                                listBoxCount = 0;
                            }

                            dependentId = xmlNode.ChildNodes[5].InnerText;
                            xpos = xmlNode.ChildNodes[6].InnerText;
                            ypos = xmlNode.ChildNodes[7].InnerText;
                            width = xmlNode.ChildNodes[8].InnerText;
                            isRequired = xmlNode.ChildNodes[9].InnerText;
                            dependency = xmlNode.ChildNodes[12].InnerText;
                            isWrap = xmlNode.ChildNodes[13].InnerText;
                            preWrap = xmlNode.ChildNodes[14].InnerText;
                            postWrap = xmlNode.ChildNodes[15].InnerText;
                            prevRef = xmlNode.ChildNodes[16].InnerText;
                            if (xmlNode.ChildNodes[20] != null)
                            {
                                IsHide = xmlNode.ChildNodes[20].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }

                            TempData["listBoxCountHidden"] = listBoxCount.ToString();
                            TempData["ListBoxArray"] += title + ",";
                            TempData["ListBoxIDArray"] += fieldId + ",";
                            TempData.Keep();

                            var DesignDiv = "";
                            DesignDiv += "<table id='lb_" + listBoxCount + "ListBoxTable' title='" + title + "' type='ListBox' class='drag' style='position:absolute;border:dashed 4px #afafaf;background-color:White; width:100px;top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)'  iswrap='" + isWrap + "' controlid='5' controltype='basic' dependency='" + dependency + "' dependentid='" + dependentId + "' prevref='" + prevRef + "' isrequired='" + isRequired + "' ismanageable='False' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False' IsHide='" + IsHide + "'>";
                            DesignDiv += "<tr ><td style='cursor:none' align='center'>" + title + "</td></tr><tr>";
                            DesignDiv += "<td align='center'><img id='lb_" + listBoxCount + "ListBox' title='" + title + "' style='z-index:-1;width:200px;;height:120px;' src='../Images/ListBoxDes.jpg'/></td></tr></table>";
                            ViewBag.DesignDiv = DesignDiv;
                        }
                        if (xmlNode.Name == "CheckBoxList")
                        {
                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;


                            if (fieldId.Replace("cbl_", "").Replace("CheckBox", "").ToString() != "")
                            {
                                checkBoxCount = Convert.ToInt32(fieldId.Replace("cbl_", "").Replace("CheckBox", "").ToString());

                            }
                            else
                            {
                                checkBoxCount = 0;
                            }

                            xpos = xmlNode.ChildNodes[5].InnerText;
                            ypos = xmlNode.ChildNodes[6].InnerText;
                            width = xmlNode.ChildNodes[7].InnerText;
                            isRequired = xmlNode.ChildNodes[8].InnerText;
                            isWrap = xmlNode.ChildNodes[13].InnerText;
                            preWrap = xmlNode.ChildNodes[14].InnerText;
                            postWrap = xmlNode.ChildNodes[15].InnerText;
                            if (xmlNode.ChildNodes[22] != null)
                            {
                                IsHide = xmlNode.ChildNodes[22].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }

                            TempData["checkBoxCountHidden"] = checkBoxCount.ToString();
                            TempData.Keep();

                            int resultheight = 0;
                            int resultmod = 0;
                            resultheight = xmlNode.ChildNodes[20].ChildNodes.Count / 5;
                            resultmod = xmlNode.ChildNodes[20].ChildNodes.Count % 5;
                            if (resultheight < 1)
                            {
                                resultheight = 1;
                            }
                            if (resultmod > 0)
                            {
                                resultheight = resultheight + 1;
                            }
                            int resultcount = 0;

                            var DesignDiv = "";
                            DesignDiv += "<table id='cbl_" + checkBoxCount + "CheckBox' title='" + title + "' type='CheckBoxList' class='drag' style='position:absolute;border:dashed 4px #afafaf;background-color:White; width:200px; top:" + ypos + "px; left:" + xpos + "px; z-index:-1;' align='right' onclick ='FillProperties(this)'  iswrap='" + isWrap + "' controlid='4' controltype='basic' dependency='False' isrequired='" + isRequired + "' ismanageable='False' prewrap='" + preWrap + "' postwrap='" + postWrap + "' ispostback='False' IsHide='" + IsHide + "'><tr style='width:50px'><td style='white-space:nowrap;'>" + title + "</td>";
                            for (int listItemCount = 0; listItemCount < xmlNode.ChildNodes[20].ChildNodes.Count; listItemCount++)
                            {
                                listItemCount = Convert.ToInt32(xmlNode.ChildNodes[20].ChildNodes[listItemCount].Attributes["Id"].Value);//+ title 
                                DesignDiv += "<td style='width:150px; cursor:hand;white-space:nowrap; vertical-align:top' align='right'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + listItemCount.ToString() + "<input id='cbl_" + checkBoxCount + "CheckBox'  title='" + listItemCount.ToString() + "' type='checkbox'  name='" + title + "' repeatdirection='horizontal' repeatcolumns='1' /></td>";
                                if (listItemCount == 4 * (resultcount + 1) && resultcount != resultheight)
                                {
                                    DesignDiv += "</tr><tr style='width:50px'> <td style='white-space: nowrap;'></td>";
                                    resultcount = resultcount + 1;
                                }
                            }
                            DesignDiv += "</tr></table>";
                            ViewBag.DesignDiv = DesignDiv;
                        }
                        if (xmlNode.Name == "RadioButtonList")
                        {
                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;


                            if (fieldId.Replace("rbl_", "").Replace("RadioButton", "").ToString() != "")
                            {
                                radioButtonCount = Convert.ToInt32(fieldId.Replace("rbl_", "").Replace("RadioButton", "").ToString());
                            }
                            else
                            {
                                radioButtonCount = 0;
                            }


                            xpos = xmlNode.ChildNodes[5].InnerText;
                            ypos = xmlNode.ChildNodes[6].InnerText;
                            width = xmlNode.ChildNodes[7].InnerText;
                            isRequired = xmlNode.ChildNodes[8].InnerText;
                            isWrap = xmlNode.ChildNodes[13].InnerText;
                            preWrap = xmlNode.ChildNodes[14].InnerText;
                            postWrap = xmlNode.ChildNodes[15].InnerText;
                            if (xmlNode.ChildNodes[22] != null)
                            {
                                IsHide = xmlNode.ChildNodes[22].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }

                            TempData["radioButtonCountHidden"] = radioButtonCount.ToString();
                            TempData.Keep();

                            int resultheight = 0;
                            int resultmod = 0;
                            resultheight = xmlNode.ChildNodes[20].ChildNodes.Count / 5;
                            resultmod = xmlNode.ChildNodes[20].ChildNodes.Count % 5;
                            if (resultheight < 1)
                            {
                                resultheight = 1;
                            }
                            if (resultmod > 0)
                            {
                                resultheight = resultheight + 1;
                            }
                            int resultcount = 0;
                            var DesignDiv = "";
                            DesignDiv += "<table id='rbl_" + radioButtonCount + "RadioButton' title='" + title + "' type='RadioButtonList' class='drag' style='position:absolute;border:dashed 4px #afafaf;background-color:White; width:200px; top:" + ypos + "px; left:" + xpos + "px; z-index:-1;' align='right' onclick ='FillProperties(this)'  iswrap='" + isWrap + "' controlid='4' controltype='basic' dependency='False' isrequired='" + isRequired + "' ismanageable='False' prewrap='" + preWrap + "' postwrap='" + postWrap + "' ispostback='False' IsHide='" + IsHide + "'><tr style='width:50px'><td style='white-space:nowrap;'>" + title + "</td>";

                            for (int listItemCount = 0; listItemCount < xmlNode.ChildNodes[20].ChildNodes.Count; listItemCount++)
                            {
                                listItemCount = Convert.ToInt32(xmlNode.ChildNodes[20].ChildNodes[listItemCount].Attributes["Id"].Value);//title +
                                DesignDiv += "<td style='width:150px; cursor:hand;white-space:nowrap; vertical-align:top' align='right'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + listItemCount.ToString() + "<input id='rbl_" + radioButtonCount + "RadioButton'  title='" + listItemCount.ToString() + "' type='radio'  name='" + title + "' repeatdirection='horizontal' repeatcolumns='1' /></td>";
                                if (listItemCount == 4 * (resultcount + 1) && resultcount != resultheight)
                                {
                                    DesignDiv += "</tr><tr style='width:50px'> <td style='white-space: nowrap;'></td>";
                                    resultcount = resultcount + 1;
                                }
                            }

                            DesignDiv += "</tr></table>";
                            ViewBag.DesignDiv = DesignDiv;
                        }
                        if (xmlNode.Name == "Label")
                        {
                            title = xmlNode.ChildNodes[3].InnerText;
                            controlId = xmlNode.ChildNodes[0].InnerText;
                            controlType = xmlNode.ChildNodes[1].InnerText;
                            fieldId = xmlNode.ChildNodes[2].InnerText;
                            xpos = xmlNode.ChildNodes[4].InnerText;
                            ypos = xmlNode.ChildNodes[5].InnerText;
                            width = xmlNode.ChildNodes[6].InnerText;
                            isWrap = xmlNode.ChildNodes[8].InnerText;
                            preWrap = xmlNode.ChildNodes[9].InnerText;
                            postWrap = xmlNode.ChildNodes[10].InnerText;

                            if (fieldId.Replace("lbl_", "").Replace("Label", "").ToString() != "")
                            {
                                labelCount = Convert.ToInt32(fieldId.Replace("lbl_", "").Replace("Label", "").ToString());
                            }
                            else
                            {
                                labelCount = 0;
                            }

                            if (xmlNode.ChildNodes[15] != null)
                            {
                                IsHide = xmlNode.ChildNodes[15].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }

                            TempData["labelCountHidden"] = labelCount.ToString();
                            TempData.Keep();

                            var DesignDiv = "";
                            DesignDiv += "<table id='lbl_" + labelCount + "LabelTable' title='" + title + "' type='Label' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; width:" + width + "px; top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)'    controlid='1' controltype='basic' dependency='False' isrequired='False' ismanageable='False' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False' IsHide='" + IsHide + "'>";
                            DesignDiv += "<tr ><td style='cursor:none;' align='center'>" + title + "</td>";
                            DesignDiv += "<td align='center'><label id='lbl_" + labelCount + "Label' title='" + title + "' style='z-index:-1;width:150px;cursor:none'></label></td></tr></table>";
                            ViewBag.DesignDiv = DesignDiv;

                        }
                        if (xmlNode.Name == "Button")
                        {

                        }
                        if (xmlNode.Name == "CC1EmployeesDropDown")
                        {
                            skillSet = "";
                            skillSetValues = "";

                            costCentre = "";
                            costCentreValues = "";

                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;


                            if (fieldId.Replace("cc_", "").Replace("DropDown", "").ToString() != "")
                            {
                                customCount = Convert.ToInt32(fieldId.Replace("cc_", "").Replace("DropDown", "").ToString());
                            }
                            else
                            {
                                customCount = 0;
                            }
                            if (xmlNode.ChildNodes[19] != null)
                            {
                                IsHide = xmlNode.ChildNodes[19].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }

                            xpos = xmlNode.ChildNodes[5].InnerText;
                            ypos = xmlNode.ChildNodes[6].InnerText;
                            width = xmlNode.ChildNodes[7].InnerText;
                            isRequired = xmlNode.ChildNodes[8].InnerText;
                            isWrap = xmlNode.ChildNodes[11].InnerText;
                            preWrap = xmlNode.ChildNodes[12].InnerText;
                            postWrap = xmlNode.ChildNodes[13].InnerText;

                            TempData["customCountHidden"] = customCount.ToString();
                            TempData.Keep();

                            for (int skillCount = 0; skillCount < xmlNode.ChildNodes[15].ChildNodes.Count; skillCount++)
                            {
                                skillSet += xmlNode.ChildNodes[15].ChildNodes[skillCount].InnerText + ",";
                                skillSetValues += xmlNode.ChildNodes[15].ChildNodes[skillCount].Attributes["Id"].Value + ",";
                            }

                            for (int costCentreCount = 0; costCentreCount < xmlNode.ChildNodes[16].ChildNodes.Count; costCentreCount++)
                            {
                                costCentre += xmlNode.ChildNodes[16].ChildNodes[costCentreCount].InnerText + ",";
                                costCentreValues += xmlNode.ChildNodes[16].ChildNodes[costCentreCount].Attributes["Id"].Value + ",";
                            }

                            var DesignDiv = "";
                            DesignDiv += "<table id='cc_" + customCount + "DropDownTable' title='" + title + "' type='EmpDropDown' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)'  controlid='4' controltype='custom' isrequired='" + isRequired + "' datasource='DB' skillset='" + skillSet + "' skillsetvalues='" + skillSetValues + "' costcentre='" + costCentre + "' costcentrevalues='" + costCentreValues + "' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False' IsHide='" + IsHide + "'>";
                            DesignDiv += "<tr ><td style='cursor:none' align='left'>" + title + "</td>";
                            DesignDiv += "<td align='right'><img id='cc_" + customCount + "DropDown' title='" + title + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/></td>";
                            DesignDiv += "<td><img id='ShowCustPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
                            DesignDiv += "cursor: hand; padding-left: 5px;' onclick='ShowCustProps(event, this);' align='left' /></td></tr></table>";
                            ViewBag.DesignDiv = DesignDiv;
                        }
                        if (xmlNode.Name == "CC3EmployeesDropDown")
                        {
                            skillSet = "";
                            skillSetValues = "";

                            costCentre = "";
                            costCentreValues = "";

                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;


                            if (fieldId.Replace("cc_", "").Replace("DropDown", "").ToString() != "")
                            {
                                customCount = Convert.ToInt32(fieldId.Replace("cc_", "").Replace("DropDown", "").ToString());

                            }
                            else
                            {
                                customCount = 0;
                            }
                            if (xmlNode.ChildNodes[19] != null)
                            {
                                IsHide = xmlNode.ChildNodes[19].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }

                            xpos = xmlNode.ChildNodes[5].InnerText;
                            ypos = xmlNode.ChildNodes[6].InnerText;
                            width = xmlNode.ChildNodes[7].InnerText;
                            isRequired = xmlNode.ChildNodes[8].InnerText;
                            isWrap = xmlNode.ChildNodes[11].InnerText;
                            preWrap = xmlNode.ChildNodes[12].InnerText;
                            postWrap = xmlNode.ChildNodes[13].InnerText;

                            TempData["customCountHidden"] = customCount.ToString();
                            TempData.Keep();

                            for (int skillCount = 0; skillCount < xmlNode.ChildNodes[16].ChildNodes.Count; skillCount++)
                            {
                                skillSet += xmlNode.ChildNodes[16].ChildNodes[skillCount].InnerText + ",";
                                skillSetValues += xmlNode.ChildNodes[16].ChildNodes[skillCount].Attributes["Id"].Value + ",";
                            }

                            for (int costCentreCount = 0; costCentreCount < xmlNode.ChildNodes[17].ChildNodes.Count; costCentreCount++)
                            {
                                costCentre += xmlNode.ChildNodes[17].ChildNodes[costCentreCount].InnerText + ",";
                                costCentreValues += xmlNode.ChildNodes[17].ChildNodes[costCentreCount].Attributes["Id"].Value + ",";
                            }

                            var DesignDiv = "";
                            DesignDiv += "<table id='cc_" + customCount + "DropDownTable' title='" + title + "' type='EmpManagerDropDown' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)'  controlid='4' controltype='custom' isrequired='" + isRequired + "' datasource='DB' skillset='" + skillSet + "' skillsetvalues='" + skillSetValues + "' costcentre='" + costCentre + "' costcentrevalues='" + costCentreValues + "' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False' IsHide='" + IsHide + "'>";
                            DesignDiv += "<tr ><td style='cursor:none' align='left'>" + title + "</td>";
                            DesignDiv += "<td align='right'><img id='cc_" + customCount + "DropDown' title='" + title + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/></td>";
                            DesignDiv += "<td><img id='ShowCustPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
                            DesignDiv += "cursor: hand; padding-left: 5px;' onclick='ShowCustProps(event, this);' align='left' /></td>";
                            DesignDiv += "</tr></table>";
                            ViewBag.DesignDiv = DesignDiv;
                        }
                        if (xmlNode.Name == "GlobalMControl")
                        {
                            skillSet = "";
                            skillSetValues = "";

                            costCentre = "";
                            costCentreValues = "";

                            globalCount++;

                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;
                            dependentId = xmlNode.ChildNodes[5].InnerText;
                            dependentCtrlId = xmlNode.ChildNodes[6].InnerText;

                            globalCountString = fieldId.Replace("gc_", "").Replace("DropDown", "").ToString();

                            TempData["globalCountHidden"] = globalCount.ToString();
                            TempData.Keep();

                            xpos = xmlNode.ChildNodes[7].InnerText;
                            ypos = xmlNode.ChildNodes[8].InnerText;
                            width = xmlNode.ChildNodes[9].InnerText;
                            isRequired = xmlNode.ChildNodes[10].InnerText;
                            isWrap = xmlNode.ChildNodes[13].InnerText;
                            preWrap = xmlNode.ChildNodes[14].InnerText;
                            postWrap = xmlNode.ChildNodes[15].InnerText;
                            if (xmlNode.ChildNodes[19] != null)
                            {
                                IsHide = xmlNode.ChildNodes[19].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }

                            for (int skillCount = 0; skillCount < xmlNode.ChildNodes[17].ChildNodes.Count; skillCount++)
                            {
                                skillSet += xmlNode.ChildNodes[17].ChildNodes[skillCount].InnerText + ",";
                                skillSetValues += xmlNode.ChildNodes[17].ChildNodes[skillCount].Attributes["Id"].Value + ",";
                            }

                            for (int costCentreCount = 0; costCentreCount < xmlNode.ChildNodes[18].ChildNodes.Count; costCentreCount++)
                            {
                                costCentre += xmlNode.ChildNodes[18].ChildNodes[costCentreCount].InnerText + ",";
                                costCentreValues += xmlNode.ChildNodes[18].ChildNodes[costCentreCount].Attributes["Id"].Value + ",";
                            }

                            var DesignDiv = "";
                            DesignDiv += "<table id='gc_" + globalCountString + "DropDownTable' title='" + title + "' type='GlobalMControl' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)'  iswrap='" + isWrap + "'  controltype='global' isrequired='" + isRequired + "' datasource='DB' skillset='" + skillSet + "' skillsetvalues='" + skillSetValues + "' costcentre='" + costCentre + "' costcentrevalues='" + costCentreValues + "' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False' dependentid='" + dependentId + "' controlid='" + controlId + "' depctrlid='" + dependentCtrlId + "' IsHide='" + IsHide + "'>";//
                            DesignDiv += "<tr ><td style='cursor:none' align='left'>" + title + "</td>";
                            DesignDiv += "<td align='right'><img id='gc_" + globalCountString + "DropDown' title='" + title + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/>&nbsp;&nbsp;";
                            DesignDiv += "<td><img id='" + dependentId + "' title='" + title + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/></td>";
                            DesignDiv += "</td>";
                            DesignDiv += "<td><img id='ShowGlobalPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
                            DesignDiv += "cursor: hand; padding-left: 5px;' onclick='ShowGlobalProps(event, this, " + controlId + ", CCArray);' align='left'/></td></tr></table>";
                            ViewBag.DesignDiv = DesignDiv;
                        }
                        if (xmlNode.Name == "GlobalSControl")
                        {
                            skillSet = "";
                            skillSetValues = "";

                            costCentre = "";
                            costCentreValues = "";

                            globalCount++;

                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;
                            dependentId = xmlNode.ChildNodes[5].InnerText;
                            //dependentCtrlId = xmlNode.ChildNodes[5].InnerText;

                            globalCountString = fieldId.Replace("gc_", "").Replace("DropDown", "").ToString();

                            TempData["globalCountHidden"] = globalCount.ToString();
                            TempData.Keep();

                            xpos = xmlNode.ChildNodes[6].InnerText;
                            ypos = xmlNode.ChildNodes[7].InnerText;
                            width = xmlNode.ChildNodes[8].InnerText;
                            isRequired = xmlNode.ChildNodes[9].InnerText;
                            isWrap = xmlNode.ChildNodes[12].InnerText;
                            preWrap = xmlNode.ChildNodes[13].InnerText;
                            postWrap = xmlNode.ChildNodes[14].InnerText;

                            for (int skillCount = 0; skillCount < xmlNode.ChildNodes[16].ChildNodes.Count; skillCount++)
                            {
                                skillSet += xmlNode.ChildNodes[16].ChildNodes[skillCount].InnerText + ",";
                                skillSetValues += xmlNode.ChildNodes[16].ChildNodes[skillCount].Attributes["Id"].Value + ",";
                            }

                            for (int costCentreCount = 0; costCentreCount < xmlNode.ChildNodes[17].ChildNodes.Count; costCentreCount++)
                            {
                                costCentre += xmlNode.ChildNodes[17].ChildNodes[costCentreCount].InnerText + ",";
                                costCentreValues += xmlNode.ChildNodes[17].ChildNodes[costCentreCount].Attributes["Id"].Value + ",";
                            }
                            if (xmlNode.ChildNodes[18] != null)
                            {
                                IsHide = xmlNode.ChildNodes[18].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }

                            var DesignDiv = "";
                            DesignDiv += "<table id='gc_" + globalCountString + "DropDownTable' title='" + title + "' type='GlobalSControl' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:" + ypos + "px;left:" + xpos + "px;' align='right' onclick ='FillProperties(this)'  controltype='global' isrequired='" + isRequired + "' datasource='DB' skillset='" + skillSet + "' skillsetvalues='" + skillSetValues + "' costcentre='" + costCentre + "' costcentrevalues='" + costCentreValues + "' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False' controlid='" + controlId + "' IsHide='" + IsHide + "'>";//
                            DesignDiv += "<tr ><td style='cursor:none' align='left'>" + title + "</td>";
                            DesignDiv += "<td align='right'><img id='gc_" + globalCountString + "DropDown' title='" + title + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/>&nbsp;&nbsp;";
                            DesignDiv += "<td><img id='ShowGlobalPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
                            DesignDiv += "cursor: hand; padding-left: 5px;' onclick='ShowGlobalProps(event, this, " + controlId + ", CCArray);' align='left' /></td></tr></table>";
                            ViewBag.DesignDiv = DesignDiv;
                        }
                    }

                }
                else
                {
                    TempData["FileModeHidden"] = "CREATEMODE";
                    TempData.Keep();
                    //dropDownCountHidden.Value = "0";
                    //listBoxCountHidden.Value = "0";
                    //radioButtonCountHidden.Value = "0";
                    //checkBoxCountHidden.Value = "0";
                    //labelCountHidden.Value = "0";
                    //textBoxCountHidden.Value = "0";
                    //customCountHidden.Value = "0";
                    //globalCountHidden.Value = "0";
                }

                return JavaScript("GetControl();");
                //ClientScript.RegisterStartupScript(this.GetType(), "script", "<script>javascript:GetControl();</script>");
            }
            catch (Exception ex)
            {

            }

            return View();
        }


        [NonAction]
        private void BindGlobalCostCentre()
        {
            string costCentreArray = "";

            try
            {
                DataSet ds = new DataSet();
                DesignManagement globalObj = new DesignManagement();
                ds = globalObj.GetGlobalCostCentre();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    costCentreArray += "\n var CCArray = new Array(" + ds.Tables[0].Rows.Count + ");\n";
                    for (int costCentreCount = 0; costCentreCount < ds.Tables[0].Rows.Count; costCentreCount++)
                    {
                        costCentreArray += "CCArray[" + costCentreCount + "] = new Array('" + ds.Tables[0].Rows[costCentreCount]["CostCentreID"].ToString() + "', '" + ds.Tables[0].Rows[costCentreCount]["CostCentre"].ToString() + "', '" + ds.Tables[0].Rows[costCentreCount]["ControlID"].ToString() + "');\n";
                    }

                    JavaScript("<script language='javascript'>" + costCentreArray + "</script>");
                    //RegisterClientScriptBlock("CostCentreArray", "\n<script language='javascript'>" + costCentreArray + "</script>\n");
                    costCentreArray = "";
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        [NonAction]
        private void BindGlobalSkillSet()
        {
            try
            {
                DataSet skillDataSet = new DataSet();
                string skillSetArray = "";

                DesignManagement desObj = new DesignManagement();
                skillDataSet = desObj.GetGlobalSkillSet();
                if (skillDataSet.Tables[0].Rows.Count > 0)
                {

                    skillSetArray += "\n var SSArray = new Array(" + skillDataSet.Tables[0].Rows.Count + ");\n";
                    for (int skillSetCount = 0; skillSetCount < skillDataSet.Tables[0].Rows.Count; skillSetCount++)
                    {
                        skillSetArray += "SSArray[" + skillSetCount + "] = new Array('" + skillDataSet.Tables[0].Rows[skillSetCount]["DepName"].ToString() + "', '" + skillDataSet.Tables[0].Rows[skillSetCount]["DepID"].ToString() + "', '" + skillDataSet.Tables[0].Rows[skillSetCount]["ControlID"].ToString() + "', '" + skillDataSet.Tables[0].Rows[skillSetCount]["CostCentreID"].ToString() + "');\n";
                    }

                    JavaScript("<script language='javascript'>" + skillSetArray + "</script>");
                    //RegisterClientScriptBlock("SkillSetArray", "\n<script language='javascript'>" + skillSetArray + "</script>\n");
                    skillSetArray = "";
                }

            }
            catch (Exception ex)
            {

            }
        }

        [HttpPost]
        public ActionResult Submit()
        {
            return View();
        }

        public ActionResult BindCustomCostCentre()
        {
            DataSet ds;
            string js = string.Empty;
            DesignManagement desObj = new DesignManagement();
            ds = desObj.GetCustomCostCentre();
            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindCustomSkillSet(string costCentreList)
        {
            DataSet ds;
            string js = string.Empty;
            DesignManagement desObj = new DesignManagement();
            ds = desObj.GetCustomSkillSet(costCentreList);
            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindGlobalControls()
        {
            string dependentIDS = "";
            StringBuilder JsonString = new StringBuilder();

            DataSet globalChildControlDataSet = new DataSet();
            globalChildControlDataSet = DesignManagement.GetGlobalChildControls();

            for (int count = 0; count < globalChildControlDataSet.Tables[0].Rows.Count; count++)
            {
                dependentIDS += globalChildControlDataSet.Tables[0].Rows[count]["DependentControlID"].ToString() + ",";
            }

            JsonString.Append("[");

            if (dependentIDS != "")
            {
                DataSet globalMControlDataSet = new DataSet();
                globalMControlDataSet = DesignManagement.GetGlobalMControls(dependentIDS);

                for (int controlCount = 0; controlCount < globalMControlDataSet.Tables[0].Rows.Count; controlCount++)
                {
                    string value = "";
                    string depctrlid = "";

                    for (int globCount = 0; globCount < globalChildControlDataSet.Tables[0].Rows.Count; globCount++)
                    {
                        if (globalChildControlDataSet.Tables[0].Rows[globCount]["DependentControlID"].ToString() == globalMControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString())
                        {
                            value = "" + globalMControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "/" + globalChildControlDataSet.Tables[0].Rows[globCount]["ChildControlName"].ToString() + "";
                            depctrlid = globalChildControlDataSet.Tables[0].Rows[globCount]["ControlID"].ToString();
                        }
                    }

                    JsonString.Append("{\"onclick\" : \"CreateMultipleGlobal(this)\", \"title\" : \"Add " + value + "\", \"ctrlid\" : \"" + globalMControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString() + "\", \"depctrlid\" : \"" + depctrlid + "\", \"value\" : \"" + value + "\"},");

                }
            }

            DataSet globalSControlDataSet = new DataSet();
            globalSControlDataSet = DesignManagement.GetGlobalSControls();

            if (globalSControlDataSet.Tables.Count > 0)
            {
                for (int controlCount = 0; controlCount < globalSControlDataSet.Tables[0].Rows.Count; controlCount++)
                {
                    JsonString.Append("{\"onclick\" : \"CreateSingleGlobal(this)\", \"title\" : \"Add " + globalSControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "\", \"ctrlid\" : \"" + globalSControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString() + "\", \"depctrlid\" : \"\", \"value\" : \"" + globalSControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "\"},");

                }
            }

            if (JsonString.Length > 1)
                JsonString.Length--;

            JsonString.Append("]");

            return Json(JsonString.ToString(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindEmployeeList(string CostCentres, string SkillSets)
        {
            DataSet ds = new DataSet();
            string js = string.Empty;
            Forms objForms = new Forms();
            ds = objForms.SelectEmployeesForCustomControl(ds, CostCentres, SkillSets);
            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetEmployeeManager(int empId)
        {
            string name = string.Empty;
            name = DataManagement.GetEmployeeManager(empId);

            return Json(name, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindParentGlobarControl(int ControlId, string SkillSets)
        {
            DataSet ds = new DataSet();
            string js = string.Empty;
            EvoSuperAdminGlobalControls objGlobalControl = new EvoSuperAdminGlobalControls();
            objGlobalControl.ControlId = ControlId;
            objGlobalControl.SkillSetId = SkillSets;
            ds = objGlobalControl.GetSelectedControlData();
            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindChildGlobarControl(int CostCentreId, string SkillSets, int ControlId)
        {
            DataSet ds = new DataSet();
            string js = string.Empty;
            EvoSuperAdminGlobalControls objGlobalControl = new EvoSuperAdminGlobalControls();
            objGlobalControl.CostCentreId = CostCentreId;
            objGlobalControl.SkillSetId = SkillSets;
            objGlobalControl.DependentControlId = ControlId;
            ds = objGlobalControl.GetChildGlobalControlData();
            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindParentGlobarControlData(string CostCentres, string SkillSets, int ControlId)
        {
            DataSet ds = new DataSet();
            string js = string.Empty;
            Forms objForms = new Forms();
            objForms.CostCentreID = CostCentres;
            objForms.SkillSetID = SkillSets;
            objForms.ControlID = ControlId;
            ds = objForms.SelectGlobalControlData(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindChildGlobarControlData(string CostCentres, string SkillSets, int ControlId, int DependentId)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            string js = string.Empty;
            Forms objForms = new Forms();
            objForms.CostCentreID = CostCentres;
            objForms.SkillSetID = SkillSets;
            objForms.ControlID = ControlId;
            ds = objForms.SelectGlobalControlData(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DataRow[] orderRows = ds.Tables[0].Select("DependentId=" + DependentId);
                var json = JsonConvert.SerializeObject(ds.Tables[0].Select("DependentId=" + DependentId));
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

    }
}