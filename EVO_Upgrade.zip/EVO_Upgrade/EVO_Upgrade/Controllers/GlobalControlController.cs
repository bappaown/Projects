﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using System.Data.SqlClient;
using EVO_Upgrade.Filter;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class GlobalControlController : Controller
    {
        EvoSuperAdminGlobalControls objGlobalControl = new EvoSuperAdminGlobalControls();
        private static int currentPageNumber = 1;
        private static int PAGE_SIZE = 10;

        // GET: GlobalControl
        public ActionResult Index()
        {
            try
            {
                ViewBag.GlobalTable = FillGrid(currentPageNumber, PAGE_SIZE);
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("GlobalControl - Load: " + ex.Message);
            }
            return View();
        }

        public ActionResult FillGrid(int currentPage, int size)
        {
            string js = string.Empty;
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();

            try
            {
                ds = objGlobalControl.GetGlobalControls();

                if (ds.Tables[0].Rows.Count > 0)
                {
                    dt = ds.Tables[0].Clone();
                    int RowNumber = (currentPage - 1) * size;
                    int PageNumber = (ds.Tables[0].Rows.Count > (currentPage * size)) ? (currentPage * size) : ds.Tables[0].Rows.Count;

                    for (int i = RowNumber; i < PageNumber; i++)
                    {
                        dt.ImportRow(ds.Tables[0].Rows[i]);
                    }

                    js = JsonConvert.SerializeObject(dt);
                }

                double totalRows = ds.Tables[0].Rows.Count;
                int totalPages = (int)Math.Ceiling(totalRows / PAGE_SIZE);

                ViewBag.currentPage = currentPage;
                ViewBag.totalPage = totalPages;
            }
            catch (Exception ex)
            {
                TempData["error"] = "FillGrid: " + ex.Message;
                ErrorLogger.logger.Error("GlobalControl - FillGrid: " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult PagingGrid(int currentPage, int size)
        {
            currentPageNumber = currentPage;
            PAGE_SIZE = size;

            return RedirectToAction("Index");
        }

        public ActionResult FilterData(string ControlType)
        {

            string js = string.Empty;
            DataSet ds = new DataSet();

            objGlobalControl.ControlType = ControlType;
            ds = objGlobalControl.GetParentGlobalControls();

            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Submit(GlobalControl model)
        {
            EvoGeneral objEvoGeneral = new EvoGeneral();
            try
            {
                if (ModelState.IsValid)
                {
                    objGlobalControl.ControlName = model.Name.Trim().Replace(" ", "_");
                    objGlobalControl.ControlType = model.Type;
                    objGlobalControl.DependentControlId = model.Parent;
                    objGlobalControl.UserLogin = objEvoGeneral.userName;

                    if (objGlobalControl.InsertGlobalControl())
                    {
                        TempData["error"] = "The control added successfully.";
                    }
                    else
                    {
                        TempData["error"] = "Control already exists.";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Could not add control. " + ex.Message;
                ErrorLogger.logger.Error("GlobalControl - Could not add control. " + ex.Message);
            }

            return RedirectToAction("Index");
        }

        public ActionResult Delete(int ControlId)
        {
            try
            {
                objGlobalControl.ControlId = ControlId;

                if (objGlobalControl.DeleteGlobalControl())
                {
                    TempData["error"] = "The record and its dependent control (if any) has been deleted successfully.";
                }
                else
                {
                    TempData["error"] = "Could not delete record.";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Could not delete record. " + ex.Message;
                ErrorLogger.logger.Error("GlobalControl - Could not delete record. " + ex.Message);
            }

            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Update(int ControlId, string ControlName)
        {
            try
            {
                objGlobalControl.ControlId = ControlId;
                objGlobalControl.ControlName = ControlName.Trim().Replace(" ", "_");

                if (objGlobalControl.UpdateGlobalControl())
                {
                    TempData["error"] = "The record has been updated successfully";
                }
                else
                {
                    TempData["error"] = "Control Name already exists.";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Could not Update data. " + ex.Message;
                ErrorLogger.logger.Error("GlobalControl - Could not Update data. " + ex.Message);
            }

            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }
    }
}