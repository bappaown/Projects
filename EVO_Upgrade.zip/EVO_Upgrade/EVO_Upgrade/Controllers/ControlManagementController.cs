﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using System.Data.SqlClient;
using EVO_Upgrade.Filter;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class ControlManagementController : Controller
    {
        EvoAdminUsersRights ObjUserRights = new EvoAdminUsersRights();
        Forms forms = new Forms();
        private static string FormId = string.Empty;
        private static string VersionId = string.Empty;
        private static string Form = string.Empty;
        private static string CategoryId = string.Empty;

        // GET: ControlManagement
        public ActionResult Index()
        {
            try
            {
                if (!IsValidUser())
                {
                    return RedirectToAction("Unauthorized", "Home");
                }

                if (CategoryId != "4")
                {
                    GetHiddenControl();
                    ViewBag.VisibleControlList = GetAssignHiddenControl(0);
                }
                else
                {
                    ViewBag.HiddenList = new List<object>();
                    ViewBag.ControlList = new List<object>();
                    ViewBag.VisibleControlList = Json(string.Empty, JsonRequestBehavior.AllowGet);
                }

                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("ControlManagement - Load: " + ex.Message);
            }

            return View();
        }

        public ActionResult EditMode(string FormID, string VersionID, string FormName, string CategoryID)
        {
            FormId = FormID;
            VersionId = VersionID;
            Form = FormName;
            CategoryId = CategoryID;

            return RedirectToAction("Index");
        }

        [NonAction]
        private bool IsValidUser()
        {
            Boolean IsValid = false;
            try
            {
                EvoGeneral objEvoGeneral = new EvoGeneral();
                string NTName = objEvoGeneral.userName;
                ObjUserRights.UserID = objEvoGeneral.RetrieveUserID(NTName);
                ObjUserRights.FormId = int.Parse(FormId);
                ObjUserRights.VersionId = int.Parse(VersionId);
                IsValid = ObjUserRights.ValidateAdminManageUser();
            }
            catch (Exception ex)
            {
                TempData["error"] = "No data found for this loginid. " + ex.Message;
                ErrorLogger.logger.Error("ControlManagement - No data found for this loginid. " + ex.Message);
            }

            return IsValid;
        }

        [NonAction]
        private void GetHiddenControl()
        {
            try
            {
                List<object> hiddenlist = new List<object>();
                List<object> controllist = new List<object>();
                string result = GetFormData();
                if (result != null && result != "")
                {
                    var js = Newtonsoft.Json.Linq.JArray.Parse(result);
                    foreach (var value in js)
                    {
                        var data = (Newtonsoft.Json.Linq.JObject)value;
                        string name = Convert.ToString(data.SelectToken("label"));
                        string type = Convert.ToString(data.SelectToken("field_type"));
                        Boolean hide = Convert.ToBoolean(data.SelectToken("hidden"));

                        if (hide)
                        {
                            hiddenlist.Add(new { controlname = name, controltype = type });
                        }
                        else
                        {
                            if (type == "dropdown" || type == "listbox" || type == "radio" || type == "checkboxes")
                            {
                                controllist.Add(new { controlname = name, controltype = type });
                            }
                        }
                    }
                }

                ViewBag.HiddenList = hiddenlist;
                ViewBag.ControlList = controllist;
            }
            catch (Exception ex)
            {
                TempData["error"] = "Load Control: " + ex.Message;
                ErrorLogger.logger.Error("ControlManagement - Load Control: " + ex.Message);
            }
        }

        public ActionResult GetAssignHiddenControl(int forparent)
        {
            Forms forms = new Forms();
            DataSet ds = new DataSet();
            string js = string.Empty;
            ds = forms.GetVisibleToHiddenControlValues(Convert.ToInt16(FormId), Convert.ToInt16(VersionId), forparent);
            if (ds != null && ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        [NonAction]
        private string GetFormData()
        {
            DataSet ds;
            string result = string.Empty;
            try
            {
                ObjUserRights.FormId = int.Parse(FormId);
                ObjUserRights.VersionId = int.Parse(VersionId);
                ds = ObjUserRights.GetXMLFileName();

                if (ds.Tables[0].Rows.Count > 0)
                {
                    //string file = Server.MapPath("../JSON/" + ds.Tables[0].Rows[0]["XMLFileName"].ToString());
                    string file = Server.MapPath("..\\JSON\\" + ds.Tables[0].Rows[0]["XMLFileName"].ToString());
                    if (System.IO.File.Exists(file))
                    {
                        result = System.IO.File.ReadAllText(file);
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Could not find the JSON file. " + ex.Message;
                ErrorLogger.logger.Error("ControlManagement - Could not find the JSON file. " + ex.Message);
            }

            return result;
        }

        public ActionResult GetFormControlData(string controlname, string controltype)
        {
            string js = string.Empty;
            string result = GetFormData();

            if (result != null && result != "")
            {
                var formData = Newtonsoft.Json.Linq.JArray.Parse(result);
                foreach (var value in formData)
                {
                    var data = (Newtonsoft.Json.Linq.JObject)value;
                    string name = Convert.ToString(data.SelectToken("label"));
                    string type = Convert.ToString(data.SelectToken("field_type"));

                    if (name == controlname && type == controltype)
                    {
                        var options = data.SelectToken("field_options").SelectToken("options");
                        js = JsonConvert.SerializeObject(options);
                        break;
                    }
                }
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetControlDetails()
        {
            var js = new { HiddenData = GetAssignHiddenControl(0), HiddenGrid = GetAssignHiddenControl(1) };

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetRemainingControl()
        {
            string data = string.Empty;
            string value = string.Empty;
            DataSet objDataSet = new DataSet();
            objDataSet = forms.GetControlsforEncrypt(Convert.ToInt32(FormId), Convert.ToInt32(VersionId));

            if (objDataSet != null)
            {
                if (objDataSet.Tables[0].Rows.Count > 0)
                {
                    data = JsonConvert.SerializeObject(objDataSet.Tables[0]);
                }
                if (objDataSet.Tables[1].Rows.Count > 0)
                {
                    value = JsonConvert.SerializeObject(objDataSet.Tables[1]);
                }
            }
            var js = new { from = data, to = value };

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Delete(int CMID)
        {
            if (CMID > 0)
            {
                Forms forms = new Forms();
                forms.DeleteControlMgm(CMID);
            }

            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Submit(ControlManagement model, FormCollection collection)
        {
            try
            {
                EvoGeneral objEvoGeneral = new EvoGeneral();
                long AddedBy = objEvoGeneral.RetrieveUserID(objEvoGeneral.userName);
                string buttonName = (collection["Submit"] == null) ? "Submit" : collection["Submit"].ToString();
                if (buttonName == "Submit")
                {
                    DataSet objDataSet = new DataSet();
                    forms.FormID = Convert.ToInt32(FormId);
                    forms.VersionID = Convert.ToInt32(VersionId);
                    objDataSet = forms.GetFormsFieldsWithVersions(objDataSet, false);

                    if (objDataSet != null)
                    {
                        string controlname = collection["hdnSelectedControl"].ToString().Split('|')[0];
                        string controltype = collection["hdnSelectedControl"].ToString().Split('|')[1];
                        string controlvalue = collection["hdnControlValue"];
                        string ParentId = (collection["HiddenData"] == null) ? "0" : collection["HiddenData"].ToString();

                        foreach (string value in controlvalue.Split(','))
                        {
                            string FieldNameValue = string.Empty;
                            string ToShowControl = string.Empty;

                            for (int i = 0; i < objDataSet.Tables[0].Rows.Count; i++)
                            {
                                if (objDataSet.Tables[0].Rows[i]["Alias"].ToString() == controlname && objDataSet.Tables[0].Rows[i]["FieldDisplayType"].ToString() == controltype)
                                {
                                    FieldNameValue = objDataSet.Tables[0].Rows[i]["FieldName"].ToString() + "" + objDataSet.Tables[0].Rows[i]["FieldDisplayType"].ToString() + "|" + value;
                                }

                                foreach (var hidden in collection["hdnHiddenControl"].ToString().Split(','))
                                {
                                    if (objDataSet.Tables[0].Rows[i]["Alias"].ToString() == hidden.Split('|')[0] && objDataSet.Tables[0].Rows[i]["FieldDisplayType"].ToString() == hidden.Split('|')[1])
                                    {
                                        ToShowControl += objDataSet.Tables[0].Rows[i]["FieldName"].ToString() + "" + objDataSet.Tables[0].Rows[i]["FieldDisplayType"].ToString() + ",";
                                    }
                                }
                            }

                            if (FieldNameValue != "" && ToShowControl != "")
                            {
                                forms.InsertControlMgm(FieldNameValue, ToShowControl.TrimEnd(','), VersionId, FormId, ParentId, AddedBy.ToString());
                                TempData["error"] = "Assignment saved successfully.";
                            }
                        }
                    }
                }
                else
                {
                    string items = (collection["to"] == null) ? "" : collection["to"].ToString();
                    bool isStatus = forms.AddEncryptControlDetails(Convert.ToInt32(FormId), Convert.ToInt32(VersionId), items, AddedBy.ToString());
                    TempData["error"] = "Assignment saved successfully.";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Something went wrong. " + ex.Message;
                ErrorLogger.logger.Error("ControlManagement - Something went wrong. " + ex.Message);
            }

            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Submit()
        {
            return RedirectToAction("EditMode", "RightsManagement", new { FormID = FormId, VersionID = VersionId, FormName = Form, CategoryID = CategoryId });
        }
    }
}