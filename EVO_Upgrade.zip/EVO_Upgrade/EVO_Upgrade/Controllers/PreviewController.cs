﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using System.Data.SqlClient;
using EVO_Upgrade.Filter;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class PreviewController : Controller
    {
        EvoAdminUsersRights ObjUserRights = new EvoAdminUsersRights();
        private static string FormId = string.Empty;
        private static string VersionId = string.Empty;
        private static string Form = string.Empty;
        private static string CategoryId = string.Empty;

        // GET: Preview
        public ActionResult Index()
        {
            try
            {
                ViewBag.FormName = Form;

                DataSet ds = DesignManagement.GetFormLayoutConfiguration(Convert.ToInt32(FormId), Convert.ToInt32(VersionId));
                if (ds.Tables[0].Rows.Count > 0)
                {
                    string style = "";
                    style += "font-family:" + ds.Tables[0].Rows[0]["FontFamily"].ToString() + ";";
                    style += "font-size:" + ds.Tables[0].Rows[0]["FontSize"].ToString() + ";";
                    style += "color:" + ds.Tables[0].Rows[0]["FontColor"].ToString() + ";";
                    style += (ds.Tables[0].Rows[0]["BackgroundImage"].ToString() != "") ? "background:url(../Images/theme/" + ds.Tables[0].Rows[0]["BackgroundImage"].ToString() + ") repeat center;" : "background:" + ds.Tables[0].Rows[0]["BackgroundColor"].ToString();
                    ViewBag.fontfamily = ds.Tables[0].Rows[0]["FontFamily"].ToString();
                    ViewBag.fontsize = ds.Tables[0].Rows[0]["FontSize"].ToString();
                    ViewBag.StyleCss = style;
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.logger.Error("Preview - Load: " + ex.Message);
            }

            return View();
        }

        public ActionResult EditMode(string FormID, string VersionID, string FormName, string CategoryID)
        {
            FormId = FormID;
            VersionId = VersionID;
            Form = FormName;
            CategoryId = CategoryID;

            return RedirectToAction("Index");
        }

        public ActionResult GetFormData()
        {
            DataSet ds;
            string result = string.Empty;
            try
            {
                ObjUserRights.FormId = int.Parse(FormId);
                ObjUserRights.VersionId = int.Parse(VersionId);
                ds = ObjUserRights.GetXMLFileName();

                if (ds.Tables[0].Rows.Count > 0)
                {
                    //string file = Server.MapPath("../JSON/" + ds.Tables[0].Rows[0]["XMLFileName"].ToString());
                    string file = Server.MapPath("..\\JSON\\" + ds.Tables[0].Rows[0]["XMLFileName"].ToString());
                    if (System.IO.File.Exists(file))
                    {
                        result = System.IO.File.ReadAllText(file);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.logger.Error("Preview - Could not found the JSON file. " + ex.Message);
            }

            return Json(result, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindEmployeeList(string CostCentres, string SkillSets)
        {
            DataSet ds = new DataSet();
            string js = string.Empty;
            Forms objForms = new Forms();
            ds = objForms.SelectEmployeesForCustomControl(ds, CostCentres, SkillSets);
            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetEmployeeManager(int empId)
        {
            string name = string.Empty;
            name = DataManagement.GetEmployeeManager(empId);

            return Json(name, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindParentGlobarControl(int ControlId, string SkillSets)
        {
            DataSet ds = new DataSet();
            string js = string.Empty;
            EvoSuperAdminGlobalControls objGlobalControl = new EvoSuperAdminGlobalControls();
            objGlobalControl.ControlId = ControlId;
            objGlobalControl.SkillSetId = SkillSets;
            ds = objGlobalControl.GetSelectedControlData();
            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindChildGlobarControl(int CostCentreId, string SkillSets, int ControlId)
        {
            DataSet ds = new DataSet();
            string js = string.Empty;
            EvoSuperAdminGlobalControls objGlobalControl = new EvoSuperAdminGlobalControls();
            objGlobalControl.CostCentreId = CostCentreId;
            objGlobalControl.SkillSetId = SkillSets;
            objGlobalControl.DependentControlId = ControlId;
            ds = objGlobalControl.GetChildGlobalControlData();
            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindParentGlobarControlData(string CostCentres, string SkillSets, int ControlId)
        {
            DataSet ds = new DataSet();
            string js = string.Empty;
            Forms objForms = new Forms();
            objForms.CostCentreID = CostCentres;
            objForms.SkillSetID = SkillSets;
            objForms.ControlID = ControlId;
            ds = objForms.SelectGlobalControlData(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindChildGlobarControlData(string CostCentres, string SkillSets, int ControlId, int DependentId)
        {
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            string js = string.Empty;
            Forms objForms = new Forms();
            objForms.CostCentreID = CostCentres;
            objForms.SkillSetID = SkillSets;
            objForms.ControlID = ControlId;
            ds = objForms.SelectGlobalControlData(ds);
            if (ds.Tables[0].Rows.Count > 0)
            {
                DataRow[] orderRows = ds.Tables[0].Select("DependentId=" + DependentId);
                var json = JsonConvert.SerializeObject(ds.Tables[0].Select("DependentId=" + DependentId));
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindGlobalControls()
        {
            string dependentIDS = "";
            StringBuilder JsonString = new StringBuilder();

            DataSet globalChildControlDataSet = new DataSet();
            globalChildControlDataSet = DesignManagement.GetGlobalChildControls();

            for (int count = 0; count < globalChildControlDataSet.Tables[0].Rows.Count; count++)
            {
                dependentIDS += globalChildControlDataSet.Tables[0].Rows[count]["DependentControlID"].ToString() + ",";
            }

            JsonString.Append("[");

            if (dependentIDS != "")
            {
                DataSet globalMControlDataSet = new DataSet();
                globalMControlDataSet = DesignManagement.GetGlobalMControls(dependentIDS);

                for (int controlCount = 0; controlCount < globalMControlDataSet.Tables[0].Rows.Count; controlCount++)
                {
                    string value = "";
                    string depctrlid = "";

                    for (int globCount = 0; globCount < globalChildControlDataSet.Tables[0].Rows.Count; globCount++)
                    {
                        if (globalChildControlDataSet.Tables[0].Rows[globCount]["DependentControlID"].ToString() == globalMControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString())
                        {
                            value = "" + globalMControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "/" + globalChildControlDataSet.Tables[0].Rows[globCount]["ChildControlName"].ToString() + "";
                            depctrlid = globalChildControlDataSet.Tables[0].Rows[globCount]["ControlID"].ToString();
                        }
                    }

                    JsonString.Append("{\"onclick\" : \"CreateMultipleGlobal(this)\", \"title\" : \"Add " + value + "\", \"ctrlid\" : \"" + globalMControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString() + "\", \"depctrlid\" : \"" + depctrlid + "\", \"value\" : \"" + value + "\"},");

                }
            }

            DataSet globalSControlDataSet = new DataSet();
            globalSControlDataSet = DesignManagement.GetGlobalSControls();

            if (globalSControlDataSet.Tables.Count > 0)
            {
                for (int controlCount = 0; controlCount < globalSControlDataSet.Tables[0].Rows.Count; controlCount++)
                {
                    JsonString.Append("{\"onclick\" : \"CreateSingleGlobal(this)\", \"title\" : \"Add " + globalSControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "\", \"ctrlid\" : \"" + globalSControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString() + "\", \"depctrlid\" : \"\", \"value\" : \"" + globalSControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "\"},");

                }
            }

            if (JsonString.Length > 1)
                JsonString.Length--;

            JsonString.Append("]");

            return Json(JsonString.ToString(), JsonRequestBehavior.AllowGet);
        }

    }
}