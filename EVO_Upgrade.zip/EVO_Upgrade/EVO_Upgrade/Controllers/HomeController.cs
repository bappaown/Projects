﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using System.Data.SqlClient;
using EVO_Upgrade.Filter;
using Microsoft.AspNet.Identity;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            if (Request.Cookies["EVO"] == null)
            {
                GetLogin();
            }

            return View();
        }

        public ActionResult GetLogin()
        {
            try
            {
                DataSet dsAuthTypes = UserAuthDataStore.GetAuthenticationTypes();
                if (dsAuthTypes != null && dsAuthTypes.Tables.Count > 0)
                {
                    int AuthenticationType = Convert.ToInt32(dsAuthTypes.Tables[0].Rows[0]["Id"]);
                    if (AuthenticationType == 1)
                    {
                        return RedirectToAction("UserAuthentication");
                    }
                    else if (AuthenticationType == 2) // CEAG
                    {
                        H3GS.Web.Security.PassportAuthentication.SignIn();
                        HttpCookie userCredentials = new HttpCookie("EVO");
                        userCredentials["AuthenticationType"] = dsAuthTypes.Tables[0].Rows[0]["Id"].ToString();
                        userCredentials["CurrentUserName"] = H3GS.Web.Security.PassportIdentity.Current.Employee.LoginId;
                        userCredentials["userName"] = H3GS.Web.Security.PassportIdentity.Current.Employee.LoginId;
                        userCredentials["userType"] = "";
                        userCredentials["userEmailID"] = H3GS.Web.Security.PassportIdentity.Current.Employee.EmailAddress;
                        userCredentials["userFullName"] = H3GS.Web.Security.PassportIdentity.Current.Employee.FullName;
                        userCredentials["userDesignation"] = H3GS.Web.Security.PassportIdentity.Current.Employee.Designation;
                        userCredentials["userEmployeeId"] = H3GS.Web.Security.PassportIdentity.Current.Employee.EmployeeId.ToString();
                        //for departement name and id
                        userCredentials["userDeptID"] = H3GS.Web.Security.PassportIdentity.Current.Employee.DepartmentId.ToString();
                        userCredentials["userDeptName"] = H3GS.Web.Security.PassportIdentity.Current.Employee.Department;
                        //for CID - departement name and id
                        userCredentials["userCIDDeptID"] = H3GS.Web.Security.PassportIdentity.Current.Employee.DepartmentId.ToString();
                        userCredentials["userCIDDeptName"] = H3GS.Web.Security.PassportIdentity.Current.Employee.Department;
                        //Location
                        userCredentials["userLocation"] = "";
                        //Rep man
                        userCredentials["userBoss1ID"] = H3GS.Web.Security.PassportIdentity.Current.Employee.BossId.ToString();
                        userCredentials["userBoss1Name"] = "";
                        //Rev Man
                        userCredentials["userBoss2Id"] = "";
                        userCredentials["userBoss2Name"] = "";

                        if (!HttpContext.Response.IsRequestBeingRedirected)
                            Response.AppendCookie(userCredentials);
                    }
                    else if (AuthenticationType == 3)
                    {
                        return RedirectToAction("Index", "Login");
                    }
                }
            }
            catch (Exception ex)
            {
                return base.File(Server.MapPath("../Images/not_autho.jpg"), "image/jpeg");
            }

            return new EmptyResult();
        }

        public ActionResult UserAuthentication()
        {
            try
            {
                int AuthenticationType = 1;
                string CurrentUserName = (User.Identity.GetUserName() != null) ? User.Identity.GetUserName() : System.Security.Principal.WindowsIdentity.GetCurrent().Name.ToString();
                CurrentUserName = CurrentUserName.ToUpper().Replace(ConfigurationSettings.AppSettings["DomainName"].ToString().ToUpper(), "");
                DataSet ds = UserAuthDataStore.AuthenticateUser(CurrentUserName);

                if (ds != null)
                {
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            HttpCookie userCredentials = new HttpCookie("EVO");
                            userCredentials["AuthenticationType"] = AuthenticationType.ToString();
                            userCredentials["CurrentUserName"] = CurrentUserName;
                            userCredentials["userName"] = ds.Tables[0].Rows[0]["NTLogin"].ToString();
                            userCredentials["userType"] = ds.Tables[0].Rows[0]["RoleName"].ToString();
                            userCredentials["userEmailID"] = ds.Tables[0].Rows[0]["Email"].ToString();
                            userCredentials["userFullName"] = ds.Tables[0].Rows[0]["FirstName"].ToString() + " " + ds.Tables[0].Rows[0]["LastName"].ToString();
                            userCredentials["userDesignation"] = ds.Tables[0].Rows[0]["DesignationName"].ToString();
                            userCredentials["userEmployeeId"] = ds.Tables[0].Rows[0]["EmployeeID"].ToString();
                            //for departement name and id
                            userCredentials["userDeptID"] = ds.Tables[0].Rows[0]["DepartmentID"].ToString();
                            userCredentials["userDeptName"] = ds.Tables[0].Rows[0]["DepartmentName"].ToString();
                            //for CID - departement name and id
                            userCredentials["userCIDDeptID"] = ds.Tables[0].Rows[0]["DepartmentID"].ToString();
                            userCredentials["userCIDDeptName"] = ds.Tables[0].Rows[0]["DepartmentName"].ToString();
                            //Location
                            userCredentials["userLocation"] = ds.Tables[0].Rows[0]["Location"].ToString();
                            //Rep man
                            userCredentials["userBoss1ID"] = ds.Tables[0].Rows[0]["Boss1Id"].ToString();
                            userCredentials["userBoss1Name"] = ds.Tables[0].Rows[0]["Boss1Name"].ToString();
                            //Rev Man
                            userCredentials["userBoss2Id"] = ds.Tables[0].Rows[0]["Boss2Id"].ToString();
                            userCredentials["userBoss2Name"] = ds.Tables[0].Rows[0]["Boss2Name"].ToString();

                            if (!HttpContext.Response.IsRequestBeingRedirected)
                                Response.AppendCookie(userCredentials);

                            return RedirectToAction("Index");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return base.File(Server.MapPath("../Images/not_autho.jpg"), "image/jpeg");
            }

            return RedirectToAction("Unauthorized");
        }

        public ActionResult Login()
        {
            try
            {
                DataSet dsAuthTypes = UserAuthDataStore.GetAuthenticationTypes();
                if (dsAuthTypes != null)
                {
                    if (dsAuthTypes.Tables.Count > 0)
                    {
                        if (dsAuthTypes.Tables[0].Rows.Count > 0)
                        {
                            int AuthenticationType = Convert.ToInt32(dsAuthTypes.Tables[0].Rows[0]["Id"]);
                            if (AuthenticationType == 1)
                            {
                                return RedirectToAction("UserAuthentication");
                            }
                            else if (AuthenticationType == 2)
                            {
                                return Redirect(ConfigurationSettings.AppSettings["CEAGLink"].ToString());
                            }
                            else if (AuthenticationType == 3)
                            {
                                return RedirectToAction("Index", "Login");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                return base.File(Server.MapPath("../Images/not_autho.jpg"), "image/jpeg");
            }

            return new EmptyResult();
        }

        public ActionResult Logout()
        {
            if (Request.Cookies["EVO"] != null)
            {
                Response.Cookies["EVO"].Expires = DateTime.Now.AddDays(-1);
            }
            TempData.Clear();
            ViewData.Clear();
            Session.Abandon();

            return View();
        }

        public ActionResult Unauthorized()
        {
            return View();
        }

        public ActionResult AdminType()
        {
            EvoGeneral objEvoGeneral = new EvoGeneral();
            EvoMain objEvoMain = new EvoMain();
            string NTName = objEvoGeneral.userName;
            objEvoMain.UserID = objEvoGeneral.RetrieveUserID(NTName);
            int role = objEvoMain.GetAdminType(objEvoMain.UserID);
            var js = new { type = role };
            return Json(js, JsonRequestBehavior.AllowGet);
        }

    }
}