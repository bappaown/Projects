﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using EVO_Upgrade.Filter;
using System.Web.Script.Serialization;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class DesignFormController : Controller
    {
        DesignManagement desObj = new DesignManagement();
        private static string FormId = string.Empty;
        private static string VersionId = string.Empty;
        private static string Form = string.Empty;
        private static string CategoryId = string.Empty;
        private static string FormMode = string.Empty;

        // GET: DesignForm
        public ActionResult Index()
        {
            DataSet getFormXMLDataset = new DataSet();
            try
            {
                if (!IsValidUser())
                {
                    return RedirectToAction("Unauthorized", "Home");
                }

                if (FormMode == "EDITMODE")
                {
                    getFormXMLDataset = DesignManagement.GetFormXMLPathForModify(int.Parse(FormId), int.Parse(VersionId));
                }
                else if (FormMode == "CREATEMODE")
                {
                    getFormXMLDataset = DesignManagement.GetFormXMLPath(int.Parse(FormId));
                }

                if (getFormXMLDataset.Tables[0].Rows.Count > 0)
                {
                    if (getFormXMLDataset.Tables[0].Rows[0]["XMLFile"].ToString() != string.Empty)
                    {
                        //string file = Server.MapPath("../JSON/" + getFormXMLDataset.Tables[0].Rows[0]["XMLFile"].ToString());
                        string file = Server.MapPath("..\\JSON\\" + getFormXMLDataset.Tables[0].Rows[0]["XMLFile"].ToString());
                        if (System.IO.File.Exists(file))
                        {
                            var result = System.IO.File.ReadAllText(file);
                            ViewBag.FormData = result;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.logger.Error("DesignForm - Load: " + ex.Message);
            }

            return View();
        }

        public ActionResult EditMode(string FormID, string VersionID, string FormName, string CategoryID)
        {
            FormId = FormID;
            VersionId = VersionID;
            Form = FormName;
            CategoryId = CategoryID;

            EvoAdminUsersRights ObjUserRights = new EvoAdminUsersRights();
            ObjUserRights.FormId = int.Parse(FormId);
            ObjUserRights.VersionId = int.Parse(VersionId);
            DataSet ds = ObjUserRights.GetXMLFileName();
            if (ds.Tables[0].Rows.Count > 0)
            {
                FormMode = (ds.Tables[0].Rows[0]["XMLFileName"].ToString() == "") ? "CREATEMODE" : "EDITMODE";
            }
            else
            {
                FormMode = "CREATEMODE";
            }

            //if (VersionID != "" && VersionID != null)
            //{
            //    FormMode = "EDITMODE";
            //}
            //else
            //{
            //    FormMode = "CREATEMODE";
            //}

            return RedirectToAction("Index");
        }

        [NonAction]
        private bool IsValidUser()
        {
            Boolean IsValid = false;
            try
            {
                EvoAdminUsersRights ObjUserRights = new EvoAdminUsersRights();
                EvoGeneral objEvoGeneral = new EvoGeneral();
                string NTName = objEvoGeneral.userName;
                ObjUserRights.UserID = objEvoGeneral.RetrieveUserID(NTName);
                ObjUserRights.FormId = int.Parse(FormId);
                ObjUserRights.VersionId = int.Parse(VersionId);
                IsValid = ObjUserRights.ValidateAdminManageUser();
            }
            catch (Exception ex)
            {
                ErrorLogger.logger.Error("No data found for this loginid. " + ex.Message);
            }

            return IsValid;
        }

        public ActionResult BindCustomSkillSet(string costCentreList)
        {
            DataSet ds;
            string js = string.Empty;
            DesignManagement desObj = new DesignManagement();
            ds = desObj.GetCustomSkillSet(costCentreList);
            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindCustomCostCentre()
        {
            DataSet ds;
            string js = string.Empty;
            DesignManagement desObj = new DesignManagement();
            ds = desObj.GetCustomCostCentre();
            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindGlobalControls()
        {
            string dependentIDS = "";
            StringBuilder JsonString = new StringBuilder();

            DataSet globalChildControlDataSet = new DataSet();
            globalChildControlDataSet = DesignManagement.GetGlobalChildControls();

            for (int count = 0; count < globalChildControlDataSet.Tables[0].Rows.Count; count++)
            {
                dependentIDS += globalChildControlDataSet.Tables[0].Rows[count]["DependentControlID"].ToString() + ",";
            }

            JsonString.Append("[");

            if (dependentIDS != "")
            {
                DataSet globalMControlDataSet = new DataSet();
                globalMControlDataSet = DesignManagement.GetGlobalMControls(dependentIDS);

                for (int controlCount = 0; controlCount < globalMControlDataSet.Tables[0].Rows.Count; controlCount++)
                {
                    string value = "";
                    string depctrlid = "";

                    for (int globCount = 0; globCount < globalChildControlDataSet.Tables[0].Rows.Count; globCount++)
                    {
                        if (globalChildControlDataSet.Tables[0].Rows[globCount]["DependentControlID"].ToString() == globalMControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString())
                        {
                            value = "" + globalMControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "/" + globalChildControlDataSet.Tables[0].Rows[globCount]["ChildControlName"].ToString() + "";
                            depctrlid = globalChildControlDataSet.Tables[0].Rows[globCount]["ControlID"].ToString();
                        }
                    }

                    JsonString.Append("{\"onclick\" : \"CreateMultipleGlobal(this)\", \"title\" : \"Add " + value + "\", \"ctrlid\" : \"" + globalMControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString() + "\", \"depctrlid\" : \"" + depctrlid + "\", \"value\" : \"" + value + "\"},");

                }
            }

            DataSet globalSControlDataSet = new DataSet();
            globalSControlDataSet = DesignManagement.GetGlobalSControls();

            if (globalSControlDataSet.Tables.Count > 0)
            {
                for (int controlCount = 0; controlCount < globalSControlDataSet.Tables[0].Rows.Count; controlCount++)
                {
                    JsonString.Append("{\"onclick\" : \"CreateSingleGlobal(this)\", \"title\" : \"Add " + globalSControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "\", \"ctrlid\" : \"" + globalSControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString() + "\", \"depctrlid\" : \"\", \"value\" : \"" + globalSControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "\"},");

                }
            }

            if (JsonString.Length > 1)
                JsonString.Length--;

            JsonString.Append("]");

            return Json(JsonString.ToString(), JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindEmployeeList(string CostCentres, string SkillSets)
        {
            DataSet ds = new DataSet();
            string js = string.Empty;
            Forms objForms = new Forms();
            ds = objForms.SelectEmployeesForCustomControl(ds, CostCentres, SkillSets);
            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Submit(string model)
        {
            EvoGeneral objEvoGeneral = new EvoGeneral();
            string versionName = "1.0";
            string formName = string.Empty;
            string fieldName = string.Empty;
            string fieldAlias = string.Empty;
            string fieldDisplayType = string.Empty;
            int controlID = 0;
            int positionID = 0;
            bool insertCtrlResult = false;
            int formId = Convert.ToInt32(FormId);
            int versionId = Convert.ToInt32(VersionId);
            DataSet versionNameDataSet = new DataSet();
            bool check = false;

            try
            {
                versionNameDataSet = desObj.GetFormLastVersionName(formId);

                if (FormMode == "EDITMODE")
                {
                    versionName = versionNameDataSet.Tables[0].Rows[0]["VersionName"].ToString();

                    string[] versionArray = versionName.Split('.');
                    int minor = int.Parse(versionArray[1].ToString());
                    int major = int.Parse(versionArray[0].ToString());
                    if (minor >= 0 && minor <= 9)
                    {
                        minor = minor + 1;
                    }
                    if (minor == 10)
                    {
                        minor = 0;
                        major = major + 1;
                    }
                    versionName = major + "." + minor;

                    formName = Form + "_" + versionName + ".json";
                    versionId = DesignManagement.InsertFormVersion(formId, versionName, formName, objEvoGeneral.userName);

                    if (Convert.ToInt32(VersionId) != versionId)
                    {
                        check = true;
                    }
                }
                else if (FormMode == "CREATEMODE")
                {
                    formName = Form + "_" + versionName + ".json";
                    check = DesignManagement.UpdateFormVersion(formId, versionName, formName, objEvoGeneral.userName, versionId);
                }

                //string path = Server.MapPath("../JSON/" + formName);
                string path = Server.MapPath("..\\JSON\\" + formName);
                var data = model;

                if ((data != "[]" && data != "" & data != null) && check == true)
                {
                    System.IO.File.WriteAllText(path, data);

                    int i = 0;
                    JavaScriptSerializer js = new JavaScriptSerializer();
                    foreach (var member in js.Deserialize<dynamic>(data))
                    {
                        if (member["control"] == "Basic")
                        {
                            fieldName = member["label"].Replace(' ', '_').ToString() + "_" + i;
                            fieldAlias = member["label"];
                            fieldDisplayType = member["field_type"];
                            controlID = member["id"];
                            positionID = i + 1;

                            insertCtrlResult = DesignManagement.InsertFormControls(formId, fieldName, fieldAlias, fieldDisplayType, versionId, controlID, positionID, objEvoGeneral.userName);
                        }
                        else if (member["control"] == "Custom")
                        {
                            fieldName = member["label"].Replace(' ', '_').ToString() + "_" + i;
                            fieldAlias = member["label"];
                            controlID = member["id"];
                            positionID = i + 1;

                            if (member["field_type"] == "employee dropdown")
                            {
                                fieldDisplayType = "DropDown";

                                insertCtrlResult = DesignManagement.InsertFormControls(formId, fieldName, fieldAlias, fieldDisplayType, versionId, controlID, positionID, objEvoGeneral.userName);
                            }
                            else if (member["field_type"] == "employee's manager dropdown")
                            {
                                fieldDisplayType = "DropDown";

                                insertCtrlResult = DesignManagement.InsertFormControls(formId, fieldName, fieldAlias, fieldDisplayType, versionId, controlID, positionID, objEvoGeneral.userName);

                                fieldAlias = fieldAlias + " Manager";
                                fieldDisplayType = "TextBox";

                                insertCtrlResult = DesignManagement.InsertFormControls(formId, fieldName, fieldAlias, fieldDisplayType, versionId, controlID, positionID, objEvoGeneral.userName);
                            }
                        }
                        else if (member["control"] == "Global")
                        {
                            var field = member["field_type"].Trim(']').Split('[');
                            var alias = field[0].Trim().Split('/');
                            var ids = field[1].Trim().Split('/');

                            for (int j = 0; j < ids.Length; j++)
                            {
                                fieldName = alias[j].Replace(' ', '_').ToString() + "_" + i;
                                fieldAlias = alias[j];
                                controlID = Convert.ToInt32(ids[j]);
                                fieldDisplayType = "DropDown";
                                positionID = i + 1;

                                insertCtrlResult = DesignManagement.InsertFormControls(formId, fieldName, fieldAlias, fieldDisplayType, versionId, controlID, positionID, objEvoGeneral.userName);
                            }
                        }

                        ++i;
                    }

                    if (insertCtrlResult)
                    {
                        DesignManagement.SetControlManagement(formId.ToString(), VersionId);
                        DesignManagement.SetDTMSControls(formId.ToString(), versionId.ToString(), objEvoGeneral.userName);

                        VersionId = versionId.ToString();
                        var result = new { FormID = formId, VersionID = versionId, FormName = Form, CategoryID = CategoryId };

                        return Json(result, JsonRequestBehavior.AllowGet);
                    }
                }
            }
            catch (Exception ex)
            {
                ErrorLogger.logger.Error("DesignForm - Something went wrong. " + ex.Message);
            }

            return new EmptyResult();
        }

        [HttpGet]
        public ActionResult Submit()
        {
            return RedirectToAction("EditMode", "AssignManagement", new { FormID = FormId, VersionID = VersionId, FormName = Form, CategoryID = CategoryId });
        }
    }
}