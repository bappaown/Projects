﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using EVO_Upgrade.Filter;
using System.Web.Routing;
using Newtonsoft.Json;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class CreateFormController : Controller
    {
        // GET: CreateForm
        public ActionResult Index()
        {
            EvoMain objEvoMain = new EvoMain();
            FormDetails tModel = new FormDetails();
            try
            {
                TempData["FormId"] = ManageSession.FormID.ToString();
                TempData["VersionID"] = ManageSession.VersionID.ToString();

                if (Convert.ToInt32(TempData["FormId"]) != 0)
                {
                    if (FillSkillSetListBoxEditMode(objEvoMain.UserID, int.Parse(TempData["FormId"].ToString())))
                    {
                        ViewBag.JS = true;
                        ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
                        return DataRead(int.Parse(TempData["FormId"].ToString()));
                    }
                    else
                    {
                        return RedirectToAction("Unauthorized", "Home");
                    }
                }
                else
                {
                    List<SkillSet> list = new List<SkillSet>();
                    ViewBag.SkillSets = list;
                    ViewBag.Categories = FillCategoryDropDown();
                    tModel.SkillSets = FillSkillSetListBox(objEvoMain.UserID);
                    ViewBag.JS = false;
                    ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
                    return View(tModel);
                }
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("CreateForm - Load: " + ex.Message);
            }
            finally
            {
                objEvoMain = null;
            }

            return View();
        }

        [NonAction]
        private List<SkillSet> FillSkillSetListBox(long userID)
        {
            EvoMain objEvoMain = new EvoMain();
            FormDetails testModel = null;
            List<SkillSet> list = new List<SkillSet>();
            try
            {
                DataSet Catds = new DataSet();
                Catds = objEvoMain.RetrieveDeptDetails(userID);
                //
                foreach (DataRow dt in Catds.Tables[0].Rows)
                {
                    list.Add(new SkillSet
                    {
                        DepartmentID = Convert.ToInt16(dt.ItemArray[0]),
                        DepartmentName = Convert.ToString(dt.ItemArray[1]),
                        CostCentreID = Convert.ToInt16(dt.ItemArray[2]),
                        DivisionID = Convert.ToInt16(dt.ItemArray[3]),
                        Status = Convert.ToBoolean(dt.ItemArray[4]),
                        LastUpdated = Convert.ToDateTime(dt.ItemArray[5])


                    });
                }
                testModel = new FormDetails
                {
                    SkillSets = list
                };
            }
            catch (Exception ex)
            {
                TempData["error"] = "Fill SkillSet: " + ex.Message;
                ErrorLogger.logger.Error("CreateForm - Fill SkillSet: " + ex.Message);
            }
            finally
            {
                objEvoMain = null;
            }
            return list;
        }

        public ActionResult DataRead(int formID)
        {
            EvoMain objEvoMain = new EvoMain();
            FormDetails model = new FormDetails();
            DataSet dsFormDetail = new DataSet();
            DataSet dsSkillSet = new DataSet();
            try
            {
                dsFormDetail = objEvoMain.RetrieveFormDetails(formID);
                dsSkillSet = objEvoMain.RetrieveSkillSetDetails(formID);

                model.Name = dsFormDetail.Tables[0].Rows[0]["FormName"].ToString();
                model.Description = dsFormDetail.Tables[0].Rows[0]["FormDesc"].ToString();
                model.Category = Convert.ToInt32(dsFormDetail.Tables[0].Rows[0]["CategoryID"].ToString());
                model.Email = dsFormDetail.Tables[0].Rows[0]["TemplateEmails"].ToString();
                TempData["FormId"] = dsFormDetail.Tables[0].Rows[0]["FormID"].ToString();
                TempData["CategoryID"] = dsFormDetail.Tables[0].Rows[0]["CategoryID"].ToString();
                TempData.Keep();

                if (dsFormDetail.Tables[0].Rows[0]["IsDtms"].ToString() != "")
                {
                    if (dsFormDetail.Tables[0].Rows[0]["IsDtms"].ToString().ToLower() == "true")
                    {
                        model.IsDTMS = true;
                        model.IsEditable = false;
                    }
                    else
                    {
                        model.IsDTMS = false;
                    }
                }
                else
                {
                    model.IsDTMS = false;
                }

                if (dsFormDetail.Tables[0].Rows[0]["Iseditable"].ToString() != "")
                {
                    if (dsFormDetail.Tables[0].Rows[0]["Iseditable"].ToString().ToLower() == "true")
                    {
                        model.IsEditable = true;
                    }
                    else
                    {
                        model.IsEditable = false;
                    }
                }
                else
                {
                    model.IsEditable = false;
                }

                if (dsFormDetail.Tables[0].Rows[0]["IsSearchFormSpecific"].ToString() != "")
                {
                    if (dsFormDetail.Tables[0].Rows[0]["IsSearchFormSpecific"].ToString().ToLower() == "true")
                    {
                        model.IsSearch = true;
                    }
                    else
                    {
                        model.IsSearch = false;
                    }
                }
                else
                {
                    model.IsSearch = false;
                }
                if (TempData["CategoryID"].ToString() == "4")
                {
                    model.IsEditable = false;
                    model.IsSearch = false;
                    model.Email = dsFormDetail.Tables[0].Rows[0]["TemplateEmails"].ToString();
                }
                if (dsSkillSet.Tables.Count > 0)
                {
                    List<SkillSet> list = new List<SkillSet>();

                    foreach (DataRow dt in dsSkillSet.Tables[0].Rows)
                    {
                        list.Add(new SkillSet
                        {
                            DepartmentID = Convert.ToInt16(dt.ItemArray[0]),
                            DepartmentName = Convert.ToString(dt.ItemArray[1]),
                            CostCentreID = Convert.ToInt16(null),
                            DivisionID = Convert.ToInt16(null),
                            Status = Convert.ToBoolean(null),
                            LastUpdated = Convert.ToDateTime(null)
                        });
                    }

                    ViewBag.SkillSets = list;
                }

                ViewBag.Categories = FillCategoryDropDown();
                model.SkillSets = FillSkillSetListBox(objEvoMain.UserID);
            }
            catch (Exception ex)
            {
                TempData["error"] = "DataRead: " + ex.Message;
                ErrorLogger.logger.Error("CreateForm - DataRead: " + ex.Message);
            }
            finally
            {
                objEvoMain = null;
            }
            return View(model);
        }

        [NonAction]
        private List<Category> FillCategoryDropDown()
        {
            EvoMain objEvoMain = new EvoMain();
            List<Category> list = new List<Category>();
            try
            {
                DataSet Catds = new DataSet();
                Catds = objEvoMain.RetrieveCatDetails();

                foreach (DataRow dt in Catds.Tables[0].Rows)
                {
                    list.Add(new Category
                    {
                        CategoryID = Convert.ToInt16(dt.ItemArray[0]),
                        CategoryName = Convert.ToString(dt.ItemArray[1]),
                        CategoryDesc = Convert.ToString(dt.ItemArray[2]),
                        AddedBy = Convert.ToString(dt.ItemArray[3]),
                        AddedWhen = Convert.ToDateTime(dt.ItemArray[4]),
                        IsActive = Convert.ToBoolean(dt.ItemArray[5])
                    });
                }

                ViewBag.Categories = list;
            }
            catch (Exception ex)
            {
                TempData["error"] = "Fill Category: " + ex.Message;
                ErrorLogger.logger.Error("CreateForm - Fill Category: " + ex.Message);
            }
            finally
            {
                objEvoMain = null;
            }
            return list;
        }

        [NonAction]
        private bool FillSkillSetListBoxEditMode(long userID, int formId)
        {
            bool isValid = false;
            EvoMain objEvoMain = new EvoMain();
            DataSet dsSkillSet = new DataSet();
            List<SkillSet> list = new List<SkillSet>();
            try
            {
                dsSkillSet = objEvoMain.RetrieveDeptDetailsEditMode(userID, formId);
                if (dsSkillSet != null && dsSkillSet.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dt in dsSkillSet.Tables[0].Rows)
                    {
                        list.Add(new SkillSet
                        {
                            DepartmentID = Convert.ToInt16(dt.ItemArray[0]),
                            DepartmentName = Convert.ToString(dt.ItemArray[1]),
                            CostCentreID = Convert.ToInt16(dt.ItemArray[2]),
                            DivisionID = Convert.ToInt16(dt.ItemArray[3]),
                            Status = Convert.ToBoolean(dt.ItemArray[4]),
                            LastUpdated = Convert.ToDateTime(dt.ItemArray[5])
                        });
                    }

                    ViewBag.SkillSets = list;
                    isValid = true;
                }
                else
                {
                    isValid = false;
                }

            }
            catch (Exception ex)
            {
                TempData["error"] = "Edit SkillSet: " + ex.Message;
                ErrorLogger.logger.Error("CreateForm - Edit SkillSet: " + ex.Message);
            }
            finally
            {
                objEvoMain = null;
            }
            return isValid;
        }

        // POST: CreateForm/Submit
        [HttpPost]
        public ActionResult Submit(FormDetails model)
        {
            EvoMain objEvoMain = new EvoMain();
            EvoGeneral objEvoGeneral = new EvoGeneral();

            try
            {
                if (ModelState.IsValid)
                {
                    string NTName = objEvoGeneral.userName;
                    objEvoMain.UserID = objEvoGeneral.RetrieveUserID(NTName);
                    bool isStatus = false;

                    try
                    {
                        if (model.Email != null)
                        {
                            string[] emails = model.Email.Split(',');
                            if (emails.Length > 5)
                            {
                                TempData["error"] = "Only 5 emails are allowed.";
                                return JavaScript("showhidechk()");
                            }
                        }

                        if (Convert.ToInt32(TempData["FormId"]) == 0)
                        {
                            objEvoMain.FormName = model.Name.ToString();
                            objEvoMain.FormDesc = model.Description.ToString();
                            objEvoMain.CategoryId = int.Parse(model.Category.ToString());
                            objEvoMain.AddedBy = objEvoGeneral.userName;
                            objEvoMain.EmpUserId = objEvoMain.UserID;

                            if (model.IsEditable == true)
                            {
                                objEvoMain.IsEditable = "true";
                            }
                            else
                            {
                                objEvoMain.IsEditable = "false";
                            }
                            if (model.Category.ToString() == "4")
                            {
                                objEvoMain.IsEditable = "false";
                            }
                            if (model.IsSearch == true)
                            {
                                objEvoMain.IsSearchFormSpecific = "true";
                            }
                            else
                            {
                                objEvoMain.IsSearchFormSpecific = "false";
                            }
                            if (model.Category.ToString() == "4")
                            {
                                objEvoMain.IsSearchFormSpecific = "false";
                            }

                            if (model.IsDTMS == true)
                            {
                                objEvoMain.IsDTMS = "true";
                            }
                            else
                            {
                                objEvoMain.IsDTMS = "false";
                            }
                            objEvoMain.TemplateEmail = "";
                            if (model.Category.ToString() == "4")
                            {
                                objEvoMain.IsDTMS = "false";
                                objEvoMain.TemplateEmail = model.Email;

                            }

                            if (objEvoMain.AddFormDetails())
                            {
                                var SkillSet = model.SkillSetID.Split(',');
                                for (int iLoop = 0; iLoop <= SkillSet.Length - 1; iLoop++)
                                {
                                    // item selected 
                                    TempData["FormId"] = objEvoMain.FormId;
                                    TempData.Keep();
                                    objEvoMain.SkillSetId = int.Parse(SkillSet[iLoop]);
                                    isStatus = objEvoMain.AddSkillSetDetails();
                                }
                                //Session Build......
                                ManageSession.FormID = objEvoMain.FormId;
                                ManageSession.VersionID = objEvoMain.VersionId;
                                ManageSession.FormName = objEvoMain.FormName;
                                ManageSession.CategoryID = objEvoMain.CategoryId;
                                ManageSession.FormMode = "CREATEMODE"; //for New form
                                ModelState.Clear();
                            }
                        }
                        else
                        {
                            DataSet objds = new DataSet();
                            objds = objEvoMain.CheckForIsEditable(Convert.ToInt32(TempData["FormId"].ToString()));

                            if (TempData["CategoryID"].ToString() != model.Category.ToString() && (TempData["CategoryID"].ToString() == "4" || model.Category.ToString() == "4"))
                            {
                                ViewBag.ErrorMessage = "Category cannot be changed from/to template";
                                return JavaScript("showhidechk()");
                            }
                            else if (model.IsEditable != Convert.ToBoolean(objds.Tables[0].Rows[0]["isEditable"].ToString() == "" ? "false" : objds.Tables[0].Rows[0]["isEditable"].ToString()) && Convert.ToInt32(objds.Tables[0].Rows[0]["TotalCount"].ToString()) > 0)
                            {
                                ViewBag.ErrorMessage = "Logger already have data. Cannot update iseditable field.";
                                return new EmptyResult();
                            }
                            else if (model.IsDTMS != Convert.ToBoolean(objds.Tables[0].Rows[0]["isDTMS"].ToString() == "" ? "false" : objds.Tables[0].Rows[0]["isDTMS"].ToString()))
                            {
                                ViewBag.ErrorMessage = "Cannot update IsDtms field. This Logger already assign to EVO OR DTMS Logger";
                                return new EmptyResult();
                            }
                            else
                            {
                                objEvoMain.FormId = int.Parse(TempData["FormId"].ToString());
                                objEvoMain.FormName = model.Name.Trim();
                                objEvoMain.FormDesc = model.Description.Trim();
                                objEvoMain.CategoryId = int.Parse(model.Category.ToString());
                                objEvoMain.VersionId = int.Parse(TempData["VersionID"].ToString());
                                objEvoMain.UpdatedBy = objEvoGeneral.userName;
                                objEvoMain.UpdatedWhen = System.DateTime.Now.ToString();

                                if (model.IsEditable == true)
                                {
                                    objEvoMain.IsEditable = "true";
                                }
                                else
                                {
                                    objEvoMain.IsEditable = "false";
                                }
                                if (model.Category.ToString() == "4")
                                {
                                    objEvoMain.IsEditable = "false";
                                }

                                if (model.IsSearch == true)
                                {
                                    objEvoMain.IsSearchFormSpecific = "true";
                                }
                                else
                                {
                                    objEvoMain.IsSearchFormSpecific = "false";
                                }
                                objEvoMain.TemplateEmail = "";
                                if (model.Category.ToString() == "4")
                                {
                                    objEvoMain.IsSearchFormSpecific = "false";
                                    objEvoMain.TemplateEmail = model.Email;
                                }

                                if (objEvoMain.UpdateFormDetails())
                                {
                                    if (objEvoMain.DeleteSkillSetRelationsls(int.Parse(TempData["FormId"].ToString())))
                                    {
                                        var SkillSet = model.SkillSetID.Split(',');
                                        for (int iLoop = 0; iLoop <= SkillSet.Length - 1; iLoop++)
                                        {
                                            // item selected 
                                            TempData["FormId"] = objEvoMain.FormId;
                                            TempData.Keep();
                                            objEvoMain.AddedBy = objEvoGeneral.userName;
                                            objEvoMain.SkillSetId = int.Parse(SkillSet[iLoop]);
                                            isStatus = objEvoMain.AddSkillSetDetails();
                                        }
                                        //Session Build...... for form mode.
                                        ManageSession.FormID = objEvoMain.FormId;
                                        ManageSession.FormName = objEvoMain.FormName;
                                        ManageSession.CategoryID = objEvoMain.CategoryId;
                                        ManageSession.VersionID = objEvoMain.VersionId;
                                        ManageSession.FormMode = "EDITMODE";
                                        ModelState.Clear();
                                    }
                                }
                            }
                        }

                        if (!isStatus)
                        {
                            TempData["error"] = "Duplicate record found.";
                        }
                        else
                        {
                            var js = new { FormID = Convert.ToString(objEvoMain.FormId), VersionID = Convert.ToString(objEvoMain.VersionId), FormName = objEvoMain.FormName, CategoryID = Convert.ToString(objEvoMain.CategoryId) };

                            return Json(js, JsonRequestBehavior.AllowGet);
                        }
                    }
                    catch (Exception ex)
                    {
                        TempData["error"] = "Save: " + ex.Message;
                        ErrorLogger.logger.Error("CreateForm - Save: " + ex.Message);
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Something went wrong." + ex.Message;
                ErrorLogger.logger.Error("CreateForm - Something went wrong." + ex.Message);
            }

            return new EmptyResult();
        }

        [HttpGet]
        public ActionResult Submit()
        {
            return RedirectToAction("EditMode", "DesignForm", new { FormID = ManageSession.FormID, VersionID = ManageSession.VersionID, FormName = ManageSession.FormName, CategoryID = ManageSession.CategoryID });
        }

        public ActionResult EditMode(string FormID, string VersionID, string FormName, string CategoryID)
        {
            ManageSession.FormID = Convert.ToInt32(FormID);
            ManageSession.VersionID = Convert.ToInt32(VersionID);
            ManageSession.FormName = FormName;
            ManageSession.CategoryID = Convert.ToInt32(CategoryID);

            return RedirectToAction("Index");
        }
    }
}