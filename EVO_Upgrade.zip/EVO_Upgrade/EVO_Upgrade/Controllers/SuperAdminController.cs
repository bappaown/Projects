﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using System.Data.SqlClient;
using EVO_Upgrade.Filter;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class SuperAdminController : Controller
    {
        private static int currentPageNumber = 1;
        private static int PAGE_SIZE = 10;

        // GET: SuperAdmin
        public ActionResult Index()
        {
            try
            {
                ViewBag.CostCentre = FillCostCentreListBox();
                ViewBag.Admin = FillAdminDDL(0, string.Empty);
                ViewBag.AdminTable = FillGrid(currentPageNumber, PAGE_SIZE);
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("SuperAdmin - Load: " + ex.Message);
            }

            return View();
        }

        [NonAction]
        private IDictionary<int, string> FillCostCentreListBox()
        {
            IDictionary<int, string> myList = new Dictionary<int, string>();
            try
            {
                AssignCostCentre ObjAssignCostCentre = new AssignCostCentre();
                DataSet ccDs = new DataSet();
                ccDs = ObjAssignCostCentre.GetCentralCostCentre();

                if (ccDs.Tables.Count > 0)
                {
                    if (ccDs.Tables[0].Rows.Count > 0)
                    {
                        myList = ccDs.Tables[0].AsEnumerable().ToDictionary<DataRow, int, string>(row => Convert.ToInt32(row[0].ToString()), row => row[1].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Fill CostCentre: " + ex.Message;
                ErrorLogger.logger.Error("SuperAdmin - Fill CostCentre: " + ex.Message);
            }

            return myList;
        }

        [NonAction]
        private IDictionary<int, string> FillAdminDDL(int costCentreId, string adminName)
        {
            IDictionary<int, string> myList = new Dictionary<int, string>();
            AssignCostCentre ObjAssignCostCentre = new AssignCostCentre();
            try
            {
                DataSet dsAdmin = new DataSet();

                dsAdmin = ObjAssignCostCentre.GetEmployeeDetails(costCentreId, adminName);

                if (dsAdmin.Tables.Count > 0)
                {
                    if (dsAdmin.Tables[0].Rows.Count > 0)
                    {
                        myList = dsAdmin.Tables[0].AsEnumerable().ToDictionary<DataRow, int, string>(row => Convert.ToInt32(row[0].ToString()), row => row[1].ToString());
                    }
                    else
                    {
                        myList.Clear();
                        myList.Add(0, "No Admin Found.");
                    }
                }
                else
                {
                    myList.Clear();
                    myList.Add(0, "No Admin Found.");
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Fill Admin: " + ex.Message;
                ErrorLogger.logger.Error("SuperAdmin - Fill Admin: " + ex.Message);
            }
            finally
            {
                ObjAssignCostCentre = null;
            }

            return myList;
        }

        public ActionResult BindAdminDDL(string costCentreId, string adminName)
        {
            AssignCostCentre ObjAssignCostCentre = new AssignCostCentre();
            DataSet ds = new DataSet();
            string js = string.Empty;
            int costCentre = (costCentreId == "" ? 0 : Convert.ToInt32(costCentreId));

            ds = ObjAssignCostCentre.GetEmployeeDetails(costCentre, adminName);

            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult FillGrid(int currentPage, int size)
        {
            AssignCostCentre ObjAssignCostCentre = new AssignCostCentre();
            string js = string.Empty;
            DataSet ds = new DataSet();
            currentPageNumber = currentPage;
            PAGE_SIZE = size;
            try
            {
                ds = ObjAssignCostCentre.GetAdminCCRelation(currentPageNumber, PAGE_SIZE);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    ds.Tables[0].Columns["UK-India"].ColumnName = "UKIndia";
                    ds.Tables[0].Columns["ROI-India"].ColumnName = "ROIIndia";
                    ds.Tables[0].Columns["AUS-India"].ColumnName = "AUSIndia";

                    js = JsonConvert.SerializeObject(ds.Tables[0]);
                }

                double totalRows = (int)ObjAssignCostCentre.TotalRows;
                int totalPages = (int)Math.Ceiling(totalRows / PAGE_SIZE);

                ViewBag.currentPage = currentPageNumber;
                ViewBag.totalPage = totalPages;
            }
            catch (Exception ex)
            {
                TempData["error"] = "FillGrid: " + ex.Message;
                ErrorLogger.logger.Error("SuperAdmin - FillGrid: " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult PagingGrid(int currentPage, int size)
        {
            currentPageNumber = currentPage;
            PAGE_SIZE = size;

            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Submit(SuperAdmin model)
        {
            SqlTransaction objSqlTransaction;
            SqlConnection objCon = new SqlConnection(DAL.SqlHelper.GetConnectionString());
            AssignCostCentre ObjAssignCostCentre = new AssignCostCentre();
            SuperAssignAdmin ObjSuperAssignAdmin = new SuperAssignAdmin();
            EvoGeneral objEvoGeneral = new EvoGeneral();
            objCon.Open();
            objSqlTransaction = objCon.BeginTransaction();
            try
            {
                if (ModelState.IsValid)
                {
                    string NTName = objEvoGeneral.userName;
                    bool isStatus = false;
                    int roleId = 2;
                    ObjSuperAssignAdmin.UserId = model.Admin;
                    ObjSuperAssignAdmin.AdminUserLogin = ObjSuperAssignAdmin.RetrieveAdminUserLogin(model.Admin);
                    ObjSuperAssignAdmin.RoleId = roleId;
                    ObjSuperAssignAdmin.AddedBy = NTName;
                    isStatus = ObjSuperAssignAdmin.AddAdmin(objSqlTransaction);
                    if (ObjSuperAssignAdmin.AdminId == 0)
                    {
                        objSqlTransaction.Rollback();
                        TempData["error"] = "User already exists as Sub-Admin.";
                    }
                    if (ObjSuperAssignAdmin.AdminId == 1)
                    {
                        for (int iLoop = 0; iLoop <= model.CostCentreList.Length - 1; iLoop++)
                        {
                            ObjAssignCostCentre.UserId = model.Admin;
                            ObjAssignCostCentre.CCId = model.CostCentreList[iLoop];
                            ObjAssignCostCentre.AddedBy = NTName;
                            isStatus = ObjAssignCostCentre.AddAdminCCR(objSqlTransaction);
                        }

                        if (isStatus == true)
                        {
                            objSqlTransaction.Commit();
                            TempData["error"] = "Record added successfully.";
                        }

                    }
                    if (ObjSuperAssignAdmin.AdminId == 2)
                    {
                        objSqlTransaction.Rollback();
                        TempData["error"] = "User already exists as Admin.";
                    }
                }
                else
                {
                    TempData["error"] = "Something went wrong.";
                }
            }
            catch (Exception ex)
            {
                objSqlTransaction.Rollback();
                TempData["error"] = "Error during submit the record. " + ex.Message;
                ErrorLogger.logger.Error("SuperAdmin - Error during submit the record. " + ex.Message);
            }
            finally
            {
                if (objCon.State == ConnectionState.Open)
                {
                    objCon.Close();
                }
                objCon = null;
                objSqlTransaction = null;
                ObjAssignCostCentre = null;
                ObjSuperAssignAdmin = null;
            }

            return RedirectToAction("Index");
        }

        public ActionResult Delete(int EmpUserID)
        {
            AssignCostCentre ObjAssignCostCentre = new AssignCostCentre();
            SqlTransaction objSqlTransaction;
            SqlConnection objCon = new SqlConnection(DAL.SqlHelper.GetConnectionString());
            objCon.Open();
            objSqlTransaction = objCon.BeginTransaction();
            ObjAssignCostCentre.UserId = EmpUserID;
            bool isStatus = false;
            try
            {
                isStatus = ObjAssignCostCentre.DeleteAdminCCR(objSqlTransaction);
                if (isStatus == true)
                {
                    objSqlTransaction.Commit();
                    TempData["error"] = "Record deleted successfully.";
                }
                else
                {
                    objSqlTransaction.Rollback();
                    TempData["error"] = "Record not deleted.";
                }
            }
            catch (Exception ex)
            {
                objSqlTransaction.Rollback();
                TempData["error"] = "Error during delete the record. " + ex.Message;
                ErrorLogger.logger.Error("SuperAdmin - Error during delete the record. " + ex.Message);
            }

            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }
    }
}