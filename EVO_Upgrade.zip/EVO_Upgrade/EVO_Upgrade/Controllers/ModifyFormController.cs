﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using EVO_Upgrade.Filter;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class ModifyFormController : Controller
    {
        Forms objForms = new Forms();
        Reports objReports = new Reports();
        EvoGeneral objEvoGeneral = new EvoGeneral();
        EvoMain objEvoMain = new EvoMain();
        SearchForm objSearchForm = null;

        int currentPageNumber = 1;
        int PAGE_SIZE = 10;
        string Title = string.Empty;
        string AddedBy = string.Empty;
        string StartDate = string.Empty;
        string EndDate = string.Empty;
        bool MyForm = false;

        // GET: ModifyForm
        public ActionResult Index()
        {
            try
            {
                currentPageNumber = 1;
                PAGE_SIZE = 10;
                ViewBag.FormTable = FillGridData(currentPageNumber, PAGE_SIZE);
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {

                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("ModifyForm - GET Load: " + ex.Message);
            }

            return View(objSearchForm);
        }


        [HttpPost]
        public ActionResult Index(FormCollection data)
        {
            try
            {
                currentPageNumber = (data["Page"] == "") ? 1 : Convert.ToInt32(data["Page"]);
                PAGE_SIZE = (data["Size"] == "") ? 10 : Convert.ToInt32(data["Size"]);
                Title = (data["Title"] == null) ? "" : data["Title"];
                AddedBy = (data["AddedBy"] == null) ? "" : data["AddedBy"];
                StartDate = (data["StartDate"] == null) ? "" : data["StartDate"];
                EndDate = (data["EndDate"] == null) ? "" : data["EndDate"];
                MyForm = (data["MyForm"] == null) ? false : Convert.ToBoolean(data["MyForm"].Split(',')[0]);

                ViewBag.FormTable = SearchData(Title, AddedBy, StartDate, EndDate, MyForm, currentPageNumber, PAGE_SIZE);
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("ModifyForm - POST Load: " + ex.Message);
            }

            return View(objSearchForm);
        }

        public ActionResult FillGridData(int currentPage, int size)
        {
            string js = string.Empty;
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            //List<Models.ModifyForm> Data = new List<Models.ModifyForm>();
            //objSearchForm = new SearchForm();

            try
            {
                string NTName = objEvoGeneral.userName;
                objReports.UserID = objEvoGeneral.RetrieveUserID(NTName);
                objReports.FormID = 0;
                objReports.Module = "ModifyForm";
                objReports.EmpName = null;
                objReports.StDate = null;
                objReports.EndDate = null;

                ds = objReports.GetFormsForReports(ds, "0");

                if (ds.Tables[0].Rows.Count > 0)
                {
                    dt = ds.Tables[0].Clone();
                    int RowNumber = (currentPage - 1) * size;
                    int PageNumber = (ds.Tables[0].Rows.Count > (currentPage * size)) ? (currentPage * size) : ds.Tables[0].Rows.Count;

                    for (int i = RowNumber; i < PageNumber; i++)
                    {
                        dt.ImportRow(ds.Tables[0].Rows[i]);
                    }

                    js = JsonConvert.SerializeObject(dt);


                    //for (int i = RowNumber; i < PageNumber; i++)
                    //{
                    //    Models.ModifyForm form = new Models.ModifyForm();
                    //    form.FormID = Convert.ToInt32(ds.Tables[0].Rows[i]["FormID"].ToString());
                    //    form.FormName = ds.Tables[0].Rows[i]["FormName"].ToString();
                    //    form.CategoryID = Convert.ToInt32(ds.Tables[0].Rows[i]["CategoryID"].ToString());
                    //    form.CategoryName = ds.Tables[0].Rows[i]["CategoryName"].ToString();
                    //    form.FormDesc = ds.Tables[0].Rows[i]["FormDesc"].ToString();
                    //    form.VersionId = Convert.ToInt32(ds.Tables[0].Rows[i]["VersionId"].ToString());
                    //    form.VersionName = ds.Tables[0].Rows[i]["VersionName"].ToString();
                    //    form.AddedBy = ds.Tables[0].Rows[i]["AddedBy"].ToString();
                    //    form.AddedWhen = Convert.ToDateTime(ds.Tables[0].Rows[i]["AddedWhen"].ToString());
                    //    form.IsActive = Convert.ToBoolean(ds.Tables[0].Rows[i]["IsActive"].ToString());
                    //    form.IsActive1 = Convert.ToBoolean(ds.Tables[0].Rows[i]["IsActive1"].ToString());
                    //    Data.Add(form);
                    //}

                    //objSearchForm.AcctData = Data;

                    double totalRows = ds.Tables[0].Rows.Count;
                    int totalPages = (int)Math.Ceiling(totalRows / PAGE_SIZE);

                    ViewBag.currentPage = currentPage;
                    ViewBag.totalPage = totalPages;
                }
                else
                {
                    ViewBag.currentPage = 1;
                    ViewBag.totalPage = 1;
                    TempData["error"] = "No Records Found.";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "FillGrid: " + ex.Message;
                ErrorLogger.logger.Error("ModifyForm - FillGrid: " + ex.Message);
            }

            //return View(objSearchForm);
            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SearchData(string txtTitle, string txtAddedBy, string txtStartDate, string txtEndDate, bool isMyForm, int currentPage, int size)
        {
            string js = string.Empty;
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            DataTable df = new DataTable();
            //List<Models.ModifyForm> Data = new List<Models.ModifyForm>();
            objSearchForm = new SearchForm();
            objSearchForm.Title = txtTitle;
            objSearchForm.AddedBy = txtAddedBy;
            objSearchForm.StartDate = txtStartDate;
            objSearchForm.EndDate = txtEndDate;
            objSearchForm.MyForm = isMyForm;

            try
            {
                string NTName = objEvoGeneral.userName;
                objReports.UserID = objEvoGeneral.RetrieveUserID(NTName);
                objReports.FormID = 0;
                objReports.Module = "ModifyForm";
                objReports.EmpName = txtAddedBy;
                if (txtStartDate.Trim() != "" && txtEndDate.Trim() != "")
                {
                    objReports.StDate = Convert.ToDateTime(txtStartDate).ToString("dd-MMM-yyyy 00:00:00");
                    objReports.EndDate = Convert.ToDateTime(txtEndDate).ToString("dd-MMM-yyyy 23:59:59");
                }

                ds = objReports.GetFormsForReports(ds, "0");

                if (txtTitle != "")
                {
                    string FormName = txtTitle.Replace("'", "");

                    ds.Tables[0].DefaultView.RowFilter = "FormName Like '%" + FormName + "%'";
                    if (ds.Tables[0].DefaultView.Count > 0)
                    {
                        df = ds.Tables[0].Clone();
                        dt = ds.Tables[0].DefaultView.ToTable();
                        int RowNumber = (currentPage - 1) * size;
                        int PageNumber = (dt.Rows.Count > (currentPage * size)) ? (currentPage * size) : dt.Rows.Count;

                        for (int i = RowNumber; i < PageNumber; i++)
                        {
                            df.ImportRow(dt.Rows[i]);
                        }

                        js = JsonConvert.SerializeObject(df);

                        //for (int i = RowNumber; i < PageNumber; i++)
                        //{
                        //    Models.ModifyForm form = new Models.ModifyForm();
                        //    form.FormID = Convert.ToInt32(dt.Rows[i]["FormID"].ToString());
                        //    form.FormName = dt.Rows[i]["FormName"].ToString();
                        //    form.CategoryID = Convert.ToInt32(dt.Rows[i]["CategoryID"].ToString());
                        //    form.CategoryName = dt.Rows[i]["CategoryName"].ToString();
                        //    form.FormDesc = dt.Rows[i]["FormDesc"].ToString();
                        //    form.VersionId = Convert.ToInt32(dt.Rows[i]["VersionId"].ToString());
                        //    form.VersionName = dt.Rows[i]["VersionName"].ToString();
                        //    form.AddedBy = dt.Rows[i]["AddedBy"].ToString();
                        //    form.AddedWhen = Convert.ToDateTime(dt.Rows[i]["AddedWhen"].ToString());
                        //    form.IsActive = Convert.ToBoolean(dt.Rows[i]["IsActive"].ToString());
                        //    form.IsActive1 = Convert.ToBoolean(dt.Rows[i]["IsActive1"].ToString());
                        //    Data.Add(form);
                        //}
                        //objSearchForm.AcctData = Data;

                        double totalRows = dt.Rows.Count;
                        int totalPages = (int)Math.Ceiling(totalRows / size);

                        ViewBag.currentPage = currentPageNumber;
                        ViewBag.totalPage = totalPages;
                    }
                    else
                    {
                        ViewBag.currentPage = 1;
                        ViewBag.totalPage = 1;
                        TempData["error"] = "No Records Found.";
                    }
                }
                else
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        dt = ds.Tables[0].Clone();
                        int RowNumber = (currentPage - 1) * size;
                        int PageNumber = (ds.Tables[0].Rows.Count > (currentPage * size)) ? (currentPage * size) : ds.Tables[0].Rows.Count;

                        for (int i = RowNumber; i < PageNumber; i++)
                        {
                            dt.ImportRow(ds.Tables[0].Rows[i]);
                        }

                        js = JsonConvert.SerializeObject(dt);

                        //for (int i = RowNumber; i < PageNumber; i++)
                        //{
                        //    Models.ModifyForm form = new Models.ModifyForm();
                        //    form.FormID = Convert.ToInt32(ds.Tables[0].Rows[i]["FormID"].ToString());
                        //    form.FormName = ds.Tables[0].Rows[i]["FormName"].ToString();
                        //    form.CategoryID = Convert.ToInt32(ds.Tables[0].Rows[i]["CategoryID"].ToString());
                        //    form.CategoryName = ds.Tables[0].Rows[i]["CategoryName"].ToString();
                        //    form.FormDesc = ds.Tables[0].Rows[i]["FormDesc"].ToString();
                        //    form.VersionId = Convert.ToInt32(ds.Tables[0].Rows[i]["VersionId"].ToString());
                        //    form.VersionName = ds.Tables[0].Rows[i]["VersionName"].ToString();
                        //    form.AddedBy = ds.Tables[0].Rows[i]["AddedBy"].ToString();
                        //    form.AddedWhen = Convert.ToDateTime(ds.Tables[0].Rows[i]["AddedWhen"].ToString());
                        //    form.IsActive = Convert.ToBoolean(ds.Tables[0].Rows[i]["IsActive"].ToString());
                        //    form.IsActive1 = Convert.ToBoolean(ds.Tables[0].Rows[i]["IsActive1"].ToString());
                        //    Data.Add(form);
                        //}
                        //objSearchForm.AcctData = Data;

                        double totalRows = ds.Tables[0].Rows.Count;
                        int totalPages = (int)Math.Ceiling(totalRows / size);

                        ViewBag.currentPage = currentPage;
                        ViewBag.totalPage = totalPages;
                    }
                    else
                    {
                        ViewBag.currentPage = 1;
                        ViewBag.totalPage = 1;
                        TempData["error"] = "No Records Found.";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "SearchData: " + ex.Message;
                ErrorLogger.logger.Error("ModifyForm - SearchData: " + ex.Message);
            }

            //return View(objSearchForm);
            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult PagingGrid(int currentPage, int size)
        {
            currentPageNumber = currentPage;
            PAGE_SIZE = size;

            return RedirectToAction("Index");
        }

        public ActionResult Reset()
        {
            currentPageNumber = 1;
            PAGE_SIZE = 10;
            Title = string.Empty;
            AddedBy = string.Empty;
            StartDate = string.Empty;
            EndDate = string.Empty;
            MyForm = false;

            return RedirectToAction("Index");
        }

        public ActionResult EditForm(int FormID)
        {
            DataSet objDataSet = new DataSet();
            string js = string.Empty;
            string NTName = objEvoGeneral.userName;
            objReports.UserID = Convert.ToInt32(objEvoGeneral.RetrieveUserID(NTName));
            objReports.FormID = FormID;
            objReports.Module = "ModifyFormVersions";
            objDataSet = objReports.GetFormsForReports(objDataSet, "0");

            if (objDataSet.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(objDataSet.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DeActiveForm(int FormID)
        {
            objReports.UpdateFormStatus(FormID, objEvoGeneral.userName);

            return RedirectToAction("Index");
        }

        public ActionResult ActivateSrabblePad(bool IsSrabble, int VersionId)
        {
            EvoMain objGeneral = new EvoMain();
            objGeneral.UpdateIsSrabblePad(VersionId, objEvoGeneral.userName, Convert.ToString(IsSrabble));

            return new EmptyResult();
        }

        public ActionResult ActivateForm(int FormId, int VersionId)
        {
            EvoMain objGeneral = new EvoMain();
            DataSet objDataSet = new DataSet();
            string NTName = objEvoGeneral.userName;
            objReports.UserID = Convert.ToInt32(objEvoGeneral.RetrieveUserID(NTName));
            objReports.FormID = FormId;
            objReports.Module = "ModifyFormVersions";
            objDataSet = objReports.GetFormsForReports(objDataSet, "0");

            DataRow[] result = objDataSet.Tables[0].Select("Status = True");
            foreach (DataRow row in result)
            {
                objGeneral.DeActivateFormVersion(Convert.ToInt32(row["VersionID"]), objEvoGeneral.userName);
            }

            objGeneral.ActivateFormVersion(VersionId, objEvoGeneral.userName);

            return new EmptyResult();
        }
    }
}