﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using EVO_Upgrade.Filter;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class UserFormsController : Controller
    {
        EvoGeneral objEvoGeneral = new EvoGeneral();
        Forms objForms = new Forms();
        Reports objReports = new Reports();
        private static int currentPageNumber = 1;
        private static int PAGE_SIZE = 10;

        // GET: UserForms
        public ActionResult Index()
        {
            try
            {
                currentPageNumber = 1;
                PAGE_SIZE = 10;

                ViewBag.Categories = FillCategoryDropDown();
                ViewBag.UserTable = FillGrid(currentPageNumber, PAGE_SIZE);
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("UserForms - GET Load: " + ex.Message);
            }

            return View();
        }

        [HttpPost]
        public ActionResult Index(FormCollection data)
        {
            try
            {
                currentPageNumber = (data["Page"] == "") ? 1 : Convert.ToInt32(data["Page"]);
                PAGE_SIZE = (data["Size"] == "") ? 10 : Convert.ToInt32(data["Size"]);
                string Title = (data["txtTitle"] == null) ? "" : data["txtTitle"];
                string Category = (data["ddlCategory"] == null) ? "" : data["ddlCategory"];

                ViewBag.Categories = FillCategoryDropDown();
                ViewBag.UserTable = SearchData(currentPageNumber, PAGE_SIZE, Title, Category);
                ViewBag.JS = Title + '|' + Category;
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("UserForms - POST Load: " + ex.Message);
            }

            return View();
        }

        [NonAction]
        private List<Category> FillCategoryDropDown()
        {
            EvoMain objEvoMain = new EvoMain();
            List<Category> list = new List<Category>();
            try
            {
                DataSet Catds = new DataSet();
                Catds = objEvoMain.RetrieveCatDetails();

                foreach (DataRow dt in Catds.Tables[0].Rows)
                {
                    list.Add(new Category
                    {
                        CategoryID = Convert.ToInt16(dt.ItemArray[0]),
                        CategoryName = Convert.ToString(dt.ItemArray[1]),
                        CategoryDesc = Convert.ToString(dt.ItemArray[2]),
                        AddedBy = Convert.ToString(dt.ItemArray[3]),
                        AddedWhen = Convert.ToDateTime(dt.ItemArray[4]),
                        IsActive = Convert.ToBoolean(dt.ItemArray[5])
                    });
                }

                var itemRemove = list.Single(m => m.CategoryID == 4);
                list.Remove(itemRemove);
                ViewBag.Categories = list;
            }
            catch (Exception ex)
            {
            }
            finally
            {
                objEvoMain = null;
            }
            return list;
        }

        public ActionResult SearchData(int currentPage, int size, string Title, string Category)
        {
            string js = string.Empty;
            string parameter = string.Empty;
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            DataTable df = new DataTable();
            currentPageNumber = currentPage;
            PAGE_SIZE = size;

            try
            {
                //objForms.LoggedInUser = objEvoGeneral.userName;
                //ds = objForms.GetFormsAsPerUser(ds);

                string NTName = objEvoGeneral.userName;
                objReports.UserID = objEvoGeneral.RetrieveUserID(NTName);
                objReports.FormID = 0;
                objReports.Module = "ModifyForm";
                objReports.EmpName = null;
                objReports.StDate = null;
                objReports.EndDate = null;
                ds = objReports.GetFormsForReports(ds, "0");

                if (Title != "" && Category == "")
                {
                    parameter += "FormName Like '%" + Title + "%'";
                }
                else if (Title == "" && Category != "")
                {
                    parameter += "CategoryID = " + Convert.ToInt16(Category);
                }
                else if (Title != "" && Category != "")
                {
                    parameter += "FormName Like '%" + Title + "%' And CategoryID = " + Convert.ToInt16(Category);
                }

                if (parameter != "")
                {
                    ds.Tables[0].DefaultView.RowFilter = parameter;
                    if (ds.Tables[0].DefaultView.Count > 0)
                    {
                        df = ds.Tables[0].Clone();
                        dt = ds.Tables[0].DefaultView.ToTable();
                        int RowNumber = (currentPage - 1) * size;
                        int PageNumber = (dt.Rows.Count > (currentPage * size)) ? (currentPage * size) : dt.Rows.Count;

                        for (int i = RowNumber; i < PageNumber; i++)
                        {
                            df.ImportRow(dt.Rows[i]);
                        }

                        js = JsonConvert.SerializeObject(df);

                        double totalRows = dt.Rows.Count;
                        int totalPages = (int)Math.Ceiling(totalRows / size);

                        ViewBag.currentPage = currentPageNumber;
                        ViewBag.totalPage = totalPages;
                    }
                    else
                    {
                        ViewBag.currentPage = 1;
                        ViewBag.totalPage = 1;
                        TempData["error"] = "No Records Found.";
                    }
                }
                else
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        dt = ds.Tables[0].Clone();
                        int RowNumber = (currentPage - 1) * size;
                        int PageNumber = (ds.Tables[0].Rows.Count > (currentPage * size)) ? (currentPage * size) : ds.Tables[0].Rows.Count;

                        for (int i = RowNumber; i < PageNumber; i++)
                        {
                            dt.ImportRow(ds.Tables[0].Rows[i]);
                        }

                        js = JsonConvert.SerializeObject(dt);

                        double totalRows = ds.Tables[0].Rows.Count;
                        int totalPages = (int)Math.Ceiling(totalRows / PAGE_SIZE);

                        ViewBag.currentPage = currentPage;
                        ViewBag.totalPage = totalPages;
                    }
                    else
                    {
                        ViewBag.currentPage = 1;
                        ViewBag.totalPage = 1;
                        TempData["error"] = "No Records Found.";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "SearchData: " + ex.Message;
                ErrorLogger.logger.Error("UserForms - SearchData: " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult FillGrid(int currentPage, int size)
        {
            string js = string.Empty;
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            currentPageNumber = currentPage;
            PAGE_SIZE = size;
            try
            {
                //objForms.LoggedInUser = objEvoGeneral.userName;
                //ds = objForms.GetFormsAsPerUser(ds);

                string NTName = objEvoGeneral.userName;
                objReports.UserID = objEvoGeneral.RetrieveUserID(NTName);
                objReports.FormID = 0;
                objReports.Module = "ModifyForm";
                objReports.EmpName = null;
                objReports.StDate = null;
                objReports.EndDate = null;
                ds = objReports.GetFormsForReports(ds, "0");

                if (ds.Tables[0].Rows.Count > 0)
                {
                    dt = ds.Tables[0].Clone();
                    int RowNumber = (currentPage - 1) * size;
                    int PageNumber = (ds.Tables[0].Rows.Count > (currentPage * size)) ? (currentPage * size) : ds.Tables[0].Rows.Count;

                    for (int i = RowNumber; i < PageNumber; i++)
                    {
                        dt.ImportRow(ds.Tables[0].Rows[i]);
                    }

                    js = JsonConvert.SerializeObject(dt);
                }
                else
                {
                    TempData["error"] = "Forms are not been assigned.";
                }

                double totalRows = ds.Tables[0].Rows.Count;
                int totalPages = (int)Math.Ceiling(totalRows / PAGE_SIZE);

                ViewBag.currentPage = currentPage;
                ViewBag.totalPage = totalPages;
            }
            catch (Exception ex)
            {
                TempData["error"] = "FillGrid: " + ex.Message;
                ErrorLogger.logger.Error("UserForms - FillGrid: " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult PagingGrid(int currentPage, int size)
        {
            currentPageNumber = currentPage;
            PAGE_SIZE = size;

            return RedirectToAction("Index");
        }
    }
}