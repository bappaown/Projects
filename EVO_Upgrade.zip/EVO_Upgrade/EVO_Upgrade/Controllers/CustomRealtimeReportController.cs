﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using System.Xml;
using System.Xml.Linq;
using EVO_Upgrade.Filter;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class CustomRealtimeReportController : Controller
    {
        Reports objReports = new Reports();
        Forms objForms = new Forms();
        ReportModel objDataDump = null;
        private static string FormID = string.Empty;
        private static string FormName = string.Empty;
        XmlDocument doc;
        XDocument xmlDoc = new XDocument();

        // GET: CustomRealtimeReport
        public ActionResult Index()
        {
            try
            {
                ViewBag.ReportTable = BindReportData(FormID);
                ViewBag.JS = true;
                ViewBag.FormName = FormName;
                ViewBag.Hour = new List<SelectListItem>() { new SelectListItem { Text = "00", Value = "00" }, new SelectListItem { Text = "01", Value = "01" }, new SelectListItem { Text = "02", Value = "02" }, new SelectListItem { Text = "03", Value = "03" }, new SelectListItem { Text = "04", Value = "04" }, new SelectListItem { Text = "05", Value = "05" }, new SelectListItem { Text = "06", Value = "06" }, new SelectListItem { Text = "07", Value = "07" }, new SelectListItem { Text = "08", Value = "08" }, new SelectListItem { Text = "09", Value = "09" }, new SelectListItem { Text = "10", Value = "10" }, new SelectListItem { Text = "11", Value = "11" }, new SelectListItem { Text = "12", Value = "12" }, new SelectListItem { Text = "13", Value = "13" }, new SelectListItem { Text = "14", Value = "14" }, new SelectListItem { Text = "15", Value = "15" }, new SelectListItem { Text = "16", Value = "16" }, new SelectListItem { Text = "17", Value = "17" }, new SelectListItem { Text = "18", Value = "18" }, new SelectListItem { Text = "19", Value = "19" }, new SelectListItem { Text = "20", Value = "20" }, new SelectListItem { Text = "21", Value = "21" }, new SelectListItem { Text = "22", Value = "22" }, new SelectListItem { Text = "23", Value = "23" } };
                ViewBag.Min = new List<SelectListItem>() { new SelectListItem { Text = "00", Value = "00" }, new SelectListItem { Text = "15", Value = "15" }, new SelectListItem { Text = "30", Value = "30" }, new SelectListItem { Text = "45", Value = "45" } };
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("CustomRealtimeReport - GET Load: " + ex.Message);
            }

            return View();
        }

        [HttpPost]
        public ActionResult Index(FormCollection data)
        {
            try
            {
                objDataDump = new ReportModel();
                objDataDump.StartDate = data["StartDate"];
                objDataDump.StartHour = data["StartHour"];
                objDataDump.StartMin = data["StartMin"];
                objDataDump.EndDate = data["EndDate"];
                objDataDump.EndHour = data["EndHour"];
                objDataDump.EndMin = data["EndMin"];
                objDataDump.Time = data["Time"];

                string Start = data["StartDate"] + " " + data["StartHour"] + ":" + data["StartMin"] + ":00";
                string End = data["EndDate"] + " " + data["EndHour"] + ":" + data["EndMin"] + ":00";
                string Time = data["Time"];
                string Form = data["FormID"];
                string VersionID = data["VersionID"];
                string TeamsName = data["TeamsName"];
                string FieldsName = data["FieldsName"];
                string ExportType = data["ExportType"];

                ViewBag.ReportTable = BindReportData(FormID);

                if (Form != "" && VersionID != "")
                {
                    //Form Name: Test123
                    ExportReport(Form, VersionID, Start, End, Time, TeamsName, FieldsName, ExportType);
                    ViewBag.Fields = Form + '|' + VersionID + '|' + TeamsName + '|' + FieldsName;
                }

                ViewBag.FormName = FormName;
                ViewBag.Hour = new List<SelectListItem>() { new SelectListItem { Text = "00", Value = "00" }, new SelectListItem { Text = "01", Value = "01" }, new SelectListItem { Text = "02", Value = "02" }, new SelectListItem { Text = "03", Value = "03" }, new SelectListItem { Text = "04", Value = "04" }, new SelectListItem { Text = "05", Value = "05" }, new SelectListItem { Text = "06", Value = "06" }, new SelectListItem { Text = "07", Value = "07" }, new SelectListItem { Text = "08", Value = "08" }, new SelectListItem { Text = "09", Value = "09" }, new SelectListItem { Text = "10", Value = "10" }, new SelectListItem { Text = "11", Value = "11" }, new SelectListItem { Text = "12", Value = "12" }, new SelectListItem { Text = "13", Value = "13" }, new SelectListItem { Text = "14", Value = "14" }, new SelectListItem { Text = "15", Value = "15" }, new SelectListItem { Text = "16", Value = "16" }, new SelectListItem { Text = "17", Value = "17" }, new SelectListItem { Text = "18", Value = "18" }, new SelectListItem { Text = "19", Value = "19" }, new SelectListItem { Text = "20", Value = "20" }, new SelectListItem { Text = "21", Value = "21" }, new SelectListItem { Text = "22", Value = "22" }, new SelectListItem { Text = "23", Value = "23" } };
                ViewBag.Min = new List<SelectListItem>() { new SelectListItem { Text = "00", Value = "00" }, new SelectListItem { Text = "15", Value = "15" }, new SelectListItem { Text = "30", Value = "30" }, new SelectListItem { Text = "45", Value = "45" } };
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("CustomRealtimeReport - POST Load: " + ex.Message);
            }

            return View(objDataDump);
        }

        public ActionResult Report(string Form)
        {
            FormID = Form.Split('|')[0];
            FormName = Form.Split('|')[1];

            return RedirectToAction("Index");
        }

        public ActionResult BindReportData(string FormId)
        {
            DataSet objDataSet = new DataSet();
            string js = string.Empty;

            try
            {
                objReports.FormID = Convert.ToInt32(FormId);
                objReports.UserID = 0;
                objReports.Module = "FormVersions";
                objReports.StDate = null;
                objReports.EndDate = null;
                objDataSet = objReports.GetFormsForReports(objDataSet, "0");

                if (objDataSet.Tables[0].Rows.Count > 0)
                {
                    js = JsonConvert.SerializeObject(objDataSet.Tables[0]);
                }
                else
                {
                    TempData["error"] = "No Records Found.";
                    return null;
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Bind Report: " + ex.Message;
                ErrorLogger.logger.Error("CustomRealtimeReport - Bind Report: " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetFieldNames(string FormID, string VersionID)
        {
            DataSet objDataSet = new DataSet();
            string js = string.Empty;

            try
            {
                objForms.FormID = Convert.ToInt32(FormID);
                objForms.VersionID = Convert.ToInt32(VersionID);
                objDataSet = objForms.GetFormsFieldsWithVersions(objDataSet, true);

                if (objDataSet.Tables[0].Rows.Count > 0)
                {
                    js = JsonConvert.SerializeObject(objDataSet.Tables[0]);
                }
                else
                {
                    TempData["error"] = "No Records Found.";
                    return null;
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "FieldName: " + ex.Message;
                ErrorLogger.logger.Error("CustomRealtimeReport - FieldName: " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ExportReport(string FormID, string VersionID, string Start, string End, string Time, string TermsName, string FieldsName, string ExportType)
        {
            EvoGeneral objEvoGeneral = new EvoGeneral();
            System.IO.StringWriter oStringWriter = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter oHtmlTextWriter = new System.Web.UI.HtmlTextWriter(oStringWriter);

            try
            {
                string team = "";
                string teams = "";
                string fields = "";
                string colHead = "";

                string[] TermsList = TermsName.Split(',');
                string[] FieldsList = FieldsName.Split(',');

                for (int i = 0; i < TermsList.Length; i++)
                {
                    team = TermsList[i];
                    if (team == "Advisor")
                    {
                        teams += "EmployeeID,FirstName +' '+LastName AS EmpName,";
                        colHead += "EmployeeID,EmpName,";
                    }
                    if (team == "Team Coach")
                    {
                        teams += "TCEmpId, (CASE WHEN ET.TCEmpName = '' THEN 'NA' ELSE ET.TCEmpName END) AS TCEmpName,";
                        colHead += "TCEmpId, TCEmpName,";
                    }
                    else if (team == "Team Leader")
                    {
                        teams += "TLEmpId, TLEmpName,";
                        colHead += "TLEmpId, TLEmpName,";
                    }
                    else if (team == "Team Operations Manager")
                    {
                        teams += "TOMEmpId, TOMEmpName,";
                        colHead += "TOMEmpId, TOMEmpName,";

                    }
                    else if (team == "Contact Centre Manager")
                    {
                        teams += "CCMEmpId, CCMEmpName,";
                        colHead += "CCMEmpId, CCMEmpName,";
                    }
                }

                for (int j = 0; j < FieldsList.Length; j++)
                {
                    fields += "[" + FieldsList[j] + "],";
                }

                //if (teams != "")
                //{
                //    teams = teams.Substring(0, teams.Length - 1);
                //}
                teams = teams.Substring(0, teams.Length - 1);
                fields = fields.Substring(0, fields.Length - 1);
                colHead = colHead.Substring(0, colHead.Length - 1);

                DataSet objDataSet = new DataSet();
                objReports.FormID = Convert.ToInt32(FormID);
                objReports.VersionID = Convert.ToInt32(VersionID);
                objReports.ColumnName = fields;
                objReports.TeamName = teams;
                objReports.ColHeaders = colHead;
                objReports.StDate = Start;
                objReports.EndDate = End;
                objReports.IsGMT = (Time == "GMT");
                objDataSet = objReports.GetCustomRealtimeReport(objDataSet, objEvoGeneral.userName);

                if (objDataSet.Tables.Count > 0)
                {
                    if (objDataSet.Tables[0].Rows.Count == 0)
                    {
                        TempData["error"] = "Data not found for the selected criteria.";
                    }
                    else
                    {
                        switch (ExportType)
                        {
                            case "Excel":
                                ExcelHelper.ToExcel(objDataSet, "EVO_CustomRealtimeReport_" + FormID + "_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xls", HttpContext.ApplicationInstance.Response);
                                break;
                            case "Word":
                                DataExport.ToWord(objDataSet, "EVO_CustomRealtimeReport_" + FormID + "_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".doc", HttpContext.ApplicationInstance.Response);
                                break;
                            case "PDF":
                                DataExport.ToPDF(objDataSet, "EVO_CustomRealtimeReport_" + FormID + "_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".pdf", HttpContext.ApplicationInstance.Response);
                                break;
                            default:
                                ExcelHelper.ToExcel(objDataSet, "EVO_CustomRealtimeReport_" + FormID + "_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xls", HttpContext.ApplicationInstance.Response);
                                break;
                        }
                    }
                }
                else
                {
                    TempData["error"] = "Data not found for the selected criteria.";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Data not found.";
                ErrorLogger.logger.Error("CustomRealtimeReport - Data not found. " + ex.Message);
            }

            return new EmptyResult();
        }
    }
}