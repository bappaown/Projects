﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Configuration;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using System.Data.SqlClient;
using EVO_Upgrade.Filter;
using Microsoft.AspNet.Identity;

namespace HBCDeliveryForms.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        public ActionResult Index()
        {
            ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();

            return View();
        }

        [HttpPost]
        public ActionResult Submit(FormCollection collection)
        {
            try
            {
                //Authenticate User
                string userid = collection["userid"];
                string password = collection["password"];
                DataSet ds = UserAuthDataStore.GetAuthenticate(userid, password);
                if (ds != null)
                {
                    if (ds.Tables.Count > 0)
                    {
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            HttpCookie userCredentials = new HttpCookie("EVO");
                            userCredentials["AuthenticationType"] = "3";
                            userCredentials["CurrentUserName"] = ds.Tables[0].Rows[0]["NTLogin"].ToString();
                            userCredentials["userName"] = ds.Tables[0].Rows[0]["NTLogin"].ToString();
                            userCredentials["userType"] = ds.Tables[0].Rows[0]["RoleName"].ToString();
                            userCredentials["userEmailID"] = ds.Tables[0].Rows[0]["Email"].ToString();
                            userCredentials["userFullName"] = ds.Tables[0].Rows[0]["FirstName"].ToString() + " " + ds.Tables[0].Rows[0]["LastName"].ToString();
                            userCredentials["userDesignation"] = ds.Tables[0].Rows[0]["DesignationName"].ToString();
                            userCredentials["userEmployeeId"] = ds.Tables[0].Rows[0]["EmployeeID"].ToString();
                            //for departement name and id
                            userCredentials["userDeptID"] = ds.Tables[0].Rows[0]["DepartmentID"].ToString();
                            userCredentials["userDeptName"] = ds.Tables[0].Rows[0]["DepartmentName"].ToString();
                            //for CID - departement name and id
                            userCredentials["userCIDDeptID"] = ds.Tables[0].Rows[0]["DepartmentID"].ToString();
                            userCredentials["userCIDDeptName"] = ds.Tables[0].Rows[0]["DepartmentName"].ToString();
                            //Location
                            userCredentials["userLocation"] = ds.Tables[0].Rows[0]["Location"].ToString();
                            //Rep man
                            userCredentials["userBoss1ID"] = ds.Tables[0].Rows[0]["Boss1Id"].ToString();
                            userCredentials["userBoss1Name"] = ds.Tables[0].Rows[0]["Boss1Name"].ToString();
                            //Rev Man
                            userCredentials["userBoss2Id"] = ds.Tables[0].Rows[0]["Boss2Id"].ToString();
                            userCredentials["userBoss2Name"] = ds.Tables[0].Rows[0]["Boss2Name"].ToString();

                            if (!HttpContext.Response.IsRequestBeingRedirected)
                                Response.AppendCookie(userCredentials);

                            return RedirectToAction("Index", "Home");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Not authorised for this application.";
                ErrorLogger.logger.Error("Login - Not authorised for this application. " + ex.Message);
            }

            TempData["error"] = "Invalid userid or password.";

            return RedirectToAction("Index");
        }
    }
}