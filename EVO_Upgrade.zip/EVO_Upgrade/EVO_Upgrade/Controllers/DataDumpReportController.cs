﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using EVO_Upgrade.Filter;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class DataDumpReportController : Controller
    {
        Reports objReports = new Reports();
        ReportModel objDataDump = null;
        private static string FormID = string.Empty;
        private static string FormName = string.Empty;

        // GET: DataDumpReport
        public ActionResult Index()
        {
            try
            {
                ViewBag.ReportTable = null;
                ViewBag.JS = true;
                ViewBag.FormName = FormName;
                ViewBag.Hour = new List<SelectListItem>() { new SelectListItem { Text = "00", Value = "00" }, new SelectListItem { Text = "01", Value = "01" }, new SelectListItem { Text = "02", Value = "02" }, new SelectListItem { Text = "03", Value = "03" }, new SelectListItem { Text = "04", Value = "04" }, new SelectListItem { Text = "05", Value = "05" }, new SelectListItem { Text = "06", Value = "06" }, new SelectListItem { Text = "07", Value = "07" }, new SelectListItem { Text = "08", Value = "08" }, new SelectListItem { Text = "09", Value = "09" }, new SelectListItem { Text = "10", Value = "10" }, new SelectListItem { Text = "11", Value = "11" }, new SelectListItem { Text = "12", Value = "12" }, new SelectListItem { Text = "13", Value = "13" }, new SelectListItem { Text = "14", Value = "14" }, new SelectListItem { Text = "15", Value = "15" }, new SelectListItem { Text = "16", Value = "16" }, new SelectListItem { Text = "17", Value = "17" }, new SelectListItem { Text = "18", Value = "18" }, new SelectListItem { Text = "19", Value = "19" }, new SelectListItem { Text = "20", Value = "20" }, new SelectListItem { Text = "21", Value = "21" }, new SelectListItem { Text = "22", Value = "22" }, new SelectListItem { Text = "23", Value = "23" } };
                ViewBag.Min = new List<SelectListItem>() { new SelectListItem { Text = "00", Value = "00" }, new SelectListItem { Text = "15", Value = "15" }, new SelectListItem { Text = "30", Value = "30" }, new SelectListItem { Text = "45", Value = "45" } };
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("DataDumpReport - GET Load: " + ex.Message);
            }

            return View();
        }

        [HttpPost]
        public ActionResult Index(FormCollection data)
        {
            try
            {
                objDataDump = new ReportModel();
                objDataDump.StartDate = data["StartDate"];
                objDataDump.StartHour = data["StartHour"];
                objDataDump.StartMin = data["StartMin"];
                objDataDump.EndDate = data["EndDate"];
                objDataDump.EndHour = data["EndHour"];
                objDataDump.EndMin = data["EndMin"];
                objDataDump.Time = data["Time"];

                string Start = data["StartDate"] + " " + data["StartHour"] + ":" + data["StartMin"] + ":00";
                string End = data["EndDate"] + " " + data["EndHour"] + ":" + data["EndMin"] + ":00";
                string Time = data["Time"];
                string Form = data["FormID"];
                string VersionID = data["VersionID"];
                string ExportType = data["ExportType"];

                //Form Name: Test123, Start Date: 01-Nov-2018
                ViewBag.ReportTable = BindReportData(Start, End);

                if (Form != "" && VersionID != "")
                {
                    ExportReport(Form, VersionID, Start, End, Time, ExportType);
                }

                ViewBag.FormName = FormName;
                ViewBag.Hour = new List<SelectListItem>() { new SelectListItem { Text = "00", Value = "00" }, new SelectListItem { Text = "01", Value = "01" }, new SelectListItem { Text = "02", Value = "02" }, new SelectListItem { Text = "03", Value = "03" }, new SelectListItem { Text = "04", Value = "04" }, new SelectListItem { Text = "05", Value = "05" }, new SelectListItem { Text = "06", Value = "06" }, new SelectListItem { Text = "07", Value = "07" }, new SelectListItem { Text = "08", Value = "08" }, new SelectListItem { Text = "09", Value = "09" }, new SelectListItem { Text = "10", Value = "10" }, new SelectListItem { Text = "11", Value = "11" }, new SelectListItem { Text = "12", Value = "12" }, new SelectListItem { Text = "13", Value = "13" }, new SelectListItem { Text = "14", Value = "14" }, new SelectListItem { Text = "15", Value = "15" }, new SelectListItem { Text = "16", Value = "16" }, new SelectListItem { Text = "17", Value = "17" }, new SelectListItem { Text = "18", Value = "18" }, new SelectListItem { Text = "19", Value = "19" }, new SelectListItem { Text = "20", Value = "20" }, new SelectListItem { Text = "21", Value = "21" }, new SelectListItem { Text = "22", Value = "22" }, new SelectListItem { Text = "23", Value = "23" } };
                ViewBag.Min = new List<SelectListItem>() { new SelectListItem { Text = "00", Value = "00" }, new SelectListItem { Text = "15", Value = "15" }, new SelectListItem { Text = "30", Value = "30" }, new SelectListItem { Text = "45", Value = "45" } };
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("DataDumpReport - POST Load: " + ex.Message);
            }

            return View(objDataDump);
        }

        public ActionResult Report(string Form)
        {
            FormID = Form.Split('|')[0];
            FormName = Form.Split('|')[1];

            return RedirectToAction("Index");
        }

        public ActionResult BindReportData(string Start, string End)
        {
            DataSet objDataSet = new DataSet();
            string js = string.Empty;

            try
            {
                objReports.FormID = Convert.ToInt32(FormID);
                objReports.UserID = 0;
                objReports.Module = "FormVersions";
                objReports.StDate = Start;
                objReports.EndDate = End;

                objDataSet = objReports.GetFormsForReports(objDataSet, "0");

                if (objDataSet.Tables[0].Rows.Count > 0)
                {
                    js = JsonConvert.SerializeObject(objDataSet.Tables[0]);
                }
                else
                {
                    TempData["error"] = "No Records Found.";
                    return null;
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Bind Report: " + ex.Message;
                ErrorLogger.logger.Error("DataDumpReport - Bind Report: " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult ExportReport(string FormID, string VersionID, string Start, string End, string Time, string ExportType)
        {
            EvoGeneral objEvoGeneral = new EvoGeneral();
            System.IO.StringWriter oStringWriter = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter oHtmlTextWriter = new System.Web.UI.HtmlTextWriter(oStringWriter);
            string js = string.Empty;

            try
            {
                DataSet objDataSet = new DataSet();

                objReports.FormID = Convert.ToInt32(FormID);
                objReports.VersionID = Convert.ToInt32(VersionID);
                objReports.StDate = Start;
                objReports.EndDate = End;
                objReports.IsGMT = (Time == "GMT");
                objDataSet = objReports.GetDataDumpReport(objDataSet, objEvoGeneral.userName);

                if (objDataSet.Tables.Count > 0)
                {
                    if (objDataSet.Tables[0].Rows.Count == 0)
                    {
                        TempData["error"] = "Data not found for the selected date/time range.";
                    }
                    else
                    {
                        switch (ExportType)
                        {
                            case "Excel":
                                ExcelHelper.ToExcel(objDataSet, "EVO_DataDump_" + FormID + "_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xls", HttpContext.ApplicationInstance.Response);
                                break;
                            case "Word":
                                DataExport.ToWord(objDataSet, "EVO_DataDump_" + FormID + "_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".doc", HttpContext.ApplicationInstance.Response);
                                break;
                            case "PDF":
                                DataExport.ToPDF(objDataSet, "EVO_DataDump_" + FormID + "_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".pdf", HttpContext.ApplicationInstance.Response);
                                break;
                            default:
                                ExcelHelper.ToExcel(objDataSet, "EVO_DataDump_" + FormID + "_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xls", HttpContext.ApplicationInstance.Response);
                                break;
                        }
                    }
                }
                else
                {
                    TempData["error"] = "Data not found for the selected date/time range.";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Data not found.";
                ErrorLogger.logger.Error("DataDumpReport - Data not found. " + ex.Message);
            }
            finally
            {
                oHtmlTextWriter.Close();
                oStringWriter.Close();
            }

            return new EmptyResult();
        }

    }
}