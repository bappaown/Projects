﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using System.Data.SqlClient;
using EVO_Upgrade.Filter;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class ConfigSettingController : Controller
    {
        private static int currentPageNumber = 1;
        private static int PAGE_SIZE = 10;

        // GET: ConfigSetting
        public ActionResult Index()
        {
            try
            {
                ViewBag.AdminTable = FillGrid(currentPageNumber, PAGE_SIZE);
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("ConfigSetting - Load: " + ex.Message);
            }
            return View();
        }


        public ActionResult FillGrid(int currentPage, int size)
        {
            AdminConfigSetting ObjAdminConfigSetting = new AdminConfigSetting();
            string js = string.Empty;
            DataSet ds = new DataSet();
            currentPageNumber = currentPage;
            PAGE_SIZE = size;
            try
            {
                ds = ObjAdminConfigSetting.GetAdminConfigDetail(currentPageNumber, PAGE_SIZE);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    js = JsonConvert.SerializeObject(ds.Tables[0]);
                }

                double totalRows = (int)ObjAdminConfigSetting.TotalRows;
                int totalPages = (int)Math.Ceiling(totalRows / PAGE_SIZE);

                ViewBag.currentPage = currentPageNumber;
                ViewBag.totalPage = totalPages;
            }
            catch (Exception ex)
            {
                TempData["error"] = "FillGrid: " + ex.Message;
                ErrorLogger.logger.Error("ConfigSetting - FillGrid: " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult PagingGrid(int currentPage, int size)
        {
            currentPageNumber = currentPage;
            PAGE_SIZE = size;

            return RedirectToAction("Index");
        }

        [HttpPost]
        public ActionResult Submit(SuperAdmin model)
        {
            AdminConfigSetting ObjAdminConfigSetting = new AdminConfigSetting();
            EvoGeneral objEvoGeneral = new EvoGeneral();
            try
            {
                if (ModelState.IsValid)
                {
                    bool isStatus = false;
                    string NTName = objEvoGeneral.userName;
                    ObjAdminConfigSetting.ConfigName = model.AdminUser.Trim();
                    ObjAdminConfigSetting.ConfigValue = model.Admin;
                    ObjAdminConfigSetting.AddedBy = NTName;
                    ObjAdminConfigSetting.UserAllowed = 5;
                    isStatus = ObjAdminConfigSetting.AddConfig();
                    if (isStatus == true)
                    {
                        TempData["error"] = "Record added successfully.";
                    }
                    else
                    {
                        TempData["error"] = "Duplicate data found.";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Error during submitted the record. " + ex.Message;
                ErrorLogger.logger.Error("ConfigSetting - Error during submitted the record. " + ex.Message);
            }
            finally
            {
                ObjAdminConfigSetting = null;
            }

            return RedirectToAction("Index");
        }

        public ActionResult Delete(int configID)
        {
            bool isStatus = false;
            AdminConfigSetting ObjAdminConfigSetting = new AdminConfigSetting();
            try
            {
                ObjAdminConfigSetting.ConfigId = configID;
                isStatus = ObjAdminConfigSetting.DeleteConfig();
                if (isStatus == true)
                {
                    TempData["error"] = "Record deleted successfully.";
                }
                else
                {
                    TempData["error"] = "Could not delete record.";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Error during deleting the record. " + ex.Message;
                ErrorLogger.logger.Error("ConfigSetting - Error during deleting the record. " + ex.Message);
            }
            finally
            {
                ObjAdminConfigSetting = null;
            }

            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Update(int configID, string Title, int Value)
        {
            bool isStatus = false;
            AdminConfigSetting ObjAdminConfigSetting = new AdminConfigSetting();
            try
            {
                ObjAdminConfigSetting.ConfigId = configID;
                ObjAdminConfigSetting.ConfigName = Title.Trim();
                ObjAdminConfigSetting.ConfigValue = Value;
                ObjAdminConfigSetting.UserAllowed = 5;
                isStatus = ObjAdminConfigSetting.UpdateConfig();
                if (isStatus == true)
                {
                    TempData["error"] = "Record updated successfully.";
                }
                else
                {
                    TempData["error"] = "Record not updated.";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Error during updating the record. " + ex.Message;
                ErrorLogger.logger.Error("ConfigSetting - Error during updating the record. " + ex.Message);
            }
            finally
            {
                ObjAdminConfigSetting = null;
            }

            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }
    }
}