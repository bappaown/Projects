﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using System.Configuration;
using EVO_Upgrade.Filter;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class ManageReportsController : Controller
    {
        EvoGeneral objEvoGeneral = new EvoGeneral();
        Forms objForms = new Forms();
        Reports objReports = new Reports();
        private static int currentPageNumber = 1;
        private static int PAGE_SIZE = 10;

        public ManageReportsController()
        {
            EvoGeneral objEvoGeneral = new EvoGeneral();

            if (objEvoGeneral.userName != "")
            {
                string NTName = objEvoGeneral.userName;
                string DashBoard = ConfigurationManager.AppSettings["DashBoardAdmin"].ToString();
                if (DashBoard.Contains(NTName))
                {
                    ViewBag.DashBoard = true;
                }
            }
            else
            {
                RedirectToAction("Login", "Home");
            }
        }

        // GET: ManageReports
        public ActionResult Index()
        {
            try
            {
                currentPageNumber = 1;
                PAGE_SIZE = 10;
                ViewBag.ReportTable = FillGrid(currentPageNumber, PAGE_SIZE);
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("ManageReports - GET Load: " + ex.Message);
            }

            return View();
        }

        [HttpPost]
        public ActionResult Index(FormCollection data)
        {
            try
            {
                currentPageNumber = (data["Page"] == "") ? 1 : Convert.ToInt32(data["Page"]);
                PAGE_SIZE = (data["Size"] == "") ? 10 : Convert.ToInt32(data["Size"]);
                string Title = (data["txtTitle"] == null) ? "" : data["txtTitle"];
                bool isDTMS = (data["isDTMS"] == null) ? false : Convert.ToBoolean(data["isDTMS"].Split(',')[0]);

                ViewBag.ReportTable = SearchData(currentPageNumber, PAGE_SIZE, Title, isDTMS);

                string[] value = { Title, isDTMS.ToString().ToLower() };
                ViewBag.JS = value;
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("ManageReports - POST Load: " + ex.Message);
            }

            return View();
        }

        public ActionResult FillGrid(int currentPage, int size)
        {
            string js = string.Empty;
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            currentPageNumber = currentPage;
            PAGE_SIZE = size;
            try
            {
                string NTName = objEvoGeneral.userName;
                objReports.UserID = objEvoGeneral.RetrieveUserID(NTName);
                objReports.Module = "Reports";
                objReports.FormID = 0;
                string reporttype = "0";

                ds = objReports.GetFormsForReports(ds, reporttype);

                if (ds.Tables[0].Rows.Count > 0)
                {
                    dt = ds.Tables[0].Clone();
                    int RowNumber = (currentPage - 1) * size;
                    int PageNumber = (ds.Tables[0].Rows.Count > (currentPage * size)) ? (currentPage * size) : ds.Tables[0].Rows.Count;

                    for (int i = RowNumber; i < PageNumber; i++)
                    {
                        ds.Tables[0].Rows[i]["IsEditable"] = (ds.Tables[0].Rows[i]["IsEditable"].ToString() == "") ? "False" : ds.Tables[0].Rows[i]["IsEditable"].ToString();
                        dt.ImportRow(ds.Tables[0].Rows[i]);
                    }

                    js = JsonConvert.SerializeObject(dt);

                    double totalRows = ds.Tables[0].Rows.Count;
                    int totalPages = (int)Math.Ceiling(totalRows / PAGE_SIZE);

                    ViewBag.currentPage = currentPage;
                    ViewBag.totalPage = totalPages;
                }
                else
                {
                    ViewBag.currentPage = 1;
                    ViewBag.totalPage = 1;
                    TempData["error"] = "No Records Found.";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "FillGrid: " + ex.Message;
                ErrorLogger.logger.Error("ManageReports - FillGrid: " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult SearchData(int currentPage, int size, string Title, bool isDTMS)
        {
            string js = string.Empty;
            DataSet ds = new DataSet();
            DataTable dt = new DataTable();
            DataTable df = new DataTable();
            currentPageNumber = currentPage;
            PAGE_SIZE = size;
            try
            {
                string NTName = objEvoGeneral.userName;
                objReports.UserID = objEvoGeneral.RetrieveUserID(NTName);
                objReports.Module = "Reports";
                objReports.FormID = 0;
                string reporttype = "0";
                if (isDTMS == true)
                {
                    reporttype = "1";
                }
                ds = objReports.GetFormsForReports(ds, reporttype);

                if (Title != "")
                {
                    ds.Tables[0].DefaultView.RowFilter = "FormName Like '%" + Title + "%'";
                    if (ds.Tables[0].DefaultView.Count > 0)
                    {
                        df = ds.Tables[0].Clone();
                        dt = ds.Tables[0].DefaultView.ToTable();
                        int RowNumber = (currentPage - 1) * size;
                        int PageNumber = (dt.Rows.Count > (currentPage * size)) ? (currentPage * size) : dt.Rows.Count;

                        for (int i = RowNumber; i < PageNumber; i++)
                        {
                            dt.Rows[i]["IsEditable"] = (dt.Rows[i]["IsEditable"].ToString() == "") ? "False" : dt.Rows[i]["IsEditable"].ToString();
                            df.ImportRow(dt.Rows[i]);
                        }

                        js = JsonConvert.SerializeObject(df);

                        double totalRows = dt.Rows.Count;
                        int totalPages = (int)Math.Ceiling(totalRows / size);

                        ViewBag.currentPage = currentPageNumber;
                        ViewBag.totalPage = totalPages;
                    }
                    else
                    {
                        ViewBag.currentPage = 1;
                        ViewBag.totalPage = 1;
                        TempData["error"] = "No Records Found.";
                    }
                }
                else
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        dt = ds.Tables[0].Clone();
                        int RowNumber = (currentPage - 1) * size;
                        int PageNumber = (ds.Tables[0].Rows.Count > (currentPage * size)) ? (currentPage * size) : ds.Tables[0].Rows.Count;

                        for (int i = RowNumber; i < PageNumber; i++)
                        {
                            ds.Tables[0].Rows[i]["IsEditable"] = (ds.Tables[0].Rows[i]["IsEditable"].ToString() == "") ? "False" : ds.Tables[0].Rows[i]["IsEditable"].ToString();
                            dt.ImportRow(ds.Tables[0].Rows[i]);
                        }

                        js = JsonConvert.SerializeObject(dt);

                        double totalRows = ds.Tables[0].Rows.Count;
                        int totalPages = (int)Math.Ceiling(totalRows / PAGE_SIZE);

                        ViewBag.currentPage = currentPage;
                        ViewBag.totalPage = totalPages;
                    }
                    else
                    {
                        ViewBag.currentPage = 1;
                        ViewBag.totalPage = 1;
                        TempData["error"] = "No Records Found.";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Something went wrong. " + ex.Message;
                ErrorLogger.logger.Error("ManageReports - Something went wrong. " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult PagingGrid(int currentPage, int size)
        {
            currentPageNumber = currentPage;
            PAGE_SIZE = size;

            return RedirectToAction("Index");
        }

        public ActionResult BindDashBoard()
        {
            DataSet objDataSet = new DataSet();
            string js = string.Empty;
            objDataSet = objReports.GetDashBoardReport(objDataSet);

            if (objDataSet.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(objDataSet.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }
    }
}