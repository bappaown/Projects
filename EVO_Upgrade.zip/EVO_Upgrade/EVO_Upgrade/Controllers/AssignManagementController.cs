﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using System.Data.SqlClient;
using EVO_Upgrade.Filter;
using System.Drawing.Text;
using System.Drawing;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class AssignManagementController : Controller
    {
        EvoGeneral objEvoGeneral = new EvoGeneral();
        EvoAdminUsersRights ObjUserRights = new EvoAdminUsersRights();
        private static string FormId = string.Empty;
        private static string VersionId = string.Empty;
        private static string Form = string.Empty;
        private static string CategoryId = string.Empty;

        // GET: AssignManagement
        public ActionResult Index()
        {
            try
            {
                InstalledFontCollection fontList = new InstalledFontCollection();
                IDictionary<string, string> myList = new Dictionary<string, string>();
                foreach (FontFamily family in fontList.Families)
                {
                    myList.Add(family.Name, family.Name);
                }
                ViewBag.FontList = myList;
                ViewBag.FontSize = new List<SelectListItem>() { new SelectListItem { Text = "8px", Value = "8px" }, new SelectListItem { Text = "9px", Value = "9px" }, new SelectListItem { Text = "10px", Value = "10px" }, new SelectListItem { Text = "11px", Value = "11px" }, new SelectListItem { Text = "12px", Value = "12px" }, new SelectListItem { Text = "14px", Value = "14px" }, new SelectListItem { Text = "16px", Value = "16px" }, new SelectListItem { Text = "18px", Value = "18px" }, new SelectListItem { Text = "20px", Value = "20px" }, new SelectListItem { Text = "22px", Value = "22px" }, new SelectListItem { Text = "24px", Value = "24px" }, new SelectListItem { Text = "26px", Value = "26px" }, new SelectListItem { Text = "28px", Value = "28px" }, new SelectListItem { Text = "36px", Value = "36px" }, new SelectListItem { Text = "48px", Value = "48px" }, new SelectListItem { Text = "72px", Value = "72px" } };

                if (CategoryId != "4")
                {
                    ViewBag.TempleteList = GetAssignTempleteList();
                    ViewBag.TempleteId = GetSelectedTemplete();
                    ViewBag.FormLayout = GetSelectedLayout();
                }
                else
                {
                    ViewBag.TempleteList = new Dictionary<int, string>();
                }

                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("AssignManagement - Load: " + ex.Message);
            }

            return View();
        }

        public ActionResult EditMode(string FormID, string VersionID, string FormName, string CategoryID)
        {
            FormId = FormID;
            VersionId = VersionID;
            Form = FormName;
            CategoryId = CategoryID;

            return RedirectToAction("Index");
        }

        [NonAction]
        private IDictionary<int, string> GetAssignTempleteList()
        {
            IDictionary<int, string> myList = new Dictionary<int, string>();
            try
            {
                DataSet ds = new DataSet();
                ds = objEvoGeneral.GetTemplateForms();

                if (ds.Tables[0].Rows.Count > 0)
                {
                    myList = ds.Tables[0].AsEnumerable().ToDictionary<DataRow, int, string>(row => Convert.ToInt32(row[0].ToString()), row => row[1].ToString());
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "FillTemplete: " + ex.Message;
                ErrorLogger.logger.Error("AssignManagement - FillTemplete: " + ex.Message);
            }

            return myList;
        }

        [NonAction]
        public string GetSelectedTemplete()
        {
            string TempleteId = "0";
            try
            {
                DataSet dscontrol = new DataSet();
                ObjUserRights.FormId = int.Parse(FormId);
                ObjUserRights.VersionId = int.Parse(VersionId);
                dscontrol = ObjUserRights.GetXMLFileName();

                if (dscontrol.Tables.Count > 0)
                {
                    if (dscontrol.Tables[0].Rows.Count > 0)
                    {
                        TempleteId = dscontrol.Tables[0].Rows[0]["TempleteID"].ToString();
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "GetTemplete: " + ex.Message;
                ErrorLogger.logger.Error("AssignManagement - GetTemplete: " + ex.Message);
            }

            return TempleteId;
        }

        [NonAction]
        public string GetSelectedLayout()
        {
            string style = string.Empty;
            try
            {
                DataSet ds = DesignManagement.GetFormLayoutConfiguration(Convert.ToInt32(FormId), Convert.ToInt32(VersionId));
                if (ds.Tables[0].Rows.Count > 0)
                {
                    style += ds.Tables[0].Rows[0]["BackgroundImage"].ToString() + "|";
                    style += ds.Tables[0].Rows[0]["BackgroundColor"].ToString() + "|";
                    style += ds.Tables[0].Rows[0]["FontFamily"].ToString() + "|";
                    style += ds.Tables[0].Rows[0]["FontSize"].ToString() + "|";
                    style += ds.Tables[0].Rows[0]["FontColor"].ToString();
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "GetLayout: " + ex.Message;
                ErrorLogger.logger.Error("AssignManagement - GetLayout: " + ex.Message);
            }

            return style;
        }

        [HttpPost]
        public ActionResult Submit(FormCollection collection)
        {
            try
            {
                int TempleteId = (collection["selectedTemplete"] == "") ? 0 : Convert.ToInt32(collection["selectedTemplete"]);
                string BackgroundImage = collection["backgroundImage"];
                string BackgroundColor = collection["backgroundColor"];
                string FontFamily = collection["fontFamily"];
                string FontSize = collection["fontSize"];
                string FontColor = collection["fontColor"];

                bool check = false;

                check = DesignManagement.SaveLayoutConfiguration(Convert.ToInt32(FormId), Convert.ToInt32(VersionId), TempleteId, BackgroundImage, BackgroundColor, FontFamily, FontSize, FontColor);
                //check = DesignManagement.UpdateFormTemplete(Convert.ToInt32(FormId), Convert.ToInt32(VersionId), TempleteId);
                if (check)
                {
                    var js = new { FormID = FormId, VersionID = VersionId, FormName = Form, CategoryID = CategoryId };
                    return Json(js, JsonRequestBehavior.AllowGet);
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Save: " + ex.Message;
                ErrorLogger.logger.Error("AssignManagement - Save: " + ex.Message);
            }

            return new EmptyResult();
        }


        [HttpGet]
        public ActionResult Submit()
        {
            return RedirectToAction("EditMode", "ControlManagement", new { FormID = FormId, VersionID = VersionId, FormName = Form, CategoryID = CategoryId });
        }
    }
}