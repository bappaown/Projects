﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using System.Data.SqlClient;
using EVO_Upgrade.Filter;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class RightsManagementController : Controller
    {
        EvoAdminUsersRights ObjUserRights = new EvoAdminUsersRights();
        private static string FormId = string.Empty;
        private static string VersionId = string.Empty;
        private static string Form = string.Empty;
        private static string CategoryId = string.Empty;

        // GET: RightsManagement
        public ActionResult Index()
        {
            try
            {
                if (!IsValidUser())
                {
                    return RedirectToAction("Unauthorized", "Home");
                }

                ViewBag.CostCentre = FillCostCentres();
                ViewBag.AdminTable = FillGridUserRights();
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("RightsManagement - Load: " + ex.Message);
            }

            return View();
        }

        public ActionResult EditMode(string FormID, string VersionID, string FormName, string CategoryID)
        {
            FormId = FormID;
            VersionId = VersionID;
            Form = FormName;
            CategoryId = CategoryID;

            return RedirectToAction("Index");
        }

        [NonAction]
        private bool IsValidUser()
        {
            Boolean IsValid = false;
            try
            {
                EvoGeneral objEvoGeneral = new EvoGeneral();
                string NTName = objEvoGeneral.userName;
                ObjUserRights.UserID = objEvoGeneral.RetrieveUserID(NTName);
                ObjUserRights.FormId = int.Parse(FormId);
                ObjUserRights.VersionId = int.Parse(VersionId);
                IsValid = ObjUserRights.ValidateAdminManageUser();
            }
            catch (Exception ex)
            {
                TempData["error"] = "No data found for this loginid. " + ex.Message;
                ErrorLogger.logger.Error("RightsManagement - No data found for this loginid. " + ex.Message);
            }

            return IsValid;
        }

        [NonAction]
        private IDictionary<int, string> FillCostCentres()
        {
            IDictionary<int, string> myList = new Dictionary<int, string>();
            try
            {
                DataSet ds = new DataSet();
                ds = ObjUserRights.GetCostCentres();

                if (ds.Tables[0].Rows.Count > 0)
                {
                    myList = ds.Tables[0].AsEnumerable().ToDictionary<DataRow, int, string>(row => Convert.ToInt32(row[0].ToString()), row => row[1].ToString());
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Fill CostCentre: " + ex.Message;
                ErrorLogger.logger.Error("RightsManagement - Fill CostCentre: " + ex.Message);
            }

            return myList;
        }

        public ActionResult FillGridUserRights()
        {
            string js = string.Empty;
            DataSet ds = new DataSet();

            try
            {
                if (FormId != "" && VersionId != "")
                {
                    ObjUserRights.FormId = int.Parse(FormId);
                    ObjUserRights.VersionId = int.Parse(VersionId);
                    ds = ObjUserRights.GetUsersRights();
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        js = JsonConvert.SerializeObject(ds.Tables[0]);
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "FillGrid: " + ex.Message;
                ErrorLogger.logger.Error("RightsManagement - FillGrid: " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult BindSkillSets(int CostCentre)
        {
            string js = string.Empty;
            DataSet ds = new DataSet();

            ObjUserRights.CostCentreId = CostCentre;
            ds = ObjUserRights.GetCostCentresDepartments();

            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetSelectedName(int CostCentre, int Department, string FilterName)
        {
            string js = string.Empty;
            DataSet ds = new DataSet();

            ObjUserRights.CostCentreId = CostCentre;
            ObjUserRights.DepartmentId = Department;
            ds = ObjUserRights.GetFilteredUserName(FilterName.Trim());

            if (ds.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(ds.Tables[0]);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public ActionResult Submit(RightsManagement model)
        {
            EvoGeneral objEvoGeneral = new EvoGeneral();
            try
            {
                if (ModelState.IsValid)
                {
                    if (FormId != "" && VersionId != "")
                    {
                        string userids = String.Join(",", model.SelectedName.Select(e => e.ToString()).ToArray());

                        ObjUserRights.UserLogin = objEvoGeneral.userName;
                        ObjUserRights.CanManage = model.EditForm;
                        ObjUserRights.IsLimerickReportsAccess = model.LimerickReports;
                        ObjUserRights.IsWaterfordReportsAccess = model.WaterfordReports;
                        ObjUserRights.IsMumbaiReportsAccess = model.MumbaiReports;
                        ObjUserRights.UserIDs = userids;
                        ObjUserRights.FormId = Convert.ToInt32(FormId);
                        ObjUserRights.VersionId = Convert.ToInt32(VersionId);

                        int retVal = ObjUserRights.InsertUserAccessRights();

                        if (retVal == 1)
                        {
                            TempData["error"] = "The User(s) has been Added successfully as a Sub Admin for this form.";
                        }
                        else if (retVal == 2)
                        {
                            TempData["error"] = "User(s) Already exists as a Super Admin.";
                        }
                        else if (retVal == 3)
                        {
                            TempData["error"] = "User(s) Already exists as a Sub Admin for this form.";
                        }
                        else if (retVal == 4)
                        {
                            TempData["error"] = "User(s) Already exists as an Admin.";
                        }
                    }
                    else
                    {
                        TempData["error"] = "Error during submitted the record.";
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Error during submitted the record. " + ex.Message;
                ErrorLogger.logger.Error("RightsManagement - Error during submitted the record. " + ex.Message);
            }

            return RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Submit()
        {
            return RedirectToAction("Index", "ModifyForm");
        }

        public ActionResult Delete(int AccessRightId)
        {
            bool isStatus = false;
            try
            {
                ObjUserRights.IsActive = false;
                ObjUserRights.AccessRightId = AccessRightId;
                isStatus = ObjUserRights.DeleteUserAccessRights();

                if (isStatus == true)
                {
                    TempData["error"] = "The record has been deleted successfully.";
                }
                else
                {
                    TempData["error"] = "Could not delete record.";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Error during deleting the record. " + ex.Message;
                ErrorLogger.logger.Error("RightsManagement - Error during deleting the record. " + ex.Message);
            }

            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Update(int AccessRightId, bool CanManage, bool LimerickReports, bool WaterfordReports, bool MumbaiReports)
        {
            bool isStatus = false;
            try
            {
                ObjUserRights.CanManage = CanManage;
                ObjUserRights.IsLimerickReportsAccess = LimerickReports;
                ObjUserRights.IsWaterfordReportsAccess = WaterfordReports;
                ObjUserRights.IsMumbaiReportsAccess = MumbaiReports;
                ObjUserRights.AccessRightId = AccessRightId;
                isStatus = ObjUserRights.UpdateUserAccessRights();

                if (isStatus == true)
                {
                    TempData["error"] = "Record updated successfully.";
                }
                else
                {
                    TempData["error"] = "Record not updated.";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Error during update the record." + ex.Message;
                ErrorLogger.logger.Error("RightsManagement - Error during update the record. " + ex.Message);
            }

            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }

    }
}