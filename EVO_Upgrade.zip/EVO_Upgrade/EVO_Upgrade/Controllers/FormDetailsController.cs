﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using System.Data.SqlClient;
using EVO_Upgrade.Filter;
using System.IO;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    //[AuthenticationFilter]
    public class FormDetailsController : Controller
    {
        EvoAdminUsersRights ObjUserRights = new EvoAdminUsersRights();
        EvoGeneral objEvoGeneral = new EvoGeneral();
        EvoMain objEvoMain = new EvoMain();
        Forms objform = new Forms();
        private static string FormId = string.Empty;
        private static string VersionId = string.Empty;
        private static string Form = string.Empty;
        private static string CategoryId = string.Empty;
        private static int TransactionID = 0;
        private static bool isUpdate = false;
        private static bool isTemplate = false;
        private static List<object> TemplateList = null;
        private static string TemplateFormId = string.Empty;
        private static string TemplateVersionId = string.Empty;


        // GET: FormDetails
        public ActionResult Index()
        {
            try
            {
                ViewBag.Header = Form;
                ViewBag.Parameter = GetParameterList();
                ViewBag.isUpdate = isUpdate;
                GetLoggedDetails();
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("FormDetails - Load: " + ex.Message);
            }

            return View();
        }

        public ActionResult Details(string FormID, string VersionID, string FormName, string CategoryID)
        {
            FormId = FormID;
            VersionId = VersionID;
            Form = FormName;
            CategoryId = CategoryID;
            isTemplate = false;
            TemplateFormId = "";
            TemplateVersionId = "";

            return RedirectToAction("Index");
        }

        [NonAction]
        public void GetLoggedDetails()
        {
            DataSet empDetailsDataSet = new DataSet();
            DataSet objds = new DataSet();
            DataSet objDataSet = new DataSet();
            DataSet ds = new DataSet();

            try
            {
                //Get Login Details
                empDetailsDataSet = objEvoGeneral.GetEmployeeInfo(objEvoGeneral.userName, FormId);
                if (empDetailsDataSet.Tables[0].Rows.Count > 0)
                {
                    ViewBag.loginName = empDetailsDataSet.Tables["EmpDetails"].Rows[0]["EmpName"].ToString();
                    ViewBag.lineManager = empDetailsDataSet.Tables["EmpDetails"].Rows[0]["Boss1Name"].ToString();
                    ViewBag.salesCount = empDetailsDataSet.Tables["SalesCount"].Rows[0]["TransID"].ToString();
                }
                else
                {
                    ViewBag.ErrorMessage = "Employee dosen't exist.";
                }

                //Check Is Editable
                objds = objEvoMain.CheckForIsEditable(Convert.ToInt32(FormId));
                if (Convert.ToBoolean(objds.Tables[0].Rows[0]["isEditable"].ToString() == "" ? "false" : objds.Tables[0].Rows[0]["isEditable"].ToString()) == true && isTemplate == false)
                {
                    ViewBag.isEditable = true;
                }

                objform.LoggedInUser = objEvoGeneral.userName;
                objDataSet = objform.GetFormsAsPerUser(objDataSet);
                if (objDataSet.Tables[0].Rows.Count > 0)
                {
                    DataRow[] formsDataRow = objDataSet.Tables[0].Select("FormID = " + FormId + " And VersionID = " + VersionId.ToString());
                    if (formsDataRow.Length > 0)
                    {
                        ViewBag.isScrabblePad = Convert.ToBoolean(formsDataRow[0]["IsScrabblePad"].ToString() == "" ? "false" : formsDataRow[0]["IsScrabblePad"].ToString());
                    }
                }

                ds = DesignManagement.GetFormLayoutConfiguration(Convert.ToInt32(FormId), Convert.ToInt32(VersionId));
                if (ds.Tables[0].Rows.Count > 0)
                {
                    string style = "";
                    style += "font-family:" + ds.Tables[0].Rows[0]["FontFamily"].ToString() + ";";
                    style += "font-size:" + ds.Tables[0].Rows[0]["FontSize"].ToString() + ";";
                    style += "color:" + ds.Tables[0].Rows[0]["FontColor"].ToString() + ";";
                    style += (ds.Tables[0].Rows[0]["BackgroundImage"].ToString() != "") ? "background:url(../Images/theme/" + ds.Tables[0].Rows[0]["BackgroundImage"].ToString() + ") repeat center;" : "background:" + ds.Tables[0].Rows[0]["BackgroundColor"].ToString();
                    ViewBag.fontfamily = ds.Tables[0].Rows[0]["FontFamily"].ToString();
                    ViewBag.fontsize = ds.Tables[0].Rows[0]["FontSize"].ToString();
                    ViewBag.StyleCss = style;
                }

                //Check Call Logger
                if (CategoryId == "2")
                {
                    ViewBag.isCallLogger = true;
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "FormDetails - Logged: " + ex.Message;
                ErrorLogger.logger.Error("FormDetails - Logged: " + ex.Message);
            }
        }

        [NonAction]
        private IDictionary<string, string> GetParameterList()
        {
            IDictionary<string, string> myList = new Dictionary<string, string>();
            try
            {
                DataSet dscontrol = new DataSet();
                dscontrol = objform.GetControls(FormId, VersionId);

                if (dscontrol.Tables.Count > 0)
                {
                    if (dscontrol.Tables[0].Rows.Count > 0)
                    {
                        myList = dscontrol.Tables[0].AsEnumerable().ToDictionary<DataRow, string, string>(row => row["FieldID"].ToString(), row => row["Alias"].ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Fill CostCentre: " + ex.Message;
                ErrorLogger.logger.Error("FormDetails - Fill CostCentre: " + ex.Message);
            }

            return myList;
        }

        [NonAction]
        public string GetGridData(string FieldId, string FieldValue, bool Transaction)
        {
            string TransId = "0";
            try
            {
                DataSet dscontrol = new DataSet();
                string Userid = string.Empty;
                if (Transaction == true)
                {
                    string NTName = objEvoGeneral.userName;
                    Userid = objEvoGeneral.RetrieveUserID(NTName).ToString();
                }
                else
                {
                    Userid = "0";
                }

                dscontrol = objform.GetTransIds(FieldId, FieldValue, Userid, FormId, VersionId);
                if (dscontrol.Tables.Count > 0)
                {
                    if (dscontrol.Tables[0].Rows.Count > 0)
                    {
                        DataSet dstransdetails = new DataSet();
                        if (dscontrol.Tables[0].Rows[0]["TransIds"].ToString() != "" || dscontrol.Tables[0].Rows[0]["TransIdsArchived"].ToString() != "")
                        {
                            TransId = dscontrol.Tables[0].Rows[0]["TransIds"].ToString() + "|" + dscontrol.Tables[0].Rows[0]["TransIdsArchived"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "GridData: " + ex.Message;
                ErrorLogger.logger.Error("FormDetails - GridData: " + ex.Message);
            }

            return TransId;
        }

        public ActionResult GetFormData()
        {
            DataSet ds;
            string js = string.Empty;
            string file = string.Empty;
            try
            {
                ObjUserRights.FormId = int.Parse(FormId);
                ObjUserRights.VersionId = int.Parse(VersionId);
                ds = ObjUserRights.GetXMLFileName();

                if (ds.Tables[0].Rows.Count > 0)
                {
                    TemplateFormId = ds.Tables[0].Rows[0]["TempleteID"].ToString();
                    if (isTemplate)
                    {
                        if (TemplateFormId != "" && TemplateFormId != "0")
                        {
                            DataTable dt = objEvoGeneral.GetTemplateDetails(Convert.ToInt32(TemplateFormId));
                            if (dt.Rows.Count > 0)
                            {
                                TemplateVersionId = dt.Rows[0]["VersionID"].ToString();
                                file = Server.MapPath("..\\JSON\\" + dt.Rows[0]["XMLFileName"].ToString());
                                //file = Server.MapPath("../JSON/" + dt.Rows[0]["XMLFileName"].ToString());
                            }
                        }
                    }
                    else
                    {
                        file = Server.MapPath("..\\JSON\\" + ds.Tables[0].Rows[0]["XMLFileName"].ToString());
                        //file = Server.MapPath("../JSON/" + ds.Tables[0].Rows[0]["XMLFileName"].ToString());
                    }

                    if (System.IO.File.Exists(file))
                    {
                        js = System.IO.File.ReadAllText(file);
                    }
                }
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Could not find the JSON file. " + ex.Message;
                ErrorLogger.logger.Error("FormDetails - Could not find the JSON file. " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetTempleteData()
        {
            string js = string.Empty;
            if (TemplateList.Count > 0)
            {
                js = JsonConvert.SerializeObject(TemplateList);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult EditFormData(string TransId)
        {
            string js = string.Empty;
            try
            {
                List<object> controllist = new List<object>();
                TemplateList = new List<object>();
                DataSet dscontrol = new DataSet();
                DataSet dstemplate = new DataSet();

                dscontrol = objform.GetFormFieldsWithData(FormId, VersionId, TransId);

                if (dscontrol.Tables.Count > 0)
                {
                    if (dscontrol.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i < dscontrol.Tables[0].Rows.Count; i++)
                        {
                            controllist.Add(new { type = dscontrol.Tables[0].Rows[i]["FieldDisplayType"].ToString(), name = dscontrol.Tables[0].Rows[i]["FieldDisplayType"].ToString() + "|" + dscontrol.Tables[0].Rows[i]["Alias"].ToString(), value = dscontrol.Tables[0].Rows[i]["DataCapture"].ToString() });
                        }

                        js = JsonConvert.SerializeObject(controllist);
                    }
                }

                if (TemplateFormId != "" && TemplateFormId != "0")
                {
                    DataTable dt = objEvoGeneral.GetTemplateDetails(Convert.ToInt32(TemplateFormId));
                    if (dt.Rows.Count > 0)
                    {
                        dstemplate = objform.GetFormFieldsWithData(TemplateFormId, dt.Rows[0]["VersionID"].ToString(), TransId);
                        if (dstemplate.Tables[0].Rows.Count > 0)
                        {
                            for (int i = 0; i < dstemplate.Tables[0].Rows.Count; i++)
                            {
                                TemplateList.Add(new { type = dstemplate.Tables[0].Rows[i]["FieldDisplayType"].ToString(), name = dstemplate.Tables[0].Rows[i]["FieldDisplayType"].ToString() + "|" + dstemplate.Tables[0].Rows[i]["Alias"].ToString(), value = dstemplate.Tables[0].Rows[i]["DataCapture"].ToString() });
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Edit FormData. " + ex.Message;
                ErrorLogger.logger.Error("FormDetails - Edit FormData. " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult Search(string Parameter, string Value, bool Transaction)
        {
            string js = string.Empty;
            string TransId = "0";
            try
            {
                if (Parameter != "" && Value != "")
                {
                    TransId = GetGridData(Parameter, Value, Transaction);
                }
                else
                {
                    TransId = GetGridData("", "", Transaction);
                }

                if (TransId != "0")
                {
                    DataSet dstransdetails = new DataSet();
                    DataTable dt = new DataTable();
                    DataSet ds = new DataSet();
                    string[] transids = TransId.Split('|');

                    dstransdetails = objform.GetTransDetails(FormId, VersionId, transids[0].ToString(), transids[1].ToString());
                    if (dstransdetails.Tables.Count > 0)
                    {
                        if (dstransdetails.Tables[0].Rows.Count > 0)
                        {
                            dt = dstransdetails.Tables[0].Copy();
                            DataRow[] dr = dt.Select("FormId <>" + FormId);
                            foreach (DataRow row in dr)
                            {
                                dt.Rows.Remove(row);
                                dt.AcceptChanges();
                            }

                            js = JsonConvert.SerializeObject(dt);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Data not found. " + ex.Message;
                ErrorLogger.logger.Error("FormDetails - Data not found. " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Save(FormCollection collection)
        {
            try
            {
                DataSet formsDataSet = new DataSet();
                DataSet dsversion = new DataSet();
                Dictionary<string, string> fieldDictionary = new Dictionary<string, string>();
                string controlValue = "";
                int versionstatus = 0;
                string Timer = collection["hdnTimer"];
                string TransIds = collection["hdnTransId"];

                if (TransIds != null && TransIds != "")
                {
                    dsversion = objform.GetVersionForTrans(TransIds);
                    if (dsversion.Tables.Count > 0)
                    {
                        if (dsversion.Tables[0].Rows.Count > 0)
                        {
                            if (Convert.ToInt32(dsversion.Tables[0].Rows[0]["VersionId"].ToString()) != Convert.ToInt32(VersionId))
                            {
                                versionstatus = 1;
                            }
                        }
                    }
                }

                if (isTemplate)
                {
                    if (TemplateFormId != "" && TemplateFormId != "0")
                    {
                        formsDataSet = objform.GetFormFieldsWithData(TemplateFormId, TemplateVersionId, "0");
                    }
                }
                else
                {
                    formsDataSet = objform.GetFormFieldsWithData(FormId, VersionId, "0");
                }

                if (formsDataSet.Tables[0].Rows.Count > 0)
                {
                    for (int iRowCount = 0; iRowCount < formsDataSet.Tables[0].Rows.Count; iRowCount++)
                    {
                        string ctrlName = formsDataSet.Tables[0].Rows[iRowCount]["FieldDisplayType"].ToString() + "|" + formsDataSet.Tables[0].Rows[iRowCount]["Alias"].ToString();

                        controlValue = collection[ctrlName];
                        controlValue = (controlValue == null) ? "" : controlValue;

                        if (formsDataSet.Tables[0].Rows[iRowCount]["FieldDisplayType"].ToString() == "file")
                        {
                            string fileName = string.Empty;
                            var files = Request.Files;
                            string[] values = controlValue.Split(',');
                            foreach (string control in values)
                            {
                                fileName += Path.GetFileName(control) + ",";
                            }
                            controlValue = fileName.TrimEnd(',');
                        }
                        else if (formsDataSet.Tables[0].Rows[iRowCount]["FieldDisplayType"].ToString() == "image")
                        {
                            controlValue = controlValue.Split(',')[1].TrimEnd(',');
                        }

                        if (versionstatus != 1)
                        {
                            if (fieldDictionary.ContainsKey(formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString()))
                            {
                                fieldDictionary[formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString()] = controlValue;
                            }
                            else
                            {
                                fieldDictionary.Add(formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString(), controlValue);
                            }
                        }
                        else
                        {
                            fieldDictionary.Add(formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString(), controlValue);
                        }
                    }

                    if (isTemplate)
                    {
                        if (TemplateFormId != "" && TemplateFormId != "0")
                        {
                            SqlTransaction objSqlTransaction;
                            SqlConnection con = new SqlConnection(DAL.SqlHelper.GetConnectionString());
                            con.Open();
                            objSqlTransaction = con.BeginTransaction();
                            Int64 uniqueId = 0;

                            try
                            {
                                int FormDetailsID = 0;
                                objform.FormID = Convert.ToInt32(TemplateFormId);
                                objform.VersionID = Convert.ToInt32(TemplateVersionId);
                                foreach (KeyValuePair<string, string> kvp in fieldDictionary)
                                {
                                    objform.FieldID = kvp.Key;
                                    objform.DataCapture = kvp.Value;
                                    objform.TransID = TransactionID;

                                    FormDetailsID = objform.InsertFormDetails(objSqlTransaction);
                                }

                                //objform.SendMailForLogger(TransactionID.ToString(), objSqlTransaction);
                                objSqlTransaction.Commit();

                                //objform.EVOSendMailForTemplate(TransactionID);

                                isTemplate = false;
                                TemplateFormId = "";
                                TemplateVersionId = "";
                                TransactionID = 0;
                                TemplateList.Clear();

                                if (isUpdate)
                                {
                                    isUpdate = false;
                                    TempData["error"] = "Form update successfully.";
                                }
                                else
                                {
                                    TempData["error"] = "Form save successfully.";
                                }

                                return RedirectToAction("Index");
                            }
                            catch (Exception ex)
                            {
                                objSqlTransaction.Rollback();
                                TempData["error"] = "Something went wrong on template.";
                                ErrorLogger.logger.Error("FormDetails - Something went wrong on template. " + ex.Message);
                            }
                        }
                    }
                    else
                    {
                        SqlTransaction objSqlTransaction;
                        SqlConnection con = new SqlConnection(DAL.SqlHelper.GetConnectionString());
                        con.Open();
                        objSqlTransaction = con.BeginTransaction();
                        Int64 uniqueId = 0;

                        try
                        {
                            string NTName = objEvoGeneral.userName;
                            objform.FormID = Convert.ToInt32(FormId);
                            objform.VersionID = Convert.ToInt32(VersionId);
                            objform.UserID = objEvoGeneral.RetrieveUserID(NTName);
                            objform.TimeTaken = (Timer == "") ? 0 : Convert.ToInt32(Timer);
                            objform.AddedBy = NTName;
                            if (TransIds != null && TransIds != "")
                            {
                                objform.TransID = Convert.ToInt32(TransIds);
                                TransactionID = Convert.ToInt32(TransIds);
                                isUpdate = true;
                            }

                            TransactionID = objform.GenerateTransationID(objSqlTransaction, out uniqueId);

                            int FormDetailsID = 0;
                            foreach (KeyValuePair<string, string> kvp in fieldDictionary)
                            {
                                objform.FieldID = kvp.Key;
                                objform.DataCapture = kvp.Value;
                                objform.TransID = TransactionID;

                                FormDetailsID = objform.InsertFormDetails(objSqlTransaction);
                            }

                            //objform.SendMailForLogger(TransactionID.ToString(), objSqlTransaction);
                            objSqlTransaction.Commit();

                            if (TemplateFormId != "" && TemplateFormId != "0")
                            {
                                isTemplate = true;
                            }
                            else
                            {
                                TransactionID = 0;

                                if (isUpdate)
                                {
                                    isUpdate = false;
                                    TempData["error"] = "Form update successfully.";
                                }
                                else
                                {
                                    TempData["error"] = "Form save successfully.";
                                }
                            }

                            return RedirectToAction("Index");
                        }
                        catch (Exception ex)
                        {
                            objSqlTransaction.Rollback();
                            TempData["error"] = "Something went wrong on form.";
                            ErrorLogger.logger.Error("FormDetails - Something went wrong on form. " + ex.Message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Something went wrong. " + ex.Message;
                ErrorLogger.logger.Error("FormDetails - Something went wrong. " + ex.Message);
            }

            return RedirectToAction("Index");
        }

        public ActionResult Reset()
        {
            TransactionID = 0;
            isUpdate = false;
            isTemplate = false;
            TemplateList = null;
            TemplateFormId = string.Empty;
            TemplateVersionId = string.Empty;

            return RedirectToAction("Index");
        }

        public ActionResult UploadFile(IEnumerable<HttpPostedFileBase> postedFile)
        {
            string js = string.Empty;
            List<object> filelist = new List<object>();
            var files = Request.Files;

            if (files != null && files.Count > 0)
            {
                for (int i = 0; i < files.Count; i++)
                {
                    string fileName = FormId + VersionId + "_" + Path.GetFileName(files[i].FileName);
                    string directory = Server.MapPath("..\\Files\\");
                    string path = Path.Combine(directory, fileName);

                    if (System.IO.File.Exists(path))
                    {
                        string fileNameOnly = Path.GetFileNameWithoutExtension(path);
                        string extension = Path.GetExtension(path);
                        fileName = fileNameOnly + "_Copy" + extension;
                    }
                    files[i].SaveAs(Path.Combine(directory, fileName));
                    filelist.Add(new { filename = fileName });
                }
            }
            if (filelist.Count > 0)
            {
                js = JsonConvert.SerializeObject(filelist);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult DeleteFile(string fileName)
        {
            string directory = Server.MapPath("..\\Files\\");
            if (System.IO.File.Exists(Path.Combine(directory, fileName)))
            {
                System.IO.File.Delete(Path.Combine(directory, fileName));
            }

            return Json(string.Empty, JsonRequestBehavior.AllowGet);
        }
    }
}