﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using EVOLib;
using System.Data;
using EVO_Upgrade.Models;
using System.Text;
using Newtonsoft.Json;
using System.Xml;
using System.Xml.Linq;
using EVO_Upgrade.Filter;

namespace EVO_Upgrade.Controllers
{
    [ExceptionFilter]
    [AuthenticationFilter]
    public class ViewLogReportController : Controller
    {
        Reports objReports = new Reports();
        Forms objForms = new Forms();
        ReportModel objDataDump = null;
        private static string FormID = string.Empty;
        private static string FormName = string.Empty;
        XmlDocument doc;
        XDocument xmlDoc = new XDocument();

        // GET: ViewLogReport
        public ActionResult Index()
        {
            try
            {
                ViewBag.ReportTable = BindReportData(FormID);
                ViewBag.JS = true;
                ViewBag.FormName = FormName;
                ViewBag.Hour = new List<SelectListItem>() { new SelectListItem { Text = "00", Value = "00" }, new SelectListItem { Text = "01", Value = "01" }, new SelectListItem { Text = "02", Value = "02" }, new SelectListItem { Text = "03", Value = "03" }, new SelectListItem { Text = "04", Value = "04" }, new SelectListItem { Text = "05", Value = "05" }, new SelectListItem { Text = "06", Value = "06" }, new SelectListItem { Text = "07", Value = "07" }, new SelectListItem { Text = "08", Value = "08" }, new SelectListItem { Text = "09", Value = "09" }, new SelectListItem { Text = "10", Value = "10" }, new SelectListItem { Text = "11", Value = "11" }, new SelectListItem { Text = "12", Value = "12" }, new SelectListItem { Text = "13", Value = "13" }, new SelectListItem { Text = "14", Value = "14" }, new SelectListItem { Text = "15", Value = "15" }, new SelectListItem { Text = "16", Value = "16" }, new SelectListItem { Text = "17", Value = "17" }, new SelectListItem { Text = "18", Value = "18" }, new SelectListItem { Text = "19", Value = "19" }, new SelectListItem { Text = "20", Value = "20" }, new SelectListItem { Text = "21", Value = "21" }, new SelectListItem { Text = "22", Value = "22" }, new SelectListItem { Text = "23", Value = "23" } };
                ViewBag.Min = new List<SelectListItem>() { new SelectListItem { Text = "00", Value = "00" }, new SelectListItem { Text = "15", Value = "15" }, new SelectListItem { Text = "30", Value = "30" }, new SelectListItem { Text = "45", Value = "45" } };
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("ViewLogReport - GET Load: " + ex.Message);
            }

            return View();
        }

        [HttpPost]
        public ActionResult Index(FormCollection data)
        {
            try
            {
                objDataDump = new ReportModel();
                objDataDump.StartDate = data["StartDate"];
                objDataDump.StartHour = data["StartHour"];
                objDataDump.StartMin = data["StartMin"];
                objDataDump.EndDate = data["EndDate"];
                objDataDump.EndHour = data["EndHour"];
                objDataDump.EndMin = data["EndMin"];

                string Start = data["StartDate"] + " " + data["StartHour"] + ":" + data["StartMin"] + ":00";
                string End = data["EndDate"] + " " + data["EndHour"] + ":" + data["EndMin"] + ":00";
                string Form = data["FormID"];
                string VersionID = data["VersionID"];
                string FieldName = data["FieldsName"];
                string FieldValue = data["FieldsValue"];
                string ExportType = data["ExportType"];

                ViewBag.ReportTable = BindReportData(FormID);

                if (Form != "" && VersionID != "")
                {
                    //Form Name: Tic Tac, Start Date: 01-Jan-2018, Field Value=''
                    ExportReport(Form, VersionID, Start, End, FieldName, FieldValue, ExportType);
                    ViewBag.Fields = Form + '|' + VersionID + '|' + FieldName + '|' + FieldValue;
                }

                ViewBag.FormName = FormName;
                ViewBag.Hour = new List<SelectListItem>() { new SelectListItem { Text = "00", Value = "00" }, new SelectListItem { Text = "01", Value = "01" }, new SelectListItem { Text = "02", Value = "02" }, new SelectListItem { Text = "03", Value = "03" }, new SelectListItem { Text = "04", Value = "04" }, new SelectListItem { Text = "05", Value = "05" }, new SelectListItem { Text = "06", Value = "06" }, new SelectListItem { Text = "07", Value = "07" }, new SelectListItem { Text = "08", Value = "08" }, new SelectListItem { Text = "09", Value = "09" }, new SelectListItem { Text = "10", Value = "10" }, new SelectListItem { Text = "11", Value = "11" }, new SelectListItem { Text = "12", Value = "12" }, new SelectListItem { Text = "13", Value = "13" }, new SelectListItem { Text = "14", Value = "14" }, new SelectListItem { Text = "15", Value = "15" }, new SelectListItem { Text = "16", Value = "16" }, new SelectListItem { Text = "17", Value = "17" }, new SelectListItem { Text = "18", Value = "18" }, new SelectListItem { Text = "19", Value = "19" }, new SelectListItem { Text = "20", Value = "20" }, new SelectListItem { Text = "21", Value = "21" }, new SelectListItem { Text = "22", Value = "22" }, new SelectListItem { Text = "23", Value = "23" } };
                ViewBag.Min = new List<SelectListItem>() { new SelectListItem { Text = "00", Value = "00" }, new SelectListItem { Text = "15", Value = "15" }, new SelectListItem { Text = "30", Value = "30" }, new SelectListItem { Text = "45", Value = "45" } };
                ViewBag.ErrorMessage = (TempData["error"] == null) ? string.Empty : TempData["error"].ToString();
            }
            catch (Exception ex)
            {
                ViewBag.ErrorMessage = "Load: " + ex.Message;
                ErrorLogger.logger.Error("ViewLogReport - POST Load: " + ex.Message);
            }

            return View(objDataDump);
        }

        public ActionResult Report(string Form)
        {
            FormID = Form.Split('|')[0];
            FormName = Form.Split('|')[1];

            return RedirectToAction("Index");
        }

        public ActionResult BindReportData(string FormId)
        {
            DataSet objDataSet = new DataSet();
            string js = string.Empty;

            try
            {
                objReports.FormID = Convert.ToInt32(FormId);
                objReports.UserID = 0;
                objReports.Module = "FormVersionsViewLog";
                objReports.StDate = null;
                objReports.EndDate = null;
                objDataSet = objReports.GetFormsForReports(objDataSet, "0");

                if (objDataSet.Tables[0].Rows.Count > 0)
                {
                    js = JsonConvert.SerializeObject(objDataSet.Tables[0]);
                }
                else
                {
                    TempData["error"] = "No Records Found.";
                    return null;
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Bind Report: " + ex.Message;
                ErrorLogger.logger.Error("ViewLogReport - Bind Report: " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetFieldNames(string FormID, string VersionID)
        {
            DataSet objDataSet = new DataSet();
            string js = string.Empty;

            try
            {
                objForms.FormID = Convert.ToInt32(FormID);
                objForms.VersionID = Convert.ToInt32(VersionID);
                objDataSet = objForms.GetFormsFieldsWithVersions(objDataSet, false);

                if (objDataSet.Tables[0].Rows.Count > 0)
                {
                    js = JsonConvert.SerializeObject(objDataSet.Tables[0]);
                }
                else
                {
                    TempData["error"] = "No Records Found.";
                    return null;
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "FieldName: " + ex.Message;
                ErrorLogger.logger.Error("ViewLogReport - FieldName: " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        public ActionResult GetFieldValues(string FieldID, string FormID, string VersionID)
        {
            DataSet objDataSet = new DataSet();
            string js = string.Empty;
            List<string> ListItem = new List<string>();

            try
            {
                string controlname = "";
                string controltype = "";
                string filepath = "";
                objForms.FieldID = FieldID;
                objForms.FormID = Convert.ToInt32(FormID);
                objForms.VersionID = Convert.ToInt32(VersionID);
                objDataSet = objForms.GetFormDetails(objDataSet);

                if (objDataSet.Tables.Count > 0)
                {
                    if (objDataSet.Tables[0].Rows.Count > 0)
                    {
                        controlname = objDataSet.Tables[0].Rows[0]["FieldName"].ToString() + objDataSet.Tables[0].Rows[0]["FieldDisplayType"].ToString();
                        filepath = objDataSet.Tables[0].Rows[0]["XMLFileName"].ToString();
                        if (objDataSet.Tables[0].Rows[0]["FieldDisplayType"].ToString() == "DropDown")
                        {
                            controltype = "DropDownList";
                        }
                        else
                        {
                            controltype = objDataSet.Tables[0].Rows[0]["FieldDisplayType"].ToString();
                        }

                        if (controltype == "DropDownList" || controltype == "ListBox")
                        {
                            ListItem = BindControlData(controlname, controltype, filepath);
                        }
                    }
                }

                if (ListItem.Count > 0)
                {
                    js = JsonConvert.SerializeObject(ListItem);
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "FieldValue: " + ex.Message;
                ErrorLogger.logger.Error("ViewLogReport - FieldValue: " + ex.Message);
            }

            return Json(js, JsonRequestBehavior.AllowGet);
        }

        [NonAction]
        public List<string> BindControlData(string controlname, string controltype, string filepath)
        {
            DataSet objDataSet = new DataSet();
            List<string> ListItem = new List<string>();

            string FileName = Server.MapPath("..\\XML\\" + filepath);
            doc = new XmlDocument();
            xmlDoc = XDocument.Load(FileName);
            doc.Load(FileName);

            XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controltype);

            for (int i = 0; i < rootNodeList.Count; i++)
            {
                XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if ((dropDownNode.ChildNodes[y].Name == "FieldID") && (dropDownNode.ChildNodes[y].InnerText == controlname))
                    {
                        for (int j = 0; j < dropDownNode.ChildNodes.Count; j++)
                        {
                            XmlNode ndListItems = dropDownNode.SelectSingleNode("LISTITEMS");
                            string ListItemText = "";
                            XmlNodeList listItems = ndListItems.ChildNodes;

                            for (int l = 0; l < listItems.Count; l++)
                            {
                                ListItemText = listItems.Item(l).InnerText;

                                if (listItems.Item(l).Name == "LISTITEM")
                                {
                                    ListItem.Add(ListItemText);
                                    //SelectedFieldsListBox.Items.Add(new ListItem(ListItemText, ListItemText));
                                }
                            }
                            break;
                        }
                    }
                }
            }

            return ListItem;
        }

        public ActionResult ExportReport(string FormID, string VersionID, string Start, string End, string FieldName, string FieldValue, string ExportType)
        {
            EvoGeneral objEvoGeneral = new EvoGeneral();
            System.IO.StringWriter oStringWriter = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter oHtmlTextWriter = new System.Web.UI.HtmlTextWriter(oStringWriter);

            try
            {
                Reports objReports = new Reports();
                DataSet objDataSet = new DataSet();
                objReports.FormID = Convert.ToInt32(FormID);
                objReports.VersionID = Convert.ToInt32(VersionID);
                objReports.ColumnName = FieldName;
                objReports.ColumnValue = FieldValue;
                objReports.StDate = Start;
                objReports.EndDate = End;
                objDataSet = objReports.GetViewLogReport(objDataSet, objEvoGeneral.userName);

                if (objDataSet.Tables.Count > 0)
                {
                    if (objDataSet.Tables[0].Rows.Count == 0)
                    {
                        TempData["error"] = "Data not found.";
                    }
                    else
                    {
                        int totaltimetaken = 0;
                        for (int i = 0; i < objDataSet.Tables[0].Rows.Count; i++)
                        {
                            totaltimetaken = totaltimetaken + Convert.ToInt32(objDataSet.Tables[0].Rows[i]["timetaken"].ToString());
                        }

                        DataSet ds = new DataSet();
                        ds = objDataSet.Copy();
                        DataRow dr = ds.Tables[0].NewRow();
                        dr["FormName"] = "Total Time Taken";
                        dr["TimeTaken"] = totaltimetaken.ToString();
                        ds.Tables[0].Rows.InsertAt(dr, objDataSet.Tables[0].Rows.Count + 1);

                        //int transid = 0;
                        //int rowcount = 0;
                        //int totaltimetaken = 0;
                        //for (int i = 0; i <= objDataSet.Tables[0].Rows.Count; i++)
                        //{
                        //    if (transid == 0)
                        //    {
                        //        transid = Convert.ToInt32(objDataSet.Tables[0].Rows[i]["TransactionID"].ToString());
                        //    }
                        //    if (i != objDataSet.Tables[0].Rows.Count)
                        //    {
                        //        if (transid == Convert.ToInt32(objDataSet.Tables[0].Rows[i]["TransactionID"].ToString()))
                        //        {
                        //            totaltimetaken = totaltimetaken + Convert.ToInt32(objDataSet.Tables[0].Rows[i]["timetaken"].ToString());
                        //        }
                        //        if (transid != Convert.ToInt32(objDataSet.Tables[0].Rows[i]["TransactionID"].ToString()))
                        //        {
                        //            DataRow dr = dt.NewRow();
                        //            dr["FormName"] = "Total Time Taken";
                        //            dr["TimeTaken"] = totaltimetaken.ToString();
                        //            dt.Rows.InsertAt(dr, i + rowcount);
                        //            rowcount = rowcount + 1;
                        //            totaltimetaken = totaltimetaken + Convert.ToInt32(objDataSet.Tables[0].Rows[i]["timetaken"].ToString());
                        //        }
                        //        transid = Convert.ToInt32(objDataSet.Tables[0].Rows[i]["TransactionID"].ToString());
                        //    }
                        //    else
                        //    {
                        //        DataRow dr = dt.NewRow();
                        //        dr["FormName"] = "<strong>Total Time Taken</strong>";
                        //        dr["TimeTaken"] = totaltimetaken.ToString();
                        //        dt.Rows.InsertAt(dr, i + rowcount);
                        //    }
                        //}

                        switch (ExportType)
                        {
                            case "Excel":
                                ExcelHelper.ToExcel(ds, "EVO_ViewLogReport_" + FormID + "_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xls", HttpContext.ApplicationInstance.Response);
                                break;
                            case "Word":
                                DataExport.ToWord(ds, "EVO_ViewLogReport_" + FormID + "_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".doc", HttpContext.ApplicationInstance.Response);
                                break;
                            case "PDF":
                                DataExport.ToPDF(ds, "EVO_ViewLogReport_" + FormID + "_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".pdf", HttpContext.ApplicationInstance.Response);
                                break;
                            default:
                                ExcelHelper.ToExcel(ds, "EVO_ViewLogReport_" + FormID + "_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xls", HttpContext.ApplicationInstance.Response);
                                break;
                        }
                    }
                }
                else
                {
                    TempData["error"] = "Data not found for the selected criteria.";
                }
            }
            catch (Exception ex)
            {
                TempData["error"] = "Data not found.";
                ErrorLogger.logger.Error("ViewLogReport - Data not found. " + ex.Message);
            }

            return new EmptyResult();
        }
    }
}