﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace EVO_Upgrade.Models
{
    public class ManageData
    {
        public int Control { get; set; }
        public int CostCentre { get; set; }
        public int[] SkillSets { get; set; }
        public int ParentData { get; set; }
        public int ChildData { get; set; }
        public string ListItem  { get; set; }
    }
}