﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EVO_Upgrade.Models
{
    public class SuperAdmin
    {
        public int? CostCentre { get; set; }
        public string AdminUser { get; set; }
        public int Admin { get; set; }
        public int[] CostCentreList { get; set; }
    }
}