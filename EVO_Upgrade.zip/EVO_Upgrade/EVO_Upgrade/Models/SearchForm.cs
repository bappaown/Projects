﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EVO_Upgrade.Models
{
    public class SearchForm
    {
        public string Title { get; set; }
        public string AddedBy { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public bool MyForm { get; set; }

        public List<ModifyForm> AcctData { get; set; }
    }
}