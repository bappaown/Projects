﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EVO_Upgrade.Models
{
    public class ModifyForm
    {
        public int FormID { get; set; }
        public string FormName { get; set; }
        public int CategoryID { get; set; }
        public string CategoryName { get; set; }
        public string FormDesc { get; set; }
        public int VersionId { get; set; }
        public string VersionName { get; set; }
        public string AddedBy { get; set; }
        public DateTime AddedWhen { get; set; }
        public bool IsActive { get; set; }
        public bool IsActive1 { get; set; }
    }
}