﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EVO_Upgrade.Models
{
    public class RightsManagement
    {
        public int CostCentre { get; set; }
        public int Department { get; set; }
        public string FilterName { get; set; }
        public string[] SelectedName { get; set; }
        public bool EditForm { get; set; }
        public bool AllReports { get; set; }
        public bool LimerickReports { get; set; }
        public bool WaterfordReports { get; set; }
        public bool MumbaiReports { get; set; }
    }
}