﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace EVO_Upgrade.Models
{
    public class FormDetails
    {
        [Required(ErrorMessage = "Name is required.")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Description is required.")]
        public string Description { get; set; }
        [Required(ErrorMessage = "Category is required.")]
        public int Category { get; set; }
        [Required(ErrorMessage = "SkillSet is required.")]
        public string SkillSetID { get; set; }
        public List<SkillSet> SkillSets { get; set; }
        public bool IsDTMS { get; set; }
        public bool IsEditable { get; set; }
        public bool IsSearch { get; set; }
        public string Email { get; set; }
    }
}