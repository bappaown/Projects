﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EVO_Upgrade.Models
{
    public class ControlManagement
    {
        public string Control { get; set; }
        public string HiddenData { get; set; }
        public string SelectedControl { get; set; }
        public string[] ControlValue { get; set; }
        public string[] HiddenControl { get; set; }
        public string SelectedControlH { get; set; }
        public string[] ControlValueH { get; set; }
        public string[] HiddenControlH { get; set; }
    }
}