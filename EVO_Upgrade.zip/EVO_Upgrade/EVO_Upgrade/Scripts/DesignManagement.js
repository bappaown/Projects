﻿// JScript File

//**********************************************Functions to handle the sliding of the properties tab - START**********************************************

var controlarray = [];

function ToggleBasic() {

    if (document.getElementById('BasicToolsListView').style.display == '') {
        document.getElementById('BasicToolsListView').style.display = 'none';
        document.getElementById('BasicControlsLabel').style.height = '0px';
        document.getElementById('BasicControlsLabel').style.width = '0px';
        document.getElementById('CustomToolsListView').style.display = 'none';
        document.getElementById('CustomControlLabel').style.height = '0px';
        document.getElementById('CustomControlLabel').style.width = '0px';
        document.getElementById('GlobalToolsListView').style.display = 'none';
        document.getElementById('GlobalControlLabel').style.height = '0px';
        document.getElementById('GlobalControlLabel').style.width = '0px';
    }
    else if (document.getElementById('BasicToolsListView').style.display == 'none') {
        document.getElementById('BasicToolsListView').style.display = '';
        document.getElementById('BasicControlsLabel').style.height = '100px';
        document.getElementById('BasicControlsLabel').style.width = '285px';
        document.getElementById('BasicControlsLabel').style.overflow = 'auto';
        document.getElementById('CustomToolsListView').style.display = 'none';
        document.getElementById('CustomControlLabel').style.height = '0px';
        document.getElementById('CustomControlLabel').style.width = '0px';
        document.getElementById('GlobalToolsListView').style.display = 'none';
        document.getElementById('GlobalControlLabel').style.height = '0px';
        document.getElementById('GlobalControlLabel').style.width = '0px';
    }
}

function ToggleCustom() {

    if (document.getElementById('CustomToolsListView').style.display == '') {
        document.getElementById('BasicToolsListView').style.display = 'none';
        document.getElementById('BasicControlsLabel').style.height = '0px';
        document.getElementById('BasicControlsLabel').style.width = '0px';
        document.getElementById('CustomToolsListView').style.display = 'none';
        document.getElementById('CustomControlLabel').style.height = '0px';
        document.getElementById('CustomControlLabel').style.width = '0px';
        document.getElementById('GlobalToolsListView').style.display = 'none';
        document.getElementById('GlobalControlLabel').style.height = '0px';
        document.getElementById('GlobalControlLabel').style.width = '0px';
    }
    else if (document.getElementById('CustomToolsListView').style.display == 'none') {
        document.getElementById('BasicToolsListView').style.display = 'none';
        document.getElementById('BasicControlsLabel').style.height = '0px';
        document.getElementById('BasicControlsLabel').style.width = '0px';
        document.getElementById('CustomToolsListView').style.display = '';
        document.getElementById('CustomControlLabel').style.height = '100px';
        document.getElementById('CustomControlLabel').style.width = '285px';
        document.getElementById('CustomControlLabel').style.overflow = 'auto';
        document.getElementById('GlobalToolsListView').style.display = 'none';
        document.getElementById('GlobalControlLabel').style.height = '0px';
        document.getElementById('GlobalControlLabel').style.width = '0px';
    }
}

function ToggleGlobal() {

    if (document.getElementById('GlobalToolsListView').style.display == '') {
        document.getElementById('BasicToolsListView').style.display = 'none';
        document.getElementById('BasicControlsLabel').style.height = '0px';
        document.getElementById('BasicControlsLabel').style.width = '0px';
        document.getElementById('CustomToolsListView').style.display = 'none';
        document.getElementById('CustomControlLabel').style.height = '0px';
        document.getElementById('CustomControlLabel').style.width = '0px';
        document.getElementById('GlobalToolsListView').style.display = 'none';
        document.getElementById('GlobalControlLabel').style.height = '0px';
        document.getElementById('GlobalControlLabel').style.width = '0px';
    }
    else if (document.getElementById('GlobalToolsListView').style.display == 'none') {
        document.getElementById('BasicToolsListView').style.display = 'none';
        document.getElementById('BasicControlsLabel').style.height = '0px';
        document.getElementById('BasicControlsLabel').style.width = '0px';
        document.getElementById('CustomToolsListView').style.display = 'none';
        document.getElementById('CustomControlLabel').style.height = '0px';
        document.getElementById('CustomControlLabel').style.width = '0px';
        document.getElementById('GlobalToolsListView').style.display = '';
        document.getElementById('GlobalControlLabel').style.height = '100px';
        document.getElementById('GlobalControlLabel').style.width = '285px';
        document.getElementById('GlobalControlLabel').style.overflow = 'auto';
    }
}


function HideProperties() {
    document.getElementById('HideTableImg').style.display = 'none';
    // document.getElementById('ViewInnerHTML').style.display = 'none';
    document.getElementById('PropertiesTable').style.display = 'none';
    document.getElementById('BasicToolsListView').style.display = 'none';
    document.getElementById('GlobalToolsListView').style.display = 'none';
    document.getElementById('CustomToolsListView').style.display = 'none';
    document.getElementById('DeleteButton').style.display = 'none';
    document.getElementById('BasicControlsDIV').style.display = 'none';
    document.getElementById('CustomControlsDIV').style.display = 'none';
    document.getElementById('GlobalControlsDIV').style.display = 'none';
    document.getElementById('ShowTableImg').style.display = 'block';
    hideit = setInterval("Hide()", 8);

}

function ShowProperties() {
    showit = setInterval("Show()", 8);
}

function Hide() {
    var width = document.getElementById('ToolsTable').style.width;
    var left = document.getElementById('ToolsTable').style.left;
    if (parseInt((document.getElementById('ToolsTable').style.width).substring(0, width.length - 2)) > 10 && parseInt((document.getElementById('ToolsTable').style.left).substring(0, left.length - 2)) < 1200) {
        document.getElementById('ToolsTable').style.left = parseInt(document.getElementById('ToolsTable').style.left) + 50;
        document.getElementById('ToolsTable').style.width = parseInt(document.getElementById('ToolsTable').style.width) - 50;
    }
    else {

        clearInterval(hideit);
    }


}

function hidetable() {

    if (document.getElementById('HideTableImg').style.display == "block") {
        document.getElementById('ToolsTable').style.width = '1%'; //changed to adjust closing and opening of property panel in design console
        document.getElementById('ToolsTable').style.left = '97%';
        document.getElementById('HideTableImg').style.display = "none";
        document.getElementById('ShowTableImg').style.display = "block";
        document.getElementById('BasicToolsListView').style.display = 'none';
        document.getElementById('GlobalToolsListView').style.display = 'none';
        document.getElementById('CustomToolsListView').style.display = 'none';
        document.getElementById('DeleteButton').style.display = 'none';
        document.getElementById('BasicControlsDIV').style.display = 'none';
        document.getElementById('CustomControlsDIV').style.display = 'none';
        document.getElementById('GlobalControlsDIV').style.display = 'none';
        document.getElementById('PropertiesTable').style.display = 'none';
        document.getElementById('BasicToolsListView').style.display = 'none';
        document.getElementById('BasicControlsLabel').style.height = '0px';
        document.getElementById('BasicControlsLabel').style.width = '0px';
        document.getElementById('CustomToolsListView').style.display = 'none';
        document.getElementById('CustomControlLabel').style.height = '0px';
        document.getElementById('CustomControlLabel').style.width = '0px';
        document.getElementById('GlobalToolsListView').style.display = 'none';
        document.getElementById('GlobalControlLabel').style.height = '0px';
        document.getElementById('GlobalControlLabel').style.width = '0px';
        document.getElementById('btnformat').style.display = 'none';
    }
    else {
        document.getElementById('ToolsTable').style.width = '15.75%';
        document.getElementById('ToolsTable').style.left = '83.6%';
        document.getElementById('HideTableImg').style.display = "block";
        document.getElementById('ShowTableImg').style.display = "none";
        document.getElementById('BasicToolsListView').style.display = 'block';
        document.getElementById('GlobalToolsListView').style.display = 'block';
        document.getElementById('CustomToolsListView').style.display = 'block';
        document.getElementById('DeleteButton').style.display = 'none';
        document.getElementById('BasicControlsDIV').style.display = '';
        document.getElementById('CustomControlsDIV').style.display = '';
        document.getElementById('GlobalControlsDIV').style.display = '';
        document.getElementById('PropertiesTable').style.display = 'none';
        document.getElementById('BasicToolsListView').style.display = 'none';
        document.getElementById('BasicControlsLabel').style.height = '0px';
        document.getElementById('BasicControlsLabel').style.width = '100%';
        document.getElementById('CustomToolsListView').style.display = 'none';
        document.getElementById('CustomControlLabel').style.height = '0px';
        document.getElementById('CustomControlLabel').style.width = '100%';
        document.getElementById('GlobalToolsListView').style.display = 'none';
        document.getElementById('GlobalControlLabel').style.height = '0px';
        document.getElementById('GlobalControlLabel').style.width = '100%';
        document.getElementById('btnformat').style.display = 'none';
    }
}



function Show() {


    var width = document.getElementById('ToolsTable').style.width;
    var left = document.getElementById('ToolsTable').style.left;

    if (parseInt((document.getElementById('ToolsTable').style.width).substring(0, width.length - 2)) != 295 && parseInt((document.getElementById('ToolsTable').style.left).substring(0, left.length - 2)) != 955) {

        document.getElementById('ToolsTable').style.left = parseInt(document.getElementById('ToolsTable').style.left) - 50;
        document.getElementById('ToolsTable').style.width = parseInt(document.getElementById('ToolsTable').style.width) + 50;

    }
    else {
        clearInterval(showit);
        document.getElementById('HideTableImg').style.display = 'block';
        document.getElementById('BasicToolsListView').style.display = 'block';
        document.getElementById('GlobalToolsListView').style.display = 'block';
        document.getElementById('CustomToolsListView').style.display = 'block';
        document.getElementById('DeleteButton').style.display = 'none';
        document.getElementById('BasicControlsDIV').style.display = '';
        document.getElementById('CustomControlsDIV').style.display = '';
        document.getElementById('GlobalControlsDIV').style.display = '';
        document.getElementById('ShowTableImg').style.display = 'none';
        document.getElementById('PropertiesTable').style.display = 'none';
        document.getElementById('BasicToolsListView').style.display = 'none';
        document.getElementById('BasicControlsLabel').style.height = '0px';
        document.getElementById('BasicControlsLabel').style.width = '0px';
        document.getElementById('CustomToolsListView').style.display = 'none';
        document.getElementById('CustomControlLabel').style.height = '0px';
        document.getElementById('CustomControlLabel').style.width = '0px';
        document.getElementById('GlobalToolsListView').style.display = 'none';
        document.getElementById('GlobalControlLabel').style.height = '0px';
        document.getElementById('GlobalControlLabel').style.width = '0px';
        //document.getElementById('ViewInnerHTML').style.display = 'block';
    }

}

function CreateGUID() {
    return (((1 + Math.random()) * 0x10000) | 0).toString(16).substring(1);
}


//*********************************Functions to handle the sliding of the properties tab - END**********************************************

//************************************Functions handling the Drag and Drop of Elements - START*********************************************  
var dragapproved = false
var dragElement;
var dragElementx;
var dragElementy;

var dropDownFlag = false;
var listBoxFlag = false;
var radioListFlag = false;
var checkListFlag = false;
var textBoxFlag = false;
var labelFlag = false;
var buttonFlag = false;
var customFlag = false;
var globalFlag = false;

var radioButtonCount = 0;
var checkBoxCount = 0;


function move() {


    var buffer = 5;
    if (event.button == 1 && dragapproved) {

        var maxRight = parseInt(document.getElementById('DesignDiv').style.left) + parseInt(document.getElementById('DesignDiv').clientWidth) - dragElement.clientWidth - parseInt(buffer);
        var maxBottom = parseInt(document.getElementById('DesignDiv').style.top) + parseInt(document.getElementById('DesignDiv').style.height) - dragElement.clientHeight - parseInt(buffer);
        //alert(parseInt(document.getElementById('DesignDiv').style.width));
        // alert(maxBottom);
        var minbottom = 595;

        //event.clientX = event.clientX + 200;
        if (event.clientY > parseInt(maxBottom - 5)) {
            maxBottom = parseInt(event.clientY + 20);
            document.getElementById('DesignDiv').style.height = parseInt(event.clientY + 20);
            document.getElementById('ctl00_maintr').height = parseInt(event.clientY + 20);
        }
        else {
            var searchEles = document.getElementById("DesignDiv").children;
            var minheight = 0;
            for (var i = 0; i < searchEles.length; i++) {
                if (parseInt(searchEles[i].offsetHeight + searchEles[i].offsetTop) > minheight) {
                    minheight = parseInt(searchEles[i].offsetHeight + searchEles[i].offsetTop);
                }
            }
            if (minheight < minbottom) {
                maxBottom = parseInt(minbottom);
                document.getElementById('DesignDiv').style.height = parseInt(minbottom);
                document.getElementById('ctl00_maintr').height = parseInt(555);
            }
            else {
                maxBottom = parseInt(minheight + 20);
                document.getElementById('DesignDiv').style.height = parseInt(minheight + 20);
                document.getElementById('ctl00_maintr').height = parseInt(minheight + 20);
            }
        }

        if ((event.clientX > parseInt(document.getElementById('DesignDiv').style.left)) && event.clientX < maxRight && (event.clientY > parseInt(document.getElementById('DesignDiv').style.top)) && event.clientY < maxBottom) {
            //            if (event.clientY <= minbottom) {
            //                dragElement.style.pixelLeft = event.clientX - parseInt(document.getElementById('DesignDiv').style.left)
            //                dragElement.style.pixelTop = event.clientY  - parseInt(document.getElementById('DesignDiv').style.top)
            //             }
            //            else {
            //                dragElement.style.pixelLeft = event.clientX //- parseInt(document.getElementById('DesignDiv').style.left)
            //                dragElement.style.pixelTop = event.clientY  //- parseInt(document.getElementById('DesignDiv').style.top)
            //            }
            //            var evt = window.event;
            //            var obj = evt.srcElement;
            $(".drag").draggable();
            return true;
        }
        else {
            return false
        }


    }

}



function drags() {

    if (!document.all)
        return
    if (event.srcElement.className == "drag" || event.srcElement.className == "drag ui-draggable") {
        dragapproved = true
        dragElement = event.srcElement
        dragElement.style.cursor = "move";
        var dragElementLeft = 0;
        var dragElementTop = 0;
        dragElementLeft = dragElement.style.pixelLeft
        dragElementTop = dragElement.style.pixelTop
        dragElementx = event.clientX
        dragElementy = event.clientY
        document.onclick = new Function("dragapproved=false;");
        document.onmousemove = move;
        document.onmouseup = new Function("dragapproved=false;");
        //$('.drag').unbind('draggable');
    }
}
document.onmousedown = drags;





//************************************Functions handling the Drag and Drop of Elements - ENDS  *********************************************
var dropDownList = "";
var dropDownArray = new Array();
var dropDownIDList = "";
var dropDownIDArray = new Array();

var listBoxList = "";
var listBoxArray = new Array();
var listBoxIDList = "";
var listBoxIDArray = new Array();

var maxlength = 150;

//var iChars = "!@/&#$%^*()+=-[]\\\';{}|\:<>~_?.|,\"£'`";
var iChars = "'\""; // "!@/#$^*()+=-[]\\\';{}|\:<>~?.|,\"£'`"; 
var iSizeChars = "!@&#$%^*()+=-[]\\\';{}|\:/<>~_£?.,|`QWERTYUIOPASDFGHJKLZXCVBNM\" ";

function CreateDropDownList() {
    //alert("In dropdown List");
    var dropDownCount = document.getElementById('dropDownCountHidden').value;
    //alert(" dropDownCount  before condition : " + dropDownCount);
    var dropdownTitle = prompt("Enter the Drop Down Title");
    var dropdownString = "";
    var titleArray = new Array();
    var validTitle = true;

    if (dropdownTitle == null) {
        return;
    }

    if (dropdownTitle != null && dropdownTitle.substring(0, 1) != " " && dropdownTitle.length <= maxlength) {
        for (var i = 0; i < dropdownTitle.length; i++) {
            if (iChars.indexOf(dropdownTitle.charAt(i)) != -1) {
                validTitle = false;
            }
        }
        if (validTitle == false) {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    else {
        validTitle = false;
        alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
        return;
    }

    for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
        titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
    }

    var isDTMSCheck = true;
    isDTMSCheck = checkforDTMS(dropdownTitle);
    if (isDTMSCheck == false) {
        return;
    }

    for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
        if (dropdownTitle.toLowerCase().trim() == titleArray[arrayCountx].toLowerCase().trim()) {
            document.getElementById('IdExistsDiv').innerHTML = "Exists"
            alert("A dropdown with the title " + dropdownTitle + " exists.");
            return;
        }
    }

    if (document.getElementById('FileModeHidden').value == "EDITMODE" && dropDownFlag == false) {
        if (document.getElementById('dropDownCountHidden').value != "") {
            dropDownCount = parseInt(document.getElementById('dropDownCountHidden').value) + parseInt(1);
            //alert(" dropDownCount : " + dropDownCount);

        }
        if (document.getElementById('dropDownCountHidden').value == "") {
            dropDownCount = parseInt(0);
            //alert(" dropDownCount when empty : " + dropDownCount);
        }
        dropDownFlag = true;
        dropDownList = document.getElementById('DropDownArray').value;
        dropDownIDList = document.getElementById('DropDownIDArray').value;

    }


    if (document.getElementById('IdExistsDiv').innerHTML != "Exists" && validTitle == true) {
        if ((dropdownTitle != "undefined") && (dropdownTitle != "") && (dropdownTitle != null)) {


            //alert(" dropDownCount control create : " + dropDownCount);


            //var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
            dropdownString += "<table id='ddl_" + dropDownCount + "DropDownTable' title='" + dropdownTitle + "' type='DropDown' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; width:200px; top:0px; left:0px;' align='right' onclick ='FillProperties(this)' controlid='2' controltype='basic' dependency='False' dependentid='' prevref='' isrequired='False' ismanageable='False' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False' IsQueryPattern='Contains' IsHide='False';>";
            dropdownString += "<tr><td style='cursor:none;white-space:nowrap;' align='center' >" + dropdownTitle + "</td>";
            dropdownString += "<td align='center'><img id='ddl_" + dropDownCount + "DropDown' title='" + dropdownTitle + "' style='z-index:-1;width:150px;cursor:none;' src='../Images/DropDownDes.jpg'/></td></tr></table>"; //
            document.getElementById('DesignDiv').innerHTML += dropdownString;
            dropDownList += dropdownTitle + ",";
            dropDownIDList += "ddl_" + dropDownCount + "DropDown" + ",";

        }
        else {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    document.getElementById('IdExistsDiv').innerHTML = "None";
    dropDownCount++;
    document.getElementById('dropDownCountHidden').value = dropDownCount;
}



function CreateListBox() {

    var listBoxCount = document.getElementById('listBoxCountHidden').value;
    var listboxTitle = prompt("Enter the List Box Title");
    var listBoxString = "";
    var titleArray = new Array();
    var validTitle = true;

    if (listboxTitle == null) {
        return;
    }
    if ((listboxTitle != "undefined") && (listboxTitle != "") && (listboxTitle != null) && listboxTitle.substring(0, 1) != " " && listboxTitle.length <= maxlength) {
        for (var i = 0; i < listboxTitle.length; i++) {
            if (iChars.indexOf(listboxTitle.charAt(i)) != -1) {
                validTitle = false;
            }
        }
        if (validTitle == false) {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    else {
        validTitle = false;
        alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
        return;
    }

    for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
        titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
    }

    var isDTMSCheck = true;
    isDTMSCheck = checkforDTMS(listboxTitle);
    if (isDTMSCheck == false) {
        return;
    }
    for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
        if (listboxTitle.toLowerCase().trim() == titleArray[arrayCountx].toLowerCase().trim()) {
            document.getElementById('IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + listboxTitle + " exists.");
            return;
        }
    }
    if (document.getElementById('FileModeHidden').value == "EDITMODE" && listBoxFlag == false) {
        if (document.getElementById('listBoxCountHidden').value != "") {
            listBoxCount = parseInt(document.getElementById('listBoxCountHidden').value) + parseInt(1);
        }
        if (document.getElementById('listBoxCountHidden').value == "") {
            listBoxCount = parseInt(0);
        }
        listBoxList = document.getElementById('ListBoxArray').value;
        listBoxIDList = document.getElementById('ListBoxIDArray').value;
        listBoxFlag = true;
    }
    else if (document.getElementById('FileModeHidden').value == "EDITMODE" && listBoxFlag == true) {
        listBoxCount = parseInt(document.getElementById('listBoxCountHidden').value) + parseInt(1);
    }



    if (document.getElementById('IdExistsDiv').innerHTML != "Exists" && validTitle == true) {
        if ((listboxTitle != "undefined") && (listboxTitle != "") && (listboxTitle != null)) {
            //var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
            listBoxString += "<table id='lb_" + listBoxCount + "ListBoxTable' title='" + listboxTitle + "' type='ListBox' class='drag' style='position:absolute;border:dashed 4px #afafaf;background-color:White; width:100px;top:0px; left:0px;height:150px;' align='right' onclick ='FillProperties(this)'  iswrap='False' controlid='5' controltype='basic' dependency='False' dependentid='' prevref='' isrequired='False' ismanageable='False' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False' IsHide='False'>";
            listBoxString += "<tr ><td style='cursor:none;white-space:nowrap;' align='center'>" + listboxTitle + "</td></tr><tr>";
            listBoxString += "<td align='center'><img id='lb_" + listBoxCount + "ListBox' title='" + listboxTitle + "' style='z-index:-1;width:200px;;height:120px;' src='../Images/ListBoxDes.jpg'/></td></tr></table>";
            document.getElementById('DesignDiv').innerHTML += listBoxString;
            listBoxList += listboxTitle + ",";
            listBoxIDList += "lb_" + listBoxCount + "ListBox" + ",";
        }
        else {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    document.getElementById('IdExistsDiv').innerHTML = "None";
    listBoxCount++;
    document.getElementById('listBoxCountHidden').value = listBoxCount;
}


function CreateRadioButtonList() {
    var radioListCount = document.getElementById('radioButtonCountHidden').value;
    var radioButtonTitle = prompt("Enter the Radio Button Title.", "Enter RedioButtonList Title");
    if (radioButtonTitle == null) {
        return;
    }
    var radioButtonSize = prompt("Enter the number of radio buttons in the list.", "Enter number of radio buttons");
    if (radioButtonSize == null) {
        return;
    }
    var radioButtonString = "";
    var titleArray = new Array();

    var totalWidth = radioButtonSize * 50;
    var avgWidth = parseInt((parseInt(totalWidth)) / (parseInt(radioButtonSize)));

    var validTitle = true;
    var validSize = true;


    if ((radioButtonTitle != "undefined") && (radioButtonTitle != "") && (radioButtonTitle != null) && (radioButtonTitle != "Enter RedioButtonList Title") && radioButtonTitle.substring(0, 1) != " " && radioButtonTitle.length <= maxlength) {
        for (var i = 0; i < radioButtonTitle.length; i++) {
            if (iChars.indexOf(radioButtonTitle.charAt(i)) != -1) {
                validTitle = false;
            }
        }
        if (validTitle == false) {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    else {
        validTitle = false;
        alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
        return;
    }


    //    if(validTitle == false)
    //    {
    //        alert ("Please enter a valid title with less than 45 characters and no special characters."); 
    //    }

    //Increase radio button count to 15 added by koshal 20-feb-2014
    var rdheight = 50;
    if (radioButtonSize != null) {
        if ((radioButtonSize != "undefined") && (radioButtonSize != "") && (radioButtonSize != null) && (radioButtonSize != "Enter number of radio buttons")) {
            for (var i = 0; i < radioButtonSize.length; i++) {
                if (iSizeChars.indexOf(radioButtonSize.charAt(i)) != -1) {
                    validSize = false;
                }
            }
            if (validSize == false) {
                alert("The number of radio button has some special characters.");
                return;
            }
            else {
                var resultheight = 0;
                var resultmod = 0;
                resultheight = radioButtonSize / 5;
                resultmod = radioButtonSize % 5;
                if (resultheight < 1) {
                    resultheight = 1;
                }
                if (resultmod > 0) {
                    resultheight = resultheight + 1;
                }
            }
        }
    }
    else {
        validSize = false;
        alert("The number of radio button has some special characters.");
        return;
    }

    if (radioButtonSize <= parseInt(15) && radioButtonSize >= parseInt(1)) {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        var isDTMSCheck = true;
        isDTMSCheck = checkforDTMS(radioButtonTitle);
        if (isDTMSCheck == false) {
            return;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (radioButtonTitle.toLowerCase().trim() == titleArray[arrayCountx].toLowerCase().trim()) {
                document.getElementById('IdExistsDiv').innerHTML = "Exists"
                alert("A control with the title " + radioButtonTitle + " exists.");
                return;
            }
        }

        if (document.getElementById('FileModeHidden').value == "EDITMODE" && radioListFlag == false) {

            if (document.getElementById('radioButtonCountHidden').value != "") {
                radioListCount = parseInt(document.getElementById('radioButtonCountHidden').value) + parseInt(1);
            }
            if (document.getElementById('radioButtonCountHidden').value == "") {
                radioListCount = parseInt(0);
            }
            radioListFlag = true;
        }

        if (document.getElementById('IdExistsDiv').innerHTML != "Exists" && validSize == true && validTitle == true) {
            if ((radioButtonTitle != "undefined") && (radioButtonTitle != "") && (radioButtonTitle != null) && (radioButtonTitle != "Enter RedioButtonList Title")) {
                var radioCount = 0
                // var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
                radioButtonString += "<table id='rbl_" + radioListCount + "RadioButton' title='" + radioButtonTitle + "' type='RadioButtonList' class='drag' style='position:absolute;border:dashed 4px #afafaf;background-color:White;width:200px; top:0px; left:0px;height:50px' align='right' onclick ='FillProperties(this)'  iswrap='False' controlid='3' controltype='basic' dependency='False' isrequired='False' ismanageable='False' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False' IsHide='False'><tr style='width:50px'><td style='white-space:nowrap;'>" + radioButtonTitle + "</td>";
                for (var newcount = 1; newcount <= parseInt(resultheight); newcount++) {
                    for (radioCount; radioCount < parseInt(radioButtonSize); radioCount++) {
                        //+ radioButtonTitle

                        radioButtonString += "<td style='width:150px;cursor:hand;white-space:nowrap;vertical-align:top' align='right'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + radioButtonCount + "<input id='rbl_" + radioListCount + "RadioButton'  title='" + radioButtonCount + "' type='radio'  name='" + radioButtonTitle + "' repeatdirection='horizontal' repeatcolumns='1' /></td>";
                        if (parseInt(radioCount + 1) == parseInt(newcount) * 5 && resultheight > 1) {
                            radioButtonString += "</tr><tr style='width:50px'> <td style='white-space: nowrap;'></td>";
                            radioButtonCount++;
                            radioCount++;
                            break;
                        }
                        //document.getElementById('DesignDiv').innerHTML += "<label id='" + radioButtonCount + "RadioButton'  title='" + radioButtonTitle + "' type='radio' controlid='3' controltype='basic' dependency='No' isrequired='' iswrap='No' prewrap='' postwrap='' style='z-index:-1;width:100px;position:absolute;top:0px;left:0px' ispostback='false' onclick='FillProperties();' onmouseover='FillProperties();' class='drag'>adadsad</label>";
                        radioButtonCount++;
                    }
                }
                radioButtonString += "</tr></table>";
                document.getElementById('DesignDiv').innerHTML += radioButtonString;
            }
            else {
                alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
                return;
            }
        }
        document.getElementById('IdExistsDiv').innerHTML = "None";
        radioButtonCount = 0;
        radioListCount++;
        document.getElementById('radioButtonCountHidden').value = radioListCount;
    }
    else {
        alert("The number of radio buttons cannot be more than 15 and less than 0.");
        return;
    }
}


function CreateCheckBoxList() {
    var checkListCount = document.getElementById('checkBoxCountHidden').value;
    var checkBoxTitle = prompt("Enter the Check Box List Title.", "Enter CheckBoxList Title");
    if (checkBoxTitle == null) {
        return;
    }
    var checkBoxSize = prompt("Enter the number of check box in the list.", "Enter number of check boxes");
    if (checkBoxSize == null) {
        return;
    }
    var checkBoxString = "";
    var titleArray = new Array();
    var totalWidth = checkBoxSize * 50;
    var avgWidth = parseInt((parseInt(totalWidth)) / (parseInt(checkBoxSize)));

    var validTitle = true;
    var validSize = true;
    var rdheight = 50;
    if (checkBoxTitle != null) {
        if ((checkBoxTitle != "undefined") && (checkBoxTitle != "") && (checkBoxTitle.substring(0, 1) != " ") && (checkBoxTitle != null) && (checkBoxTitle != "Enter number of check boxes") && (checkBoxTitle.length <= maxlength)) //Earlier it was checkBoxTitle < 45. Imran
        {
            for (var i = 0; i < checkBoxTitle.length; i++) {
                if (iChars.indexOf(checkBoxTitle.charAt(i)) != -1) {
                    validTitle = false;
                }
            }
            if (validTitle == false) {
                alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
                return;
            }
            else {
                var resultheight = 0;
                var resultmod = 0;
                resultheight = checkBoxSize / 5;
                resultmod = checkBoxSize % 5;
                if (resultheight < 1) {
                    resultheight = 1;
                }
                if (resultmod > 0) {
                    resultheight = resultheight + 1;
                }
            }

        }
        else {
            validTitle = false;

        }
    }
    else {
        validTitle = false;
        alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
        return;
    }


    //    if(validTitle == false)
    //    {
    //        alert ("Please enter a valid title with less than 45 characters and no special characters."); 
    //    }

    if ((checkBoxSize != "undefined") && (checkBoxSize != "") && (checkBoxSize != null) && (checkBoxSize != "Enter number of check boxes")) {
        for (var i = 0; i < checkBoxSize.length; i++) {
            if (iSizeChars.indexOf(checkBoxSize.charAt(i)) != -1) {
                validSize = false;
            }
        }
        if (validSize == false) {
            alert("The number of check boxes has some special characters.");
            return;
        }
    }
    else {
        validSize = false;
        alert("The number of check boxes has some special characters.");
        return;
    }

    if (checkBoxSize < parseInt(16) && checkBoxSize >= parseInt(1)) {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        var isDTMSCheck = true;
        isDTMSCheck = checkforDTMS(checkBoxTitle);
        if (isDTMSCheck == false) {
            return;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (checkBoxTitle.toLowerCase().trim() == titleArray[arrayCountx].toLowerCase().trim()) {
                document.getElementById('IdExistsDiv').innerHTML = "Exists"
                alert("A control with the title " + checkBoxTitle + " exists.");
                return;
            }
        }
        if (document.getElementById('FileModeHidden').value == "EDITMODE" && checkListFlag == false) {
            if (document.getElementById('checkBoxCountHidden').value != "") {
                checkListCount = parseInt(document.getElementById('checkBoxCountHidden').value) + parseInt(1);

            }
            if (document.getElementById('checkBoxCountHidden').value == "") {
                checkListCount = parseInt(0);
            }
            checkListFlag = true;
        }


        if (document.getElementById('IdExistsDiv').innerHTML != "Exists" && validSize == true && validTitle == true) {
            if ((checkBoxTitle != "undefined") && (checkBoxTitle != "") && (checkBoxTitle != null) && (checkBoxTitle != "Enter CheckBoxList Title")) {
                var checkCount = 0
                // var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
                checkBoxString += "<table id='cbl_" + checkListCount + "CheckBox' title='" + checkBoxTitle + "' type='CheckBoxList' class='drag' style='position:absolute;border:dashed 4px #afafaf;background-color:White; width:200px; top:0px; left:0px;height:50px' align='right' onclick ='FillProperties(this)'  iswrap='False' controlid='4' controltype='basic' dependency='False' isrequired='False' ismanageable='False' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False' IsHide='False'><tr style='width:50px'><td style='white-space:nowrap;'>" + checkBoxTitle + "</td>";
                for (var newcount = 1; newcount <= parseInt(resultheight); newcount++) {
                    for (checkCount; checkCount < parseInt(checkBoxSize); checkCount++) {
                        //" + parseInt(checkBoxCount) +" //checkBoxTitle
                        //checkBoxString += "<td style='cursor:hand;white-space:nowrap; width:150px; vertical-align:top' align='right'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + parseInt(checkBoxCount) + "<input id='cbl_" + checkListCount + "CheckBox'  title='" + parseInt(checkBoxCount) + "' type='checkbox'  name='" + checkBoxTitle + "' repeatdirection='horizontal' repeatcolumns='1' /></td>";
                        checkBoxString += "<td style='cursor:hand;white-space:nowrap; width:150px; vertical-align:top' align='right'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + parseInt(checkBoxCount) + "<input id='cbl_" + checkListCount + "CheckBox'  title='" + parseInt(checkBoxCount) + "' type='checkbox'  name='" + checkBoxTitle + "' repeatdirection='horizontal' repeatcolumns='1' /></td>";
                        if (parseInt(checkCount + 1) == parseInt(newcount) * 5 && resultheight > 1) {
                            checkBoxString += "</tr><tr style='width:50px'> <td style='white-space: nowrap;'></td>";
                            checkBoxCount++;
                            checkCount++;
                            break;
                        }
                        //document.getElementById('DesignDiv').innerHTML += "<label id='" + radioButtonCount + "RadioButton'  title='" + radioButtonTitle + "' type='radio' controlid='3' controltype='basic' dependency='No' isrequired='' iswrap='No' prewrap='' postwrap='' style='z-index:-1;width:100px;position:absolute;top:0px;left:0px' ispostback='False' onclick='FillProperties();' onmouseover='FillProperties();' class='drag'>adadsad</label>";
                        checkBoxCount++;
                    }
                }
                checkBoxString += "</tr></table>";
                document.getElementById('DesignDiv').innerHTML += checkBoxString;
            }
            else {
                alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
                return;
            }
        }
        document.getElementById('IdExistsDiv').innerHTML = "None";
        checkBoxCount = parseInt(0);
        checkListCount++;
        document.getElementById('checkBoxCountHidden').value = checkListCount;
    }
    else {
        alert("The number of check boxes cannot be more than 15 and less than 0.");
        return;
    }
}

function CreateTextBox() {
    var textBoxCount = document.getElementById('textBoxCountHidden').value;
    var textboxTitle = prompt("Enter the Text Box Title");
    var textboxString = "";
    var titleArray = new Array();

    var validTitle = true;
    if (textboxTitle == null) {
        return;
    }

    if ((textboxTitle != "undefined") && (textboxTitle != "") && (textboxTitle != null) && textboxTitle.substring(0, 1) != " " && textboxTitle.length <= maxlength) {
        for (var i = 0; i < textboxTitle.length; i++) {
            if (iChars.indexOf(textboxTitle.charAt(i)) != -1) {
                validTitle = false;
            }
        }
        if (validTitle == false) {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    else {
        validTitle = false;
        alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
        return;
    }


    for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
        titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
    }
    var isDTMSCheck = true;
    isDTMSCheck = checkforDTMS(textboxTitle);
    if (isDTMSCheck == false) {
        return;
    }
    for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
        //if (textboxTitle.toLowerCase().trim() == titleArray[arrayCountx].toLowerCase().trim()) {
        if (textboxTitle == titleArray[arrayCountx]) {
            document.getElementById('IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + textboxTitle + " exists.");
            return;
        }
    }

    if (document.getElementById('FileModeHidden').value == "EDITMODE" && textBoxFlag == false) {
        if (document.getElementById('textBoxCountHidden').value != "") {
            textBoxCount = parseInt(document.getElementById('textBoxCountHidden').value) + parseInt(1);
        }
        if (document.getElementById('textBoxCountHidden').value == "") {
            textBoxCount = parseInt(0);
        }
        textBoxFlag = true;
    }

    if (document.getElementById('IdExistsDiv').innerHTML != "Exists" && validTitle == true) {
        if ((textboxTitle != "undefined") && (textboxTitle != "") && (textboxTitle != null)) {
            // var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
            textboxString += "<table id='txt_" + textBoxCount + "TextBoxTable' title='" + textboxTitle + "' type='TextBox' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; width:200px; top:0px; left:0px;' align='right' onclick ='FillProperties(this)'    controlid='1' controltype='basic' dependency='False' isrequired='False' ismanageable='False' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False'  maxlength='20' textmode='Singleline' istype='Numeric' IsHide='False'>";
            textboxString += "<tr ><td style='cursor:none;white-space:nowrap;' align='center'>" + textboxTitle + "</td>";
            textboxString += "<td align='center'><input id='txt_" + textBoxCount + "TextBox' title='" + textboxTitle + "' style='z-index:-1;width:150px;cursor:none' type='text'/></td></tr></table>";
            document.getElementById('DesignDiv').innerHTML += textboxString;
            // dropDownList += dropdownTitle + ",";
        }
        else {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    document.getElementById('IdExistsDiv').innerHTML = "None";
    textBoxCount++;
    document.getElementById('textBoxCountHidden').value = textBoxCount;
}

function CreateLabel() {
    var labelCount = document.getElementById('labelCountHidden').value;
    var labelTitle = prompt("Enter the Label Title");
    var labelString = "";
    var titleArray = new Array();

    var validTitle = true;

    if (labelTitle == null) {
        return;
    }
    if ((labelTitle != "undefined") && (labelTitle != "") && (labelTitle != null) && labelTitle.substring(0, 1) != " " && labelTitle.length <= maxlength) {
        for (var i = 0; i < labelTitle.length; i++) {
            if (iChars.indexOf(labelTitle.charAt(i)) != -1) {
                validTitle = false;
            }
        }
        if (validTitle == false) {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    else {
        validTitle = false;
        alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
        return;
    }


    for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
        titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
    }
    var isDTMSCheck = true;
    isDTMSCheck = checkforDTMS(labelTitle);
    if (isDTMSCheck == false) {
        return;
    }
    for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
        if (labelTitle.toLowerCase().trim() == titleArray[arrayCountx].toLowerCase().trim()) {
            document.getElementById('IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + labelTitle + " exists.");
            return;
        }
    }
    if (document.getElementById('FileModeHidden').value == "EDITMODE" && labelFlag == false) {
        if (document.getElementById('labelCountHidden').value != "") {
            labelCount = parseInt(document.getElementById('labelCountHidden').value) + parseInt(1);
        }
        if (document.getElementById('labelCountHidden').value == "") {
            labelCount = parseInt(0);
        }
        labelFlag = true;
    }

    if (document.getElementById('IdExistsDiv').innerHTML != "Exists" && validTitle == true) {
        if ((labelTitle != "undefined") && (labelTitle != "") && (labelTitle != null)) {
            //var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
            labelString += "<table id='lbl_" + labelCount + "LabelTable' title='" + labelTitle + "' type='Label' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; width:200px; top:0px; left:0px;' align='right' onclick ='FillProperties(this)'    controlid='1' controltype='basic' dependency='False' isrequired='False' ismanageable='False' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False' IsHide='False'>";
            labelString += "<tr ><td style='cursor:none;white-space:nowrap;' align='center'>" + labelTitle + "</td>";
            labelString += "<td align='center'><label id='lbl_" + labelCount + "Label' title='" + labelTitle + "' style='z-index:-1;width:150px;cursor:none'></label></td></tr></table>";
            document.getElementById('DesignDiv').innerHTML += labelString;
            // dropDownList += dropdownTitle + ",";
        }
        else {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    document.getElementById('IdExistsDiv').innerHTML = "None";
    labelCount++;
    document.getElementById('labelCountHidden').value = labelCount;
}

function CreateButton() {
    var buttonCount = document.getElementById('buttonCountHidden').value;
    var buttonTitle = prompt("Enter the Button Title");
    var buttonString = "";
    var titleArray = new Array();

    var validTitle = true;
    if (buttonTitle == null) {
        return;
    }
    if ((buttonTitle != "undefined") && (buttonTitle != "") && (buttonTitle != null) && buttonTitle.substring(0, 1) != " " && buttonTitle.length <= maxlength) {
        for (var i = 0; i < buttonTitle.length; i++) {
            if (iChars.indexOf(buttonTitle.charAt(i)) != -1) {
                validTitle = false;
            }
        }
        if (validTitle == false) {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    else {
        validTitle = false;
        alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
        return;
    }

    for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
        titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
    }
    var isDTMSCheck = true;
    isDTMSCheck = checkforDTMS(buttonTitle);
    if (isDTMSCheck == false) {
        return;
    }
    for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
        if (buttonTitle.toLowerCase().trim() == titleArray[arrayCountx].toLowerCase().trim()) {
            document.getElementById('IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + buttonTitle + " exists.");
            return;
        }
    }
    if (document.getElementById('FileModeHidden').value == "EDITMODE" && buttonFlag == false) {
        if (document.getElementById('buttonCountHidden').value != "") {
            buttonCount = parseInt(document.getElementById('buttonCountHidden').value) + parseInt(1);
        }
        if (document.getElementById('buttonCountHidden').value == "") {
            buttonCount = parseInt(0);
        }
        buttonFlag = true;
    }

    if (document.getElementById('IdExistsDiv').innerHTML != "Exists" && validTitle == true) {
        if ((buttonTitle != "undefined") && (buttonTitle != "") && (buttonTitle != null)) {
            // var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
            buttonString += "<table id='but_" + buttonCount + "ButtonTable' title='" + buttonTitle + "' type='BButton' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; width:200px;top:0px; left:0px;' align='right' onclick ='FillProperties(this)'    controlid='1' controltype='basic' dependency='False' isrequired='False' ismanageable='False' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False' IsHide='False'>";
            buttonString += "<tr ><td style='cursor:none;white-space:nowrap;' align='center'></td>";
            buttonString += "<td align='center'><input id='but_" + buttonCount + "Button' title='" + buttonTitle + "' style='z-index:-1;width:100px;cursor:none' type='button' readonly='true' value='" + buttonTitle + "'/></td></tr></table>";
            document.getElementById('DesignDiv').innerHTML += buttonString;
            // dropDownList += dropdownTitle + ",";
        }
        else {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    document.getElementById('IdExistsDiv').innerHTML = "None";
    buttonCount++;
    document.getElementById('buttonCountHidden').value = buttonCount;
}

//******************************************Region for Employee Custom Control - Starts **************************************************//

function CreateCC1Employees() {
    // alert();
    var customCount = document.getElementById('customCountHidden').value;
    var empDropDownTitle = prompt("Enter the Emp Drop Down Title");
    var empDropDownString = "";
    var titleArray = new Array();

    var validTitle = true;
    if (empDropDownTitle == null) {
        return;
    }

    if ((empDropDownTitle != "undefined") && (empDropDownTitle != "") && (empDropDownTitle != null) && empDropDownTitle.substring(0, 1) != " " && empDropDownTitle.length <= maxlength) {
        for (var i = 0; i < empDropDownTitle.length; i++) {
            if (iChars.indexOf(empDropDownTitle.charAt(i)) != -1) {
                validTitle = false;
            }
        }
        if (validTitle == false) {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    else {
        validTitle = false;
        alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
        return;
    }

    for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
        titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
    }
    var isDTMSCheck = true;
    isDTMSCheck = checkforDTMS(empDropDownTitle);
    if (isDTMSCheck == false) {
        return;
    }
    for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
        if (empDropDownTitle.toLowerCase().trim() == titleArray[arrayCountx].toLowerCase().trim()) {
            document.getElementById('IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + empDropDownTitle + " exists.");
            return;
        }
    }
    if (document.getElementById('FileModeHidden').value == "EDITMODE" && customFlag == false) {
        if (document.getElementById('customCountHidden').value != "") {
            customCount = parseInt(document.getElementById('customCountHidden').value) + parseInt(1);
        }
        if (document.getElementById('customCountHidden').value == "") {
            customCount = parseInt(0);
        }
        customFlag = true;
    }

    if (document.getElementById('IdExistsDiv').innerHTML != "Exists" && validTitle == true) {
        if ((empDropDownTitle != "undefined") && (empDropDownTitle != "") && (empDropDownTitle != null)) {
            //var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
            empDropDownString += "<table id='cc_" + customCount + "DropDownTable' title='" + empDropDownTitle + "' type='EmpDropDown' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:0px; left:0px;width:200px' align='right' onclick ='FillProperties(this)'  iswrap='False' controlid='4' controltype='custom' isrequired='False' datasource='DB' skillset='None' skillsetvalues='None' costcentre='None' costcentrevalues='None' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False' IsQueryPattern='Contains' IsHide='False'>";
            empDropDownString += "<tr ><td style='cursor:none;white-space:nowrap;' align='left'>" + empDropDownTitle + "</td>";
            empDropDownString += "<td align='right'><img id='cc_" + customCount + "DropDown' title='" + empDropDownTitle + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/></td>";
            empDropDownString += "<td><img id='ShowCustPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
            empDropDownString += "cursor: hand; padding-left: 5px;' onclick='ShowCustProps(event, this);' align='left' /></td></tr></table>";
            document.getElementById('DesignDiv').innerHTML += empDropDownString;
            //dropDownList += dropdownTitle + ",";
        }
        else {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    document.getElementById('IdExistsDiv').innerHTML = "None";
    customCount++;
    document.getElementById('customCountHidden').value = customCount;
}


// code added on aug

function CreateCC3Employees() {
    // alert();
    var customCount = document.getElementById('customCountHidden').value;
    var empDropDownTitle = prompt("Enter the Emp Drop Down Title");
    var empDropDownString = "";
    var titleArray = new Array();

    var validTitle = true;
    if (empDropDownTitle == null) {
        return;
    }

    if ((empDropDownTitle != "undefined") && (empDropDownTitle != "") && (empDropDownTitle != null) && empDropDownTitle.substring(0, 1) != " " && empDropDownTitle.length <= maxlength) {
        for (var i = 0; i < empDropDownTitle.length; i++) {
            if (iChars.indexOf(empDropDownTitle.charAt(i)) != -1) {
                validTitle = false;
            }
        }
        if (validTitle == false) {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    else {
        validTitle = false;
        alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
        return;
    }

    for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
        titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
    }
    var isDTMSCheck = true;
    isDTMSCheck = checkforDTMS(empDropDownTitle);
    if (isDTMSCheck == false) {
        return;
    }
    for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
        if (empDropDownTitle.toLowerCase().trim() == titleArray[arrayCountx].toLowerCase().trim()) {
            document.getElementById('IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + empDropDownTitle + " exists.");
            return;
        }
    }
    if (document.getElementById('FileModeHidden').value == "EDITMODE" && customFlag == false) {
        if (document.getElementById('customCountHidden').value != "") {
            customCount = parseInt(document.getElementById('customCountHidden').value) + parseInt(1);
        }
        if (document.getElementById('customCountHidden').value == "") {
            customCount = parseInt(0);
        }
        customFlag = true;
    }

    if (document.getElementById('IdExistsDiv').innerHTML != "Exists" && validTitle == true) {
        if ((empDropDownTitle != "undefined") && (empDropDownTitle != "") && (empDropDownTitle != null)) {
            //var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()

            // old code commented
            //            empDropDownString += "<table id='cc_" + customCount + "DropDownTable' title='" + empDropDownTitle + "' type='EmpManagerDropDown' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:0px; left:0px;width:200px' align='right' onclick ='FillProperties(this)'  iswrap='False' controlid='4' controltype='custom' isrequired='False' datasource='DB' skillset='None' skillsetvalues='None' costcentre='None' costcentrevalues='None' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False' IsQueryPattern='Contains' IsHide='False'>";
            //            empDropDownString += "<tr ><td style='cursor:none;white-space:nowrap;' align='left'>" + empDropDownTitle + "</td>";
            //            empDropDownString += "<td align='right'><img id='cc_" + customCount + "DropDown' title='" + empDropDownTitle + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/></td>";
            //            empDropDownString += "<td><img id='ShowCustPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
            //            empDropDownString += "cursor: hand; padding-left: 5px;' onclick='ShowCustProps(event, this);' align='left' /></td></tr>";
            //            empDropDownString += "<tr><input id='cctxt_" + customCount + "TextBox' title='" + empDropDownTitle + " Manager' style='z-index:-1;width:150px;cursor:none' type='text' readonly/></tr></table>";
            //            document.getElementById('DesignDiv').innerHTML += empDropDownString;
            // old code commented

            empDropDownString += "<table id='cc_" + customCount + "DropDownTable' title='" + empDropDownTitle + "' type='EmpManagerDropDown' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:0px; left:0px;width:200px' align='right' onclick ='FillProperties(this)'  iswrap='False' controlid='4' controltype='custom' isrequired='False' datasource='DB' skillset='None' skillsetvalues='None' costcentre='None' costcentrevalues='None' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False' IsQueryPattern='Contains' IsHide='False'>";
            empDropDownString += "<tr ><td style='cursor:none;white-space:nowrap;' align='left'>" + empDropDownTitle + "</td>";
            empDropDownString += "<td align='right'><img id='cc_" + customCount + "DropDown' title='" + empDropDownTitle + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/></td>";
            empDropDownString += "<td><img id='ShowCustPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
            empDropDownString += "cursor: hand; padding-left: 5px;' onclick='ShowCustProps(event, this);' align='left' /></td></tr>";
            empDropDownString += "</table>";

            empDropDownString += "<table id='cctxt_" + customCount + "DropDownTable' title='" + empDropDownTitle + "' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:0px; left:250px;width:200px' align='right' controltype='custom'  iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False' IsQueryPattern='Contains' IsHide='False'>";
            empDropDownString += "<tr ><td style='cursor:none;white-space:nowrap;' align='left'>" + empDropDownTitle + " Manager</td>";
            empDropDownString += "<td align='right'><input id='cctxt_" + customCount + "TextBox' title='" + empDropDownTitle + " Manager' style='z-index:-1;width:150px;cursor:none' type='text' readonly/></td>";
            empDropDownString += "</tr></table>";


            document.getElementById('DesignDiv').innerHTML += empDropDownString;

        }
        else {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    document.getElementById('IdExistsDiv').innerHTML = "None";
    customCount++;
    document.getElementById('customCountHidden').value = customCount;
}

// code ends



var controlID = "";

function ShowCustProps(e, element) {
    var height = e.clientY + parseInt('2');
    var offsetHeight = parseInt(e.offsetY);
    height = height - offsetHeight;
    var width = e.clientX
    var offsetWidth = parseInt(e.offsetX);
    width = width - offsetWidth;
    var div = document.getElementById('EmpCtrlDiv');
    div.style.display = 'block';
    var rightedge = parseInt(document.body.clientWidth) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientX) - 2;
    var bottomedge = parseInt(document.body.clientHeight) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientY) + 2;
    lefter = (rightedge < width) ? event.srcElement.parentNode.parentNode.parentNode.parentNode.clientX - 200 : event.clientX - 0;
    topper = (bottomedge < height) ? event.srcElement.parentNode.parentNode.parentNode.parentNode.clientY - 200 : event.clientY - 0;
    if (parseInt(width) >= 1000) {
        lefter = parseInt(event.clientX) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientWidth) - 200;
    }
    if (parseInt(height) >= 550) {
        topper = parseInt(event.clientY) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientHeight) - 250;
    }
    div.style.top = topper;
    div.style.left = lefter;
    document.getElementById('SkillSetSelect').options.length = 0;
    document.getElementById('IdLabel').innerHTML = event.srcElement.parentNode.parentNode.parentNode.parentNode.title;
    controlID = event.srcElement.parentNode.parentNode.parentNode.parentNode.id;

    var empCustObject = event.srcElement.parentNode.parentNode.parentNode.parentNode;

    if (empCustObject.costcentre != "None") {
        var costCentreArray = new Array();
        costCentreArray = empCustObject.getAttribute('costcentre').split(',');
        costCentreArray.pop(costCentreArray.length - 1);
        document.getElementById('ChangeCCLabel').style.display = 'block';
        document.getElementById('CostCentreSelect').style.display = 'none';
        document.getElementById('CCLabel').innerHTML = costCentreArray;
        //       if(document.getElementById('CostCentreSelect').options.selectedIndex == -1)
        //       {
        //        event.srcElement.parentNode.parentNode.parentNode.parentNode.costcentre = "None";
        //        alert();
        //       }
    }
    if (empCustObject.costcentre == "None" || empCustObject.costcentre == null) {
        document.getElementById('CostCentreSelect').options.selectedIndex = -1;
        document.getElementById('ChangeCCLabel').style.display = 'none';
        document.getElementById('CostCentreSelect').style.display = 'block';
    }

    if (empCustObject.skillset != "None") {
        var skillSetArray = new Array();
        skillSetArray = empCustObject.getAttribute('skillset').split(',');
        skillSetArray.pop(skillSetArray.length - 1);
        document.getElementById('ChangeSSLabel').style.display = 'block';
        document.getElementById('SkillSetSelect').style.display = 'none';
        document.getElementById('SSLabel').innerHTML = skillSetArray;
        //document.getElementById('SSLabel').style.display = 'block';
        //         if(document.getElementById('SkillSetSelect').options.selectedIndex == -1)
        //       {
        //        event.srcElement.parentNode.parentNode.parentNode.parentNode.skillset = "None";
        //       }
    }

    if (empCustObject.skillset == "None" || empCustObject.skillset == null) {
        document.getElementById('SkillSetSelect').options.selectedIndex = -1;
        document.getElementById('ChangeSSLabel').style.display = 'none';
        document.getElementById('SkillSetSelect').style.display = 'block';
    }

    //   if(document.getElementById('SkillSetSelect').style.display == 'none')
    //   {
    //    document.getElementById('ChangeSSLabel').style.display = 'block';
    //   }
    //   
    //   if(document.getElementById('SkillSetSelect').style.display == 'block')
    //   {
    //    document.getElementById('ChangeSSLabel').style.display = 'none';
    //   }
    //    if(document.getElementById('CostCentreSelect').style.display == 'none')
    //   {
    //    document.getElementById('ChangeCCLabel').style.display = 'block';
    //   }
    //   
    //   if(document.getElementById('CostCentreSelect').style.display == 'block')
    //   {
    //    document.getElementById('ChangeCCLabel').style.display = 'none';
    //   }

}

function ChangeSSSelect() {
    document.getElementById('CostCentreSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.costcentre = "None";
    document.getElementById('CostCentreSelect').style.display = 'block';
    document.getElementById('ChangeCCLabel').style.display = 'none';
    document.getElementById('CCLabel').innerHTML = "";

    document.getElementById('SkillSetSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.skillset = "None";
    document.getElementById('SkillSetSelect').style.display = 'block';
    document.getElementById('ChangeSSLabel').style.display = 'none';
    document.getElementById('SSLabel').innerHTML = "";


}

function ChangeCCSelect() {
    document.getElementById('CostCentreSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.costcentre = "None";
    document.getElementById('CostCentreSelect').style.display = 'block';
    document.getElementById('ChangeCCLabel').style.display = 'none';
    document.getElementById('CCLabel').innerHTML = "";

    document.getElementById('SkillSetSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.skillset = "None";
    document.getElementById('SkillSetSelect').style.display = 'block';
    document.getElementById('ChangeSSLabel').style.display = 'none';
    document.getElementById('SSLabel').innerHTML = "";
}


function HideShowProps() {
    var costcentreString = "";
    var costcentreValues = "";
    var skillsetString = "";
    var skillsetValues = "";
    document.getElementById('EmpCtrlDiv').style.display = 'none';
    var controlILabel = document.getElementById('IdLabel').innerHTML;
    for (var selectCC = 0; selectCC < document.getElementById('CostCentreSelect').options.length; selectCC++) {
        if (document.getElementById('CostCentreSelect').options[selectCC].selected) {
            costcentreString += document.getElementById('CostCentreSelect').options[selectCC].innerText;
            costcentreString += ",";
            costcentreValues += document.getElementById('CostCentreSelect').options[selectCC].value;
            costcentreValues += ",";
        }
    }
    for (var selectSS = 0; selectSS < document.getElementById('SkillSetSelect').options.length; selectSS++) {
        if (document.getElementById('SkillSetSelect').options[selectSS].selected) {
            skillsetString += document.getElementById('SkillSetSelect').options[selectSS].innerText;
            skillsetString += ",";
            skillsetValues += document.getElementById('SkillSetSelect').options[selectSS].value;
            skillsetValues += ",";
        }
    }
    if (skillsetValues == "") {
        document.getElementById('EmpCtrlDiv').style.display = '';
        alert("Please select a skillset");
        return false;
    }

    document.getElementById(controlID).setAttribute('costcentre', costcentreString);
    document.getElementById(controlID).setAttribute('costcentrevalues', costcentreValues);
    document.getElementById(controlID).setAttribute('skillset', skillsetString);
    document.getElementById(controlID).setAttribute('skillsetvalues', skillsetValues);

    if (costcentreString == "") {
        document.getElementById(controlID).costcentre = 'None';
        document.getElementById(controlID).costcentrevalues = 'None';
    }
    if (costcentreValues == "") {
        document.getElementById(controlID).costcentrevalues = 'None';
    }
    if (skillsetString == "") {
        document.getElementById(controlID).skillset = 'None';
        document.getElementById(controlID).skillsetvalues = 'None';
    }
    if (skillsetValues == "") {
        document.getElementById(controlID).skillsetvalues = 'None';
    }





}
//******************************************Region for Employee Custom Control - Ends **************************************************//

//******************************************Region for Employee Global Control - Starts **************************************************//


function CreateMultipleGlobal(element) {
    //    alert(element.innerHTML);//Error in element.

    var globalCount = document.getElementById('globalCountHidden').value;
    var elementArray = new Array();
    elementArray = element.innerHTML.split('/');

    var globalMDropDownTitle = prompt("Enter the " + element.innerHTML + " Title");
    var globalMDropDownString = "";
    var titleArray = new Array();

    var validTitle = true;
    if (globalMDropDownTitle == null) {
        return;
    }
    if ((globalMDropDownTitle != "undefined") && (globalMDropDownTitle != "") && (globalMDropDownTitle != null) && globalMDropDownTitle.substring(0, 1) != " " && globalMDropDownTitle.length <= maxlength) {
        for (var i = 0; i < globalMDropDownTitle.length; i++) {
            if (iChars.indexOf(globalMDropDownTitle.charAt(i)) != -1) {
                validTitle = false;
            }
        }
        if (validTitle == false) {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    else {
        validTitle = false;
        alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
        return;
    }
    for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
        titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
    }
    var isDTMSCheck = true;
    isDTMSCheck = checkforDTMS(globalMDropDownTitle);
    if (isDTMSCheck == false) {
        return;
    }
    for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
        if (globalMDropDownTitle.toLowerCase().trim() == titleArray[arrayCountx].toLowerCase().trim()) {
            document.getElementById('IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + globalMDropDownTitle + " exists.");
            return;
        }
    }

    if (document.getElementById('FileModeHidden').value == "EDITMODE" && globalFlag == false) {
        if (document.getElementById('globalCountHidden').value != "") {
            globalCount = parseInt(document.getElementById('globalCountHidden').value) + parseInt(1);
        }
        if (document.getElementById('globalCountHidden').value == "") {
            globalCount = parseInt(0);
        }
        globalFlag = true;
    }

    if (document.getElementById('IdExistsDiv').innerHTML != "Exists" && validTitle == true) {
        if ((globalMDropDownTitle != "undefined") && (globalMDropDownTitle != "") && (globalMDropDownTitle != null)) {
            globalMDropDownString += "<table id='gc_" + globalCount + "_" + elementArray[0] + "DropDownTable' title='" + globalMDropDownTitle + "' type='GlobalMControl' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:0px; left:0px;width:400px' align='right' onclick ='FillProperties(this)'  iswrap='False'  controltype='global' isrequired='False' datasource='DB' skillset='None' skillsetvalues='None' costcentre='None' costcentrevalues='None' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False' dependentid='gc_" + globalCount + "_" + elementArray[1] + "DropDown' controlid='" + element.getAttribute('ctrlid') + "' depctrlid='" + element.getAttribute('depctrlid') + "'; IsQueryPattern='Contains'>"; //
            globalMDropDownString += "<tr ><td style='cursor:none;white-space:nowrap;' align='left'>" + globalMDropDownTitle + "</td>";
            globalMDropDownString += "<td align='right'><img id='gc_" + globalCount + "_" + elementArray[0] + "DropDown' title='" + globalMDropDownTitle + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/>&nbsp;&nbsp;";
            globalMDropDownString += "<td><img id='gc_" + globalCount + "_" + elementArray[1] + "DropDown' title='" + globalMDropDownTitle + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/></td>";
            globalMDropDownString += "</td>";
            globalMDropDownString += "<td><img id='ShowGlobalPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
            globalMDropDownString += "cursor: hand; padding-left: 5px;' onclick='ShowGlobalProps(event, this, " + element.getAttribute('ctrlid') + ", CCArray);' align='left'/></td></tr></table>";
            document.getElementById('DesignDiv').innerHTML += globalMDropDownString;
            //dropDownList += dropdownTitle + ",";
        }
        else {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    document.getElementById('IdExistsDiv').innerHTML = "None";
    globalCount++;
    document.getElementById('globalCountHidden').value = globalCount;
}



function CreateSingleGlobal(element) {
    var globalCount = document.getElementById('globalCountHidden').value;
    var globalSDropDownTitle = prompt("Enter the " + element.innerHTML + " Title");
    var globalSDropDownString = "";
    var titleArray = new Array();

    var validTitle = true;
    if (globalSDropDownTitle == null) {
        return;
    }
    if ((globalSDropDownTitle != "undefined") && (globalSDropDownTitle != "") && (globalSDropDownTitle != null) && globalSDropDownTitle.substring(0, 1) != " " && globalSDropDownTitle.length <= maxlength) {
        for (var i = 0; i < globalSDropDownTitle.length; i++) {
            if (iChars.indexOf(globalSDropDownTitle.charAt(i)) != -1) {
                validTitle = false;
            }
        }
        if (validTitle == false) {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    else {
        validTitle = false;
        alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
        return;
    }


    for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
        titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
    }
    var isDTMSCheck = true;
    isDTMSCheck = checkforDTMS(globalSDropDownTitle);
    if (isDTMSCheck == false) {
        return;
    }
    for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
        if (globalSDropDownTitle.toLowerCase().trim() == titleArray[arrayCountx].toLowerCase().trim()) {
            document.getElementById('IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + globalSDropDownTitle + " exists.");
            return;
        }
    }

    var ctrlid = element.getAttribute('ctrlid');

    if (document.getElementById('FileModeHidden').value == "EDITMODE" && globalFlag == false) {
        if (document.getElementById('globalCountHidden').value != "") {
            globalCount = parseInt(document.getElementById('globalCountHidden').value) + parseInt(1);
        }
        if (document.getElementById('globalCountHidden').value == "") {
            globalCount = parseInt(0);
        }
        globalFlag = true;
    }

    if (document.getElementById('IdExistsDiv').innerHTML != "Exists" && validTitle == true) {
        if ((globalSDropDownTitle != "undefined") && (globalSDropDownTitle != "") && (globalSDropDownTitle != null)) {
            globalSDropDownString += "<table id='gc_" + globalCount + "_" + element.innerHTML + "DropDownTable' title='" + globalSDropDownTitle + "' type='GlobalSControl' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:0px; left:0px;width:300px' align='right' onclick ='FillProperties(this)'  iswrap='False'  controltype='global' isrequired='False' datasource='DB' skillset='None' skillsetvalues='None' costcentre='None' costcentrevalues='None' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False' controlid='" + element.getAttribute('ctrlid') + "'; IsQueryPattern='Contains'>"; //
            globalSDropDownString += "<tr ><td style='cursor:none;white-space:nowrap;' align='left'>" + globalSDropDownTitle + "</td>";
            globalSDropDownString += "<td align='right'><img id='gc_" + globalCount + "_" + element.innerHTML + "DropDown' title='" + globalSDropDownTitle + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/>&nbsp;&nbsp;";
            globalSDropDownString += "<td><img id='ShowGlobalPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
            globalSDropDownString += "cursor: hand; padding-left: 5px;' onclick='ShowGlobalProps(event, this, " + ctrlid + ", CCArray);' align='left' /></td></tr></table>";
            document.getElementById('DesignDiv').innerHTML += globalSDropDownString;

            //dropDownList += dropdownTitle + ",";
        }
        else {
            alert("Please enter a valid title with less than " + maxlength + " characters and no special characters.");
            return;
        }
    }
    document.getElementById('IdExistsDiv').innerHTML = "None";
    globalCount++;
    document.getElementById('globalCountHidden').value = globalCount;
}


var controlID = "";


function ShowGlobalProps(e, element, ctrlID, ccarray) {
    var height = e.clientY + parseInt('2');
    var offsetHeight = parseInt(e.offsetY);
    height = height - offsetHeight;
    var width = e.clientX
    var offsetWidth = parseInt(e.offsetX);
    width = width - offsetWidth;
    var div = document.getElementById('HandsetDiv');
    div.style.display = 'block';
    var rightedge = parseInt(document.body.clientWidth) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientX) - 2;
    var bottomedge = parseInt(document.body.clientHeight) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientY) + 2;
    lefter = (rightedge < width) ? event.srcElement.parentNode.parentNode.parentNode.parentNode.clientX - 200 : event.clientX - 0;
    topper = (bottomedge < height) ? event.srcElement.parentNode.parentNode.parentNode.parentNode.clientY - 200 : event.clientY - 0;
    if (parseInt(width) >= 1000) {
        lefter = parseInt(event.clientX) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientWidth) - 200;
    }
    if (parseInt(height) >= 550) {
        topper = parseInt(event.clientY) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientHeight) - 250;
    }
    div.style.top = topper;
    div.style.left = lefter;

    document.getElementById('CostCentreGlobalSelect').length = 0;
    document.getElementById('SkillSetGlobalSelect').length = 0;

    BindGlobalCostCentre(ctrlID, ccarray);
    document.getElementById('CtrlIDLabel').innerHTML = ctrlID;

    document.getElementById('IdGlobalLabel').innerHTML = event.srcElement.parentNode.parentNode.parentNode.parentNode.title;
    controlID = event.srcElement.parentNode.parentNode.parentNode.parentNode.id;

    var empCustObject = event.srcElement.parentNode.parentNode.parentNode.parentNode;

    if (empCustObject.costcentre != "None") {
        var costCentreArray = new Array();
        costCentreArray = empCustObject.getAttribute('costcentre').split(',');
        costCentreArray.pop(costCentreArray.length - 1);
        document.getElementById('ChangeCCGlobalLabel').style.display = 'block';
        document.getElementById('CostCentreGlobalSelect').style.display = 'none';
        document.getElementById('CCGlobalLabel').innerHTML = costCentreArray;
        document.getElementById('CCGlobalLabel').style.display = 'block';
        //       if(document.getElementById('CostCentreGlobalSelect').options.selectedIndex == -1)
        //       {
        //        event.srcElement.parentNode.parentNode.parentNode.parentNode.costcentre = "None";
        //       }

    }
    if (empCustObject.costcentre == "None" || empCustObject.costcentre == null) {
        document.getElementById('CostCentreGlobalSelect').options.selectedIndex = -1;
        document.getElementById('ChangeCCGlobalLabel').style.display = 'none';
        document.getElementById('CCGlobalLabel').style.display = 'none';
        document.getElementById('CostCentreGlobalSelect').style.display = 'block';
    }

    if (empCustObject.skillset != "None") {
        var skillSetArray = new Array();
        skillSetArray = empCustObject.getAttribute('skillset').split(',');
        skillSetArray.pop(skillSetArray.length - 1);
        document.getElementById('ChangeSSGlobalLabel').style.display = 'block';
        document.getElementById('SkillSetGlobalSelect').style.display = 'none';
        document.getElementById('SSGlobalLabel').innerHTML = skillSetArray;
        document.getElementById('SSGlobalLabel').style.display = 'block';
        //document.getElementById('SSLabel').style.display = 'block';
        //         if(document.getElementById('SkillSetGlobalSelect').options.selectedIndex == -1)
        //       {
        //        event.srcElement.parentNode.parentNode.parentNode.parentNode.skillset = "None";
        //       }
    }

    if (empCustObject.skillset == "None" || empCustObject.skillset == null) {
        document.getElementById('SkillSetGlobalSelect').options.selectedIndex = -1;
        document.getElementById('ChangeSSGlobalLabel').style.display = 'none';
        document.getElementById('SSGlobalLabel').style.display = 'none';
        document.getElementById('SkillSetGlobalSelect').style.display = 'block';
    }

}

function ChangeSSGlobalSelect() {
    document.getElementById('CostCentreGlobalSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.costcentre = "None";
    document.getElementById('CostCentreGlobalSelect').style.display = 'block';
    document.getElementById('ChangeCCGlobalLabel').style.display = 'none';
    document.getElementById('CCGlobalLabel').innerHTML = "";

    document.getElementById('SkillSetGlobalSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.skillset = "None";
    document.getElementById('SkillSetGlobalSelect').style.display = 'block';
    document.getElementById('ChangeSSGlobalLabel').style.display = 'none';
    document.getElementById('SSGlobalLabel').innerHTML = "";
}

function ChangeCCGlobalSelect() {
    document.getElementById('CostCentreGlobalSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.costcentre = "None";
    document.getElementById('CostCentreGlobalSelect').style.display = 'block';
    document.getElementById('ChangeCCGlobalLabel').style.display = 'none';
    document.getElementById('CCGlobalLabel').innerHTML = "";

    document.getElementById('SkillSetGlobalSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.skillset = "None";
    document.getElementById('SkillSetGlobalSelect').style.display = 'block';
    document.getElementById('ChangeSSGlobalLabel').style.display = 'none';
    document.getElementById('SSGlobalLabel').innerHTML = "";
}


function BindGlobalCostCentre(ctrlID, ccarray) {
    for (arrayCounter = 0; arrayCounter < ccarray.length; arrayCounter++) {
        if (ctrlID == ccarray[arrayCounter][2]) {
            var opt = document.createElement("option");
            document.getElementById("CostCentreGlobalSelect").options.add(opt);
            textVal = ccarray[arrayCounter][0];
            textDet = ccarray[arrayCounter][1];
            opt.text = textDet;
            opt.value = textVal;
        }
    }
}

function BindGlobalSkillSet(costCentre) {  //alert(costCentre.options[costCentre.options.selectedIndex].value);
    // alert(ctrlid);
    //alert(event.srcElement.parentNode.parentNode.parentNode.parentNode.tagName);
    document.getElementById("SkillSetGlobalSelect").length = 0;
    for (var arrayCounter = 0; arrayCounter < document.getElementById("CostCentreGlobalSelect").length; arrayCounter++) {
        if (document.getElementById("CostCentreGlobalSelect").options[arrayCounter].selected) {
            for (ssarrayCounter = 0; ssarrayCounter < SSArray.length; ssarrayCounter++) {
                //checking if the costcentreid in skillset array matches with CCid in cost centre listbox
                if (document.getElementById("CostCentreGlobalSelect").options[arrayCounter].value == SSArray[ssarrayCounter][3] && document.getElementById('CtrlIDLabel').innerHTML == SSArray[ssarrayCounter][2]) {
                    var skillid = SSArray[ssarrayCounter][1];

                    var ssopt = document.createElement("option");
                    document.getElementById("SkillSetGlobalSelect").options.add(ssopt);

                    sstextDet = SSArray[ssarrayCounter][0];
                    sstextVal = SSArray[ssarrayCounter][1];
                    ssopt.text = sstextDet;
                    ssopt.value = sstextVal;
                }
            }
        }
    }
}


function HideShowGlobalProps() {
    var costcentreString = "";
    var costcentreValues = "";
    var skillsetString = "";
    var skillsetValues = "";
    document.getElementById('HandsetDiv').style.display = 'none';
    var controlILabel = document.getElementById('IdGlobalLabel').innerHTML;
    for (var selectCC = 0; selectCC < document.getElementById('CostCentreGlobalSelect').options.length; selectCC++) {
        if (document.getElementById('CostCentreGlobalSelect').options[selectCC].selected) {
            costcentreString += document.getElementById('CostCentreGlobalSelect').options[selectCC].innerText;
            costcentreString += ",";
            costcentreValues += document.getElementById('CostCentreGlobalSelect').options[selectCC].value;
            costcentreValues += ",";
        }
    }
    for (var selectSS = 0; selectSS < document.getElementById('SkillSetGlobalSelect').options.length; selectSS++) {
        if (document.getElementById('SkillSetGlobalSelect').options[selectSS].selected) {
            skillsetString += document.getElementById('SkillSetGlobalSelect').options[selectSS].innerText;
            skillsetString += ",";
            skillsetValues += document.getElementById('SkillSetGlobalSelect').options[selectSS].value;
            skillsetValues += ",";
        }
    }

    if (skillsetValues == "") {
        document.getElementById('HandsetDiv').style.display = '';
        alert("Please select a skillset");
        return false;
    }

    document.getElementById(controlID).setAttribute('costcentre', costcentreString);
    document.getElementById(controlID).setAttribute('costcentrevalues', costcentreValues);
    document.getElementById(controlID).setAttribute('skillset', skillsetString);
    document.getElementById(controlID).setAttribute('skillsetvalues', skillsetValues);
    if (costcentreString == "") {
        document.getElementById(controlID).costcentre = 'None';
        document.getElementById(controlID).costcentrevalues = 'None';
    }
    if (costcentreValues == "") {
        document.getElementById(controlID).costcentrevalues = 'None';
    }
    if (skillsetString == "") {
        document.getElementById(controlID).skillset = 'None';
        document.getElementById(controlID).skillsetvalues = 'None';
    }
    if (skillsetValues == "") {
        document.getElementById(controlID).skillsetvalues = 'None';
    }
}

//******************************************Region for Employee Global Control - Ends **************************************************//



//This function is used to fill the properties of the clicked control in the design view.
function FillProperties(clickedElement) {
    clickedElement = event.srcElement;
    document.getElementById('storeControlTypeDiv').innerHTML = clickedElement.type;
    document.getElementById('storeIdDiv').innerHTML = clickedElement.id;
    document.getElementById('ToHideSelect').value = clickedElement.IsHide;

    document.getElementById('MultilineWidth').style.display = "none";
    document.getElementById('txtmultilinewidth').style.display = "none";
    document.getElementById('MultilineHeight').style.display = "none";
    document.getElementById('txtmultilineheight').style.display = "none";

    if (clickedElement.type == "MainDiv") {
        document.getElementById('PropertiesTable').style.display = 'none';
        document.getElementById('DeleteButton').style.display = 'none';

        //added to hide format button when property panel closed and show when opened
        //for format button visibility issue : Bappa
        //if (document.getElementById('HideTableImg').style.display != "block")
        //    document.getElementById('btnformat').style.display = 'none';
        //else
        document.getElementById('btnformat').style.display = 'block';

        for (var checkChild = 0; checkChild < document.getElementById('DesignDiv').childNodes.length; checkChild++) {
            document.getElementById('DesignDiv').childNodes[checkChild].style.border = "#afafaf 4px dashed";
        }
    }
    else {
        document.getElementById('btnformat').style.display = 'none';
        if (document.getElementById('HideTableImg').style.display != 'none') {
            for (var checkChild = 0; checkChild < document.getElementById('DesignDiv').childNodes.length; checkChild++) {
                //clickedElement.style.border = "#40BF8C 4px dashed";
                if (document.getElementById('DesignDiv').childNodes[checkChild].id == clickedElement.id) {
                    document.getElementById('DeleteButton').style.display = 'block';
                    clickedElement.style.border = "#40BF8C 4px dashed";

                }
                else {
                    //document.getElementById('DesignDiv').childNodes[checkChild].style.border = "#afafaf 4px dashed";
                }
            }
            document.getElementById('PropertiesTable').style.display = 'block';
        }
    }

    /* Removed the Query Pattern Property
    if (clickedElement.type == 'DropDown' || clickedElement.type == 'EmpDropDown' || clickedElement.id.indexOf("DropDown") > 0) {
    document.getElementById('QueryPatternLabel').style.display = "inline";
    document.getElementById('IsQueryPattern').style.display = "inline";
    }
    else {
    document.getElementById('QueryPatternLabel').style.display = "none";
    document.getElementById('IsQueryPattern').style.display = "none";
    }*/

    if (clickedElement.type == 'DropDown' || clickedElement.type == 'ListBox' || clickedElement.type == 'EmpDropDown' || clickedElement.type == 'EmpManagerDropDown' || clickedElement.type == 'GlobalMControl' || clickedElement.type == 'GlobalSControl') {
        if (document.getElementById('FileModeHidden').value == "EDITMODE" && dropDownFlag == false) {
            dropDownList = document.getElementById('DropDownArray').value;
            dropDownIDList = document.getElementById('DropDownIDArray').value;
            dropDownFlag = true;
        }
        if (document.getElementById('FileModeHidden').value == "EDITMODE" && listBoxFlag == false) {
            listBoxList = document.getElementById('ListBoxArray').value;
            listBoxIDList = document.getElementById('ListBoxIDArray').value;
            listBoxFlag = true;
        }

        document.getElementById('titleTextBox').value = clickedElement.title;
        document.getElementById('textTextBox').style.display = "none";
        document.getElementById('textLabel').style.display = "none";
        document.getElementById('storeIdDiv').innerHTML = clickedElement.id;
        document.getElementById('maxLengthLabel').style.display = "none";
        document.getElementById('maxLengthTextBox').style.display = "none";
        document.getElementById('topTextBox').value = clickedElement.style.top;
        document.getElementById('leftTextBox').value = clickedElement.style.left;
        document.getElementById('TextModeSelect').style.display = 'none';
        document.getElementById('TextModeLabel').style.display = 'none';
        document.getElementById('IsTypeSelect').style.display = 'none';
        document.getElementById('IsTypeLabel').style.display = 'none';
        document.getElementById('WidthText').style.display = "none";
        document.getElementById('WidthLabel').style.display = "none";
        document.getElementById('IsRequiredLabel').style.display = "inline";
        document.getElementById('IsRequiredSelect').style.display = "inline";

        //        if(clickedElement.type == 'DropDown')
        //        {
        //            document.getElementById('WidthText').value=clickedElement.style.width;
        //        }
        //        if(clickedElement.type == 'ListBox')
        //        {
        document.getElementById('WidthText').value = clickedElement.style.width;
        //     }

        document.getElementById('IsDependentLabel').style.display = "inline";
        document.getElementById('IsDependentSelect').style.display = "inline";
        document.getElementById('ListItemsLabel').style.display = 'none';
        document.getElementById('ListItemsSelect').style.display = 'none';


        if (clickedElement.iswrap == 'False') {
            document.getElementById('IsWrapLabelSelect').options.selectedIndex = 1;
            document.getElementById('PreWraptextbox').style.display = 'none';
            document.getElementById('PreWraptextbox').value = '';
            document.getElementById('PreWraplabel').style.display = 'none';
            document.getElementById('PostWrapTextBox').style.display = 'none';
            document.getElementById('PostWrapTextBox').value = '';
            document.getElementById('PostWrapLabel').style.display = 'none';
        }
        else {
            document.getElementById('IsWrapLabelSelect').options.selectedIndex = 0;
            document.getElementById('PreWraptextbox').style.display = 'inline';
            document.getElementById('PreWraptextbox').value = clickedElement.prewrap;
            document.getElementById('PreWraplabel').style.display = 'inline';
            document.getElementById('PostWrapTextBox').style.display = 'inline';
            document.getElementById('PostWrapTextBox').value = clickedElement.postwrap;
            document.getElementById('PostWrapLabel').style.display = 'inline';
        }

        if (clickedElement.type == 'DropDown') {
            FillPrevRefAndDependentDDCtrl(clickedElement);
        }

        if (clickedElement.type == 'ListBox') {
            FillPrevRefAndDependentLBCtrl(clickedElement);
        }

        if (clickedElement.dependency == 'False') {
            document.getElementById('IsDependentSelect').options.selectedIndex = 1;
            document.getElementById('DependentControlSelect').style.display = 'none';
            document.getElementById('DependentControlSelect').options.selectedIndex = 0;
            document.getElementById('DependentControlLabel').style.display = 'none';
            document.getElementById('PreRefSelect').style.display = 'none';
            document.getElementById('PreRefSelect').options.selectedIndex = 0;
            document.getElementById('PreRefLabel').style.display = 'none';
        }
        else {
            document.getElementById('IsDependentSelect').options.selectedIndex = 0;
            document.getElementById('DependentControlLabel').style.display = 'inline';
            document.getElementById('DependentControlSelect').style.display = 'inline';
            for (var depSelCount = 0; depSelCount < document.getElementById('DependentControlSelect').options.length; depSelCount++) {
                if (document.getElementById('DependentControlSelect').options[depSelCount].value == clickedElement.dependentid) {
                    document.getElementById('DependentControlSelect').options[depSelCount].setAttribute('selected', 'true');
                }
            }
            document.getElementById('PreRefLabel').style.display = 'inline';
            document.getElementById('PreRefSelect').style.display = 'inline';
            for (var refSelCount = 0; refSelCount < document.getElementById('PreRefSelect').options.length; refSelCount++) {
                if (document.getElementById('PreRefSelect').options[refSelCount].value == clickedElement.prevref) {
                    document.getElementById('PreRefSelect').options[refSelCount].setAttribute('selected', 'true');
                }
            }
        }
        if (clickedElement.type == 'EmpDropDown' || clickedElement.type == 'EmpManagerDropDown' || clickedElement.type == 'GlobalMControl' || clickedElement.type == 'GlobalSControl') {
            document.getElementById('IsDependentLabel').style.display = "none";
            document.getElementById('IsDependentSelect').style.display = "none";
            document.getElementById('PreRefLabel').style.display = 'none';
            document.getElementById('PreRefSelect').style.display = 'none';
            document.getElementById('DependentControlSelect').style.display = 'none';
            document.getElementById('DependentControlLabel').style.display = 'none';
        }
        if (clickedElement.isrequired == 'False') {
            document.getElementById('IsRequiredSelect').options.selectedIndex = 1;
        }
        else {
            document.getElementById('IsRequiredSelect').options.selectedIndex = 0;
        }

        if (clickedElement.ismanageable == 'False') {
            document.getElementById('IsManageableSelect').options.selectedIndex = 1;
        }
        else {
            document.getElementById('IsManageableSelect').options.selectedIndex = 0;
        }
    }

    //Section to fill properties for RadioButtonList and CheckBoxList - Starts
    if (clickedElement.type == "RadioButtonList" || clickedElement.type == "CheckBoxList") {
        //alert(clickedElement.childNodes[0].childNodes[0].childNodes[1].childNodes[1].type)
        if (clickedElement.childNodes[0].childNodes[0].childNodes[1].childNodes[1].type == 'radio' || clickedElement.childNodes[0].childNodes[0].childNodes[1].childNodes[1].type == 'checkbox') {

            document.getElementById('ListItemsLabel').style.display = 'none';
            document.getElementById('ListItemsSelect').style.display = 'none';
            document.getElementById('titleTextBox').value = clickedElement.title;
            document.getElementById('textTextBox').style.display = "none";
            document.getElementById('textLabel').style.display = "none";
            document.getElementById('storeIdDiv').innerHTML = clickedElement.id;
            document.getElementById('maxLengthLabel').style.display = "none";
            document.getElementById('maxLengthTextBox').style.display = "none";
            document.getElementById('topTextBox').value = clickedElement.style.top;
            document.getElementById('leftTextBox').value = clickedElement.style.left;
            document.getElementById('WidthText').value = clickedElement.style.width;
            document.getElementById('WidthText').style.display = "none";
            document.getElementById('WidthLabel').style.display = "none";
            document.getElementById('IsRequiredLabel').style.display = "inline";
            document.getElementById('IsRequiredSelect').style.display = "inline";
            document.getElementById('IsDependentLabel').style.display = "none";
            document.getElementById('IsDependentSelect').style.display = "none";
            document.getElementById('PreRefLabel').style.display = "none";
            document.getElementById('PreRefSelect').style.display = "none";
            document.getElementById('DependentControlLabel').style.display = "none";
            document.getElementById('DependentControlSelect').style.display = "none";
            document.getElementById('TextModeSelect').style.display = 'none';
            document.getElementById('TextModeLabel').style.display = 'none';
            document.getElementById('IsTypeSelect').style.display = 'none';
            document.getElementById('IsTypeLabel').style.display = 'none';

            if (clickedElement.iswrap == 'False') {
                document.getElementById('IsWrapLabelSelect').options.selectedIndex = 1;
                document.getElementById('PreWraptextbox').style.display = 'none';
                document.getElementById('PreWraptextbox').value = '';
                document.getElementById('PreWraplabel').style.display = 'none';
                document.getElementById('PostWrapTextBox').style.display = 'none';
                document.getElementById('PostWrapTextBox').value = '';
                document.getElementById('PostWrapLabel').style.display = 'none';
            }
            else {
                document.getElementById('IsWrapLabelSelect').options.selectedIndex = 0;
                document.getElementById('PreWraptextbox').style.display = 'inline';
                document.getElementById('PreWraptextbox').value = clickedElement.prewrap;
                document.getElementById('PreWraplabel').style.display = 'inline';
                document.getElementById('PostWrapTextBox').style.display = 'inline';
                document.getElementById('PostWrapTextBox').value = clickedElement.postwrap;
                document.getElementById('PostWrapLabel').style.display = 'inline';
            }

            for (var listItemCount = 0; listItemCount < document.getElementById('ListItemsSelect').options.length + 1; listItemCount++) {
                document.getElementById('ListItemsSelect').options.remove(1);
            }

            for (var controlCount = 1; controlCount < clickedElement.childNodes[0].childNodes[0].childNodes.length; controlCount++) {
                // alert(clickedElement.childNodes[0].childNodes[0].childNodes[controlCount].childNodes[1].title);
                //alert(clickedElement.childNodes[0].childNodes[0].childNodes[controlCount].childNodes[0].value);
                var controlListItemOption = document.createElement("option");
                document.getElementById('ListItemsSelect').options.add(controlListItemOption);
                controlListItemOption.innerText = clickedElement.childNodes[0].childNodes[0].childNodes[controlCount].childNodes[1].title;
                controlListItemOption.value = clickedElement.childNodes[0].childNodes[0].childNodes[controlCount].childNodes[1].title;
            }

            if (clickedElement.isrequired == 'False') {
                document.getElementById('IsRequiredSelect').options.selectedIndex = 1;
            }
            else {
                document.getElementById('IsRequiredSelect').options.selectedIndex = 0;
            }

            if (clickedElement.ismanageable == 'False') {
                document.getElementById('IsManageableSelect').options.selectedIndex = 1;
            }
            else {
                document.getElementById('IsManageableSelect').options.selectedIndex = 0;
            }

        }
    }
    //Section to fill properties for RadioButtonList and CheckBoxList - Ends

    if (clickedElement.type == 'TextBox') {
        document.getElementById('titleTextBox').value = clickedElement.title;
        document.getElementById('textTextBox').style.display = "none";
        document.getElementById('textLabel').style.display = "none";
        // document.getElementById('textTextBox').value = clickedElement.value;
        document.getElementById('storeIdDiv').innerHTML = clickedElement.id;
        document.getElementById('maxLengthLabel').style.display = "inline";
        document.getElementById('maxLengthTextBox').style.display = "inline";
        document.getElementById('maxLengthTextBox').value = document.getElementById(document.getElementById('storeIdDiv').innerHTML).getAttribute('maxlength');
        document.getElementById('topTextBox').value = clickedElement.style.top;
        document.getElementById('leftTextBox').value = clickedElement.style.left;
        document.getElementById('IsDependentLabel').style.display = "none";
        document.getElementById('IsDependentSelect').style.display = "none";
        document.getElementById('IsManageableLabel').style.display = 'none';
        document.getElementById('IsManageableSelect').style.display = 'none';
        document.getElementById('IsRequiredSelect').style.display = 'inline';
        document.getElementById('IsRequiredLabel').style.display = 'inline';
        document.getElementById('TextModeSelect').style.display = 'inline';
        document.getElementById('TextModeLabel').style.display = 'inline';
        document.getElementById('IsTypeSelect').style.display = 'inline';
        document.getElementById('IsTypeLabel').style.display = 'inline';
        document.getElementById('IsDependentLabel').style.display = "none";
        document.getElementById('IsDependentSelect').style.display = "none";
        document.getElementById('PreRefLabel').style.display = 'none';
        document.getElementById('PreRefSelect').style.display = 'none';
        document.getElementById('DependentControlSelect').style.display = 'none';
        document.getElementById('DependentControlLabel').style.display = 'none';
        document.getElementById('WidthText').value = clickedElement.style.width;
        document.getElementById('WidthText').style.display = "none";
        document.getElementById('WidthLabel').style.display = "none";


        if (clickedElement.isrequired == 'False') {
            document.getElementById('IsRequiredSelect').options.selectedIndex = 1;
        }
        else {
            document.getElementById('IsRequiredSelect').options.selectedIndex = 0;
        }

        if (clickedElement.textmode == 'Multiline') {
            document.getElementById('TextModeSelect').options.selectedIndex = 1;
            document.getElementById('MultilineWidth').style.display = "inline";
            document.getElementById('txtmultilinewidth').style.display = "inline";
            document.getElementById('txtmultilinewidth').value = document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.width.replace("px", "");
            document.getElementById('MultilineHeight').style.display = "inline";
            document.getElementById('txtmultilineheight').style.display = "inline";
            document.getElementById('txtmultilineheight').value = document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.height.replace("px", "");

            var select = document.getElementById('IsTypeSelect');

            for (i = select.length - 1; i >= 0; i--) {
                if (select.options[i].value == 'Date' || select.options[i].value == 'Time') {
                    select.remove(i);
                }
            }



        }
        else {
            document.getElementById('TextModeSelect').options.selectedIndex = 0;
            document.getElementById('MultilineWidth').style.display = "none";
            document.getElementById('txtmultilinewidth').style.display = "none";
            document.getElementById('MultilineHeight').style.display = "none";
            document.getElementById('txtmultilineheight').style.display = "none";

            var select = document.getElementById('IsTypeSelect');

            if (select.length == 3) {
                var opt = document.createElement("option");
                opt.text = "Time";
                select.options.add(opt);
                var opt = document.createElement("option");
                opt.text = "Date";
                select.options.add(opt);


            }
        }

        if (clickedElement.istype == 'Numeric') {
            document.getElementById('IsTypeSelect').options.selectedIndex = 0;
        }
        if (clickedElement.istype == 'Alphabet') {
            document.getElementById('IsTypeSelect').options.selectedIndex = 1;
        }
        if (clickedElement.istype == 'AlphaNumeric') {
            document.getElementById('IsTypeSelect').options.selectedIndex = 2;
        }
        if (clickedElement.istype == 'Date') {//Date Change.
            document.getElementById('IsTypeSelect').options.selectedIndex = 3;
        }
        if (clickedElement.istype == 'Time') {//Time.
            document.getElementById('IsTypeSelect').options.selectedIndex = 4;
        }

        if (clickedElement.iswrap == 'False') {
            document.getElementById('IsWrapLabelSelect').options.selectedIndex = 1;
            document.getElementById('PreWraptextbox').style.display = 'none';
            document.getElementById('PreWraptextbox').value = '';
            document.getElementById('PreWraplabel').style.display = 'none';
            document.getElementById('PostWrapTextBox').style.display = 'none';
            document.getElementById('PostWrapTextBox').value = '';
            document.getElementById('PostWrapLabel').style.display = 'none';
        }
        else {
            document.getElementById('IsWrapLabelSelect').options.selectedIndex = 0;
            document.getElementById('PreWraptextbox').style.display = 'inline';
            document.getElementById('PreWraptextbox').value = clickedElement.prewrap;
            document.getElementById('PreWraplabel').style.display = 'inline';
            document.getElementById('PostWrapTextBox').style.display = 'inline';
            document.getElementById('PostWrapTextBox').value = clickedElement.postwrap;
            document.getElementById('PostWrapLabel').style.display = 'inline';
        }
    }
    if (clickedElement.type == 'Label') {
        document.getElementById('titleTextBox').value = clickedElement.title;
        document.getElementById('textTextBox').style.display = "none";
        document.getElementById('textLabel').style.display = "none";
        // document.getElementById('textTextBox').value = clickedElement.value;
        document.getElementById('storeIdDiv').innerHTML = clickedElement.id;
        document.getElementById('maxLengthLabel').style.display = "none";
        document.getElementById('maxLengthTextBox').style.display = "none";
        document.getElementById('topTextBox').value = clickedElement.style.top;
        document.getElementById('leftTextBox').value = clickedElement.style.left;
        document.getElementById('IsDependentLabel').style.display = "none";
        document.getElementById('IsDependentSelect').style.display = "none";
        document.getElementById('IsManageableLabel').style.display = 'none';
        document.getElementById('IsManageableSelect').style.display = 'none';
        document.getElementById('IsRequiredSelect').style.display = 'none';
        document.getElementById('IsRequiredLabel').style.display = 'none';
        document.getElementById('TextModeSelect').style.display = 'none';
        document.getElementById('TextModeLabel').style.display = 'none';
        document.getElementById('IsTypeSelect').style.display = 'none';
        document.getElementById('IsTypeLabel').style.display = 'none';
        document.getElementById('IsDependentLabel').style.display = "none";
        document.getElementById('IsDependentSelect').style.display = "none";
        document.getElementById('PreRefLabel').style.display = 'none';
        document.getElementById('PreRefSelect').style.display = 'none';
        document.getElementById('DependentControlSelect').style.display = 'none';
        document.getElementById('DependentControlLabel').style.display = 'none';
        document.getElementById('WidthText').value = clickedElement.style.width;
        document.getElementById('WidthText').style.display = "none";
        document.getElementById('WidthLabel').style.display = "none";

        if (clickedElement.iswrap == 'False') {
            document.getElementById('IsWrapLabelSelect').options.selectedIndex = 1;
            document.getElementById('PreWraptextbox').style.display = 'none';
            document.getElementById('PreWraptextbox').value = '';
            document.getElementById('PreWraplabel').style.display = 'none';
            document.getElementById('PostWrapTextBox').style.display = 'none';
            document.getElementById('PostWrapTextBox').value = '';
            document.getElementById('PostWrapLabel').style.display = 'none';
        }
        else {
            document.getElementById('IsWrapLabelSelect').options.selectedIndex = 0;
            document.getElementById('PreWraptextbox').style.display = 'inline';
            document.getElementById('PreWraptextbox').value = clickedElement.prewrap;
            document.getElementById('PreWraplabel').style.display = 'inline';
            document.getElementById('PostWrapTextBox').style.display = 'inline';
            document.getElementById('PostWrapTextBox').value = clickedElement.postwrap;
            document.getElementById('PostWrapLabel').style.display = 'inline';
        }
    }

    if (clickedElement.type == 'BButton') {
        document.getElementById('titleTextBox').value = clickedElement.title;
        document.getElementById('textTextBox').style.display = "none";
        document.getElementById('textLabel').style.display = "none";
        // document.getElementById('textTextBox').value = clickedElement.value;
        document.getElementById('storeIdDiv').innerHTML = clickedElement.id;
        document.getElementById('maxLengthLabel').style.display = "none";
        document.getElementById('maxLengthTextBox').style.display = "none";
        document.getElementById('topTextBox').value = clickedElement.style.top;
        document.getElementById('leftTextBox').value = clickedElement.style.left;
        document.getElementById('IsDependentLabel').style.display = "none";
        document.getElementById('IsDependentSelect').style.display = "none";
        document.getElementById('IsManageableLabel').style.display = 'none';
        document.getElementById('IsManageableSelect').style.display = 'none';
        document.getElementById('IsRequiredSelect').style.display = 'none';
        document.getElementById('IsRequiredLabel').style.display = 'none';
        document.getElementById('TextModeSelect').style.display = 'none';
        document.getElementById('TextModeLabel').style.display = 'none';
        document.getElementById('IsTypeSelect').style.display = 'none';
        document.getElementById('IsTypeLabel').style.display = 'none';
        document.getElementById('IsDependentLabel').style.display = "none";
        document.getElementById('IsDependentSelect').style.display = "none";
        document.getElementById('PreRefLabel').style.display = 'none';
        document.getElementById('PreRefSelect').style.display = 'none';
        document.getElementById('DependentControlSelect').style.display = 'none';
        document.getElementById('DependentControlLabel').style.display = 'none';
        document.getElementById('WidthText').value = clickedElement.style.width;
        document.getElementById('WidthText').style.display = "none";
        document.getElementById('WidthLabel').style.display = "none";
        if (clickedElement.iswrap == 'False') {
            document.getElementById('IsWrapLabelSelect').options.selectedIndex = 1;
            document.getElementById('PreWraptextbox').style.display = 'none';
            document.getElementById('PreWraptextbox').value = '';
            document.getElementById('PreWraplabel').style.display = 'none';
            document.getElementById('PostWrapTextBox').style.display = 'none';
            document.getElementById('PostWrapTextBox').value = '';
            document.getElementById('PostWrapLabel').style.display = 'none';
        }
        else {
            document.getElementById('IsWrapLabelSelect').options.selectedIndex = 0;
            document.getElementById('PreWraptextbox').style.display = 'inline';
            document.getElementById('PreWraptextbox').value = clickedElement.prewrap;
            document.getElementById('PreWraplabel').style.display = 'inline';
            document.getElementById('PostWrapTextBox').style.display = 'inline';
            document.getElementById('PostWrapTextBox').value = clickedElement.postwrap;
            document.getElementById('PostWrapLabel').style.display = 'inline';
        }
    }
}


//This function is called when the update button is clicked in the Propertie Panel and updates the changed properties of the selected control.     
function UpdateProperties() {
    if (document.getElementById('DesignDiv').childNodes.length != 0) {
        if (document.getElementById('storeControlTypeDiv').innerHTML == "DropDown" || document.getElementById('storeControlTypeDiv').innerHTML == "ListBox" || document.getElementById('storeControlTypeDiv').innerHTML == "EmpDropDown" || document.getElementById('storeControlTypeDiv').innerHTML == "EmpManagerDropDown" || document.getElementById('storeControlTypeDiv').innerHTML == "GlobalMControl" || document.getElementById('storeControlTypeDiv').innerHTML == 'GlobalSControl') {
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).title = document.getElementById('titleTextBox').value;
            // alert(document.getElementById(document.getElementById('storeIdDiv').innerHTML).childNodes[2].innerHTML); //= document.getElementById('titleTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.top = document.getElementById('topTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.left = document.getElementById('leftTextBox').value;


            document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.width = document.getElementById('WidthText').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).prewrap = document.getElementById('PreWrapTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).postwrap = document.getElementById('PostWrapTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).iswrap = document.getElementById('IsWrapLabelSelect').options[document.getElementById('IsWrapLabelSelect').options.selectedIndex].text;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).dependency = document.getElementById('IsDependentSelect').options[document.getElementById('IsDependentSelect').options.selectedIndex].text;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).isrequired = document.getElementById('IsRequiredSelect').options[document.getElementById('IsRequiredSelect').options.selectedIndex].text;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).ismanageable = document.getElementById('IsManageableSelect').options[document.getElementById('IsManageableSelect').options.selectedIndex].text;
            if (document.getElementById('ToHideSelect').options.selectedIndex != -1) {
                document.getElementById(document.getElementById('storeIdDiv').innerHTML).IsHide = document.getElementById('ToHideSelect').options[document.getElementById('ToHideSelect').options.selectedIndex].text;
            }
            else {
                document.getElementById(document.getElementById('storeIdDiv').innerHTML).IsHide = 'False';
            }
            // alert(document.getElementById('storeControlTypeDiv').innerHTML);
            if (document.getElementById('DependentControlSelect').options.selectedIndex != 0) {
                //document.getElementById(document.getElementById('storeIdDiv').innerHTML).dependentid = document.getElementById('DependentControlSelect').options[document.getElementById('DependentControlSelect').options.selectedIndex].value;
                if (document.getElementById('storeControlTypeDiv').innerHTML != "GlobalMControl") {//Date Change
                    document.getElementById(document.getElementById('storeIdDiv').innerHTML).dependentid = document.getElementById('DependentControlSelect').options[document.getElementById('DependentControlSelect').options.selectedIndex].value;

                }
            }
            else {
                // document.getElementById(document.getElementById('storeIdDiv').innerHTML).dependentid = "";
                if (document.getElementById('storeControlTypeDiv').innerHTML != "GlobalMControl") {//Date Change
                    document.getElementById(document.getElementById('storeIdDiv').innerHTML).dependentid = "";
                }
            }
            if (document.getElementById('PreRefSelect').options.selectedIndex != 0) {
                document.getElementById(document.getElementById('storeIdDiv').innerHTML).prevref = document.getElementById('PreRefSelect').options[document.getElementById('PreRefSelect').options.selectedIndex].value;
            }
            else {
                document.getElementById(document.getElementById('storeIdDiv').innerHTML).prevref = "";
            }
        }


        if (document.getElementById('storeControlTypeDiv').innerHTML == "RadioButtonList" || document.getElementById('storeControlTypeDiv').innerHTML == "CheckBoxList") {
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).title = document.getElementById('titleTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.top = document.getElementById('topTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.left = document.getElementById('leftTextBox').value;
            if (parseInt(document.getElementById('WidthText').value) <= 500) {
                document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.width = document.getElementById('WidthText').value;
            }
            else {
                alert('Width cannot be more than 500');
            }
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).prewrap = document.getElementById('PreWrapTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).postwrap = document.getElementById('PostWrapTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).iswrap = document.getElementById('IsWrapLabelSelect').options[document.getElementById('IsWrapLabelSelect').options.selectedIndex].text;
            //document.getElementById(document.getElementById('storeIdDiv').innerHTML).dependency = document.getElementById('IsDependentSelect').options[document.getElementById('IsDependentSelect').options.selectedIndex].text;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).isrequired = document.getElementById('IsRequiredSelect').options[document.getElementById('IsRequiredSelect').options.selectedIndex].text;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).ismanageable = document.getElementById('IsManageableSelect').options[document.getElementById('IsManageableSelect').options.selectedIndex].text;
            if (document.getElementById('ToHideSelect').options.selectedIndex != -1) {
                document.getElementById(document.getElementById('storeIdDiv').innerHTML).IsHide = document.getElementById('ToHideSelect').options[document.getElementById('ToHideSelect').options.selectedIndex].text;
            }
            else {
                document.getElementById(document.getElementById('storeIdDiv').innerHTML).IsHide = 'False';
            }

        }

        if (document.getElementById('storeControlTypeDiv').innerHTML == "TextBox") {

            document.getElementById(document.getElementById('storeIdDiv').innerHTML).title = document.getElementById('titleTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.top = document.getElementById('topTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.left = document.getElementById('leftTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).isrequired = document.getElementById('IsRequiredSelect').options[document.getElementById('IsRequiredSelect').options.selectedIndex].text;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.width = document.getElementById('WidthText').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).prewrap = document.getElementById('PreWrapTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).postwrap = document.getElementById('PostWrapTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).iswrap = document.getElementById('IsWrapLabelSelect').options[document.getElementById('IsWrapLabelSelect').options.selectedIndex].text;
            if (document.getElementById('ToHideSelect').options.selectedIndex != -1) {
                document.getElementById(document.getElementById('storeIdDiv').innerHTML).IsHide = document.getElementById('ToHideSelect').options[document.getElementById('ToHideSelect').options.selectedIndex].text;
            }
            else {
                document.getElementById(document.getElementById('storeIdDiv').innerHTML).IsHide = 'False';
            }
            if (document.getElementById(document.getElementById('storeIdDiv').innerHTML).outerHTML.indexOf('textmode="Multiline"') > -1) {
                document.getElementById('maxLengthTextBox').height = "20";
                //Set height and width of multiline textbox
                if (document.getElementById('txtmultilinewidth').value == "") {
                    document.getElementById('txtmultilinewidth').value = 150;
                }
                if (parseInt(document.getElementById('txtmultilinewidth').value) > 500 || parseInt(document.getElementById('txtmultilinewidth').value) < 150) {
                    document.getElementById('txtmultilinewidth').value = 150;
                    alert("Multiline text box width should in range of 150 to 500");
                }

                document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.width = document.getElementById('txtmultilinewidth').value;


                if (document.getElementById('txtmultilineheight').value == "") {
                    document.getElementById('txtmultilineheight').value = 50;
                }
                if (parseInt(document.getElementById('txtmultilineheight').value) > 100 || parseInt(document.getElementById('txtmultilineheight').value) < 50) {
                    document.getElementById('txtmultilineheight').value = 50;
                    alert("Multiline text box height should in range of 50 to 100");
                }
                document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.height = document.getElementById('txtmultilineheight').value;


            }
            else {
                document.getElementById('maxLengthTextBox').height = "12";
                document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.width = 200;
                document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.height = 50;
            }
            if (document.getElementById('maxLengthTextBox').value == 0) {
                document.getElementById('maxLengthTextBox').value = 20;
                document.getElementById(document.getElementById('storeIdDiv').innerHTML).maxlength = 20;

            }
            else {
                if (document.getElementById(document.getElementById('storeIdDiv').innerHTML).outerHTML.indexOf('textmode="Multiline"') > -1) {
                    if (parseInt(document.getElementById('maxLengthTextBox').value) <= 2000) {
                        document.getElementById(document.getElementById('storeIdDiv').innerHTML).maxlength = document.getElementById('maxLengthTextBox').value;
                    }
                    else {
                        document.getElementById(document.getElementById('storeIdDiv').innerHTML).maxlength = 20;
                    }
                }
                else {
                    if (parseInt(document.getElementById('maxLengthTextBox').value.length) <= 3) {
                        document.getElementById(document.getElementById('storeIdDiv').innerHTML).maxlength = document.getElementById('maxLengthTextBox').value;
                    }
                    else {
                        document.getElementById(document.getElementById('storeIdDiv').innerHTML).maxlength = 20;
                    }
                }
            }
        }




        if (document.getElementById('storeControlTypeDiv').innerHTML == "Label" || document.getElementById('storeControlTypeDiv').innerHTML == "BButton") {
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).title = document.getElementById('titleTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.top = document.getElementById('topTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.left = document.getElementById('leftTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).style.width = document.getElementById('WidthText').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).prewrap = document.getElementById('PreWrapTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).postwrap = document.getElementById('PostWrapTextBox').value;
            document.getElementById(document.getElementById('storeIdDiv').innerHTML).iswrap = document.getElementById('IsWrapLabelSelect').options[document.getElementById('IsWrapLabelSelect').options.selectedIndex].text;
            if (document.getElementById('ToHideSelect').options.selectedIndex != -1) {
                document.getElementById(document.getElementById('storeIdDiv').innerHTML).IsHide = document.getElementById('ToHideSelect').options[document.getElementById('ToHideSelect').options.selectedIndex].text;
            }
            else {
                document.getElementById(document.getElementById('storeIdDiv').innerHTML).IsHide = 'False';
            }
        }
    }
}

function DeleteControl() {
    if (document.getElementById('storeIdDiv').childNodes.length != 0) {
        var controlID = document.getElementById('storeIdDiv').innerHTML;
        var childToRemove = document.getElementById(controlID);

        var dropDownDelArray = new Array();
        dropDownDelArray = dropDownList.split(',')
        dropDownDelArray.pop(dropDownArray.length - 1);

        if (childToRemove.type == "DropDown") {
            for (var depArrayCount = 0; depArrayCount < dropDownDelArray.length; depArrayCount++) {

                if (childToRemove.title == dropDownDelArray[depArrayCount]) {
                    var textToRemove = childToRemove.title + ",";
                    dropDownList = dropDownList.replace(textToRemove, '');
                    document.getElementById('DropDownArray').value = dropDownList;
                    dropDownFlag = false;
                }
            }
            FillPrevRefAndDependentDDCtrlAfterDel();
        }

        var listBoxDelArray = new Array();
        listBoxDelArray = listBoxList.split(',')
        listBoxDelArray.pop(listBoxDelArray.length - 1);

        if (childToRemove.type == "ListBox") {
            for (var depArrayCount = 0; depArrayCount < listBoxDelArray.length; depArrayCount++) {
                if (childToRemove.title == listBoxDelArray[depArrayCount]) {
                    document.getElementById('DependentControlSelect').options.removeChild(document.getElementById('DependentControlSelect').options[depArrayCount]);
                    var textToRemove = childToRemove.title + ",";
                    listBoxList = listBoxList.replace(textToRemove, '');
                    document.getElementById('ListBoxArray').value = listBoxList;
                    listBoxFlag = false;
                }
            }
            FillPrevRefAndDependentLBCtrlAfterDel();
        }
        document.getElementById('DesignDiv').removeChild(childToRemove);
        document.getElementById('PropertiesTable').style.display = 'none';
        document.getElementById('DeleteButton').style.display = 'none';
    }
}

function SetTextMode() {
    var titleArray = new Array();

    if (document.getElementById('TextModeSelect').options.selectedIndex != "0") {
        document.getElementById('MultilineWidth').style.display = "inline";
        document.getElementById('txtmultilinewidth').style.display = "inline";
        document.getElementById('MultilineHeight').style.display = "inline";
        document.getElementById('txtmultilineheight').style.display = "inline";
        var select = document.getElementById('IsTypeSelect');

        for (i = select.length - 1; i >= 0; i--) {
            if (select.options[i].value == 'Date' || select.options[i].value == 'Time') {
                select.remove(i);
            }
        }
    }
    else {
        document.getElementById('MultilineWidth').style.display = "none";
        document.getElementById('txtmultilinewidth').style.display = "none";
        document.getElementById('MultilineHeight').style.display = "none";
        document.getElementById('txtmultilineheight').style.display = "none";
        var select = document.getElementById('IsTypeSelect');

        if (select.length == 3) {
            var opt = document.createElement("option");
            opt.text = "Time";
            opt.value = "Time";
            select.options.add(opt);
            var opt = document.createElement("option");
            opt.text = "Date";
            opt.value = "Date";
            select.options.add(opt);


        }
    }
    if (document.getElementById('TextModeSelect').options.selectedIndex == "0") {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].textmode = 'Singleline';
            }
        }
    }
    if (document.getElementById('TextModeSelect').options.selectedIndex == "1") {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].textmode = 'Multiline';
            }
        }
    }
}

function IsType() {
    var titleArray = new Array();

    if (document.getElementById('IsTypeSelect').options.selectedIndex == "0") {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].istype = 'Numeric';
            }
        }
    }
    if (document.getElementById('IsTypeSelect').options.selectedIndex == "1") {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].istype = 'Alphabet';
            }
        }
    }
    if (document.getElementById('IsTypeSelect').options.selectedIndex == "2") {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].istype = 'AlphaNumeric';
            }
        }
    }
    if (document.getElementById('IsTypeSelect').options.selectedIndex == "3") { //Date Change.
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].istype = 'Date';
            }
        }
    }
    if (document.getElementById('IsTypeSelect').options.selectedIndex == "4") { //Date Change.
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].istype = 'Time';
            }
        }
    }
}

function SetIsManageable() {
    var titleArray = new Array();

    if (document.getElementById('IsManageableSelect').options.selectedIndex == "0") {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].ismanageable = 'True';
            }
        }
    }
    if (document.getElementById('IsManageableSelect').options.selectedIndex == "1") {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].ismanageable = 'False';
            }
        }
    }
}

function SetIsRequired() {
    var titleArray = new Array();

    if (document.getElementById('IsRequiredSelect').options.selectedIndex == "0") {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].isrequired = 'True';
            }
        }
    }
    if (document.getElementById('IsRequiredSelect').options.selectedIndex == "1") {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].isrequired = 'False';
            }
        }
    }
}

function SetWrap() {
    var titleArray = new Array();

    if (document.getElementById('IsWrapLabelSelect').options.selectedIndex == "0") {
        document.getElementById('PreWrapTextBox').style.display = 'inline';
        document.getElementById('PreWrapLabel').style.display = 'inline';
        document.getElementById('PostWrapTextBox').style.display = 'inline';
        document.getElementById('PostWrapLabel').style.display = 'inline';
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].iswrap = 'True';
            }
        }
    }
    if (document.getElementById('IsWrapLabelSelect').options.selectedIndex == "1") {
        document.getElementById('PreWraptextbox').style.display = 'none';
        document.getElementById('PreWraptextbox').value = '';
        document.getElementById('PreWraplabel').style.display = 'none';
        document.getElementById('PostWrapTextBox').style.display = 'none';
        document.getElementById('PostWrapTextBox').value = '';
        document.getElementById('PostWrapLabel').style.display = 'none';
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].iswrap = 'False';
                document.getElementById('DesignDiv').childNodes[arrayCountx].prewrap = '';
                document.getElementById('DesignDiv').childNodes[arrayCountx].postwrap = '';
            }
        }
    }
}



function SetDependent() {
    var titleArray = new Array();

    if (document.getElementById('IsDependentSelect').options.selectedIndex == "0") {
        document.getElementById('DependentControlLabel').style.display = 'inline';
        document.getElementById('DependentControlSelect').style.display = 'inline';
        document.getElementById('PreRefLabel').style.display = 'inline';
        document.getElementById('PreRefSelect').style.display = 'inline';
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].dependency = 'True';
            }
        }
    }
    if (document.getElementById('IsDependentSelect').options.selectedIndex == "1") {
        document.getElementById('DependentControlLabel').style.display = 'none';
        document.getElementById('DependentControlSelect').style.display = 'none';
        document.getElementById('PreRefLabel').style.display = 'none';
        document.getElementById('PreRefSelect').style.display = 'none';

        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].dependency = 'False';
                document.getElementById('DesignDiv').childNodes[arrayCountx].prevref = "";
                document.getElementById('DesignDiv').childNodes[arrayCountx].dependentid = "";
            }
        }
    }
}

function SetIsHide() {
    var titleArray = new Array();

    if (document.getElementById('ToHideSelect').options.selectedIndex == "0") {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].ishide = 'True';
            }
        }
    }
    if (document.getElementById('IsTypeSelect').options.selectedIndex == "1") {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].ishide = 'False';
            }
        }
    }

}

function FillPrevRefAndDependentLBCtrl(clickElementObj) {

    document.getElementById('DependentControlSelect').length = 0;
    document.getElementById('PreRefSelect').length = 0;

    var noneDepOption = document.createElement("option");
    document.getElementById('DependentControlSelect').options.add(noneDepOption);
    noneDepOption.innerText = "None";
    noneDepOption.value = "None";

    var nonePrevOption = document.createElement("option");
    document.getElementById('PreRefSelect').options.add(nonePrevOption);
    nonePrevOption.innerText = "None";
    nonePrevOption.value = "None";

    listBoxArray = listBoxList.split(',');
    listBoxArray.pop(listBoxArray.length - 1)


    listBoxIDArray = listBoxIDList.split(',');
    listBoxIDArray.pop(listBoxIDArray.length - 1)

    for (var depArrayCount = 0; depArrayCount < listBoxArray.length; depArrayCount++) {
        if (listBoxArray[depArrayCount] != clickElementObj.title) {
            var depOption = document.createElement("option");
            document.getElementById('DependentControlSelect').options.add(depOption);
            depOption.innerText = listBoxArray[depArrayCount];
            depOption.value = listBoxIDArray[depArrayCount];
        }
    }
    for (var prevArrayCount = 0; prevArrayCount < listBoxArray.length; prevArrayCount++) {
        if (listBoxArray[prevArrayCount] != clickElementObj.title) {
            var prevOption = document.createElement("option");
            document.getElementById('PreRefSelect').options.add(prevOption);
            prevOption.innerText = listBoxArray[prevArrayCount];
            prevOption.value = listBoxIDArray[prevArrayCount];
        }
    }
}


function FillPrevRefAndDependentLBCtrlAfterDel() {

    document.getElementById('DependentControlSelect').length = 0;
    document.getElementById('PreRefSelect').length = 0;

    var noneDepOption = document.createElement("option");
    document.getElementById('DependentControlSelect').options.add(noneDepOption);
    noneDepOption.innerText = "None";
    noneDepOption.value = "None";

    var nonePrevOption = document.createElement("option");
    document.getElementById('PreRefSelect').options.add(nonePrevOption);
    nonePrevOption.innerText = "None";
    nonePrevOption.value = "None";


    listBoxArray = listBoxList.split(',');
    listBoxArray.pop(listBoxArray.length - 1)


    listBoxIDArray = listBoxIDList.split(',');
    listBoxIDArray.pop(listBoxIDArray.length - 1)

    for (var depArrayCount = 0; depArrayCount < listBoxArray.length; depArrayCount++) {

        var depOption = document.createElement("option");
        document.getElementById('DependentControlSelect').options.add(depOption);
        depOption.innerText = listBoxArray[depArrayCount];
        depOption.value = listBoxIDArray[depArrayCount];

    }
    for (var prevArrayCount = 0; prevArrayCount < listBoxArray.length; prevArrayCount++) {

        var prevOption = document.createElement("option");
        document.getElementById('PreRefSelect').options.add(prevOption);
        prevOption.innerText = listBoxArray[prevArrayCount];
        prevOption.value = listBoxIDArray[prevArrayCount];

    }
}



function FillPrevRefAndDependentDDCtrl(clickElementObj) {
    document.getElementById('DependentControlSelect').length = 0;
    document.getElementById('PreRefSelect').length = 0;

    var noneDropDepOption = document.createElement("option");
    document.getElementById('DependentControlSelect').options.add(noneDropDepOption);
    noneDropDepOption.innerText = "None";
    noneDropDepOption.value = "None";

    var noneDropPrevOption = document.createElement("option");
    document.getElementById('PreRefSelect').options.add(noneDropPrevOption);
    noneDropPrevOption.innerText = "None";
    noneDropPrevOption.value = "None";

    dropDownArray = dropDownList.split(',');
    dropDownArray.pop(dropDownArray.length - 1);

    dropDownIDArray = dropDownIDList.split(',');
    dropDownIDArray.pop(dropDownIDArray.length - 1);

    for (var depArrayCount = 0; depArrayCount < dropDownArray.length; depArrayCount++) {
        if (dropDownArray[depArrayCount] != clickElementObj.title) {
            var depDropOption = document.createElement("option");
            document.getElementById('DependentControlSelect').options.add(depDropOption);
            depDropOption.innerText = dropDownArray[depArrayCount];
            depDropOption.value = dropDownIDArray[depArrayCount];
        }

    }
    for (var prevArrayCount = 0; prevArrayCount < dropDownArray.length; prevArrayCount++) {
        if (dropDownArray[prevArrayCount] != clickElementObj.title) {
            var prevDropOption = document.createElement("option");
            document.getElementById('PreRefSelect').options.add(prevDropOption);
            prevDropOption.innerText = dropDownArray[prevArrayCount];
            prevDropOption.value = dropDownIDArray[prevArrayCount];
        }

    }
}


function FillPrevRefAndDependentDDCtrlAfterDel() {
    document.getElementById('DependentControlSelect').length = 0;
    document.getElementById('PreRefSelect').length = 0;

    var noneDropDepOption = document.createElement("option");
    document.getElementById('DependentControlSelect').options.add(noneDropDepOption);
    noneDropDepOption.innerText = "None";
    noneDropDepOption.value = "None";

    var noneDropPrevOption = document.createElement("option");
    document.getElementById('PreRefSelect').options.add(noneDropPrevOption);
    noneDropPrevOption.innerText = "None";
    noneDropPrevOption.value = "None";

    dropDownArray = dropDownList.split(',');
    dropDownArray.pop(dropDownArray.length - 1);

    dropDownIDArray = dropDownIDList.split(',');
    dropDownIDArray.pop(dropDownIDArray.length - 1);

    for (var depArrayCount = 0; depArrayCount < dropDownArray.length; depArrayCount++) {

        var depDropOption = document.createElement("option");
        document.getElementById('DependentControlSelect').options.add(depDropOption);
        depDropOption.innerText = dropDownArray[depArrayCount];
        depDropOption.value = dropDownIDArray[depArrayCount];


    }
    for (var prevArrayCount = 0; prevArrayCount < dropDownArray.length; prevArrayCount++) {

        var prevDropOption = document.createElement("option");
        document.getElementById('PreRefSelect').options.add(prevDropOption);
        prevDropOption.innerText = dropDownArray[prevArrayCount];
        prevDropOption.value = dropDownIDArray[prevArrayCount];


    }
}


function CreateXmlString() {
    var xmlstring = "";
    var CCSSunset = false;
    var DDunset = false;
    var confirmalert = confirm("All the controls will be formatted automatically at the time of saving the design.")
    if (confirmalert != true) {
        return false;
    }
    aligncontrol();
    settabindex();
    var resultdeppre = true;
    resultdeppre = checkfordependentcontrols();
    if (resultdeppre == false) {
        return resultdeppre;
    }
    sethiddencontrol();
    if (document.getElementById('DesignDiv').childNodes.length != 0) {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            if (document.getElementById('DesignDiv').childNodes[arrayCount].type == 'EmpDropDown' || document.getElementById('DesignDiv').childNodes[arrayCount].type == 'EmpManagerDropDown' || document.getElementById('DesignDiv').childNodes[arrayCount].type == 'GlobalMControl' || document.getElementById('DesignDiv').childNodes[arrayCount].type == 'GlobalSControl') {
                var checkSS = document.getElementById('DesignDiv').childNodes[arrayCount].getAttribute('skillset');

                var checkSSV = document.getElementById('DesignDiv').childNodes[arrayCount].getAttribute('skillsetvalues')
                var checkCCV = document.getElementById('DesignDiv').childNodes[arrayCount].getAttribute('costcentrevalues')
                var checkCC = document.getElementById('DesignDiv').childNodes[arrayCount].getAttribute('costcentre')
                if (checkSS == "None" || checkSSV == "None" || checkCCV == "None" || checkCC == "None") {
                    document.getElementById('DesignDiv').childNodes[arrayCount].style.border = "dashed 4px Red";
                    CCSSunset = true;
                }
            }
        }
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            if (document.getElementById('DesignDiv').childNodes[arrayCount].type == 'DropDown') {
                if (document.getElementById('DesignDiv').childNodes[arrayCount].dependency == 'True') {
                    if (document.getElementById('DesignDiv').childNodes[arrayCount].dependentid != "" && document.getElementById('DesignDiv').childNodes[arrayCount].dependentid != "ddl_DropDown") {
                        if (document.getElementById(document.getElementById('DesignDiv').childNodes[arrayCount].dependentid + "Table").dependency == 'False') {
                            document.getElementById(document.getElementById('DesignDiv').childNodes[arrayCount].dependentid + "Table").style.border = "dashed 4px Blue";
                            DDunset = true;
                        }
                    }
                    if (document.getElementById('DesignDiv').childNodes[arrayCount].prevref != "" && document.getElementById('DesignDiv').childNodes[arrayCount].prevref != "ddl_DropDown") {
                        if (document.getElementById(document.getElementById('DesignDiv').childNodes[arrayCount].prevref + "Table").dependency == 'False') {
                            document.getElementById(document.getElementById('DesignDiv').childNodes[arrayCount].prevref + "Table").style.border = "dashed 4px Blue";
                            DDunset = true;
                        }
                        if (document.getElementById(document.getElementById('DesignDiv').childNodes[arrayCount].prevref + "Table").dependentid == '') {
                            document.getElementById(document.getElementById('DesignDiv').childNodes[arrayCount].prevref + "Table").style.border = "dashed 4px Blue";
                            DDunset = true;
                        }
                    }
                }
                if (document.getElementById('DesignDiv').childNodes[arrayCount].dependency == 'True') {
                    if (document.getElementById('DesignDiv').childNodes[arrayCount].dependentid == "" && document.getElementById('DesignDiv').childNodes[arrayCount].prevref == "") {
                        document.getElementById('DesignDiv').childNodes[arrayCount].style.border = "dashed 4px Blue";
                        DDunset = true;
                    }
                }
            }
        }

        if (DDunset == true) {
            //alert('Please complete the dependency settings for the dropdowns highlighted in blue.');
            alert('Please provide dependency for the highlighted dropdown.');   //Added by Bappa
            return false;
        }
        if (CCSSunset == false) {
            for (var arrayControlCount = 0; arrayControlCount < document.getElementById('DesignDiv').childNodes.length; arrayControlCount++) {
                // alert(document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('Table',''));
                if (document.getElementById('DesignDiv').childNodes[arrayControlCount].type == 'TextBox' && document.getElementById('DesignDiv').childNodes[arrayControlCount].prewrap != "cc") {
                    xmlstring += "<TextBox><Label><Text>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                    xmlstring += "<ControlID>1</ControlID><ControlType>Basic</ControlType>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].prewrap == 'cc') {
                        xmlstring += "<FieldID>cc" + document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('Table', '').replace(' ', '_') + "</FieldID>";
                    }
                    else {
                        xmlstring += "<FieldID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('Table', '').replace(' ', '_') + "</FieldID>";
                    }
                    xmlstring += "<Title>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                    xmlstring += "<X-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.left.replace('px', '') + "</X-Pos>";
                    xmlstring += "<Y-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.top.replace('px', '') + "</Y-Pos>";
                    xmlstring += "<Width>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.width.replace('px', '') + "</Width>";
                    xmlstring += "<IsRequired>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                    xmlstring += "<IsPostBack>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                    xmlstring += "<IsWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                    xmlstring += "<PreWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                    xmlstring += "<PostWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                    xmlstring += "<TextMode>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].textmode + "</TextMode>";
                    xmlstring += "<IsType>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].istype + "</IsType>";
                    xmlstring += "<MaxLength>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].maxlength + "</MaxLength>";
                    xmlstring += "<Dependency></Dependency>";
                    xmlstring += "<PrevRef></PrevRef>";
                    xmlstring += "<DependentID></DependentID>";
                    xmlstring += "<Tabindex>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].tabIndex + "</Tabindex>";
                    xmlstring += "<Height>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.height.replace('px', '') + "</Height>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide == 'undefined') {
                        xmlstring += "<IsHide>False</IsHide>";
                    }
                    else {
                        xmlstring += "<IsHide>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide + "</IsHide>";
                    }
                    xmlstring += "</TextBox>";
                    //document.getElementById('DesignDiv').childNodes[arrayControlCount]
                }

                if (document.getElementById('DesignDiv').childNodes[arrayControlCount].type == 'DropDown') {

                    xmlstring += "<DropDownList><Label><Text>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                    xmlstring += "<ControlID>2</ControlID><ControlType>Basic</ControlType>";

                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('Table', '').replace(' ', '_') == 'ddl_DropDown') {
                        xmlstring += "<FieldID>ddl_0DropDown</FieldID>";
                    }
                    else {
                        xmlstring += "<FieldID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('Table', '').replace(' ', '_') + "</FieldID>";
                    }
                    xmlstring += "<Title>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].dependency == 'False') {
                        document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid = ""
                        document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref = "";
                    }
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid != "") {
                        if (document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid == 'ddl_DropDown') {
                            xmlstring += "<DependentID>ddl_0DropDown</DependentID>";
                        }
                        else {
                            xmlstring += "<DependentID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>";
                        }
                    }
                    else {
                        if (document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid == 'ddl_DropDown') {
                            xmlstring += "<DependentID>ddl_0DropDown</DependentID>";
                        }
                        else {
                            xmlstring += "<DependentID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>";
                        }
                        //xmlstring += "<DependentID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>";
                    }
                    xmlstring += "<X-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.left.replace('px', '') + "</X-Pos>";
                    xmlstring += "<Y-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.top.replace('px', '') + "</Y-Pos>";
                    xmlstring += "<Width>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.width.replace('px', '') + "</Width>";
                    xmlstring += "<IsRequired>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                    xmlstring += "<IsManageable>True</IsManageable>";
                    xmlstring += "<IsPostBack>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                    xmlstring += "<Dependency>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].dependency + "</Dependency>";
                    xmlstring += "<IsWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                    xmlstring += "<PreWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                    xmlstring += "<PostWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";

                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref != "") {
                        if (document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref == 'ddl_DropDown') {
                            xmlstring += "<PrevRef>ddl_0DropDown</PrevRef>";
                        }
                        else {
                            xmlstring += "<PrevRef>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref + "</PrevRef>";
                        }
                    }
                    else {
                        if (document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref == 'ddl_DropDown') {
                            xmlstring += "<PrevRef>ddl_0DropDown</PrevRef>";
                        }
                        else {
                            xmlstring += "<PrevRef>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref + "</PrevRef>";
                        }
                        //xmlstring += "<PrevRef>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref + "</PrevRef>";
                    }

                    xmlstring += "<IsQueryPattern>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsQueryPattern + "</IsQueryPattern>";
                    xmlstring += "<DataSource>XML</DataSource>";
                    xmlstring += "<LISTITEMS></LISTITEMS><Tabindex>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].tabIndex + "</Tabindex>"
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide == 'undefined') {
                        xmlstring += "<IsHide>False</IsHide>";
                    }
                    else {
                        xmlstring += "<IsHide>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide + "</IsHide>";
                    }
                    xmlstring += "</DropDownList>";
                    //document.getElementById('DesignDiv').childNodes[arrayControlCount]
                }
                if (document.getElementById('DesignDiv').childNodes[arrayControlCount].type == 'ListBox') {
                    xmlstring += "<ListBox><Label><Text>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                    xmlstring += "<ControlID>5</ControlID><ControlType>Basic</ControlType>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('Table', '').replace(' ', '_') == 'lb_ListBox') {
                        xmlstring += "<FieldID>lb_0ListBox</FieldID>";
                    }
                    else {
                        xmlstring += "<FieldID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('Table', '').replace(' ', '_') + "</FieldID>";
                    }

                    xmlstring += "<Title>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                    //xmlstring += "<DependentID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid + "ListBox</DependentID>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].dependency == 'False') {
                        document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid = ""
                        document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref = "";
                    }
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid != "") {
                        if (document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid == 'lb_ListBox') {
                            xmlstring += "<DependentID>lb_0ListBox</DependentID>";
                        }
                        else {
                            xmlstring += "<DependentID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>";
                        }
                    }
                    else {
                        if (document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid == 'lb_ListBox') {
                            xmlstring += "<DependentID>lb_0ListBox</DependentID>";
                        }
                        else {
                            xmlstring += "<DependentID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>";
                        }
                        //xmlstring += "<DependentID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>";
                    }
                    xmlstring += "<X-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.left.replace('px', '') + "</X-Pos>";
                    xmlstring += "<Y-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.top.replace('px', '') + "</Y-Pos>";
                    xmlstring += "<Width>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.width.replace('px', '') + "</Width>";
                    xmlstring += "<IsRequired>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                    xmlstring += "<IsManageable>True</IsManageable>";
                    xmlstring += "<IsPostBack>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                    xmlstring += "<Dependency>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].dependency + "</Dependency>";
                    xmlstring += "<IsWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                    xmlstring += "<PreWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                    xmlstring += "<PostWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref != "") {
                        if (document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref == 'lb_ListBox') {
                            xmlstring += "<PrevRef>lb_0ListBox</PrevRef>";
                        }
                        else {
                            xmlstring += "<PrevRef>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref + "</PrevRef>";
                        }
                    }
                    else {
                        if (document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref == 'lb_ListBox') {
                            xmlstring += "<PrevRef>lb_0ListBox</PrevRef>";
                        }
                        else {
                            xmlstring += "<PrevRef>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref + "</PrevRef>";
                        }
                        // xmlstring += "<PrevRef>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref + "</PrevRef>";
                    }
                    //xmlstring += "<PrevRef>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref + "ListBox</PrevRef>";
                    xmlstring += "<DataSource>XML</DataSource>";
                    xmlstring += "<LISTITEMS></LISTITEMS><Tabindex>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].tabIndex + "</Tabindex>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide == 'undefined') {
                        xmlstring += "<IsHide>False</IsHide>";
                    }
                    else {
                        xmlstring += "<IsHide>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide + "</IsHide>";
                    }

                    xmlstring += "</ListBox>";


                }

                if (document.getElementById('DesignDiv').childNodes[arrayControlCount].type == 'CheckBoxList') {
                    xmlstring += "<CheckBoxList><Label><Text>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                    xmlstring += "<ControlID>4</ControlID><ControlType>Basic</ControlType>";
                    xmlstring += "<FieldID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('Table', '').replace(' ', '_') + "</FieldID>";
                    xmlstring += "<Title>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                    //xmlstring += "<DependentID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>";
                    xmlstring += "<X-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.left.replace('px', '') + "</X-Pos>";
                    xmlstring += "<Y-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.top.replace('px', '') + "</Y-Pos>";
                    xmlstring += "<Width>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.width.replace('px', '') + "</Width>";
                    xmlstring += "<IsRequired>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                    xmlstring += "<IsManageable>True</IsManageable>";
                    xmlstring += "<IsPostBack>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                    xmlstring += "<RepeatColumns>1</RepeatColumns>";
                    xmlstring += "<RepeatDirection>Horizontal</RepeatDirection>";
                    //xmlstring += "<Dependency>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].dependency + "</Dependency>";
                    xmlstring += "<IsWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                    xmlstring += "<PreWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                    xmlstring += "<PostWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                    xmlstring += "<Dependency></Dependency>";
                    xmlstring += "<PrevRef></PrevRef>";
                    xmlstring += "<DependentID></DependentID>";
                    xmlstring += "<DataSource>XML</DataSource>";
                    //xmlstring += "<PrevRef>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref + "</PrevRef>";
                    xmlstring += "<LISTITEMS>";
                    //                        for(var listCount =1; listCount < document.getElementById('DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes.length; listCount++)
                    //                        {  
                    //                            xmlstring += "<LISTITEM Id='" + (parseInt(listCount)-parseInt(1)) + "' value='' DependentOn='0'>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes[listCount].childNodes[1].title + "List Item text here.</LISTITEM>";//+ document.getElementById('DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes[listCount].childNodes[1].title + "
                    //                        }
                    var checkcount = document.getElementById('DesignDiv').childNodes[arrayControlCount].children[0].childNodes.length;
                    if (checkcount < 2) {
                        for (var listCount = 1; listCount < document.getElementById('DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes.length; listCount++) {
                            xmlstring += "<LISTITEM Id='" + (parseInt(listCount) - parseInt(1)) + "' value='' DependentOn='0'>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes[listCount].childNodes[1].title + "List Item text here.</LISTITEM>"; //" + document.getElementById('DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes[listCount].childNodes[1].title + "
                        }
                    }
                    else {
                        var totallistcount = 0;
                        for (var newlistcount = 0; newlistcount < checkcount; newlistcount++) {
                            for (var listCount = 1; listCount < document.getElementById('DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[newlistcount].childNodes.length; listCount++) {
                                xmlstring += "<LISTITEM Id='" + (totallistcount) + "' value='' DependentOn='0'>" + totallistcount + "List Item text here.</LISTITEM>"; //" + document.getElementById('DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes[listCount].childNodes[1].title + "
                                totallistcount++;
                            }
                        }
                    }
                    xmlstring += "</LISTITEMS><Tabindex>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].tabIndex + "</Tabindex>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide == 'undefined') {
                        xmlstring += "<IsHide>False</IsHide>";
                    }
                    else {
                        xmlstring += "<IsHide>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide + "</IsHide>";
                    }

                    xmlstring += "</CheckBoxList>";

                    //document.getElementById('DesignDiv').childNodes[arrayControlCount]
                }

                if (document.getElementById('DesignDiv').childNodes[arrayControlCount].type == 'RadioButtonList') {
                    xmlstring += "<RadioButtonList><Label><Text>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                    xmlstring += "<ControlID>3</ControlID><ControlType>Basic</ControlType>";
                    xmlstring += "<FieldID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('Table', '').replace(' ', '_') + "</FieldID>";
                    xmlstring += "<Title>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                    //xmlstring += "<DependentID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>";
                    xmlstring += "<X-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.left.replace('px', '') + "</X-Pos>";
                    xmlstring += "<Y-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.top.replace('px', '') + "</Y-Pos>";
                    xmlstring += "<Width>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.width.replace('px', '') + "</Width>";
                    xmlstring += "<IsRequired>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                    xmlstring += "<IsPostBack>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                    xmlstring += "<IsManageable>True</IsManageable>"; // xmlstring += "<IsManageable>True</IsManageable>";
                    //xmlstring += "<Dependency>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].dependency + "</Dependency>";
                    xmlstring += "<RepeatColumns>1</RepeatColumns>";
                    xmlstring += "<RepeatDirection>Horizontal</RepeatDirection>";
                    xmlstring += "<IsWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                    xmlstring += "<PreWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                    xmlstring += "<PostWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                    xmlstring += "<Dependency></Dependency>";
                    xmlstring += "<PrevRef></PrevRef>";
                    xmlstring += "<DependentID></DependentID>";
                    xmlstring += "<DataSource>XML</DataSource>";
                    //xmlstring += "<PrevRef>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prevref + "</PrevRef>";
                    xmlstring += "<LISTITEMS>";
                    var radiocount = document.getElementById('DesignDiv').childNodes[arrayControlCount].children[0].childNodes.length;
                    if (radiocount < 2) {
                        for (var listCount = 1; listCount < document.getElementById('DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes.length; listCount++) {
                            xmlstring += "<LISTITEM Id='" + (parseInt(listCount) - parseInt(1)) + "' value='' DependentOn='0'>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes[listCount].childNodes[1].title + "List Item text here.</LISTITEM>"; //" + document.getElementById('DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes[listCount].childNodes[1].title + "
                        }
                    }
                    else {
                        var totallistcount = 0;
                        for (var newlistcount = 0; newlistcount < radiocount; newlistcount++) {
                            for (var listCount = 1; listCount < document.getElementById('DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[newlistcount].childNodes.length; listCount++) {
                                xmlstring += "<LISTITEM Id='" + (totallistcount) + "' value='' DependentOn='0'>" + totallistcount + "List Item text here.</LISTITEM>"; //" + document.getElementById('DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes[listCount].childNodes[1].title + "
                                totallistcount++;
                            }
                        }
                    }
                    xmlstring += "</LISTITEMS><Tabindex>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].tabIndex + "</Tabindex>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide == 'undefined') {
                        xmlstring += "<IsHide>False</IsHide>";
                    }
                    else {
                        xmlstring += "<IsHide>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide + "</IsHide>";
                    }

                    xmlstring += "</RadioButtonList>";



                    //document.getElementById('DesignDiv').childNodes[arrayControlCount]
                }

                if (document.getElementById('DesignDiv').childNodes[arrayControlCount].type == 'Label') {
                    xmlstring += "<Label>";
                    xmlstring += "<ControlID>6</ControlID><ControlType>Basic</ControlType>";
                    xmlstring += "<FieldID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('Table', '').replace(' ', '_') + "</FieldID>";
                    xmlstring += "<Title>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                    xmlstring += "<X-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.left.replace('px', '') + "</X-Pos>";
                    xmlstring += "<Y-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.top.replace('px', '') + "</Y-Pos>";
                    xmlstring += "<Width>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.width.replace('px', '') + "</Width>";
                    xmlstring += "<IsPostBack>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                    xmlstring += "<IsWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                    xmlstring += "<PreWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                    xmlstring += "<PostWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                    xmlstring += "<Dependency></Dependency>";
                    xmlstring += "<PrevRef></PrevRef>";
                    xmlstring += "<DependentID></DependentID>";
                    xmlstring += "<Tabindex>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].tabIndex + "</Tabindex>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide == 'undefined') {
                        xmlstring += "<IsHide>False</IsHide>";
                    }
                    else {
                        xmlstring += "<IsHide>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide + "</IsHide>";
                    }

                    xmlstring += "</Label>";



                    //document.getElementById('DesignDiv').childNodes[arrayControlCount]
                }

                if (document.getElementById('DesignDiv').childNodes[arrayControlCount].type == 'Button') {
                    xmlstring += "<Button>";
                    xmlstring += "<ControlID>7</ControlID><ControlType>Basic</ControlType>";
                    xmlstring += "<FieldID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('Table', '').replace(' ', '_') + "</FieldID>";
                    xmlstring += "<Title>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                    xmlstring += "<X-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.left.replace('px', '') + "</X-Pos>";
                    xmlstring += "<Y-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.top.replace('px', '') + "</Y-Pos>";
                    xmlstring += "<Width>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.width.replace('px', '') + "</Width>";
                    xmlstring += "<IsPostBack>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                    xmlstring += "<IsWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                    xmlstring += "<PreWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                    xmlstring += "<PostWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                    xmlstring += "<Dependency></Dependency>";
                    xmlstring += "<PrevRef></PrevRef>";
                    xmlstring += "<DependentID></DependentID>";
                    xmlstring += "<Tabindex>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].tabIndex + "</Tabindex>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide == 'undefined') {
                        xmlstring += "<IsHide>False</IsHide>";
                    }
                    else {
                        xmlstring += "<IsHide>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide + "</IsHide>";
                    }

                    xmlstring += "</Button>";


                    //document.getElementById('DesignDiv').childNodes[arrayControlCount]
                }

                if (document.getElementById('DesignDiv').childNodes[arrayControlCount].type == 'EmpDropDown') {
                    xmlstring += "<CC1EmployeesDropDown><Label><Text>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                    xmlstring += "<ControlID>8</ControlID><ControlType>Custom</ControlType>";
                    xmlstring += "<FieldID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('Table', '') + "</FieldID>";
                    xmlstring += "<Title>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                    xmlstring += "<X-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.left.replace('px', '') + "</X-Pos>";
                    xmlstring += "<Y-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.top.replace('px', '') + "</Y-Pos>";
                    xmlstring += "<Width>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.width.replace('px', '') + "</Width>";
                    xmlstring += "<IsRequired>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                    xmlstring += "<IsManageable>False</IsManageable>";
                    xmlstring += "<IsPostBack>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                    xmlstring += "<IsWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                    xmlstring += "<PreWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                    xmlstring += "<PostWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                    xmlstring += "<DataSource>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].datasource + "</DataSource>";
                    xmlstring += "<SkillSets>";

                    var skillSetArray = new Array();
                    skillSetArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('skillset').split(',');
                    skillSetArray.pop(skillSetArray.length - 1);

                    var skillSetValuesArray = new Array();
                    skillSetValuesArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('skillsetvalues').split(',');
                    skillSetValuesArray.pop(skillSetValuesArray.length - 1);

                    for (var ssCount = 0; ssCount < skillSetArray.length; ssCount++) {
                        xmlstring += "<SkillSet Id='" + skillSetValuesArray[ssCount] + "'>" + skillSetArray[ssCount] + "</SkillSet>";
                    }
                    xmlstring += "</SkillSets>";

                    xmlstring += "<CostCentres>";
                    var costCentreArray = new Array();
                    costCentreArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('costcentre').split(',');
                    costCentreArray.pop(costCentreArray.length - 1);

                    var costCentreValuesArray = new Array();
                    costCentreValuesArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('costcentrevalues').split(',');
                    costCentreValuesArray.pop(costCentreValuesArray.length - 1);

                    for (var ccCount = 0; ccCount < costCentreArray.length; ccCount++) {
                        xmlstring += "<CostCentre Id='" + costCentreValuesArray[ccCount] + "'>" + costCentreArray[ccCount] + "</CostCentre>";
                    }
                    xmlstring += "</CostCentres>";
                    xmlstring += "<IsQueryPattern>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsQueryPattern + "</IsQueryPattern>";
                    xmlstring += "<Tabindex>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].tabIndex + "</Tabindex>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide == 'undefined') {
                        xmlstring += "<IsHide>False</IsHide>";
                    }
                    else {
                        xmlstring += "<IsHide>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide + "</IsHide>";
                    }
                    xmlstring += "</CC1EmployeesDropDown>";
                }



                if (document.getElementById('DesignDiv').childNodes[arrayControlCount].type == 'EmpManagerDropDown') {


                    var x = parseInt(document.getElementById('DesignDiv').childNodes[arrayControlCount].style.left.replace('px', ''));
                    var y = 200;
                    var z = x + y;

                    xmlstring += "<CC3EmployeesDropDown><Label><Text>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                    xmlstring += "<ControlID>10</ControlID><ControlType>Custom</ControlType>";
                    xmlstring += "<FieldID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('Table', '') + "</FieldID>";
                    xmlstring += "<Title>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                    xmlstring += "<X-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.left.replace('px', '') + "</X-Pos>";
                    xmlstring += "<Y-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.top.replace('px', '') + "</Y-Pos>";
                    xmlstring += "<Width>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.width.replace('px', '') + "</Width>";
                    xmlstring += "<IsRequired>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                    xmlstring += "<IsManageable>False</IsManageable>";
                    //xmlstring += "<IsOnClickedChanged>GetEmployeeManager(this)</IsOnClickedChanged>";
                    xmlstring += "<IsOnClickedChanged></IsOnClickedChanged>";
                    xmlstring += "<IsPostBack>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                    xmlstring += "<IsWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                    xmlstring += "<PreWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                    xmlstring += "<PostWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                    xmlstring += "<DataSource>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].datasource + "</DataSource>";
                    xmlstring += "<SkillSets>";

                    var skillSetArray = new Array();
                    skillSetArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('skillset').split(',');
                    skillSetArray.pop(skillSetArray.length - 1);

                    var skillSetValuesArray = new Array();
                    skillSetValuesArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('skillsetvalues').split(',');
                    skillSetValuesArray.pop(skillSetValuesArray.length - 1);

                    for (var ssCount = 0; ssCount < skillSetArray.length; ssCount++) {
                        xmlstring += "<SkillSet Id='" + skillSetValuesArray[ssCount] + "'>" + skillSetArray[ssCount] + "</SkillSet>";
                    }
                    xmlstring += "</SkillSets>";

                    xmlstring += "<CostCentres>";
                    var costCentreArray = new Array();
                    costCentreArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('costcentre').split(',');
                    costCentreArray.pop(costCentreArray.length - 1);

                    var costCentreValuesArray = new Array();
                    costCentreValuesArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('costcentrevalues').split(',');
                    costCentreValuesArray.pop(costCentreValuesArray.length - 1);

                    for (var ccCount = 0; ccCount < costCentreArray.length; ccCount++) {
                        xmlstring += "<CostCentre Id='" + costCentreValuesArray[ccCount] + "'>" + costCentreArray[ccCount] + "</CostCentre>";
                    }
                    xmlstring += "</CostCentres>";
                    xmlstring += "<IsQueryPattern>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsQueryPattern + "</IsQueryPattern>";
                    xmlstring += "<Tabindex>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].tabIndex + "</Tabindex>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide == 'undefined') {
                        xmlstring += "<IsHide>False</IsHide>";
                    }
                    else {
                        xmlstring += "<IsHide>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide + "</IsHide>";
                    }
                    xmlstring += "</CC3EmployeesDropDown>";


                    // code commented on 22 aug 2016 8.30

                    //                    if (document.getElementById('FileModeHidden').value != "EDITMODE") {

                    //                        xmlstring += "<TextBox><Label><Text>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + " Manager</Text></Label>";
                    //                        xmlstring += "<ControlID>1</ControlID><ControlType>Basic</ControlType>";
                    //                        xmlstring += "<FieldID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('DropDownTable', 'TextBox').replace(' ', '_').replace('cc', 'cctxt') + "</FieldID>";
                    //                        //xmlstring += "<Title>Employee Manager</Title>";
                    //                        xmlstring += "<Title>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + " Manager</Title>";
                    //                        xmlstring += "<X-Pos>" + z + "</X-Pos>";
                    //                        xmlstring += "<Y-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.top.replace('px', '') + "</Y-Pos>";
                    //                        xmlstring += "<Width>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.width.replace('px', '') + "</Width>";
                    //                        xmlstring += "<IsRequired>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                    //                        xmlstring += "<IsPostBack>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                    //                        xmlstring += "<IsWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                    //                        xmlstring += "<PreWrap>cc</PreWrap>";
                    //                        xmlstring += "<PostWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                    //                        xmlstring += "<TextMode>SingleLine</TextMode>";
                    //                        xmlstring += "<IsType>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].istype + "</IsType>";
                    //                        xmlstring += "<MaxLength>100</MaxLength>";
                    //                        xmlstring += "<Dependency></Dependency>";
                    //                        xmlstring += "<PrevRef></PrevRef>";
                    //                        xmlstring += "<DependentID></DependentID>";
                    //                        xmlstring += "<Tabindex>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].tabIndex + "</Tabindex>";
                    //                        xmlstring += "<Height>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.height.replace('px', '') + "</Height>";
                    //                        if (document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide == 'undefined') {
                    //                            xmlstring += "<IsHide>False</IsHide>";
                    //                        }
                    //                        else {
                    //                            xmlstring += "<IsHide>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide + "</IsHide>";
                    //                        }
                    //                        xmlstring += "</TextBox>";


                    xmlstring += "<TextBox1><Label><Text>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + " Manager</Text></Label>";
                    xmlstring += "<ControlID>1</ControlID><ControlType>Basic</ControlType>";
                    xmlstring += "<FieldID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('DropDownTable', 'TextBox').replace(' ', '_').replace('cc', 'cctxt') + "</FieldID>";
                    //xmlstring += "<Title>Employee Manager</Title>";
                    xmlstring += "<Title>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + " Manager</Title>";
                    xmlstring += "<X-Pos>" + z + "</X-Pos>";
                    xmlstring += "<Y-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.top.replace('px', '') + "</Y-Pos>";
                    xmlstring += "<Width>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.width.replace('px', '') + "</Width>";
                    xmlstring += "<IsRequired>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                    xmlstring += "<IsPostBack>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                    xmlstring += "<IsWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                    xmlstring += "<PreWrap>cc</PreWrap>";
                    xmlstring += "<PostWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                    xmlstring += "<TextMode>SingleLine</TextMode>";
                    xmlstring += "<IsType>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].istype + "</IsType>";
                    xmlstring += "<MaxLength>100</MaxLength>";
                    xmlstring += "<Dependency></Dependency>";
                    xmlstring += "<PrevRef></PrevRef>";
                    xmlstring += "<DependentID></DependentID>";
                    xmlstring += "<Tabindex>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].tabIndex + "</Tabindex>";
                    xmlstring += "<Height>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.height.replace('px', '') + "</Height>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide == 'undefined') {
                        xmlstring += "<IsHide>False</IsHide>";
                    }
                    else {
                        xmlstring += "<IsHide>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide + "</IsHide>";
                    }
                    xmlstring += "</TextBox1>";
                    //  }
                    // code commented on 22 aug 2016 8.30
                }


                if (document.getElementById('DesignDiv').childNodes[arrayControlCount].type == 'GlobalMControl') {
                    xmlstring += "<GlobalMControl><Label><Text>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                    xmlstring += "<ControlID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].controlid + "</ControlID><ControlType>Global</ControlType>";
                    xmlstring += "<FieldID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('DropDownTable', '') + "DropDown</FieldID>";
                    xmlstring += "<Title>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                    xmlstring += "<DependentID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>"; //.replace('DropDownTable','')+"DropDown
                    xmlstring += "<DependentCtrlID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].depctrlid + "</DependentCtrlID>";
                    xmlstring += "<X-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.left.replace('px', '') + "</X-Pos>";
                    xmlstring += "<Y-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.top.replace('px', '') + "</Y-Pos>";
                    xmlstring += "<Width>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.width.replace('px', '') + "</Width>";
                    xmlstring += "<IsRequired>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                    xmlstring += "<IsManageable>False</IsManageable>";
                    xmlstring += "<IsPostBack>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                    xmlstring += "<IsWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                    xmlstring += "<PreWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                    xmlstring += "<PostWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                    xmlstring += "<DataSource>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].datasource + "</DataSource>";
                    xmlstring += "<SkillSets>";

                    var skillSetArray = new Array();
                    skillSetArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('skillset').split(',');
                    skillSetArray.pop(skillSetArray.length - 1);

                    var skillSetValuesArray = new Array();
                    skillSetValuesArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('skillsetvalues').split(',');
                    skillSetValuesArray.pop(skillSetValuesArray.length - 1);

                    for (var ssCount = 0; ssCount < skillSetArray.length; ssCount++) {
                        xmlstring += "<SkillSet Id='" + skillSetValuesArray[ssCount] + "'>" + skillSetArray[ssCount] + "</SkillSet>";
                    }
                    xmlstring += "</SkillSets>";

                    xmlstring += "<CostCentres>";
                    var costCentreArray = new Array();
                    costCentreArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('costcentre').split(',');
                    costCentreArray.pop(costCentreArray.length - 1);

                    var costCentreValuesArray = new Array();
                    costCentreValuesArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('costcentrevalues').split(',');
                    costCentreValuesArray.pop(costCentreValuesArray.length - 1);

                    for (var ccCount = 0; ccCount < costCentreArray.length; ccCount++) {
                        xmlstring += "<CostCentre Id='" + costCentreValuesArray[ccCount] + "'>" + costCentreArray[ccCount] + "</CostCentre>";
                    }
                    xmlstring += "</CostCentres>";
                    xmlstring += "<IsQueryPattern>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsQueryPattern + "</IsQueryPattern>";
                    xmlstring += "<Tabindex>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].tabIndex + "</Tabindex>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide == 'undefined') {
                        xmlstring += "<IsHide>False</IsHide>";
                    }
                    else {
                        xmlstring += "<IsHide>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide + "</IsHide>";
                    }
                    xmlstring += "</GlobalMControl>";

                }


                if (document.getElementById('DesignDiv').childNodes[arrayControlCount].type == 'GlobalSControl') {
                    xmlstring += "<GlobalSControl><Label><Text>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                    xmlstring += "<ControlID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].controlid + "</ControlID><ControlType>Global</ControlType>";
                    xmlstring += "<FieldID>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].id.replace('DropDownTable', '') + "DropDown</FieldID>";
                    xmlstring += "<Title>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                    xmlstring += "<DependentID></DependentID>"; //.replace('DropDownTable','')+"DropDown
                    xmlstring += "<X-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.left.replace('px', '') + "</X-Pos>";
                    xmlstring += "<Y-Pos>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.top.replace('px', '') + "</Y-Pos>";
                    xmlstring += "<Width>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].style.width.replace('px', '') + "</Width>";
                    xmlstring += "<IsRequired>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                    xmlstring += "<IsManageable>False</IsManageable>";
                    xmlstring += "<IsPostBack>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                    xmlstring += "<IsWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                    xmlstring += "<PreWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                    xmlstring += "<PostWrap>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                    xmlstring += "<DataSource>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].datasource + "</DataSource>";
                    xmlstring += "<SkillSets>";

                    var skillSetArray = new Array();
                    skillSetArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('skillset').split(',');
                    skillSetArray.pop(skillSetArray.length - 1);

                    var skillSetValuesArray = new Array();
                    skillSetValuesArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('skillsetvalues').split(',');
                    skillSetValuesArray.pop(skillSetValuesArray.length - 1);

                    for (var ssCount = 0; ssCount < skillSetArray.length; ssCount++) {
                        xmlstring += "<SkillSet Id='" + skillSetValuesArray[ssCount] + "'>" + skillSetArray[ssCount] + "</SkillSet>";
                    }
                    xmlstring += "</SkillSets>";

                    xmlstring += "<CostCentres>";
                    var costCentreArray = new Array();
                    costCentreArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('costcentre').split(',');
                    costCentreArray.pop(costCentreArray.length - 1);

                    var costCentreValuesArray = new Array();
                    costCentreValuesArray = document.getElementById('DesignDiv').childNodes[arrayControlCount].getAttribute('costcentrevalues').split(',');
                    costCentreValuesArray.pop(costCentreValuesArray.length - 1);

                    for (var ccCount = 0; ccCount < costCentreArray.length; ccCount++) {
                        xmlstring += "<CostCentre Id='" + costCentreValuesArray[ccCount] + "'>" + costCentreArray[ccCount] + "</CostCentre>";
                    }
                    xmlstring += "</CostCentres>";
                    xmlstring += "<IsQueryPattern>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsQueryPattern + "</IsQueryPattern>";
                    xmlstring += "<Tabindex>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].tabIndex + "</Tabindex>";
                    if (document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide == 'undefined') {
                        xmlstring += "<IsHide>False</IsHide>";
                    }
                    else {
                        xmlstring += "<IsHide>" + document.getElementById('DesignDiv').childNodes[arrayControlCount].IsHide + "</IsHide>";
                    }
                    xmlstring += "</GlobalSControl>";

                }

            }


            xmlstring += "<DataScript><IsUpdated>False</IsUpdated><Array></Array></DataScript>";
            document.getElementById('SaveXMLHidden').value = xmlstring;
        }
        else {
            alert("Please select the CostCentre and SkillSets for the highlighted controls.")
            return false;
        }

    }
    else {

        alert("An empty form cannot be submitted.");
        return false;

    }

    //return false;
    //***alert(xmlstring); COMMENTED BY AARTI
}



//**=====================================================File Edit Mode Functions to ReCreate Controls==================================**//

function ReCreateControls() {
    var xmlString = document.getElementById("ReadXMLHidden").value


    var xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
    xmlDoc.async = "false";
    xmlDoc.loadXML(xmlString);

    // alert(xmlDoc.childNodes[1].childNodes.length);

    for (var xmlChildCount = 0; xmlChildCount < xmlDoc.childNodes[1].childNodes.length; xmlChildCount++) {
        alert(xmlDoc.childNodes[1].childNodes[xmlChildCount].innerHTML);
    }



}

function SetQueryPattern() {
    var titleArray = new Array();

    if (document.getElementById('IsQueryPattern').options.selectedIndex == "0") {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].isrequired = 'True';
            }
        }
    }
    if (document.getElementById('IsQueryPattern').options.selectedIndex == "1") {
        for (var arrayCount = 0; arrayCount < document.getElementById('DesignDiv').childNodes.length; arrayCount++) {
            titleArray[arrayCount] = document.getElementById('DesignDiv').childNodes[arrayCount].title;
        }
        for (var arrayCountx = 0; arrayCountx < document.getElementById('DesignDiv').childNodes.length; arrayCountx++) {
            if (document.getElementById('titleTextBox').value == titleArray[arrayCountx]) {
                document.getElementById('DesignDiv').childNodes[arrayCountx].isrequired = 'Start';
            }
        }
    }
}


function GetControlnew(formid) {

    PageMethods.GetDTMSControl(formid, OnSuccess);

}
function OnSuccess(response, userContext, methodName) {
    // alert(response);
    var ctype = response.split(",");

    var ctypevalue = 0;
    for (var ctypevalue = 0; ctypevalue < ctype.length; ctypevalue++) {
        if (ctype[ctypevalue] != "") {
            controlarray[ctypevalue] = { name: ctype[ctypevalue] };
        }
    }
}

function checkforDTMS(controlname) {
    if (controlarray.length != 0) {
        for (var i = 0; i < controlarray.length; i++) {
            if (controlname.toLowerCase().trim().replace(" ", "") == controlarray[i]["name"].toLowerCase().trim().replace(" ", "")) {
                alert('For DTMS Logger control name' + '"' + controlname + '"' + ' is not allowed.')
                return false;
            }
        }
    }
}