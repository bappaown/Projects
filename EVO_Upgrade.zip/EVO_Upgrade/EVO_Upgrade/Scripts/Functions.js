﻿//Popup preview page.
function PreviewPage() {
    window.open("../User/Preview.aspx", "Preview", 'toolbar=0,scrollbars=1,location=0,status=1,menubar=0,resizable=1,width=1200,height=900,left = 25,top = 50');
}

//Popup Dash Board
function popUpDashBoard() {
    window.open("DashBoard.aspx", "DashBoard", 'toolbar=0,scrollbars=1,location=0,status=1,menubar=0,resizable=1,width=1000,height=900,left = 100,top = 100');
}



function EditDeleteItemNew(Control, ControlType, wrap)   //,DepId, ItemId
{

    //  alert("EditDeleteItem");
    //   alert(Control);
    var selFullVal;
    var selValText;
    var selVal;
    var wrapNote;
    //alert(" DepIdFromXml : " + DepIdFromXml);

    if ((ControlType == "DropDownList") || (ControlType == "ListBox") || (ControlType == "DropDown") || (ControlType == "CheckBoxList")) {
        selFullVal = document.getElementById("ctl00_ContentPlaceHolder1_" + Control).options[document.getElementById("ctl00_ContentPlaceHolder1_" + Control).selectedIndex].value.split(",");
        alert(" selFullVal : " + selFullVal);
        selVal = selFullVal[0];
        selValText = selFullVal[1];
        DepIdFromXml = selFullVal[2];
        wrapNote = wrap;

        if (((ControlType == "DropDownList") || (ControlType == "DropDown")) && (document.getElementById("ctl00_ContentPlaceHolder1_" + Control).selectedIndex <= 0)) {
            //	alert("In If");
            document.getElementById("ctl00_ContentPlaceHolder1_txtValue").value = "";
            document.getElementById("ctl00_ContentPlaceHolder1_SelectedItemOldValue").value = 0;
            document.getElementById("ctl00_ContentPlaceHolder1_SelectedValue").value = "";
            document.getElementById("ctl00_ContentPlaceHolder1_SelectedDepIdFromXml").value = 0;
            document.getElementById("ctl00_ContentPlaceHolder1_txtWrapNote").value = wrapNote;
            alert(1);
        }
        else {
            //	alert("in else " + selFullVal);
            //alert(document.getElementById("ctl00_ContentPlaceHolder1_" + Control).options[document.getElementById("ctl00_ContentPlaceHolder1_"+ Control).selectedIndex].value);

            //alert(" selVal : " + selVal);
            document.getElementById("ctl00_ContentPlaceHolder1_txtValue").value = selValText;
            document.getElementById("ctl00_ContentPlaceHolder1_SelectedItemOldValue").value = selValText;
            document.getElementById("ctl00_ContentPlaceHolder1_SelectedValue").value = selVal;
            document.getElementById("ctl00_ContentPlaceHolder1_SelectedDepIdFromXml").value = DepIdFromXml;
            document.getElementById("ctl00_ContentPlaceHolder1_txtWrapNote").value = wrapNote;
            alert(2);
        }
    }
    else if (ControlType == "RadioButtonList") {
        var len = document.getElementsByName("ctl00$ContentPlaceHolder1$" + Control).length;
        for (i = 0; i < len; i++) {
            if (document.getElementById("ctl00_ContentPlaceHolder1_" + Control + "_" + [i]).checked) {
                //alert(document.getElementById("ctl00_ContentPlaceHolder1_" + Control +  "_" + [i]).value);
                selFullVal = document.getElementById("ctl00_ContentPlaceHolder1_" + Control + "_" + [i]).value.split(",");
                selVal = selFullVal[0];
                selValText = selFullVal[1];
                DepIdFromXml = selFullVal[2];
            }
        }

        document.getElementById("ctl00_ContentPlaceHolder1_txtValue").value = selValText;
        document.getElementById("ctl00_ContentPlaceHolder1_SelectedItemOldValue").value = selValText;
        document.getElementById("ctl00_ContentPlaceHolder1_SelectedValue").value = selVal;
        document.getElementById("ctl00_ContentPlaceHolder1_SelectedDepIdFromXml").value = 0;
    }
    //alert(" DepIdFromXml : " + DepIdFromXml);
    ////   else if(ControlType =="CheckBoxList")
    ////   {
    ////        var chkText = '';
    ////        var chktable = $('#' + Control);
    ////        //alert(" chktable : " + chktable.id);
    ////        var chktr = chktable.getElementsByTagName('tr');
    ////        alert("selectedIndex : " + chktr.selectedIndex);

    ////        for(var i=0; i < chktr.length;i++)
    ////        {
    ////            var chktd = chktr[i].getElementsByTagName('td');
    ////            //$('#ChkListLength').value = chktd.length;
    ////            for(var j=0; j < chktd.length; j++)
    ////            {
    ////                var chkinput = chktd[j].getElementsByTagName('input');
    ////                var chklabel= chktd[j].getElementsByTagName('label');
    ////                for(k=0;k < chkinput.length;k++)
    ////                {
    ////                    //chkinput[k].checked = false;
    ////                    var chkopt = chkinput[k];
    ////                    if(chkopt.checked)
    ////                    {
    ////                        selValText = chkText + chklabel[k].innerText;
    ////                        //document.getElementById("ctl00_ContentPlaceHolder1_SelectedValue").value = DepId;
    ////                    }
    ////                }
    ////            }
    ////        }
    ////        //document.getElementById("ctl00_ContentPlaceHolder1_SelectedControl").value = "ctl00_ContentPlaceHolder1_" + Control;
    ////   }
}



// function to set data for edit / delete
function EditDeleteItem(Control, ControlType)   //,DepId, ItemId
{

    //  alert("EditDeleteItem");
    //   alert(Control);
    var selFullVal;
    var selValText;
    var selVal;
    var wrapNote;
    var optionTooltip;
    var template;

    //alert(" DepIdFromXml : " + DepIdFromXml);

    if ((ControlType == "DropDownList") || (ControlType == "ListBox") || (ControlType == "DropDown") || (ControlType == "CheckBoxList")) {
        selFullVal = document.getElementById("ctl00_ContentPlaceHolder1_" + Control).options[document.getElementById("ctl00_ContentPlaceHolder1_" + Control).selectedIndex].value.split(",");
        //alert(" selFullVal : " + selFullVal); 
        selVal = selFullVal[0];
        selValText = selFullVal[1];
        DepIdFromXml = selFullVal[2];
        if (selFullVal.length > 3) {
            wrapNote = selFullVal[3].toString().replace(/¢/g, "\n\r");
            optionTooltip = selFullVal[4];
            template = selFullVal[5];
        }

        if (((ControlType == "DropDownList") || (ControlType == "DropDown")) && (document.getElementById("ctl00_ContentPlaceHolder1_" + Control).selectedIndex <= 0)) {
            //	alert("In If");
            document.getElementById("ctl00_ContentPlaceHolder1_txtValue").value = "";
            document.getElementById("ctl00_ContentPlaceHolder1_SelectedItemOldValue").value = 0;
            document.getElementById("ctl00_ContentPlaceHolder1_SelectedValue").value = "";
            document.getElementById("ctl00_ContentPlaceHolder1_SelectedDepIdFromXml").value = 0;
            document.getElementById("ctl00_ContentPlaceHolder1_txtWrapNote").value = wrapNote;
            document.getElementById("ctl00_ContentPlaceHolder1_txtOptionTooltip").value = optionTooltip;
            
            //select item from template 
            for (var i = 0; i < document.getElementById("ctl00_ContentPlaceHolder1_ddlTemplate").length; i++) {
                //alert( document.getElementById("ctl00_ContentPlaceHolder1_ddlTemplate")[i].value);
                if (document.getElementById("ctl00_ContentPlaceHolder1_ddlTemplate")[i].value == template) {
                    //alert('found');
                    document.getElementById("ctl00_ContentPlaceHolder1_ddlTemplate").selectedIndex = i;
                    break;
                }
            }

        }
        else {
            //	alert("in else " + selFullVal);
            //alert(document.getElementById("ctl00_ContentPlaceHolder1_" + Control).options[document.getElementById("ctl00_ContentPlaceHolder1_"+ Control).selectedIndex].value);

            //alert(" selVal : " + selVal);

            //select item from template
            if (document.getElementById("ctl00_ContentPlaceHolder1_ddlTemplate") != null) {
                for (var i = 0; i < document.getElementById("ctl00_ContentPlaceHolder1_ddlTemplate").length; i++) {
                    //alert( document.getElementById("ctl00_ContentPlaceHolder1_ddlTemplate")[i].value);
                    if (document.getElementById("ctl00_ContentPlaceHolder1_ddlTemplate")[i].value == template) {
                        //alert('found');
                        document.getElementById("ctl00_ContentPlaceHolder1_ddlTemplate").selectedIndex = i;
                        break;
                    }
                }
            }
            document.getElementById("ctl00_ContentPlaceHolder1_txtValue").value = selValText;
            document.getElementById("ctl00_ContentPlaceHolder1_SelectedItemOldValue").value = selValText;
            document.getElementById("ctl00_ContentPlaceHolder1_SelectedValue").value = selVal;
            document.getElementById("ctl00_ContentPlaceHolder1_SelectedDepIdFromXml").value = DepIdFromXml;
            document.getElementById("ctl00_ContentPlaceHolder1_txtWrapNote").value = wrapNote;
            if (document.getElementById("ctl00_ContentPlaceHolder1_txtOptionTooltip") != null) {
                document.getElementById("ctl00_ContentPlaceHolder1_txtOptionTooltip").value = optionTooltip;
            }
           
        }
    }
    else if (ControlType == "RadioButtonList") {
        var len = document.getElementsByName("ctl00$ContentPlaceHolder1$" + Control).length;
        for (i = 0; i < len; i++) {
            if (document.getElementById("ctl00_ContentPlaceHolder1_" + Control + "_" + [i]).checked) {
                //alert(document.getElementById("ctl00_ContentPlaceHolder1_" + Control +  "_" + [i]).value);
                selFullVal = document.getElementById("ctl00_ContentPlaceHolder1_" + Control + "_" + [i]).value.split(",");
                selVal = selFullVal[0];
                selValText = selFullVal[1];
                DepIdFromXml = selFullVal[2];
            }
        }

        document.getElementById("ctl00_ContentPlaceHolder1_txtValue").value = selValText;
        document.getElementById("ctl00_ContentPlaceHolder1_SelectedItemOldValue").value = selValText;
        document.getElementById("ctl00_ContentPlaceHolder1_SelectedValue").value = selVal;
        document.getElementById("ctl00_ContentPlaceHolder1_SelectedDepIdFromXml").value = 0;
    }
    //alert(" DepIdFromXml : " + DepIdFromXml);
    ////   else if(ControlType =="CheckBoxList")
    ////   {
    ////        var chkText = '';
    ////        var chktable = $('#' + Control);
    ////        //alert(" chktable : " + chktable.id);
    ////        var chktr = chktable.getElementsByTagName('tr');
    ////        alert("selectedIndex : " + chktr.selectedIndex);

    ////        for(var i=0; i < chktr.length;i++)
    ////        {
    ////            var chktd = chktr[i].getElementsByTagName('td');
    ////            //$('#ChkListLength').value = chktd.length;
    ////            for(var j=0; j < chktd.length; j++)
    ////            {
    ////                var chkinput = chktd[j].getElementsByTagName('input');
    ////                var chklabel= chktd[j].getElementsByTagName('label');
    ////                for(k=0;k < chkinput.length;k++)
    ////                {
    ////                    //chkinput[k].checked = false;
    ////                    var chkopt = chkinput[k];
    ////                    if(chkopt.checked)
    ////                    {
    ////                        selValText = chkText + chklabel[k].innerText;
    ////                        //document.getElementById("ctl00_ContentPlaceHolder1_SelectedValue").value = DepId;
    ////                    }
    ////                }
    ////            }
    ////        }
    ////        //document.getElementById("ctl00_ContentPlaceHolder1_SelectedControl").value = "ctl00_ContentPlaceHolder1_" + Control;
    ////   }
}

// Function to confirm to delete a node
function ConfirmDeleteNode() {
    //    alert(document.getElementById("ctl00_ContentPlaceHolder1_SelectedControl").value);
    //    alert(document.getElementById("ctl00_ContentPlaceHolder1_SelectedDepIdFromXml").value );
    var isDelete;

    var NoOfDiff = document.getElementById("ctl00_ContentPlaceHolder1_NoOfSelectedParentsHidden").value.split(",");
    var ActualDep = document.getElementById("ctl00_ContentPlaceHolder1_NoOfDependentsHidden").value;

    if (document.getElementById("ctl00_ContentPlaceHolder1_drpFrom").selectedIndex <= 0) {
        alert("Please Select Control");
        document.getElementById("ctl00_ContentPlaceHolder1_drpFrom").focus();
        return false;
    }
    else if (document.getElementById("ctl00_ContentPlaceHolder1_SelectedValue").value == "0") {
        alert("Please Select Parent control to delete");
        return false;
    }
    else if ((document.getElementById("ctl00_ContentPlaceHolder1_SelectedControl").value == "Parent") && (document.getElementById("ctl00_ContentPlaceHolder1_SelectedDepIdFromXml").value == "0")) {
        alert("Please Select Child control to delete");
        return false;
    }
    else if (document.getElementById("ctl00_ContentPlaceHolder1_txtValue").value == "") {
        alert("Please Select Child control to delete");
        return false;
    }
    else if (ActualDep != NoOfDiff.length) {
        alert("Please Select Parent control");
        return false;
    }
    else if (confirm("Are you sure you want to delete selected option and its sub options?"))   // need to ask some one abt the sentence
    {
        var obj1 = document.getElementById("ctl00_ContentPlaceHolder1_btnDelete");
        obj1.click;
        isDelete = true;
    }

    else {
        isDelete = false;
    }
    return isDelete;
}

// Function to Populate dropdowns based on previous selection
function Populate(FromControl, ToControl, ArrName, Module, NoOfDep) {
    var Difference = (document.getElementById("ctl00_ContentPlaceHolder1_NoOfDependentsHidden").value - (NoOfDep - 1));

    if (Difference == "1") {
        document.getElementById("ctl00_ContentPlaceHolder1_NoOfSelectedParentsHidden").value = "";
    }
    else if (Difference == "2") {
        var GetDiffVal = document.getElementById("ctl00_ContentPlaceHolder1_NoOfSelectedParentsHidden").value.split(",");
        var val1 = GetDiffVal[0];
        var val2 = GetDiffVal[1];
        document.getElementById("ctl00_ContentPlaceHolder1_NoOfSelectedParentsHidden").value = val1 + "," + val2;
    }
    else if (Difference == "3") {
        var GetDiffVal = document.getElementById("ctl00_ContentPlaceHolder1_NoOfSelectedParentsHidden").value.split(",");
        var val1 = GetDiffVal[0];
        var val2 = GetDiffVal[1];
        var val3 = GetDiffVal[2];        
        document.getElementById("ctl00_ContentPlaceHolder1_NoOfSelectedParentsHidden").value = val1 + "," + val2 + "," + val3;
    }

    for (k = document.getElementById("ctl00_ContentPlaceHolder1_" + ToControl).options.length; k >= 0; k--) {
        document.getElementById("ctl00_ContentPlaceHolder1_" + ToControl).options[k] = null;
    }
    if (ToControl.substring(0, 3) == "ddl") {
        var optDefault = document.createElement("option");
        document.getElementById("ctl00_ContentPlaceHolder1_" + ToControl).options.add(optDefault);
        optDefault.text = "-- Select --";
        optDefault.value = 0;
    }
    var selFullVal = document.getElementById("ctl00_ContentPlaceHolder1_" + FromControl).options[document.getElementById("ctl00_ContentPlaceHolder1_" + FromControl).selectedIndex].value.split(",");

    selVal = selFullVal[0];
    selValText = selFullVal[1];
    DepIdFromXml = selFullVal[2];
    wrap = selFullVal[3];
    optionTooltip = selFullVal[4];
    template = selFullVal[5];
    
    //    alert(" DepIdFromXml : " + DepIdFromXml);

    if (Module == "") {
        document.getElementById("ctl00_ContentPlaceHolder1_txtValue").value = "";
        // This is used only to store the selected value in Hidden Field. This will be used while adding the listItem.
        document.getElementById("ctl00_ContentPlaceHolder1_PopulateParentIdHidden").value = selVal;
        document.getElementById("ctl00_ContentPlaceHolder1_SelectedValue").value = selVal;
        document.getElementById("ctl00_ContentPlaceHolder1_SelectedControl").value = "Parent";
        document.getElementById("ctl00_ContentPlaceHolder1_selectedField").value = FromControl;
        document.getElementById("ctl00_ContentPlaceHolder1_SelectedDepIdFromXml").value = DepIdFromXml;
        document.getElementById("ctl00_ContentPlaceHolder1_NoOfSelectedParentsHidden").value = document.getElementById("ctl00_ContentPlaceHolder1_NoOfSelectedParentsHidden").value + "," + selVal;

    }
    if (ArrName[selVal] === undefined) {
    }
    else {
        for (var i = 0; i < ArrName[selVal].length; i++) {
            if (ArrName[selVal][i] === undefined) {
            }
            else {
                var opt = document.createElement("option");
                document.getElementById("ctl00_ContentPlaceHolder1_" + ToControl).options.add(opt);
                var Array1 = ArrName[selVal][i];
                if (Array1.length > 0) {
                    var NameAndWrap = Array1[0].split(",");
                    opt.text = NameAndWrap[0];
                    opt.value = i + "," + NameAndWrap[0] + "," + selVal + "," + NameAndWrap[1] + "," + NameAndWrap[2] + "," + NameAndWrap[3];
                } else {
                    opt.value = i + "," + ArrName[selVal][i] + "," + selVal;
                    opt.text = ArrName[selVal][i];
                }

            }
        }
    }

   // alert('calling');
    EditDeleteItem(FromControl, "DropDownList");
}



// Function to Populate dropdowns based on previous selection for control manangement
function PopulateNew(FromControl, ToControl, ArrName, Module, NoOfDep) {
    var Difference = (document.getElementById("ctl00_ContentPlaceHolder1_NoOfDependentsHidden").value - (NoOfDep - 1));
    
    if (Difference == "1") {
        document.getElementById("ctl00_ContentPlaceHolder1_NoOfSelectedParentsHidden").value = "";
    }
    else if (Difference == "2") {
        var GetDiffVal = document.getElementById("ctl00_ContentPlaceHolder1_NoOfSelectedParentsHidden").value.split(",");
        var val1 = GetDiffVal[0];
        var val2 = GetDiffVal[1];
        document.getElementById("ctl00_ContentPlaceHolder1_NoOfSelectedParentsHidden").value = val1 + "," + val2;
    }
    else if (Difference == "3") {
        var GetDiffVal = document.getElementById("ctl00_ContentPlaceHolder1_NoOfSelectedParentsHidden").value.split(",");
        var val1 = GetDiffVal[0];
        var val2 = GetDiffVal[1];
        var val3 = GetDiffVal[2];
        document.getElementById("ctl00_ContentPlaceHolder1_NoOfSelectedParentsHidden").value = val1 + "," + val2 + "," + val3;
    }
    if (document.getElementById("ctl00_ContentPlaceHolder1_" + ToControl) != null) {
        for (k = document.getElementById("ctl00_ContentPlaceHolder1_" + ToControl).options.length; k >= 0; k--) {
            document.getElementById("ctl00_ContentPlaceHolder1_" + ToControl).options[k] = null;
        }
    }
    if (ToControl.substring(0, 3) == "ddl") {
        //var optDefault = document.createElement("option");
        //document.getElementById("ctl00_ContentPlaceHolder1_" + ToControl).options.add(optDefault);
       
       
    }
    var selFullVal = document.getElementById("ctl00_ContentPlaceHolder1_" + FromControl).options[document.getElementById("ctl00_ContentPlaceHolder1_" + FromControl).selectedIndex].value.split(",");

    selVal = selFullVal[0];
    selValText = selFullVal[1];
    DepIdFromXml = selFullVal[2];
    wrap = selFullVal[3];
    optionTooltip = selFullVal[4];
    template = selFullVal[5];

    //    alert(" DepIdFromXml : " + DepIdFromXml);

    
    if (ArrName[selVal] === undefined) {
    }
    else {
        for (var i = 0; i < ArrName[selVal].length; i++) {
            if (ArrName[selVal][i] === undefined) {
            }
            else {
                var opt = document.createElement("option");
                if (document.getElementById("ctl00_ContentPlaceHolder1_" + ToControl) != null) {
                    document.getElementById("ctl00_ContentPlaceHolder1_" + ToControl).options.add(opt);
                    var Array1 = ArrName[selVal][i];
                    if (Array1.length > 0) {
                        var NameAndWrap = Array1[0].split(",");
                        opt.text = NameAndWrap[0];
                        opt.value = i + "," + NameAndWrap[0] + "," + selVal + "," + NameAndWrap[1] + "," + NameAndWrap[2] + "," + NameAndWrap[3];
                    } else {
                        opt.value = i + "," + ArrName[selVal][i] + "," + selVal;
                        opt.text = ArrName[selVal][i];
                    }
                }
            }
        }
    }

    
}


function loadXMLDoc(FromControl, ToControl, id, setValue) {
    var xmlhttp;
    if (window.XMLHttpRequest) {
        // code for IE7+, Firefox, Chrome, Opera, Safari
        xmlhttp = new XMLHttpRequest();
    }
    else {
        // code for IE6, IE5
        xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.onreadystatechange = function() {
        alert(xmlhttp.readyState);
        if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
            var values = xmlhttp.responseText;
            alert(values);
        }
    }
    xmlhttp.open("GET", "AjaxPage.aspx?FromControl='" + FromControl + "',ToControl='" + ToControl + "'&id='" + id + "',name='" + setValue + "'", true);
    xmlhttp.send();
}



function ValidateDataManagement(btnClicked, txtClientId, txtWrapNoteClientId, txtOptionTooltipClientId) {
    var isClickedValid = true;
    var NoOfDiff = document.getElementById("ctl00_ContentPlaceHolder1_NoOfSelectedParentsHidden").value.split(",");
    var ActualDep = document.getElementById("ctl00_ContentPlaceHolder1_NoOfDependentsHidden").value;

    if (document.getElementById("ctl00_ContentPlaceHolder1_drpFrom").selectedIndex <= 0) {
        alert("Please Select Control");
        document.getElementById("ctl00_ContentPlaceHolder1_drpFrom").focus();
        isClickedValid = false;
        //return false;
    }
    else if (trim(document.getElementById("ctl00_ContentPlaceHolder1_txtValue").value) == "") {
        alert("Please enter List Item Value");
        document.getElementById("ctl00_ContentPlaceHolder1_txtValue").focus();
        isClickedValid = false;
        //return false;
    }
    else if ((document.getElementById("ctl00_ContentPlaceHolder1_SelectedControl").value == "Parent") && (document.getElementById("ctl00_ContentPlaceHolder1_SelectedValue").value == "0")) {
        //        alert("Else if 1");
        alert("Please Select Parent control");
        isClickedValid = false;
        //return false;
    }
    else if (ActualDep != NoOfDiff.length) {
        //        alert("Else if 2");
        //    alert("ActualDep : " + ActualDep );
        //    alert("NoOfDiff.length : " + NoOfDiff.length );
        alert("Please Select Parent control");
        isClickedValid = false;
    }
    else if (document.getElementById(txtClientId).value != "") {
        //var iChars = "_!@#$%^&*()+=[]\\\';,./{}|\":<>?~`-£ "; 
        var iChars = "',\""; //Removed characters "/()&£ -_!@#$%^*+=[]\\\.{}|:<>?~`"
        var text = document.getElementById(txtClientId).value;
        var IsFound = false;
        for (var i = 0; i < text.length; i++) {
            if (iChars.indexOf(text.charAt(i)) != -1) {
                IsFound = true; //alert ("The form name has some special characters."); 
                document.getElementById(txtClientId).focus();
                //return false; 
                isClickedValid = false;
            }
        }
        if (IsFound == true) {
            alert("Special Characters " + iChars + " are not allowed in List Item field.");
            return false;
        }
    }
    if (document.getElementById(txtWrapNoteClientId).value != "") {
        //var iChars = "_!@#$%^&*()+=[]\\\';,./{}|\":<>?~`-£ "; 
        var iChars = "',\""; //Removed characters "/()&£ -_!@#$%^*+=[]\\\.{}|:<>?~`"
        var textWrap = document.getElementById(txtWrapNoteClientId).value;
        var IsWrapFound = false;
        for (var i = 0; i < textWrap.length; i++) {

            //alert("char At : " + textWrap.charCodeAt(i));

            if ((iChars.indexOf(textWrap.charAt(i)) != -1)) { //|| (textWrap.charCodeAt(i) == 13)
                IsWrapFound = true; //alert ("The form name has some special characters.");
                //document.getElementById(txtWrapNoteClientId).focus();
                //return false; 
                isClickedValid = false;
            }
        }

        if (IsWrapFound == true) {
            alert("Special Characters " + iChars + " or Enter are not allowed in Smart Note field.");
            return false;
        }
    }

    if (document.getElementById(txtOptionTooltipClientId).value != "") {
        var iChars = "',\"";
        var textOption = document.getElementById(txtOptionTooltipClientId).value;
        var IsOptionFound = false;
        for (var i = 0; i < textOption.length; i++) {
            if ((iChars.indexOf(textOption.charAt(i)) != -1) || (textOption.charCodeAt(i) == 13)) {
                IsOptionFound = true; 
                isClickedValid = false;
            }
        }

        if (IsOptionFound == true) {
            alert("Special Characters " + iChars + " or Enter are not allowed in Tooltip Message field.");
            return false;
        }
    }

    if (isClickedValid == true) {
        var obj1 = document.getElementById("ctl00_ContentPlaceHolder1_" + btnClicked);
        obj1.click;
        isClickedValid = true;
    }
    return isClickedValid;
}

function ValidateGlobalControlData(button) {
    var IsValid = true;
    var btn = button.toString();

    document.getElementById("ctl00_ContentPlaceHolder1_lblSuccess").innerText = "";
    document.getElementById("ctl00_ContentPlaceHolder1_lblErr").innerText = "";

    if (document.getElementById("ctl00_ContentPlaceHolder1_drpFrom").selectedIndex <= 0) {
        alert("Please select Control ");
        document.getElementById("ctl00_ContentPlaceHolder1_drpFrom").focus();
        IsValid = false;
    }
    else if (document.getElementById("ctl00_ContentPlaceHolder1_drpCostCentre").selectedIndex <= 0) {
        alert("Please select cost centre");
        document.getElementById("ctl00_ContentPlaceHolder1_drpCostCentre").focus();
        IsValid = false;
    }
    else if (document.getElementById("ctl00_ContentPlaceHolder1_lstSkillSet").selectedIndex < 0) {
        alert("Please select Skillset");
        document.getElementById("ctl00_ContentPlaceHolder1_lstSkillSet").focus();
        IsValid = false;
    }
    else if (trim(document.getElementById("ctl00_ContentPlaceHolder1_txtValue").value) == "") {
        alert("Please enter a value in the List Item box.");
        document.getElementById("ctl00_ContentPlaceHolder1_txtValue").focus();
        IsValid = false;
    }
    //    else if ((btn == "ctl00_ContentPlaceHolder1_btnUpdate") && (document.getElementById("ctl00_ContentPlaceHolder1_ddlCtrlParent").selectedIndex <=0))
    //    {
    //        alert("Please select Parent Control");
    //        document.getElementById("ctl00_ContentPlaceHolder1_ddlCtrlParent").focus();
    //        IsValid = false;
    //    }
    //    else if ((btn == "ctl00_ContentPlaceHolder1_btnUpdate") && (document.getElementById("ctl00_ContentPlaceHolder1_hidIsParentAvail").Value = "yes") && (document.getElementById("ctl00_ContentPlaceHolder1_ddlCtrlChild").selectedIndex <=0))
    //    {
    //        alert("Please select Child Control");
    //        document.getElementById("ctl00_ContentPlaceHolder1_ddlCtrlChild").focus();
    //        IsValid = false;
    //    }
    else if (trim(document.getElementById("ctl00_ContentPlaceHolder1_txtValue").value) != "") {
        var iChars = "_!@#$%^&*()+=[]\\\';,./{}|\":<>?~`-£ ";
        var text = document.getElementById("ctl00_ContentPlaceHolder1_txtValue").value;
        var IsFound = false;

        for (var i = 0; i < text.length; i++) {
            if (iChars.indexOf(text.charAt(i)) != -1) {
                IsFound = true; //
                document.getElementById("ctl00_ContentPlaceHolder1_txtValue").focus();
                IsValid = false;
            }
        }

        if (IsFound == true) {
            alert("Special Characters are not allowed.");
            return false;
        }
    }

    if (IsValid == true) {
        var obj1 = document.getElementById(button);
        obj1.click;
        IsValid = true;
    }
    return IsValid;
}

function ValidateGlobalControl(name, ControlType, IsDependency, DepControl) {
    var IsValid = true;
    document.getElementById("ctl00_ContentPlaceHolder1_lblError").innerText = "";
    document.getElementById("ctl00_ContentPlaceHolder1_lblSuccess").innerText = "";

    //var chkIfNoJunk  = CheckFieldJunkChars(name,'50');

    if (trim(document.getElementById(name).value) == "") {
        alert("Please enter a Global Control name.");
        document.getElementById(name).focus();
        IsValid = false;
    }
    else if (document.getElementById(ControlType).selectedIndex <= 0) {
        alert("Please select control type");
        document.getElementById(ControlType).focus();
        IsValid = false;
    }
    else if (document.getElementById(IsDependency).selectedIndex <= 0) {
        alert("Please select dependency");
        document.getElementById(IsDependency).focus();
        IsValid = false;
    }
    else if ((document.getElementById(IsDependency).selectedIndex == 1) && (document.getElementById(DepControl).selectedIndex <= 0)) {
        //alert("Please select dependent control");  //commented and added to show correct alert text
        alert("Please select parent control");
        document.getElementById(DepControl).focus();
        IsValid = false;
    }
    else if (document.getElementById(name).value != "") {
        // alert(trim(document.getElementById(name).value));
        var iChars = "_!@#$%^&*()+=[]\\\';,./{}|\":<>?~`-£ ";
        var text = document.getElementById(name).value;
        var IsFound = false;

        for (var i = 0; i < text.length; i++) {
            if (iChars.indexOf(text.charAt(i)) != -1) {
                IsFound = true; //alert ("The form name has some special characters.");
                document.getElementById(name).focus();
                IsValid = false;
            }
        }

        if (IsFound == true) {
            alert("Special Characters are not allowed.");
            return false;
        }
        return IsValid;
    }

    if (IsValid == true) {
        var obj1 = document.getElementById("ctl00_ContentPlaceHolder1_btnCreate");
        obj1.click;
        IsValid = true;
    }
    return IsValid;
}

function PopulateGlobalData(FromControl, ToControl, ArrName) {

    for (k = document.getElementById("ctl00_ContentPlaceHolder1_" + ToControl).options.length; k >= 0; k--) {
        document.getElementById("ctl00_ContentPlaceHolder1_" + ToControl).options[k] = null;
    }

    var optDefault = document.createElement("option");
    document.getElementById("ctl00_ContentPlaceHolder1_" + ToControl).options.add(optDefault);
    optDefault.text = "-- Select --";
    optDefault.value = 0;

    var selectedValue;
    var selectedData = $get("ctl00_ContentPlaceHolder1_" + FromControl).options[$get("ctl00_ContentPlaceHolder1_" + FromControl).selectedIndex].value.split(",");
    selectedValue = selectedData[0];

    for (arrayCounter = 0; arrayCounter < ArrName.length; arrayCounter++) {
        if (selectedValue == ArrName[arrayCounter][0]) {
            var opt = document.createElement("option");
            $get("ctl00_ContentPlaceHolder1_" + ToControl).options.add(opt);

            textVal = ArrName[arrayCounter][1];
            textDet = ArrName[arrayCounter][2];
            opt.text = textDet;
            opt.value = textVal + "," + textDet;
        }
    }
}

//Clear data from specified control.
function ClearListBox(listBox) {
    for (var l = listBox.options.length - 1; l > -1; l--) {
        listBox.options[l] = null;
    }
}

// Function to check if junk characters have entered.
function JunkCharacters(fieldId, NoOfChars) {
    var val = document.getElementById(fieldId).value;
    val = trim(val);

    var TotLen = val.length;
    //alert(val.length);
    var IsValid = true;
    if (val != "") {
        //tit1 = trim(val);

        if (TotLen < 1) {
            alert('Field Cannot be Blank');
            return false;
        }
        if (NoOfChars > 0) {
            if (TotLen > NoOfChars) {
                alert('Max ' + NoOfChars + ' characters allowed');
                return false;
            }
            //return;
        }

        var iChars = "_!@#$%^&*()+=[]\\\';,./{}|\":<>?~`-£ ";
        var IsFound = false;

        for (var i = 0; i < TotLen; i++) {
            if (iChars.indexOf(val.charAt(i)) != -1) {
                IsFound = true; //alert('Special Characters not Allowed');

                IsValid = false;
                //return false;
            }
        }

        if (IsFound) {
            alert("Special Characters are not allowed");
            //**document.getElementById(fieldId).value = val.substring(0,val.length - 1);
            IsValid = false;
        }

        return IsValid;
    }
    return IsValid;
}

// Function to check if junk characters have entered.
function JunkCharactersDataManagement(fieldId, NoOfChars) {
    var val = document.getElementById(fieldId).value;
    val = trim(val);

    var TotLen = val.length;
    var IsValid = true;
    if (val != "") {
        if (TotLen < 1) {
            alert('Field Cannot be Blank');
            return false;
        }
        if (NoOfChars > 0) {
            if (TotLen > NoOfChars) {
                alert('Max ' + NoOfChars + ' characters allowed');
                return false;
            }
        }

        var iChars = "'\"\\"; //Removed characters "/()&£ -_!@#$%^*+=[]\\\.{}|:<>?~`;"
        var IsFound = false;

        for (var i = 0; i < TotLen; i++) {
            if (iChars.indexOf(val.charAt(i)) != -1) {
                IsFound = true; //alert('Special Characters not Allowed');

                IsValid = false;
            }
        }

        if (IsFound) {
            alert("Special Characters " + iChars + " are not allowed");
            IsValid = false;
        }
        return IsValid;
    }
    return IsValid;
}

function CheckFieldJunkChars(fieldId, NoOfChars) {
    if (event.keyCode == 13) {
        return false;
    }
    else {
        var val = document.getElementById(fieldId).value;
        val = trim(val);
        JunkCharacters(fieldId, NoOfChars);
        //        if (val =="")
        //        {
        //            alert("Enter value");
        //            return false;
        //        }
        //        else
        //        {
        //            JunkCharacters(val,NoOfChars);
        //        }
    }
    return;
}

function CheckFieldJunkCharsDataManagement(fieldId, NoOfChars) {
    if (event.keyCode == 13) {
        return false;
    }
    else {
        var val = document.getElementById(fieldId).value;
        val = trim(val);
        JunkCharactersDataManagement(fieldId, NoOfChars);
    }
    return;
}

function ValidateRights() {
    if ($('#drpFilterCostCtr').selectedIndex <= 0) {
        alert("Please select cost centre");
        $('#drpFilterCostCtr').focus();
        return false;
    }
    else if ($('#drpDept').selectedIndex <= 0) {
        alert("Please select department");
        $('#drpDept').focus();
        return false;
    }

    var isselected = false;
    var x = document.getElementById("ctl00_ContentPlaceHolder1_drpSearchedUsers");
    for (var i = 0; i < x.options.length; i++) {
        if (x.options[i].selected == true) {
            isselected = true;
        }
    }
    if (isselected == false) {
        alert("Please select User(s)");
        $('#drpSearchedUsers').focus();
        return false;
    }
    return;
}

function LTrim(value) {
    var re = /\s*((\S+\s*)*)/;
    return value.replace(re, "$1");
}

// Removes ending whitespaces
function RTrim(value) {
    var re = /((\s*\S+)*)\s*/;
    return value.replace(re, "$1");
}

// Removes leading and ending whitespaces
function trim(value) {
    return LTrim(RTrim(value));
}

function CheckEnterPressed() {
    if (e.keyCode == 13) {
        return false;
    }
    return;
}

//Used to validate the number of characters being entered in a textbox. This is also used to check characters being copy pasted.

//oCtlToVal : is object of the TextBox to be validated.

//ctrlName  : name of the object to be dispalyed in error message.

//maxCharLen: valid number of characters that can be entered.

//isOnPaste : pass true if object needs to be validated onPaste event, else pass false if just control length to be validated.

function CheckValidLength(oCtlToVal, maxCharLen, isOnPast) {
    var clipLen = 0, currentFieldLength = 0, resultantLength = 0;
    var clipboardText = window.clipboardData.getData("Text");
    if (isOnPast)//if the data is being pasted then get its length.
    {
        clipLen = clipboardText.length;
    }
    // Get the current and maximum field length
    currentFieldLength = parseInt(oCtlToVal.value.length, 10);
    resultantLength = currentFieldLength + clipLen;

    //If any numeric, alphabet or symbol is entered then keyCode is never zero.
    if (event.keyCode != 0) {
        //OnKeyPress event the last character entered is not been considered so add 1 to the lenght so that it gets considered.
        resultantLength += 1;
    }
    maxCharLen = parseInt(maxCharLen, 10);

    if (resultantLength > maxCharLen) {
        alert("You can enter maximum " + maxCharLen + " characters.");
        oCtlToVal.focus();
        return false;
    }
    return true;
}