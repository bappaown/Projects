// JScript File Added By Santosh

////User for whitespaces 
function LTrim(value) {

    var re = /\s*((\S+\s*)*)/;
    return value.replace(re, "$1");

}
//// Removes ending whitespaces
function RTrim(value) {

    var re = /((\s*\S+)*)\s*/;
    return value.replace(re, "$1");

}

//// Removes leading and ending whitespaces
function trim(value) {
    return LTrim(RTrim(value));

}
//This function is check the length of  text box key press time.
//Created by Santosh
function MaxLengthTilte(txt, maxLen) {
    if (txt.value.length > (maxLen)) {
        txt.value = txt.value.substring(0, maxLen);
        alert("Max " + maxLen + " char allowed");
        return false;
    }
}
//This function is check the length of  text box key press time.
//Created by Kushal
function SetMaxLength(txt, maxLen, e) {
    if (e.keyCode != '8' && e.keyCode != '46' && e.keyCode != '36' && e.keyCode != '35' && e.keyCode != '39' && e.keyCode != '37') {
        if (txt.outerHTML.indexOf('height=20') > -1) {
            var max = document.getElementById("ctl00_ContentPlaceHolder1_maxLengthTextBox").value;
            var iChars = "!@#$%^*()+=-[]\\\';{}|\:<>~_\" qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM";
            for (var i = 0; i < max.length; i++) {
                if (iChars.indexOf(max.charAt(i)) != -1) {
                    alert("The maxlength has some special characters.");
                    document.getElementById("ctl00_ContentPlaceHolder1_maxLengthTextBox").value = 20;
                    return false;
                }
            }

            if (txt.value.length == 0) {
                alert("Please enter the maxlength");
                document.getElementById("ctl00_ContentPlaceHolder1_maxLengthTextBox").value = 20;
                $('#maxLengthTextBox').select();
                return false;
            }
            else if (parseInt(txt.value) > 2000) {
                alert("Max 2000 is allowed in multiline.");
                document.getElementById("ctl00_ContentPlaceHolder1_maxLengthTextBox").value = 20;
                $('#maxLengthTextBox').select();
                return false;
            }
        }
        else {
            if (txt.value.length > (maxLen)) {
                //txt.value = txt.value.substring(0,maxLen);
                alert("Max " + maxLen + " char allowed");
                document.getElementById("ctl00_ContentPlaceHolder1_maxLengthTextBox").value = 20;
                $('#maxLengthTextBox').select();
                return false;
            }
            if (txt.value.length == 0) {
                alert("Please enter the maxlength");
                document.getElementById("ctl00_ContentPlaceHolder1_maxLengthTextBox").value = 20;
                $('#maxLengthTextBox').select();
                return false;
            }
            else {
                var max = document.getElementById("ctl00_ContentPlaceHolder1_maxLengthTextBox").value;
                var iChars = "!@#$%^*()+=-[]\\\';{}|\:<>~_\" qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM";
                for (var i = 0; i < max.length; i++) {
                    if (iChars.indexOf(max.charAt(i)) != -1) {
                        alert("The maxlength has some special characters.");
                        document.getElementById("ctl00_ContentPlaceHolder1_maxLengthTextBox").value = 20;
                        return false;
                    }
                }
            }
        }
    }
    else {

        return false;
    }
}

function SetCheckWrap(txt, maxLen, type)//New Parameter 'type' has been added to display whether it is Pre wrap or Post Wrap. Imran
{
    if (txt.value.length > (maxLen)) {
        //txt.value = txt.value.substring(0,maxLen);
        alert("Max " + maxLen + " char allowed.");

        return false;
    }
    if (txt.value.length == 0) {
        alert("Please enter " + type);// 'type' parameter used. Imran

        return false;
    }
    else {
        var max = LTrim(RTrim(txt.value));// Removes leading and ending whitespaces. Imran
        var iChars = "<>&";//Removed blank space " ". Imran !@#$%^*()+=-[]\';{}|,\:~_?.\/`\"\\
        for (var i = 0; i < max.length; i++) {
            if (iChars.indexOf(max.charAt(i)) != -1) {
                alert("The wrap text has some special characters.");

                return false;
            }
        }
    }
}
//This function is check the length of  text box paste time.
//Created by Santosh
function ValidatePasteValue(txt, maxLen) {

    var content = clipboardData.getData("Text");
    if (content.length > (maxLen)) {
        txt.value = txt.value.substring(0, maxLen);
        alert("Max " + maxLen + " char allowed");
        return false;
    }
}

//This function is check the length of  text box paste time.
//Created by Kushal
function ValidatePasteMaxlength(txt, maxLen) {

    var content = clipboardData.getData("Text");
    if (content.length > (maxLen - 1)) {
        txt.value = txt.value.substring(0, maxLen);
        alert("Max " + maxLen + " char allowed");
        return false;
    }
}
//  <%--/*
//        Function Name               : ValidatePasteNumeric()
//        Parameter(s)                : Allows numeric paste only.
//        Created By / On DateTime    : santosh / 12 Dec 2008
//        Modified By / On DateTime   : 
//        Description                 : This function allows only numeric values in the CONTROL.
//    */--%>
function ValidatePasteNumeric() {
    var content = clipboardData.getData("Text");
    if (IsNumeric(content)) {
        window.event.returnValue = true;
    }
    else {
        window.event.returnValue = false;
        alert("You can paste only numbers here");
    }
}
//  <%--/*
//        Function Name               : submitValidate()
//        Parameter(s)                : 
//        Created By / On DateTime    : santosh / 12 Dec 2008
//        Modified By / On DateTime   : 
//        Description                 : This function allows validate the controls submit time.
//    */--%>       
function SubmitValidation() {
    document.getElementById("ctl00_ContentPlaceHolder1_MessageLabel").innerText = "";
    document.getElementById("ctl00_ContentPlaceHolder1_ErrorMessageLabel").innerText = "";

    var configTitle = document.getElementById("ctl00_ContentPlaceHolder1_TitleTextBox").value;
    configTitle = trim(configTitle)
    if (configTitle == "") {
        alert("Please enter the Config Title");
        document.getElementById("ctl00_ContentPlaceHolder1_TitleTextBox").focus();
        return false;
    }
    else {
        if (!configTitle.match(/^[a-zA-Z0-9 ]+$/)) {
            alert("Special Characters are not allowed.");
            document.getElementById("ctl00_ContentPlaceHolder1_TitleTextBox").select();
            return false;
        }

    }

    var valueTextBox = document.getElementById("ctl00_ContentPlaceHolder1_ValueTextBox").value;
    valueTextBox = trim(valueTextBox)
    if (valueTextBox == "") {
        alert("Please enter the Config value");
        document.getElementById("ctl00_ContentPlaceHolder1_ValueTextBox").focus();
        return false;
    }
    else {
        var ValidChars = "0123456789";
        var IsNumber = true;
        var Char;
        for (i = 0; i < valueTextBox.length && IsNumber == true; i++) {
            Char = valueTextBox.charAt(i);
            if (ValidChars.indexOf(Char) == -1) {
                alert("You can enter only numbers here");
                document.getElementById("ctl00_ContentPlaceHolder1_ValueTextBox").select();
                IsNumber = false;
                return false;
            }
        }
    }
    if (parseInt(valueTextBox, 10) == 0) {
        alert("you can not entered zero value.");
        document.getElementById("ctl00_ContentPlaceHolder1_ValueTextBox").focus();
        return false;
    }

}


//  <%--/*
//        Function Name               : ValidateOnSave()
//        Parameter(s)                : 
//        Created By / On DateTime    : santosh / 22 Jan 2009
//        Modified By / On DateTime   : 
//        Description                 : This function allows validate the controls submit time.
//    */--%>    
function ValidateOnSave() {
    var formName = document.getElementById("ctl00_ContentPlaceHolder1_NameTextBox").value;
    formName = trim(formName)
    if (formName == "") {
        alert("Please enter Form Name.");
        document.getElementById("ctl00_ContentPlaceHolder1_NameTextBox").focus();
        return false;
    }
    else {

        if (!formName.match(/^[a-zA-Z0-9 ]+$/)) {
            alert("Special Characters are not allowed.");
            document.getElementById("ctl00_ContentPlaceHolder1_NameTextBox").select();
            return false;
        }
    }
    var formDesc = document.getElementById("ctl00_ContentPlaceHolder1_DescriptionTextBox").value;
    formDesc = trim(formDesc)
    if (formDesc == "") {
        alert("Please enter the form description");
        document.getElementById("ctl00_ContentPlaceHolder1_DescriptionTextBox").focus();
        return false;
    }
    else {
        //Special characters in description field : Bappa
        var pattern = /^[a-zA-Z_0-9\&<>\ ]+$/;
        if (!pattern.test(document.getElementById("ctl00_ContentPlaceHolder1_DescriptionTextBox").value)) {
            alert("Special Characters are not allowed.");
            document.getElementById("ctl00_ContentPlaceHolder1_DescriptionTextBox").select();
            return false;
        }
        //End

        //var iChars = "&'<>";
        //for (var i = 0; i < document.getElementById("ctl00_ContentPlaceHolder1_DescriptionTextBox").value.length; i++) {
        //if (iChars.indexOf(document.getElementById("ctl00_ContentPlaceHolder1_DescriptionTextBox").value.charAt(i)) != -1) {
        //    alert("Special Characters are not allowed.");
        //    document.getElementById("ctl00_ContentPlaceHolder1_DescriptionTextBox").select();
        //    return false;
        //}
        //}             

    }
    var skillSetListBox = document.getElementById("ctl00_ContentPlaceHolder1_lstselectedskillset");
    if (skillSetListBox.length == 0) {
        alert("Please select Skill Set. You can select multiple Skill Sets.");
        return false;

    }
    var skillSetListBox = document.getElementById("ctl00_ContentPlaceHolder1_CategoryDropDown").selectedIndex;
    if (skillSetListBox == 0) {
        alert("Please select category.");
        return false;
    }

    if (document.getElementById("ctl00_ContentPlaceHolder1_txtmail").value != '') {
        var emailcntl = document.getElementById("ctl00_ContentPlaceHolder1_txtmail");

        var value = emailcntl.value;
        if (value != '') {
            var result = value.split(",");
        }
        var valleng = value.length;
        if (valleng <= 500) {
            if (result.length > 5) {
                alert('Only 5 emails are allowed.');
                return false;
            }
        }
    }
}




//  <%--/*
//        Function Name               : ValidateOnSearch()
//        Parameter(s)                : 
//        Created By / On DateTime    : Kushal / 27 Feb 2009
//        Modified By / On DateTime   : 
//        Description                 : This function allows validate the controls submit time.
//    */--%>    
function ValidateOnSearch() {
    var formName = document.getElementById("ctl00_ContentPlaceHolder1_TitleTextBox").value;
    formName = trim(formName)
    var EmpName = document.getElementById("ctl00_ContentPlaceHolder1_txtemp").value;
    EmpName = trim(EmpName);
    var MyForm = document.getElementById("ctl00_ContentPlaceHolder1_chkmyform").checked;
    var startdate = document.getElementById("ctl00_ContentPlaceHolder1_StDateTextBox").value;
    var enddate = document.getElementById("ctl00_ContentPlaceHolder1_EdDateTextBox").value;
    if (formName == "" && EmpName == "" && MyForm == false && startdate == "" && enddate == "") {
        alert("Please enter any one search criteria");
        document.getElementById("ctl00_ContentPlaceHolder1_TitleTextBox").focus();
        return false;
    }
    else {
        var iChars = "!@#$%^*()+=-[]\\\';{}|\:<>~_?&`,\"./�";
        for (var i = 0; i < formName.length; i++) {
            if (iChars.indexOf(formName.charAt(i)) != -1) {
                alert("The form name has some special characters.");
                document.getElementById("ctl00_ContentPlaceHolder1_TitleTextBox").select();
                return false;
            }
        }
    }
    CheckValidDates();
}

//Date time validation.
function Checkdatevalidation(startDate, endDate, startHour, endHour, startMin, endMin) {
    var startDateTime = "";
    var endDateTime = "";

    var arrMonths = new Array("Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec");

    // --------- find year, month, day, hours, minutes, seconds for start date ---------
    var startMonth = startDate.substring(startDate.indexOf('-') + 1, startDate.indexOf('-') + 4);

    for (var extnCount = 0; extnCount < arrMonths.length; extnCount++) {
        if (arrMonths[extnCount] == startMonth) {
            var startMonth = extnCount;
        }
    }
    startMonth = parseInt(startMonth) + 1;

    var startYear = startDate.substring(startDate.indexOf('-') + 5, startDate.indexOf('-') + 10);
    var startDay = startDate.substring(0, startDate.indexOf('-'));

    //Date(year, month, day, hours, minutes, seconds)
    startDateTime = Date.UTC(startYear, startMonth, startDay, startHour, startMin, 0, 0)


    // --------- find year, month, day, hours, minutes, seconds for end date ---------
    var endMonth = endDate.substring(endDate.indexOf('-') + 1, endDate.indexOf('-') + 4);

    for (var extnCount = 0; extnCount < arrMonths.length; extnCount++) {
        if (arrMonths[extnCount] == endMonth) {
            var endMonth = extnCount;
        }
    }
    endMonth = parseInt(endMonth) + 1;

    var endYear = endDate.substring(endDate.indexOf('-') + 5, endDate.indexOf('-') + 10);
    var endDay = endDate.substring(0, endDate.indexOf('-'));

    //Date(year, month, day, hours, minutes, seconds)
    endDateTime = Date.UTC(endYear, endMonth, endDay, endHour, endMin, 0, 0)

    var tempstartDateTime = new Date(startYear, startMonth - 1, startDay, startHour, startMin)
    var tempendDateTime = new Date(endYear, endMonth - 1, endDay, endHour, endMin)

    if (tempstartDateTime >= tempendDateTime) {
        alert('Start date time cannot be greater than or equal to End date time.');
        return false;
    }

    return true;
}


