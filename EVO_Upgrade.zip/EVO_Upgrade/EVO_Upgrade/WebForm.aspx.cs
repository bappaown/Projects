﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace EVO_Upgrade
{
    public partial class WebForm : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

            //var Shorturl = URLShorten("http://www.paytm.com");
            //string Shorturl = GoogleUrlShortener("http://www.paytm.com");
            string Shorturl = ShortenUrl("http://www.paytm.com");
        }

        public string URLShorten(string longUrl)
        {
            string responseText = "";
            var httpWebRequest = (HttpWebRequest)WebRequest.Create("https://www.googleapis.com/urlshortener/v1/url");
            httpWebRequest.ContentType = "application/json";
            httpWebRequest.Method = "POST";
            httpWebRequest.UseDefaultCredentials = true;
            httpWebRequest.Proxy.Credentials = System.Net.CredentialCache.DefaultCredentials;
            using (var streamWriter = new StreamWriter(httpWebRequest.GetRequestStream()))
            {
                string json = "{\"longUrl\": \"" + longUrl + "\"}";
                Console.WriteLine(json);
                streamWriter.Write(json);
            }

            var httpResponse = (HttpWebResponse)httpWebRequest.GetResponse();
            using (var streamReader = new StreamReader(httpResponse.GetResponseStream()))
            {
                responseText = streamReader.ReadToEnd();
                //Console.WriteLine(responseText);
            }
            return responseText;
        }

        public string GoogleUrlShortener(string longUrl)
        {

            string finalURL = "";
            string key = "AIzaSyB8xJyT9-ROHYzhMYoG2gUfIIMEa01C_WU";
            string post = "{\"longUrl\": \"" + longUrl + "\"}";
            string shortUrl = longUrl;
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create("https://www.googleapis.com/urlshortener/v1/url?key=" + key);
            request.UseDefaultCredentials = true;
            request.Proxy.Credentials = System.Net.CredentialCache.DefaultCredentials;
            try
            {
                request.ServicePoint.Expect100Continue = false;
                request.Method = "POST";
                request.ContentLength = post.Length;
                request.ContentType = "application/json";
                request.Headers.Add("Cache-Control", "no-cache");
                using (Stream requestStream = request.GetRequestStream())
                {
                    byte[] postBuffer = Encoding.ASCII.GetBytes(post);
                    requestStream.Write(postBuffer, 0, postBuffer.Length);
                }
                using (HttpWebResponse response = (HttpWebResponse)request.GetResponse())
                {
                    using (Stream responseStream = response.GetResponseStream())
                    {
                        using (StreamReader responseReader = new StreamReader(responseStream))
                        {
                            string json = responseReader.ReadToEnd();

                            JObject jsonResult = JObject.Parse(json);
                            finalURL = jsonResult["id"].ToString();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                System.Console.WriteLine(" Success -- > " + ex.StackTrace);
                System.Diagnostics.Debug.WriteLine(ex.Message);
                System.Diagnostics.Debug.WriteLine(ex.StackTrace);
                ErrorLogger.logger.Error("UserForms - URL: " + ex.Message);
            }
            return finalURL;
        }

        public string ShortenUrl(string longURL)
        {
            string output;

            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(
                string.Format(@"http://api.bit.ly/v3/shorten?login={0}&apiKey={1}&longUrl={2}&format={3}&domain={4}",
                "bappaown", "R_2c2640039b154aedadc28a5fa2ddc8e5", HttpUtility.UrlEncode(longURL), "xml", "bit.ly"));

            using (WebResponse response = request.GetResponse())
            {
                using (StreamReader reader = new StreamReader(response.GetResponseStream()))
                {
                    output = reader.ReadToEnd();
                }
            }

            return output;
        }
    }
}