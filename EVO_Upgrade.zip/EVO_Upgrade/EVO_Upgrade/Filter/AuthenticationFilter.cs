﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Mvc.Filters;
using EVOLib;

namespace EVO_Upgrade.Filter
{
    public class AuthenticationFilter : ActionFilterAttribute, IAuthenticationFilter
    {
        public void OnAuthentication(AuthenticationContext filterContext)
        {
            EvoGeneral objEvoGeneral = new EvoGeneral();
            EvoMain objEvoMain = new EvoMain();

            if (objEvoGeneral.userName != "")
            {
                string NTName = objEvoGeneral.userName;
                objEvoMain.UserID = objEvoGeneral.RetrieveUserID(NTName);
                bool isValid = objEvoMain.GetAllAdmin(objEvoMain.UserID);
                //bool isValid = objEvoMain.GetSuperAdmin(objEvoMain.UserID);
                if (isValid == false)
                {
                    filterContext.Result = new HttpUnauthorizedResult();
                }
            }
            else
            {
                filterContext.Result = new HttpNotFoundResult();
            }
        }

        public void OnAuthenticationChallenge(AuthenticationChallengeContext filterContext)
        {
            if (filterContext.Result == null || filterContext.Result is HttpUnauthorizedResult)
            {
                filterContext.Result = new RedirectResult("../Home/Unauthorized");
            }
            if (filterContext.Result == null || filterContext.Result is HttpNotFoundResult)
            {
                filterContext.Result = new RedirectResult("../Home/Login");
            }
        }
    }
}