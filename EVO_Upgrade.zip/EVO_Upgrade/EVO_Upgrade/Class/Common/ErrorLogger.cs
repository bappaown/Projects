﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using NLog;

/// <summary>
/// Summary description for error log
/// </summary>
public static class ErrorLogger
{
    public static Logger logger = LogManager.GetCurrentClassLogger();

}