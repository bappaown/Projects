﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Data.SqlClient;
using DAL;

/// <summary>
/// Summary description for ControlTypes
/// </summary>
namespace EVOLib
{
    public class ControlTypes
    {
        public ControlTypes()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public DataSet GetBasicDataManagableControlTypes()
        {
            //DataSet dsControlTypes;
            //string commandText = "Select * from Evo_ControlMain where ControlType='Basic' and IsManageable = 1";
            //dsControlTypes = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //return dsControlTypes;

            DataSet dsControlTypes;
            try
            {
                string spName = "EVO_GetBasicDataManagableControlTypes";
                dsControlTypes = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

                if (dsControlTypes != null && dsControlTypes.Tables.Count > 0)
                {
                    return dsControlTypes;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetBasicDataManagableControlTypes" + ex.Message);
            }
        }
    }
}