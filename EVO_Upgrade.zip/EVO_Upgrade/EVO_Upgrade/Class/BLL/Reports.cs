﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DAL;
/// <summary>
/// Summary description for Reports
/// </summary>
namespace EVOLib
{
    public class Reports
    {
        public Reports()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Declare Properties

        private Int64 userID;
        private string module;
        private Int32 formID;
        private string stDate;
        private string endDate;
        private Int32 versionID;
        private string columnName;
        private string teamName;
        private string colHeaders;
        private bool isGMT;
        private string empName;
        private string columnvalue;

        public Int64 UserID
        {
            get
            {
                return userID;
            }
            set
            {
                userID = value;
            }
        }
        public string Module
        {
            get
            {
                return module;
            }
            set
            {
                module = value;
            }
        }
        public Int32 FormID
        {
            get
            {
                return formID;
            }
            set
            {
                formID = value;
            }
        }
        public string StDate
        {
            get
            {
                return stDate;
            }
            set
            {
                stDate = value;
            }
        }
        public string EndDate
        {
            get
            {
                return endDate;
            }
            set
            {
                endDate = value;
            }
        }
        public Int32 VersionID
        {
            get
            {
                return versionID;
            }
            set
            {
                versionID = value;
            }
        }
        public string ColumnName
        {
            get
            {
                return columnName;
            }
            set
            {
                columnName = value;
            }
        }
        public string TeamName
        {
            get
            {
                return teamName;
            }
            set
            {
                teamName = value;
            }
        }
        public string ColHeaders
        {
            get
            {
                return colHeaders;
            }
            set
            {
                colHeaders = value;
            }
        }

        public bool IsGMT
        {
            get
            {
                return isGMT;
            }
            set
            {
                isGMT = value;
            }
        }

        public string EmpName
        {
            get
            {
                return empName;
            }
            set
            {
                empName = value;
            }
        }


        public string ColumnValue
        {
            get
            {
                return columnvalue;
            }
            set
            {
                columnvalue = value;
            }
        }
        #endregion

        #region Declare Handlers

        /// <summary>
        /// Get form details as per LoggedIn User rights
        /// </summary>
        /// <param name="objDataSet"></param>
        /// <returns></returns>
        public DataSet GetFormsForReports(DataSet objDataSet, string IsDTMS)
        {
            string procName = "[EVO_Select_FormsForReports]";
            try
            {
                SqlParameter[] parameters = new SqlParameter[7];
                parameters[0] = new SqlParameter("@UserID", SqlDbType.Int);
                parameters[0].Value = this.UserID;
                parameters[1] = new SqlParameter("@Module", SqlDbType.VarChar);
                parameters[1].Value = this.Module;
                parameters[2] = new SqlParameter("@FormID", SqlDbType.Int);
                parameters[2].Value = this.FormID;
                parameters[3] = new SqlParameter("@StartDate", SqlDbType.VarChar);
                parameters[3].Value = this.StDate;
                parameters[4] = new SqlParameter("@EndDate", SqlDbType.VarChar);
                parameters[4].Value = this.EndDate;
                parameters[5] = new SqlParameter("@EmpName", SqlDbType.VarChar);
                parameters[5].Value = this.EmpName;
                parameters[6] = new SqlParameter("@IsDTMS", SqlDbType.Int);
                parameters[6].Value = IsDTMS;
                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters);

                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        //-------START Added by Sagar CR Client Requirement For Wrap Note Hits   
        /// <summary>
        /// Get form details as per LoggedIn User rights
        /// </summary>
        /// <param name="objDataSet"></param>
        /// <returns></returns>
        public DataSet GetWrapNoteUserHitsReport(DataSet objDataSet)
        {
            string procName = "[EVO_Select_WrapNoteUserHits]";
            try
            {
                SqlParameter[] parameters = new SqlParameter[6];
                parameters[0] = new SqlParameter("@UserID", SqlDbType.Int);
                parameters[0].Value = this.UserID;
                parameters[1] = new SqlParameter("@Module", SqlDbType.VarChar);
                parameters[1].Value = this.Module;
                parameters[2] = new SqlParameter("@FormID", SqlDbType.Int);
                parameters[2].Value = this.FormID;
                parameters[3] = new SqlParameter("@VersionID", SqlDbType.Int);
                parameters[3].Value = this.VersionID;
                parameters[4] = new SqlParameter("@StartDate", SqlDbType.VarChar);
                parameters[4].Value = this.StDate;
                parameters[5] = new SqlParameter("@EndDate", SqlDbType.VarChar);
                parameters[5].Value = this.EndDate;

                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters);

                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        //-------END Added by Sagar CR Client Requirement For Wrap Note Hits




        /// <summary>
        /// Get transposed report for the selected form and version
        /// </summary>
        /// <param name="objDataSet"></param>
        /// <returns></returns>
        public DataSet GetDataDumpReport(DataSet objDataSet, string username)
        {
            string procName = "[EVO_Select_DataDumpReport]";
            try
            {
                SqlParameter[] parameters = new SqlParameter[6];
                parameters[0] = new SqlParameter("@FormID", SqlDbType.Int);
                parameters[0].Value = this.FormID;
                parameters[1] = new SqlParameter("@VersionID", SqlDbType.Int);
                parameters[1].Value = this.VersionID;
                parameters[2] = new SqlParameter("@StartDate", SqlDbType.VarChar);
                parameters[2].Value = this.StDate;
                parameters[3] = new SqlParameter("@EndDate", SqlDbType.VarChar);
                parameters[3].Value = this.EndDate;
                parameters[4] = new SqlParameter("@IsGMT", SqlDbType.Bit);
                parameters[4].Value = this.IsGMT;
                parameters[5] = new SqlParameter("@UserName", SqlDbType.VarChar);
                parameters[5].Value = username;

                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters);

                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get Combination of Realtime and Archived Data as a report for the selected form and version.
        /// </summary>
        /// <param name="objDataSet"></param>
        /// <returns></returns>
        public DataSet GetArchivedReport(DataSet objDataSet, string UserName)
        {
            string procName = "[EVO_Select_ArchivedReport_v1]";
            try
            {
                SqlParameter[] parameters = new SqlParameter[6];
                parameters[0] = new SqlParameter("@FormID", SqlDbType.Int);
                parameters[0].Value = this.FormID;
                parameters[1] = new SqlParameter("@VersionID", SqlDbType.Int);
                parameters[1].Value = this.VersionID;
                parameters[2] = new SqlParameter("@StartDate", SqlDbType.VarChar);
                parameters[2].Value = this.StDate;
                parameters[3] = new SqlParameter("@EndDate", SqlDbType.VarChar);
                parameters[3].Value = this.EndDate;
                parameters[4] = new SqlParameter("@IsGMT", SqlDbType.Bit);
                parameters[4].Value = this.IsGMT;
                parameters[5] = new SqlParameter("@UserName", SqlDbType.VarChar);
                parameters[5].Value = UserName;

                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters);

                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get transposed report for the selected form and version with selected fields.
        /// </summary>
        /// <param name="objDataSet"></param>
        /// <returns></returns>
        public DataSet GetCustomRealtimeReport(DataSet objDataSet, string UserName)
        {
            string procName = "[EVO_Select_CustomRealtimeReport]";
            try
            {
                SqlParameter[] parameters = new SqlParameter[9];
                parameters[0] = new SqlParameter("@FormID", SqlDbType.Int);
                parameters[0].Value = this.FormID;
                parameters[1] = new SqlParameter("@VersionID", SqlDbType.Int);
                parameters[1].Value = this.VersionID;
                parameters[2] = new SqlParameter("@ColumnName", SqlDbType.VarChar);
                parameters[2].Value = this.ColumnName;
                parameters[3] = new SqlParameter("@ColHead", SqlDbType.VarChar);
                parameters[3].Value = this.ColHeaders;
                parameters[4] = new SqlParameter("@TeamName", SqlDbType.VarChar);
                parameters[4].Value = this.TeamName;
                parameters[5] = new SqlParameter("@StartDate", SqlDbType.VarChar);
                parameters[5].Value = this.StDate;
                parameters[6] = new SqlParameter("@EndDate", SqlDbType.VarChar);
                parameters[6].Value = this.EndDate;
                parameters[7] = new SqlParameter("@IsGMT", SqlDbType.Bit);
                parameters[7].Value = this.IsGMT;
                parameters[8] = new SqlParameter("@UserName", SqlDbType.VarChar);
                parameters[8].Value = UserName;

                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters);

                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get Dashboard Report.
        /// </summary>
        /// <param name="objDataSet"></param>
        /// <returns></returns>
        public DataSet GetDashBoardReport(DataSet objDataSet)
        {
            string spName = "[EVO_DashBoard]";
            try
            {
                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName);
                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Set Form Status to active or deactive.
        /// </summary>
        public void UpdateFormStatus(int Formid, string UserName)
        {
            string procName = "[EVO_Update_FormStatus]";
            try
            {
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@FormId", SqlDbType.Int);
                parameters[0].Value = Formid;
                parameters[1] = new SqlParameter("@UserName", SqlDbType.VarChar, 100);
                parameters[1].Value = UserName;

                SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters);


            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Get transposed report for the selected form and version with selected fields.
        /// </summary>
        /// <param name="objDataSet"></param>
        /// <returns></returns>
        public DataSet GetViewLogReport(DataSet objDataSet, string UserName)
        {
            string procName = "[EVO_Select_ViewLogReport]";
            try
            {
                SqlParameter[] parameters = new SqlParameter[7];
                parameters[0] = new SqlParameter("@FormID", SqlDbType.Int);
                parameters[0].Value = this.FormID;
                parameters[1] = new SqlParameter("@VersionID", SqlDbType.Int);
                parameters[1].Value = this.VersionID;
                parameters[2] = new SqlParameter("@ColumnName", SqlDbType.VarChar);
                parameters[2].Value = this.ColumnName;
                parameters[3] = new SqlParameter("@ColumnValue", SqlDbType.VarChar);
                parameters[3].Value = this.ColumnValue;
                parameters[4] = new SqlParameter("@StartDate", SqlDbType.VarChar);
                parameters[4].Value = this.StDate;
                parameters[5] = new SqlParameter("@EndDate", SqlDbType.VarChar);
                parameters[5].Value = this.EndDate;
                parameters[6] = new SqlParameter("@UserName", SqlDbType.VarChar);
                parameters[6].Value = UserName;


                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters);

                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion
    }

}