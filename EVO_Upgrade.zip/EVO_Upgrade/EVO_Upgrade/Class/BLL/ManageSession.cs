﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Collections;
using System.Collections.Generic;

/// <summary>
/// Summary description for ManageSession
/// Created By: Imran
/// Created Date: 27-JAN-2009
/// </summary>

namespace EVOLib
{
    public sealed class ManageSession
    {
        private static int formID;
        private static int versionID;
        private static string xmlFileName;
        private static int categoryID;
        private static string formName;
        private static string formMode;
        private static string categoryName;


        private static int transactionID;
        private static int prevFormID;
        private static int prevVersionID;
        private static string prevXmlFileName;
        private static int prevCategoryID;
        private static string prevFormName;
        private static string controlname;
        private static string controltype;
        private static string iseditable;
        private static string isscrabblepad;

        public static int FormID
        {
            get
            {
                formID = Convert.ToInt32(HttpContext.Current.Session["formID"]);
                HttpContext.Current.Session["formID"] = null;
                return formID;
            }
            set
            {
                HttpContext.Current.Session["formID"] = value;
            }
        }
        public static int VersionID
        {
            get
            {
                versionID = Convert.ToInt32(HttpContext.Current.Session["versionID"]);
                HttpContext.Current.Session["versionID"] = null;
                return versionID;
            }
            set
            {
                HttpContext.Current.Session["versionID"] = value;
            }
        }
        public static string XmlFileName
        {
            get
            {
                xmlFileName = Convert.ToString(HttpContext.Current.Session["xmlFileName"]);
                HttpContext.Current.Session["xmlFileName"] = null;
                return xmlFileName;
            }
            set
            {
                HttpContext.Current.Session["xmlFileName"] = value;
            }
        }

        public static int CategoryID
        {
            get
            {
                categoryID = Convert.ToInt32(HttpContext.Current.Session["categoryID"]);
                HttpContext.Current.Session["categoryID"] = null;
                return categoryID;
            }
            set
            {
                HttpContext.Current.Session["categoryID"] = value;
            }
        }
        public static string FormName
        {
            get
            {
                formName = Convert.ToString(HttpContext.Current.Session["formName"]);
                HttpContext.Current.Session["formName"] = null;
                return formName;
            }
            set
            {
                HttpContext.Current.Session["formName"] = value;
            }
        }
        public static string FormMode
        {
            get
            {
                formMode = Convert.ToString(HttpContext.Current.Session["formMode"]);
                HttpContext.Current.Session["formMode"] = null;
                return formMode;
            }
            set
            {
                HttpContext.Current.Session["formMode"] = value;
            }
        }
        public static string CategoryName
        {
            get
            {
                categoryName = Convert.ToString(HttpContext.Current.Session["categoryName"]);
                HttpContext.Current.Session["categoryName"] = null;
                return categoryName;
            }
            set
            {
                HttpContext.Current.Session["categoryName"] = value;
            }
        }

        public static int TransactionID
        {
            get
            {
                transactionID = Convert.ToInt32(HttpContext.Current.Session["transactionID"]);
                HttpContext.Current.Session["transactionID"] = null;
                return transactionID;
            }
            set
            {
                HttpContext.Current.Session["transactionID"] = value;
            }
        }


        public static int PreviousFormID
        {
            get
            {
                formID = Convert.ToInt32(HttpContext.Current.Session["prevFormID"]);
                HttpContext.Current.Session["prevFormID"] = null;
                return formID;
            }
            set
            {
                HttpContext.Current.Session["prevFormID"] = value;
            }
        }
        public static int PreviousVersionID
        {
            get
            {
                versionID = Convert.ToInt32(HttpContext.Current.Session["prevVersionID"]);
                HttpContext.Current.Session["prevVersionID"] = null;
                return versionID;
            }
            set
            {
                HttpContext.Current.Session["prevVersionID"] = value;
            }
        }
        public static string PreviousXmlFileName
        {
            get
            {
                xmlFileName = Convert.ToString(HttpContext.Current.Session["prevXmlFileName"]);
                HttpContext.Current.Session["prevXmlFileName"] = null;
                return xmlFileName;
            }
            set
            {
                HttpContext.Current.Session["prevXmlFileName"] = value;
            }
        }

        public static string PreviousCategoryName
        {
            get
            {
                categoryName = Convert.ToString(HttpContext.Current.Session["prevCategoryName"]);
                HttpContext.Current.Session["prevCategoryName"] = null;
                return categoryName;
            }
            set
            {
                HttpContext.Current.Session["prevCategoryName"] = value;
            }
        }

        public static string PreviousFormName
        {
            get
            {
                formName = Convert.ToString(HttpContext.Current.Session["prevFormName"]);
                HttpContext.Current.Session["prevFormName"] = null;
                return formName;
            }
            set
            {
                HttpContext.Current.Session["prevFormName"] = value;
            }
        }

        public static string ControlName
        {
            get
            {
                controlname = Convert.ToString(HttpContext.Current.Session["controlname"]);
                HttpContext.Current.Session["controlname"] = null;
                return controlname;
            }
            set
            {
                HttpContext.Current.Session["controlname"] = value;
            }
        }


        public static string ControlType
        {
            get
            {
                controltype = Convert.ToString(HttpContext.Current.Session["controltype"]);
                HttpContext.Current.Session["controltype"] = null;
                return controltype;
            }
            set
            {
                HttpContext.Current.Session["controltype"] = value;
            }
        }


        public static string IsEditable
        {
            get
            {
                iseditable = Convert.ToString(HttpContext.Current.Session["iseditable"]);
                HttpContext.Current.Session["iseditable"] = null;
                return iseditable;
            }
            set
            {
                HttpContext.Current.Session["iseditable"] = value;
            }
        }

        public static string IsScrabblePad
        {
            get
            {
                isscrabblepad = Convert.ToString(HttpContext.Current.Session["isscrabblepad"]);
                HttpContext.Current.Session["isscrabblepad"] = null;
                return isscrabblepad;
            }
            set
            {
                HttpContext.Current.Session["isscrabblepad"] = value;
            }
        }

        //public static ArrayList frmVariable = new ArrayList();
    }

    public class FormsVariables<T>
    {

        public FormsVariables(string varName, T varValue)
        {
            HttpContext.Current.Session[varName + "_n"] = varName;
            HttpContext.Current.Session[varName + "_v"] = varValue;
        }

        private string variableName;
        private T variableValue;

        public string VariableName
        {
            get
            {
                variableName = Convert.ToString(HttpContext.Current.Session[variableName + "_n"]);
                return variableName;
            }
        }

        public T VariableValue
        {
            get
            {
                variableValue = (T)(HttpContext.Current.Session[variableName + "_v"]);
                HttpContext.Current.Session[variableName + "_v"] = null;
                HttpContext.Current.Session[variableName + "_n"] = null;
                return variableValue;
            }
        }


    }


}