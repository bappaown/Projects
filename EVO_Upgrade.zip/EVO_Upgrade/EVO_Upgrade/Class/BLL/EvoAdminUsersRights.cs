﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DAL;
/// <summary>
/// Summary description for EvoAdminUsersRights
/// Created By : Aarti
/// </summary>
/// 
namespace EVOLib
{
    public class EvoAdminUsersRights
    {
        private int formId;
        private int versionId;
        private Int64 userID;
        private int accessRightId;
        private bool canManage;
        private bool isReportsAccess;
        private bool isLimerickReportsAccess;
        private bool isWaterfordReportsAccess;
        private bool isMumbaiReportsAccess;
        private bool isActive;
        private int costCentreId;
        private int departmentId;
        private string userLogin;
        private string userIds;

        public EvoAdminUsersRights()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Properties

        /// <summary>
        /// This property used to set and get to the FormId.
        /// </summary>
        public int FormId
        {
            get
            {
                return formId;
            }
            set
            {
                formId = value;
            }
        }

        /// <summary>
        ///   This property is used to Get Or Set the version Id of the form  
        /// </summary>
        public int VersionId
        {
            get
            {
                return versionId;
            }
            set
            {
                versionId = value;
            }
        }

        /// <summary>
        /// This property used to set and get to the UserId.
        /// </summary>
        public Int64 UserID
        {
            get
            {
                return userID;
            }
            set
            {
                userID = value;
            }
        }

        /// <summary>
        /// This property is used to get n set CanManage field in DV EVO_AccessRights
        /// </summary>
        public bool CanManage
        {
            get
            {
                return canManage;
            }
            set
            {
                canManage = value;
            }
        }

        /// <summary>
        /// This property is used to get n set isReportsAccess field in DV EVO_AccessRights
        /// </summary>
        public bool IsReportsAccess
        {
            get
            {
                return isReportsAccess;
            }
            set
            {
                isReportsAccess = value;
            }
        }

        /// <summary>
        /// This property is used to get n set isLimerickReportsAccess field in DV EVO_AccessRights
        /// </summary>
        public bool IsLimerickReportsAccess
        {
            get
            {
                return isLimerickReportsAccess;
            }
            set
            {
                isLimerickReportsAccess = value;
            }
        }

        /// <summary>
        /// This property is used to get n set isWaterfordReportsAccess field in DV EVO_AccessRights
        /// </summary>
        public bool IsWaterfordReportsAccess
        {
            get
            {
                return isWaterfordReportsAccess;
            }
            set
            {
                isWaterfordReportsAccess = value;
            }
        }

        /// <summary>
        /// This property is used to get n set isReportsAccess field in DV EVO_AccessRights
        /// </summary>
        public bool IsMumbaiReportsAccess
        {
            get
            {
                return isMumbaiReportsAccess;
            }
            set
            {
                isMumbaiReportsAccess = value;
            }
        }


        /// <summary>
        ///   This property is used to Get Or Set the version Id of the form  
        /// </summary>
        public int AccessRightId
        {
            get
            {
                return accessRightId;
            }
            set
            {
                accessRightId = value;
            }
        }


        /// <summary>
        /// This property is used to get n set Isactive field in DV EVO_AccessRights
        /// </summary>
        public bool IsActive
        {
            get
            {
                return isActive;
            }
            set
            {
                isActive = value;
            }
        }


        /// <summary>
        ///   This property is used to Get Or Set the costCentreId of the form  
        /// </summary>
        public int CostCentreId
        {
            get
            {
                return costCentreId;
            }
            set
            {
                costCentreId = value;
            }
        }


        /// <summary>
        ///   This property is used to Get Or Set the DepartmentId of the form  
        /// </summary>
        public int DepartmentId
        {
            get
            {
                return departmentId;
            }
            set
            {
                departmentId = value;
            }
        }


        /// <summary>
        ///   This property is used to Get Or Set the UserLogin of the form  
        /// </summary>
        public string UserLogin
        {
            get
            {
                return userLogin;
            }
            set
            {
                userLogin = value;
            }
        }

        /// <summary>
        /// This property used to set and get to the UserIds.
        /// </summary>
        public string UserIDs
        {
            get
            {
                return userIds;
            }
            set
            {
                userIds = value;
            }
        }

        #endregion


        #region Methods

        public bool ValidateAdminManageUser()
        {
            bool IsValid = false;
            int retValue = 0;

            string spName = "EVO_Select_AdminValidManageUser";
            SqlParameter[] parameters = new SqlParameter[4];
            parameters[0] = new SqlParameter("@EmpUserId", UserID);
            parameters[1] = new SqlParameter("@FormID", FormId);
            parameters[2] = new SqlParameter("@VersionId", VersionId);
            parameters[3] = new SqlParameter("@RetVal", retValue);
            parameters[3].Direction = ParameterDirection.Output;

            int noOfRowsAffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString().ToString(), CommandType.StoredProcedure, spName, parameters);
            retValue = int.Parse(parameters[3].Value.ToString());

            if (retValue > 0)
            {
                IsValid = true;
            }
            return IsValid;
        }

        /// <summary>
        /// Function is used to retrieve all the active users with their rights for particular FORM and VERSION. from Evo_AccessRights table
        /// </summary>
        /// <returns></returns>
        public DataSet GetUsersRights()
        {
            //DataSet ds;
            //string query = "select a.*, (b.FirstName + ' ' + b.lastName) as UserName from Evo_AccessRights a inner join central_Employee_Main b on a.UserId =  b.empUserId  where a.IsActive = 1 and a.FormId= " + FormId + " order by UserName";
            //ds = DAL.SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, query);
            //return ds;

            DataSet dsRights;
            try
            {
                string spName = "EVO_GetUsersRights";
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@FormId", FormId);
                dsRights = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsRights != null && dsRights.Tables.Count > 0)
                {
                    return dsRights;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetUsersRights" + ex.Message);
            }
        }

        /// <summary>
        /// Function to virtually update the record from the table Evo_AccessRights
        /// </summary>
        /// <returns></returns>
        public bool UpdateUserAccessRights()
        {
            bool result = false;
            int rowsEffected = 0;

            string spName = "EVO_Update_UserAccessRights";
            SqlParameter[] parameters = new SqlParameter[5];
            parameters[0] = new SqlParameter("@AccessRightId", AccessRightId);
            parameters[1] = new SqlParameter("@CanManage", CanManage);
            //parameters[2] = new SqlParameter("@IsReportAccess", IsReportsAccess);
            parameters[2] = new SqlParameter("@IsLimerickReportsAccess", IsLimerickReportsAccess);
            parameters[3] = new SqlParameter("@IsWaterfordReportsAccess", IsWaterfordReportsAccess);
            parameters[4] = new SqlParameter("@IsMumbaiReportsAccess", IsMumbaiReportsAccess);
            rowsEffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
            if (rowsEffected > 0)
            {
                result = true;
            }

            return result;
        }

        /// <summary>
        /// Function to virtually delete the record from the table Evo_AccessRights
        /// </summary>
        /// <returns></returns>
        public bool DeleteUserAccessRights()
        {
            bool result = false;
            int rowsEffected = 0;

            string spName = "EVO_Delete_UserAccessRights";
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@AccessRightId", AccessRightId);
            parameters[1] = new SqlParameter("@IsActive", IsActive);
            rowsEffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
            if (rowsEffected > 0)
            {
                result = true;
            }

            return result;
        }

        /// <summary>
        /// Function to retrieve all the cost centres from Central_CostCentre_Main table
        /// </summary>
        /// <returns></returns>
        public DataSet GetCostCentres()
        {
            //DataSet ds;
            //string query = "select * from Central_CostCentre_Main order by CostCentre";
            //ds = DAL.SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, query);
            //return ds;

            DataSet dsCC;
            try
            {
                string spName = "EVO_GetCostCentres";
                dsCC = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

                if (dsCC != null && dsCC.Tables.Count > 0)
                {
                    return dsCC;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetCostCentres" + ex.Message);
            }
        }

        /// <summary>
        /// Function to retrieve all the Active cost centres departments from Central_CostCentre_Main table
        /// </summary>
        /// <returns></returns>
        public DataSet GetCostCentresDepartments()
        {
            //DataSet ds;
            ////string query = "select * from Central_Department_Main where CostCentreId = " + CostCentreId + " order by DepartmentName";
            //string query = "select * from Central_Department_Main where CostCentreId = " + CostCentreId + " AND status = 1 AND DepartmentName not like '%tesco%' order by DepartmentName";
            //ds = DAL.SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, query);
            //return ds;

            DataSet dsDept;
            try
            {
                string spName = "EVO_GetCostCentresDepartments";
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@CostCentreId", CostCentreId);
                dsDept = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsDept != null && dsDept.Tables.Count > 0)
                {
                    return dsDept;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetCostCentresDepartments" + ex.Message);
            }

        }

        /// <summary>
        /// Function to retrieve all the Users based on selected cost centres and departments from central_employee_Main table
        /// </summary>
        /// <returns></returns>
        public DataSet GetFilteredUserName(string PartialUserName)
        {
            //DataSet ds;
            //string query = "select *, (FirstName + ' ' + LastName + ' [' + convert(Varchar, employeeId) + '] ') as UserName from Central_Employee_Main where CostCentreId = " + CostCentreId + " and DepartmentId= " + DepartmentId + " and FirstName like '%" + PartialUserName + "%' and Status = 1 order by UserName";
            //ds = DAL.SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, query);
            //return ds;

            DataSet dsUser;
            try
            {
                string spName = "EVO_GetFilteredUserName";
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@PartialUserName", PartialUserName);
                parameters[1] = new SqlParameter("@CostCentreId", costCentreId);
                parameters[2] = new SqlParameter("@DepartmentId", departmentId);
                dsUser = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsUser != null && dsUser.Tables.Count > 0)
                {
                    return dsUser;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetFilteredUserName" + ex.Message);
            }

        }

        /// <summary>
        /// Function is used to retrieve active XML filename for particular FORM and VERSION. from Evo_FormVersions table
        /// </summary>
        /// <returns></returns>
        public DataSet GetXMLFileName()
        {
            //DataSet ds;
            //string query = "select XMLFileName from Evo_FormVersions where formId=" + FormId + " and VersionId = " + VersionId;  //and IsActive = 1
            //ds = DAL.SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, query);
            //return ds;

            DataSet dsXML;
            try
            {
                string spName = "EVO_GetXMLFileName";
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@FormId", FormId);
                parameters[1] = new SqlParameter("@VersionId", VersionId);

                dsXML = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsXML != null && dsXML.Tables.Count > 0)
                {
                    return dsXML;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetXMLFileName" + ex.Message);
            }

        }

        public DataSet GetMaxUsersPerForm()
        {
            //DataSet ds;
            //string query = "select * from Evo_AdminConfig where ConfigName='Admin_Users_Per_Form' and IsActive = 1";  //and IsActive = 1
            //ds = DAL.SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, query);
            //return ds;

            DataSet dsMaxUser;
            try
            {
                string spName = "EVO_GetMaxUsersPerForm";

                dsMaxUser = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

                if (dsMaxUser != null && dsMaxUser.Tables.Count > 0)
                {
                    return dsMaxUser;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetMaxUsersPerForm" + ex.Message);
            }

        }

        public int InsertUserAccessRights()
        {
            bool result = false;
            int rowsEffected = 0;
            int retValue = 0;

            string spName = "EVO_Insert_AdminAccessRights";
            SqlParameter[] parameters = new SqlParameter[9];
            parameters[0] = new SqlParameter("@UserID", userIds);
            parameters[1] = new SqlParameter("@FormId", FormId);
            parameters[2] = new SqlParameter("@VersionId", VersionId);
            parameters[3] = new SqlParameter("@CanManage", CanManage);
            //parameters[4] = new SqlParameter("@IsReportsAccess", IsReportsAccess);
            parameters[4] = new SqlParameter("@IsLimerickReportsAccess", IsLimerickReportsAccess);
            parameters[5] = new SqlParameter("@IsWaterfordReportsAccess", IsWaterfordReportsAccess);
            parameters[6] = new SqlParameter("@IsMumbaiReportsAccess", IsMumbaiReportsAccess);
            parameters[7] = new SqlParameter("@AddedBy", UserLogin);
            parameters[8] = new SqlParameter("@RetVal", retValue);
            parameters[8].Direction = ParameterDirection.Output;

            rowsEffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
            retValue = int.Parse(parameters[8].Value.ToString());

            if (rowsEffected > 0)
            {

                result = true;
            }
            return retValue;
        }
        #endregion
    }
}