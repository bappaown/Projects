﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using DAL;
using System.Data.SqlClient;

/// <summary>
/// Summary description for DesignManagement
/// </summary>
public class DesignManagement : System.Web.UI.Page
{
    public DesignManagement()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    /// <summary>
    /// 
    /// </summary>
    /// <returns></returns>
    public static DataSet GetBasicControls()
    {
        //string getBasicControlsQry = "SELECT ControlName AS ControlName FROM EVO_ControlMain WHERE IsActive = 'True' AND ControlType = 'Basic'";
        //DataSet getBasicControlsDataset = new DataSet();
        //try
        //{
        //    getBasicControlsDataset = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, getBasicControlsQry);
        //}
        //catch (Exception ex)
        //{
        //    throw ex;
        //}
        //return getBasicControlsDataset;

        DataSet getBasicControlsDataset = new DataSet();
        try
        {
            string spName = "EVO_GetBasicControls";
            getBasicControlsDataset = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

            if (getBasicControlsDataset != null && getBasicControlsDataset.Tables.Count > 0)
            {
                return getBasicControlsDataset;
            }
            else
                return null;
        }
        catch (Exception ex)
        {
            throw new Exception("GetBasicControls" + ex.Message);
        }
    }



    public static DataSet GetCustomControls()
    {
        //string getCustomControlsQry = "SELECT ControlName AS ControlName FROM EVO_ControlMain WHERE IsActive = 'True' AND ControlType = 'Custom'";
        //DataSet getCustomControlsDataset = new DataSet();
        //try
        //{
        //    getCustomControlsDataset = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, getCustomControlsQry);
        //}
        //catch (Exception ex)
        //{
        //    throw ex;
        //}
        //return getCustomControlsDataset;

        DataSet getCustomControlsDataset = new DataSet();
        try
        {
            string spName = "EVO_GetCustomControls";
            getCustomControlsDataset = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

            if (getCustomControlsDataset != null && getCustomControlsDataset.Tables.Count > 0)
            {
                return getCustomControlsDataset;
            }
            else
                return null;
        }
        catch (Exception ex)
        {
            throw new Exception("GetCustomControls" + ex.Message);
        }
    }



    public static DataSet GetGlobalChildControls()
    {
        //string getGlobalChildControlsQry = "SELECT ControlID AS ControlID, DependentControlID AS DependentControlID, ControlName AS ChildControlName FROM EVO_ControlMain WHERE IsActive = 'True' AND ControlType = 'Global' AND DependentControlID <> 0 ORDER BY ControlID DESC";
        //DataSet getGlobalChildControlsDataset = new DataSet();
        //try
        //{
        //    getGlobalChildControlsDataset = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, getGlobalChildControlsQry);
        //}
        //catch (Exception ex)
        //{
        //    throw ex;
        //}
        //return getGlobalChildControlsDataset;

        DataSet getGlobalChildControlsDataset = new DataSet();
        try
        {
            string spName = "EVO_GetGlobalChildControls";
            getGlobalChildControlsDataset = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

            if (getGlobalChildControlsDataset != null && getGlobalChildControlsDataset.Tables.Count > 0)
            {
                return getGlobalChildControlsDataset;
            }
            else
                return null;
        }
        catch (Exception ex)
        {
            throw new Exception("GetGlobalChildControls" + ex.Message);
        }
    }


    public static DataSet GetGlobalMControls(string dependentIDS)
    {
        //uncommented to remove extra "," coming in string getting formed
        dependentIDS = dependentIDS.Substring(0, dependentIDS.Length - 1);
        //string getGlobalMControlsQry = "SELECT ControlID AS ControlID, ControlName AS ControlName FROM EVO_ControlMain WHERE IsActive = 'True' AND ControlType = 'Global' AND ControlID IN (" + dependentIDS + ") ORDER BY ControlID DESC";
        //DataSet getGlobalMControlsDataset = new DataSet();
        //try
        //{
        //    getGlobalMControlsDataset = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, getGlobalMControlsQry);
        //}
        //catch (Exception ex)
        //{
        //    throw ex;
        //}
        //return getGlobalMControlsDataset;

        DataSet getGlobalMControlsDataset = new DataSet();
        try
        {
            string spName = "EVO_GetGlobalMControls";
            SqlParameter[] parameters = new SqlParameter[1];

            parameters[0] = new SqlParameter("@dependentIDS", dependentIDS);
            getGlobalMControlsDataset = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

            if (getGlobalMControlsDataset != null && getGlobalMControlsDataset.Tables.Count > 0)
            {
                return getGlobalMControlsDataset;
            }
            else
                return null;
        }
        catch (Exception ex)
        {
            throw new Exception("GetGlobalMControls" + ex.Message);
        }


    }

    public static DataSet GetGlobalSControls()
    {
        //SELECT ControlID AS ControlID, ControlName AS ControlName FROM EVO_ControlMain 
        //WHERE IsActive = 'True' AND ControlType = 'Global' AND ControlID NOT IN (11,14) AND DependentControlID = 0;
        // dependentIDS = dependentIDS.Substring(0, dependentIDS.Length - 1);
        string inDepString = "";
        //string getGlobalSControlsQry = "SELECT DependentControlID AS DependentControlID, ControlName AS ChildControlName FROM EVO_ControlMain WHERE IsActive = 'True' AND ControlType = 'Global' AND DependentControlID <> 0";
        string spName = "EVO_GetGlobalSControls";
        DataSet getGlobalSControlsDataset = new DataSet();
        try
        {
            getGlobalSControlsDataset = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

            for (int sCount = 0; sCount < getGlobalSControlsDataset.Tables[0].Rows.Count; sCount++)
            {
                inDepString += getGlobalSControlsDataset.Tables[0].Rows[sCount]["DependentControlID"] + ",";
            }

            if (inDepString != "")
            {
                inDepString = inDepString.Substring(0, inDepString.Length - 1);

                //getGlobalSControlsQry = "SELECT ControlID AS ControlID, ControlName AS ControlName FROM EVO_ControlMain " +
                //                        "WHERE IsActive = 'True' AND ControlType = 'Global' AND ControlID NOT IN (" + inDepString + ") AND DependentControlID = 0";

                string spName1 = "EVO_GetGlobalSControlsWithParam";
                SqlParameter[] parameters = new SqlParameter[1];

                parameters[0] = new SqlParameter("@inDepString", inDepString);

                getGlobalSControlsDataset = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName1, parameters);
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
        return getGlobalSControlsDataset;
    }



    /// <summary>
    /// 
    /// </summary>
    /// <param name="formId"></param>
    /// <param name="versionId"></param>
    /// <returns></returns>
    public static DataSet GetFormXMLPathForModify(int formId, int versionId)
    {
        //string getFormXMLPathQry = "SELECT Evo_FormVersions.XMLFileName AS XMLFile, Evo_FormVersions.VersionName AS VersionName " +
        //                           "FROM Evo_FormVersions INNER JOIN Evo_Main ON Evo_FormVersions.FormID = Evo_Main.FormID " +
        //                           "WHERE (Evo_Main.FormID = " + formId + ") AND Evo_FormVersions.VersionID = " + versionId + "";
        //DataSet getFormXMLPathDataset = new DataSet();
        //try
        //{
        //    getFormXMLPathDataset = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, getFormXMLPathQry);
        //}
        //catch (Exception ex)
        //{
        //    throw ex;
        //}
        //return getFormXMLPathDataset;

        DataSet getFormXMLPathDataset = new DataSet();
        try
        {
            string spName = "EVO_GetFormXMLPathForModify";
            SqlParameter[] parameters = new SqlParameter[2];

            parameters[0] = new SqlParameter("@formId", formId);
            parameters[1] = new SqlParameter("@versionId", versionId);
            getFormXMLPathDataset = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

            if (getFormXMLPathDataset != null && getFormXMLPathDataset.Tables.Count > 0)
            {
                return getFormXMLPathDataset;
            }
            else
                return null;
        }
        catch (Exception ex)
        {
            throw new Exception("GetFormXMLPathForModify" + ex.Message);
        }
    }


    public DataSet GetFormLastVersionName(int formId)
    {
        //string getFormLastVersionNameQry = "SELECT Evo_FormVersions.VersionName AS VersionName " +
        //                                   "FROM Evo_FormVersions " +
        //                                   "WHERE (Evo_FormVersions.FormID = " + formId + ") ORDER BY VersionID DESC";
        //DataSet getFormLastVersionNameDataset = new DataSet();
        //try
        //{
        //    getFormLastVersionNameDataset = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, getFormLastVersionNameQry);
        //}
        //catch (Exception ex)
        //{
        //    throw ex;
        //}
        //return getFormLastVersionNameDataset;

        DataSet getFormLastVersionNameDataset = new DataSet();
        try
        {
            string spName = "EVO_GetFormLastVersionName";
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@formId", formId);
            getFormLastVersionNameDataset = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

            if (getFormLastVersionNameDataset != null && getFormLastVersionNameDataset.Tables.Count > 0)
            {
                return getFormLastVersionNameDataset;
            }
            else
                return null;
        }
        catch (Exception ex)
        {
            throw new Exception("GetFormLastVersionName" + ex.Message);
        }
    }



    /// <summary>
    /// 
    /// </summary>
    /// <param name="formId"></param>
    /// <returns></returns>
    public static DataSet GetFormXMLPath(int formId)
    {
        //string getFormXMLPathQry = "SELECT Evo_FormVersions.XMLFileName AS XMLFile, Evo_FormVersions.VersionName AS VersionName " +
        //                           "FROM Evo_FormVersions INNER JOIN Evo_Main ON Evo_FormVersions.FormID = Evo_Main.FormID " +
        //                           "WHERE (Evo_Main.FormID = " + formId + ")";//AND Evo_FormVersions.IsActive = 'True'
        //DataSet getFormXMLPathDataset = new DataSet();
        //try
        //{
        //    getFormXMLPathDataset = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, getFormXMLPathQry);
        //}
        //catch (Exception ex)
        //{
        //    throw ex;
        //}
        //return getFormXMLPathDataset;

        DataSet getFormXMLPathDataset = new DataSet();
        try
        {
            string spName = "EVO_GetFormXMLPath";
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@formId", formId);
            getFormXMLPathDataset = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

            if (getFormXMLPathDataset != null && getFormXMLPathDataset.Tables.Count > 0)
            {
                return getFormXMLPathDataset;
            }
            else
                return null;
        }
        catch (Exception ex)
        {
            throw new Exception("GetFormXMLPath" + ex.Message);
        }

    }




    /// <summary>
    /// 
    /// </summary>
    /// <param name="formID"></param>
    /// <param name="versionName"></param>
    /// <param name="xmlFileName"></param>
    /// <returns></returns>
    public static int InsertFormVersion(int formID, string versionName, string xmlFileName, string userName)
    {
        int rowsAffected = 0;
        bool result = false;
        int versionID = 0;

        //string registerFormQry = "INSERT INTO EVO_FormVersions (FormID, VersionName, XMLFileName, XMLConfigID, AddedBy) VALUES (" + formID + ", '" + versionName + "', '" + xmlFileName + "', 1, '" + userName + "')SELECT @@IDENTITY";

        //try
        //{
        //    versionID = int.Parse(DAL.SqlHelper.ExecuteScalar(SqlHelper.GetConnectionString(), CommandType.Text, registerFormQry).ToString());

        //    if (rowsAffected > 0)
        //    {
        //        result = true;
        //    }
        //}
        //catch (Exception ex)
        //{
        //    throw ex;
        //}
        //return versionID;

        string spName = "EVO_InsertFormVersion";
        SqlParameter[] parameters = new SqlParameter[5];
        parameters[0] = new SqlParameter("@formId", formID);
        parameters[1] = new SqlParameter("@versionName", versionName);
        parameters[2] = new SqlParameter("@xmlFileName", xmlFileName);
        parameters[3] = new SqlParameter("@userName", userName);
        parameters[4] = new SqlParameter("@versionId", versionID);
        parameters[4].Direction = ParameterDirection.Output;

        rowsAffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
        versionID = int.Parse(parameters[4].Value.ToString());

        if (rowsAffected > 0)
        {

            result = true;
        }
        return versionID;

    }


    public static bool UpdateFormVersion(int formID, string versionName, string xmlFileName, string userName, int versionID)
    {
        int rowsAffected = 0;

        bool result = false;

        //try
        //{
        //    string updateFormVersionQry = "UPDATE EVO_FormVersions SET VersionName='" + versionName + "', XMLFileName = '" + xmlFileName + "', AddedBy = '" + userName + "' WHERE VersionID = " + versionID + "";

        //    rowsAffected = DAL.SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.Text, updateFormVersionQry);

        //    if (rowsAffected > 0)
        //    {
        //        result = true;
        //    }
        //}
        //catch (Exception ex)
        //{
        //    throw ex;
        //}
        //return result;

        try
        {
            string spName = "EVO_UpdateFormVersion";
            SqlParameter[] parameters = new SqlParameter[5];
            parameters[0] = new SqlParameter("@formId", formID);
            parameters[1] = new SqlParameter("@versionName", versionName);
            parameters[2] = new SqlParameter("@xmlFileName", xmlFileName);
            parameters[3] = new SqlParameter("@userName", userName);
            parameters[4] = new SqlParameter("@versionId", versionID);

            rowsAffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

            if (rowsAffected > 0)
            {
                result = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return result;



    }

    public static bool UpdateFormTemplete(int formID, int versionID, int templeteID)
    {
        int rowsAffected = 0;
        bool result = false;
        try
        {
            string spName = "EVO_UpdateFormTemplete";
            SqlParameter[] parameters = new SqlParameter[3];
            parameters[0] = new SqlParameter("@formId", formID);
            parameters[1] = new SqlParameter("@versionId", versionID);
            parameters[2] = new SqlParameter("@templeteID", templeteID);

            rowsAffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

            if (rowsAffected > 0)
            {
                result = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return result;
    }

    public static bool SaveLayoutConfiguration(int FormId, int VersionId, int TempleteId, string BackgroundImage, string BackgroundColor, string FontFamily, string FontSize, string FontColor)
    {
        int rowsAffected = 0;
        bool result = false;
        try
        {
            string spName = "EVO_SaveLayoutConfiguration";
            SqlParameter[] parameters = new SqlParameter[8];
            parameters[0] = new SqlParameter("@FormId", FormId);
            parameters[1] = new SqlParameter("@VersionId", VersionId);
            parameters[2] = new SqlParameter("@TempleteId", TempleteId);
            parameters[3] = new SqlParameter("@BackgroundImage", BackgroundImage);
            parameters[4] = new SqlParameter("@BackgroundColor", BackgroundColor);
            parameters[5] = new SqlParameter("@FontFamily", FontFamily);
            parameters[6] = new SqlParameter("@FontSize", FontSize);
            parameters[7] = new SqlParameter("@FontColor", FontColor);

            rowsAffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

            if (rowsAffected > 0)
            {
                result = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return result;
    }

    public static DataSet GetFormLayoutConfiguration(int FormId, int VersionId)
    {
        DataSet getFormXMLPathDataset = new DataSet();
        try
        {
            string spName = "EVO_GetFormLayoutConfiguration";
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@FormId", FormId);
            parameters[1] = new SqlParameter("@VersionId", VersionId);
            getFormXMLPathDataset = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

            if (getFormXMLPathDataset != null && getFormXMLPathDataset.Tables.Count > 0)
            {
                return getFormXMLPathDataset;
            }
            else
                return null;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }


    public static bool InsertFormControls(int formID, string fieldName, string fieldAlias, string fieldDispType, int versionID, int controlID, int positionID, string userName)
    {
        int rowsAffected = 0;
        bool result = false;

        //string registerFormCtrlQry = "INSERT INTO EVO_FormFields (FormID, FieldName, Alias, FieldDisplayType, VersionID, ControlID, PositionID, AddedBy) VALUES (" + formID + ", '" + fieldName + "', '" + fieldAlias + "', '" + fieldDispType + "', " + versionID + "," + controlID + ", " + positionID + ",'" + userName + "')";

        //try
        //{
        //    rowsAffected = int.Parse(DAL.SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.Text, registerFormCtrlQry).ToString());

        //    if (rowsAffected > 0)
        //    {
        //        result = true;
        //    }
        //}
        //catch (Exception ex)
        //{
        //    throw ex;
        //}
        //return result;

        try
        {
            string spName = "EVO_InsertFormControls";
            SqlParameter[] parameters = new SqlParameter[8];
            parameters[0] = new SqlParameter("@formID", formID);
            parameters[1] = new SqlParameter("@fieldName", fieldName);
            parameters[2] = new SqlParameter("@fieldAlias", fieldAlias);
            parameters[3] = new SqlParameter("@fieldDispType", fieldDispType);
            parameters[4] = new SqlParameter("@versionID", versionID);
            parameters[5] = new SqlParameter("@controlID", controlID);
            parameters[6] = new SqlParameter("@positionID", positionID);
            parameters[7] = new SqlParameter("@userName", userName);

            rowsAffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

            if (rowsAffected > 0)
            {
                result = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return result;

    }


    public DataSet GetCustomCostCentre()
    {
        //string commandText = "SELECT CostCentreID,CostCentre FROM Central_CostCentre_Main";

        //DataSet centralCostCentreDs = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
        //return centralCostCentreDs;
        DataSet centralCostCentreDs;
        try
        {
            string spName = "EVO_GetFilterCostCentre";
            centralCostCentreDs = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

            if (centralCostCentreDs != null && centralCostCentreDs.Tables.Count > 0)
            {
                return centralCostCentreDs;
            }
            else
                return null;
        }
        catch (Exception ex)
        {
            throw new Exception("GetCustomCostCentre" + ex.Message);
        }

    }

    public DataSet GetCustomSkillSet(string costCentreList)
    {
        //costCentreList = costCentreList.Substring(0, costCentreList.Length - 1);
        ////string commandText = "SELECT DepartmentID,DepartmentName FROM Central_Department_Main WHERE CostCentreID IN (" + costCentreList + ") ORDER BY DepartmentName";
        //string commandText = "SELECT DepartmentID,DepartmentName FROM Central_Department_Main WHERE CostCentreID IN (" + costCentreList + ") AND status = 1 AND DepartmentName not like '%tesco%' ORDER BY DepartmentName";


        //DataSet skillSetDs = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
        //return skillSetDs;

        DataSet skillSetDs;
        try
        {
            string spName = "EVO_GetCustomSkillSet";
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@costCentreList", costCentreList);
            skillSetDs = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

            if (skillSetDs != null && skillSetDs.Tables.Count > 0)
            {
                return skillSetDs;
            }
            else
                return null;
        }
        catch (Exception ex)
        {
            throw new Exception("GetCustomSkillSet" + ex.Message);
        }


    }


    public DataSet GetGlobalCostCentre()
    {
        //DataSet globalCostCentreDs = new DataSet();

        //string commandText = "SELECT DISTINCT Central_CostCentre_Main.CostCentre AS CostCentre, Central_CostCentre_Main.CostCentreID AS CostCentreID, Evo_GlobalControlDataStore.ControlID AS ControlID " +
        //                     "FROM Evo_GlobalControlDataStore INNER JOIN " +
        //                     "Central_CostCentre_Main ON Evo_GlobalControlDataStore.CostCentreID = Central_CostCentre_Main.CostCentreID WHERE Evo_GlobalControlDataStore.DependentID = 0 AND Evo_GlobalControlDataStore.IsActive='True'";

        //globalCostCentreDs = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
        //return globalCostCentreDs;

        DataSet globalCostCentreDs;
        try
        {
            string spName = "EVO_GetGlobalCostCentre";
            globalCostCentreDs = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

            if (globalCostCentreDs != null && globalCostCentreDs.Tables.Count > 0)
            {
                return globalCostCentreDs;
            }
            else
                return null;
        }
        catch (Exception ex)
        {
            throw new Exception("GetGlobalCostCentre" + ex.Message);
        }
    }




    public DataSet GetGlobalSkillSet()
    {
        DataSet skillSetDs = new DataSet();

        //string commandText = "SELECT DISTINCT Central_Department_Main.DepartmentName AS DepName, Central_Department_Main.DepartmentID AS DepID, Evo_GlobalControlDataStore.ControlID AS ControlID, Evo_GlobalControlDataStore.CostCentreID AS CostCentreID " +
        //                     "FROM Evo_GlobalControlDataStore INNER JOIN " +
        //                     "Central_Department_Main ON Evo_GlobalControlDataStore.SkillSetID = Central_Department_Main.DepartmentID " +
        //                     "WHERE Evo_GlobalControlDataStore.DependentID = 0";


        //string commandText = "SELECT DISTINCT Central_Department_Main.DepartmentName AS DepName, Central_Department_Main.DepartmentID AS DepID, Evo_GlobalControlDataStore.ControlID, " +
        //                     "Evo_GlobalControlDataStore.CostCentreID FROM Evo_GlobalControlDataSkillSetRelation INNER JOIN " +
        //                     "Evo_GlobalControlDataStore ON Evo_GlobalControlDataSkillSetRelation.DataStoreID = Evo_GlobalControlDataStore.DataStoreID INNER JOIN " +
        //                     "Central_Department_Main ON Evo_GlobalControlDataSkillSetRelation.SkillSetID = Central_Department_Main.DepartmentID " +
        //                     "WHERE Evo_GlobalControlDataStore.DependentID = 0 AND Evo_GlobalControlDataStore.IsActive='True'";

        //skillSetDs = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
        //return skillSetDs;

        try
        {
            string spName = "EVO_GetGlobalSkillSet";
            skillSetDs = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

            if (skillSetDs != null && skillSetDs.Tables.Count > 0)
            {
                return skillSetDs;
            }
            else
                return null;
        }
        catch (Exception ex)
        {
            throw new Exception("GetGlobalSkillSet" + ex.Message);
        }

    }

    public static void SetDTMSControls(string FormId, string VersionId, string AddedBy)
    {
        string spName = "[EVO_setDTMSControls]";

        try
        {
            SqlParameter[] parameters = new SqlParameter[3];
            parameters[0] = new SqlParameter("@FormId", SqlDbType.Int);
            parameters[0].Value = FormId;
            parameters[1] = new SqlParameter("@VersionId", SqlDbType.Int);
            parameters[1].Value = VersionId;
            parameters[2] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
            parameters[2].Value = AddedBy;


            SqlHelper.ExecuteNonQuery(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public static DataSet GetDTMSControls(string FormId, DataSet objDataSet)
    {
        string procName = "[EVO_GetDTMSControl]";
        try
        {

            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@FormId", SqlDbType.Int);
            parameters[0].Value = FormId;

            objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters);

            return objDataSet;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public static bool SetControlManagement(string FormId, string VersionId)
    {
        string procName = "[EVO_SetControlManagement]";
        bool result = false;
        int rowsAffected = 0;
        try
        {

            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@FormId", SqlDbType.Int);
            parameters[0].Value = FormId;
            parameters[1] = new SqlParameter("@VersionId", SqlDbType.Int);
            parameters[1].Value = VersionId;

            rowsAffected = int.Parse(DAL.SqlHelper.ExecuteNonQuery(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters).ToString());

            if (rowsAffected > 0)
            {
                result = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return result;
    }
}


