﻿using System;
using System.Data;
using System.Web;
using System.Text;
using System.IO;
using iTextSharp;
using iTextSharp.text;
using iTextSharp.text.pdf;
using System.Web.UI.WebControls;
using System.Web.UI;
using iTextSharp.text.html.simpleparser;
using System.Drawing;

namespace EVOLib
{
    /// <summary>
    /// Summary description for DataExport
    /// </summary>
    public class DataExport : ExcelHelper
    {
        #region Public Methods
        public static void ToPDF(DataSet dsInput, string filename, HttpResponse response)
        {
            try
            {
                DataTable dataTable = dsInput.Tables[0];
                GridView GridView1 = new GridView();
                GridView1.AllowPaging = false;
                GridView1.DataSource = dataTable;
                GridView1.DataBind();
                response.Clear();
                response.Buffer = true;
                response.ContentType = "application/pdf";
                response.AddHeader("content-disposition", "attachment;filename=" + filename);
                response.Cache.SetCacheability(HttpCacheability.NoCache);
                StringWriter sw = new StringWriter();
                HtmlTextWriter hw = new HtmlTextWriter(sw);
                //GridView1.HeaderRow.Style.Add("font-size", "13px");
                //GridView1.Width = Unit.Percentage(100);
                GridView1.HeaderRow.ForeColor = System.Drawing.Color.Brown;
                GridView1.HeaderRow.Font.Bold = true;
                GridView1.RenderControl(hw);
                StringReader sr = new StringReader(sw.ToString());
                Document pdfDoc = new Document(PageSize.A1, 7f, 7f, 7f, 0f);
                HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
                PdfWriter.GetInstance(pdfDoc, response.OutputStream);
                pdfDoc.Open();
                htmlparser.Parse(sr);
                pdfDoc.Close();
                response.Write(pdfDoc);
                response.End();
            }
            catch (Exception ex)
            {

            }
        }


        public static void ToWord(DataSet dsInput, string filename, HttpResponse response)
        {
            try
            {
                DataTable dataTable = dsInput.Tables[0];
                GridView mygrid = new GridView();
                mygrid.AllowPaging = false;
                mygrid.DataSource = dataTable;
                mygrid.DataBind();
                response.ClearContent();
                response.AddHeader("content-disposition", string.Format("attachment; filename={0}", filename));
                response.Charset = "";
                response.ContentType = "application/ms-word";
                StringWriter sw = new StringWriter();
                HtmlTextWriter htw = new HtmlTextWriter(sw);
                mygrid.RenderControl(htw);
                var strBody = new StringBuilder();
                strBody.Append("<html><head><title></title>");
                strBody.Append("<style>" +
                 "@page Section1" +
                 "   {size:22.0in 11.0in; " +
                 "   margin:1.0in 1.0in 1.0in 1.0in; " +
                 "   mso-header-margin:.5in; " +
                 "   mso-footer-margin:.5in; mso-paper-source:0;}" +
                 " div.Section1" +
                 "   {page:Section1;}" +
                 " table" +
                 "   {font-size:10px; }" +
                 "</style></head>");
                strBody.Append("<body lang=EN-US style='tab-interval:.5in'><div class=Section1>");
                strBody.Append(sw.ToString());
                strBody.Append("</div></body></html>");
                response.Write(strBody);
                response.End();
            }
            catch (Exception ex)
            {

            }
        }

        //public static void ToDoc(DataSet dsInput, string filename, HttpResponse response)
        //{
        //DataTable dataTable = dsInput.Tables[0];

        //response.Clear();
        //response.ClearContent();
        //response.ContentType = "application/octet-stream";
        //response.AddHeader("Content-Disposition", "attachment; filename=" + filename);
        //GridView excel = new GridView();
        //excel.DataSource = dataTable;
        //excel.DataBind();
        //excel.RenderControl(new HtmlTextWriter(response.Output));
        //response.Flush();
        //response.End();
        //System.Diagnostics.Process.Start(filename);

        //GridView GridView1 = new GridView();
        //GridView1.AllowPaging = false;
        //GridView1.DataSource = dataTable;
        //GridView1.DataBind();
        //response.Clear();
        //response.Buffer = true;
        //response.ContentType = "application/vnd.ms-word";
        //response.AddHeader("content-disposition", "attachment;filename=" + filename);
        //response.Cache.SetCacheability(HttpCacheability.NoCache);
        //StringWriter sw = new StringWriter();
        //HtmlTextWriter hw = new HtmlTextWriter(sw);
        //GridView1.HeaderRow.ForeColor = System.Drawing.Color.Brown;
        //GridView1.HeaderRow.Font.Bold = true;
        //GridView1.RenderControl(hw);
        //StringReader sr = new StringReader(sw.ToString());
        //Document pdfDoc = new Document(PageSize.A1, 7f, 7f, 7f, 0f);
        //HTMLWorker htmlparser = new HTMLWorker(pdfDoc);
        //pdfDoc.Open();
        //htmlparser.Parse(sr);
        //pdfDoc.Close();
        //response.Write(pdfDoc);
        //response.End();


        //Document document = new Document();
        //PdfPTable table = new PdfPTable(dataTable.Columns.Count);
        ////table.WidthPercentage = 100;
        ////float[] terms = new float[dataTable.Columns.Count];
        //for (int k = 0; k < dataTable.Columns.Count; k++)
        //{
        //    PdfPCell cell = new PdfPCell(new Phrase(dataTable.Columns[k].ColumnName));
        //    cell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
        //    cell.VerticalAlignment = PdfPCell.ALIGN_CENTER;
        //    cell.BackgroundColor = new iTextSharp.text.BaseColor(255, 255, 204);
        //    table.AddCell(cell);
        //    //terms[k] = 100;
        //}
        //for (int i = 0; i < dataTable.Rows.Count; i++)
        //{
        //    for (int j = 0; j < dataTable.Columns.Count; j++)
        //    {
        //        PdfPCell cell = new PdfPCell(new Phrase(dataTable.Rows[i][j].ToString()));
        //        cell.HorizontalAlignment = PdfPCell.ALIGN_CENTER;
        //        cell.VerticalAlignment = PdfPCell.ALIGN_CENTER;
        //        table.AddCell(cell);
        //    }
        //}
        ////table.SetWidthPercentage(terms, document.PageSize);
        ////table.SetTotalWidth(terms);
        ////table.SetWidths(terms);
        //response.ContentType = "application/vnd.ms-word";
        //response.AddHeader("content-disposition", "attachment;filename=" + filename);
        //response.Cache.SetCacheability(HttpCacheability.NoCache);
        //HTMLWorker htmlparser = new HTMLWorker(document);
        //document.Open();
        //document.Add(table);
        //document.Close();
        //response.Write(document);
        //response.End();


        //GridView GridView1 = new GridView();
        //GridView1.AllowPaging = false;
        //GridView1.DataSource = dsInput.Tables[0];
        //GridView1.DataBind();
        //response.Clear();
        //response.Buffer = true;
        //response.AddHeader("content-disposition", "attachment;filename=" + filename);
        //response.Charset = string.Empty;
        //response.ContentType = "application/vnd.ms-word";
        //StringWriter sw = new StringWriter();
        //HtmlTextWriter hw = new HtmlTextWriter(sw);
        //GridView1.RenderControl(hw);
        //response.Output.Write(sw.ToString());
        //response.Flush();
        //response.End();
        //}

        #endregion
    }
}
