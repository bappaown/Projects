﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DAL;

namespace EVOLib
{
    public class EvoMain
    {
        private Int64 userID;
        private string formName;
        private string addedBy;
        private int categoryId;
        private Int64 empUserId;
        private int versionId;
        private int formId;
        private string formDesc;
        private int skillSetId;
        private string updatedBy;
        private string updatedWhen;
        private string iseditable;
        private string issearchfromspecific;
        private string isdtms;
        private string TemplateEmails;
        public EvoMain()
        {

        }
        #region Properties declared.
        /// <summary>
        /// This property used to set and get to the EmpUserId.
        /// </summary>
        public Int64 EmpUserId
        {
            get
            {
                return empUserId;
            }
            set
            {
                empUserId = value;
            }
        }
        /// <summary>
        /// This property used to set and get to the UpdatedWhen.
        /// </summary>
        public string UpdatedWhen
        {
            get
            {
                return updatedWhen;
            }
            set
            {
                updatedWhen = value;
            }
        }
        /// <summary>
        /// This property used to set and get to the UpdatedBy.
        /// </summary>
        public string UpdatedBy
        {
            get
            {
                return updatedBy;
            }
            set
            {
                updatedBy = value;
            }
        }
        /// <summary>
        /// This property used to set and get to the SkillSetId.
        /// </summary>
        public int SkillSetId
        {
            get
            {
                return skillSetId;
            }
            set
            {
                skillSetId = value;
            }
        }

        /// <summary>
        /// This property used to set and get to the SkillSetId.
        /// </summary>
        public int VersionId
        {
            get
            {
                return versionId;
            }
            set
            {
                versionId = value;
            }
        }

        /// <summary>
        /// This property used to set and get to the FormId.
        /// </summary>
        public int FormId
        {
            get
            {
                return formId;
            }
            set
            {
                formId = value;
            }
        }
        /// <summary>
        /// This property used to set and get to the CategoryId.
        /// </summary>
        public int CategoryId
        {
            get
            {
                return categoryId;
            }
            set
            {
                categoryId = value;
            }
        }
        /// <summary>
        /// This property used to set and get to the FormDesc.
        /// </summary>
        public string FormDesc
        {
            get
            {
                return formDesc;
            }
            set
            {
                formDesc = value;
            }
        }
        /// <summary>
        /// This property used to set and get to the AddedBy.
        /// </summary>
        public string AddedBy
        {
            get
            {
                return addedBy;
            }
            set
            {
                addedBy = value;
            }
        }
        /// <summary>
        /// This property used to set and get to the FormName.
        /// </summary>
        public string FormName
        {
            get
            {
                return formName;
            }
            set
            {
                formName = value;
            }
        }
        /// <summary>
        /// This property used to set and get to the UserId.
        /// </summary>
        public Int64 UserID
        {
            get
            {
                return userID;
            }
            set
            {
                userID = value;
            }
        }

        /// <summary>
        /// This property used to set and get to the IsEditable.
        /// </summary>
        public string IsEditable
        {
            get
            {
                return iseditable;
            }
            set
            {
                iseditable = value;
            }
        }

        /// <summary>
        /// This property used to set and get to the IsSearchFormSpecific.
        /// </summary>
        public string IsSearchFormSpecific
        {
            get
            {
                return issearchfromspecific;
            }
            set
            {
                issearchfromspecific = value;
            }
        }
        /// <summary>
        /// This property used to set and get to the IsDTMS.
        /// </summary>
        public string IsDTMS
        {
            get
            {
                return isdtms;
            }
            set
            {
                isdtms = value;
            }
        }

        /// <summary>
        /// This property used to set and get to the TemplateEmails.
        /// </summary>
        public string TemplateEmail
        {
            get
            {
                return TemplateEmails;
            }
            set
            {
                TemplateEmails = value;
            }
        }

        #endregion

        #region Methods
        /// <summary>
        /// This method is used for Check admins or super Admin in AdminUserRights.
        /// </summary>
        /// <param name="empID"></param>
        /// <returns></returns>
        public bool GetAllAdmin(long empID)
        {
            bool isValid = false;
            //string commandText = "SELECT * FROM Evo_AdminUserRights WHERE UserID =" + empID + "";
            //SqlDataReader NTNameResult = DAL.SqlHelper.ExecuteReader(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //if (NTNameResult.HasRows == true)
            //{
            //    isValid = true;
            //}
            //else
            //{
            //    isValid = false;
            //}
            //return isValid;

            //EVO_GetAllAdmin

            DataSet ds;
            try
            {
                string spName = "EVO_GetAllAdmin";
                SqlParameter[] parameters = new SqlParameter[1];

                parameters[0] = new SqlParameter("@EmployeeId", empID);
                ds = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (ds != null && ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        isValid = true;

                    }
                }
                else
                    isValid = false;
            }
            catch (Exception ex)
            {
                throw new Exception("GetAllAdmin" + ex.Message);
            }
            return isValid;

        }
        /// <summary>
        /// This method is used for admin or super admin or user RoleType in AdminUserRights.
        /// </summary>
        /// <param name="empID"></param>
        /// <returns></returns>
        public int GetAdminType(long empID)
        {
            int roleType = 0;
            DataSet ds;

            try
            {
                string spName = "EVO_GetAllAdmin";
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@EmployeeId", empID);
                ds = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (ds != null && ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        roleType = Convert.ToInt16(ds.Tables[0].Rows[0]["RoleID"].ToString());
                    }
                }
                else
                    roleType = 0;
            }
            catch (Exception ex)
            {
                throw new Exception("GetAllAdmin" + ex.Message);
            }

            return roleType;
        }
        /// <summary>
        /// This method is used for Check super Admin in AdminUserRights.
        /// </summary>
        /// <param name="empID"></param>
        /// <returns></returns>
        public bool GetSuperAdmin(long empID)
        {
            bool isValid = false;
            //string commandText = "SELECT * FROM Evo_AdminUserRights WHERE RoleID =1 AND UserID =" + empID + " and IsActive =1";
            //SqlDataReader NTNameResult = DAL.SqlHelper.ExecuteReader(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //if (NTNameResult.HasRows == true)
            //{
            //    isValid = true;
            //}
            //else
            //{
            //    isValid = false;
            //}
            //return isValid;

            DataSet ds;
            try
            {
                string spName = "EVO_GetSuperAdmin";
                SqlParameter[] parameters = new SqlParameter[1];

                parameters[0] = new SqlParameter("@EmployeeId", empID);
                ds = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (ds != null && ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        isValid = true;

                    }
                }
                else
                    isValid = false;
            }
            catch (Exception ex)
            {
                throw new Exception("GetSuperAdmin" + ex.Message);
            }
            return isValid;

        }
        /// <summary>
        /// Get Departments(Table - Central_Department_Main) for Create mode.
        /// </summary>        
        public DataSet RetrieveDeptDetails(long userId)
        {
            DataSet deptDetailsDataSet = null;
            SqlParameter[] oParams;
            try
            {
                string spName = "EVO_Select_SkillSet";
                oParams = new SqlParameter[1];
                oParams[0] = new SqlParameter("@UserID", userId);
                deptDetailsDataSet = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, oParams);

                if (deptDetailsDataSet != null && deptDetailsDataSet.Tables.Count > 0)
                {
                    return deptDetailsDataSet;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("RetrieveDeptDetails" + ex.Message);
            }

        }
        /// <summary>
        /// Get Departments(Table - Central_Department_Main) for Edit mode.
        /// </summary>        
        public DataSet RetrieveDeptDetailsEditMode(long userId, int formId)
        {
            DataSet deptDetailsDataSet = null;
            SqlParameter[] oParams;
            try
            {
                string spName = "EVO_Select_ModifyForms";
                oParams = new SqlParameter[2];
                oParams[0] = new SqlParameter("@UserID", userId);
                oParams[1] = new SqlParameter("@FormId", formId);
                deptDetailsDataSet = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, oParams);

                if (deptDetailsDataSet != null && deptDetailsDataSet.Tables[0].Rows.Count > 0)
                {
                    return deptDetailsDataSet;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("RetrieveDeptDetails" + ex.Message);
            }

        }
        /// <summary>
        /// Get Category(Table - Evo_CategoryMain).
        /// </summary>       
        public DataSet RetrieveCatDetails()
        {
            //string commandText = "SELECT * FROM Evo_CategoryMain";
            //DataSet catDetailsDataSet = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //return catDetailsDataSet;

            DataSet catDetailsDataSet = null;
            try
            {
                string spName = "EVO_RetrieveCatDetails";
                catDetailsDataSet = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

                if (catDetailsDataSet != null && catDetailsDataSet.Tables[0].Rows.Count > 0)
                {
                    return catDetailsDataSet;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("RetrieveCatDetails" + ex.Message);
            }

        }

        /// <summary>
        /// This method is used to retrive forms Details
        /// </summary>
        /// <returns></returns>  
        public DataSet RetrieveFormDetails(int frmID)
        {
            //string commandText = "SELECT FormID, FormName,FormDesc,CategoryID,IsEditable,IsSearchFormSpecific,IsDtms,TemplateEmails FROM Evo_Main WHERE FormID=" + frmID + "";
            //DataSet catDetailsDataSet = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //return catDetailsDataSet;

            DataSet dsFormDetails = null;
            try
            {
                string spName = "EVO_RetrieveFormDetails";
                SqlParameter[] oParams;
                oParams = new SqlParameter[1];
                oParams[0] = new SqlParameter("@formId", frmID);
                dsFormDetails = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, oParams);

                if (dsFormDetails != null && dsFormDetails.Tables[0].Rows.Count > 0)
                {
                    return dsFormDetails;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("RetrieveFormDetails" + ex.Message);
            }

        }
        /// <summary>
        /// This method is used to retrive Skill set.
        /// </summary>
        /// <returns></returns>  
        public DataSet RetrieveSkillSetDetails(int frmID)
        {
            //string commandText = "SELECT DepartmentId,DepartmentName FROM Evo_SkillSetRelations  ES JOIN Central_Department_Main CD ON CD.DepartmentId = ES.SkillSetId WHERE ES.FormId =" + frmID + "";
            //DataSet catDetailsDataSet = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //return catDetailsDataSet;

            DataSet dsFormDetails = null;
            try
            {
                string spName = "EVO_RetrieveSkillSetDetails";
                SqlParameter[] oParams;
                oParams = new SqlParameter[1];
                oParams[0] = new SqlParameter("@formId", frmID);
                dsFormDetails = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, oParams);

                if (dsFormDetails != null && dsFormDetails.Tables[0].Rows.Count > 0)
                {
                    return dsFormDetails;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("RetrieveSkillSetDetails" + ex.Message);
            }

        }

        /// <summary>
        /// This method is used to add record into Evo_Main table.
        /// </summary>
        /// <returns></returns>
        public bool AddFormDetails()
        {
            bool result = false;
            int noOfEffectedRows = 0;
            try
            {
                string spName = "EVO_Insert_EvoMain";
                SqlParameter[] parameters = new SqlParameter[11];
                parameters[0] = new SqlParameter("@FormName", FormName);
                parameters[1] = new SqlParameter("@FormDesc", FormDesc);
                parameters[2] = new SqlParameter("@CategoryID", CategoryId);
                parameters[3] = new SqlParameter("@AddedBy", AddedBy);
                parameters[4] = new SqlParameter("@EmpUserId", EmpUserId);
                parameters[5] = new SqlParameter("@FormID", FormId);
                parameters[5].Direction = ParameterDirection.Output;
                parameters[6] = new SqlParameter("@VersionID", VersionId);
                parameters[6].Direction = ParameterDirection.Output;
                parameters[7] = new SqlParameter("@IsEditable", IsEditable);
                parameters[8] = new SqlParameter("@IsSearchFormSpecific", IsSearchFormSpecific);
                parameters[9] = new SqlParameter("@IsDTMS", IsDTMS);
                parameters[10] = new SqlParameter("@TempEmails", TemplateEmails);
                noOfEffectedRows = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                FormId = int.Parse(parameters[5].Value.ToString());
                VersionId = int.Parse(parameters[6].Value.ToString());
                if (noOfEffectedRows > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;

        }
        /// <summary>
        /// This method is used to update  record From Evo_Main table.
        /// </summary>
        /// <returns></returns>
        public bool UpdateFormDetails()
        {
            bool result = false;
            int noOfEffectedRows = 0;
            try
            {

                string spName = "EVO_Update_EvoMain";
                SqlParameter[] parameters = new SqlParameter[9];
                parameters[0] = new SqlParameter("@FormID", FormId);
                parameters[1] = new SqlParameter("@FormName", FormName);
                parameters[2] = new SqlParameter("@FormDesc", FormDesc);
                parameters[3] = new SqlParameter("@CategoryID", CategoryId);
                parameters[4] = new SqlParameter("@UpdatedBy", UpdatedBy);
                parameters[5] = new SqlParameter("@UpdateWhen", SqlDbType.DateTime);
                parameters[5].Value = DateTime.Parse(UpdatedWhen);
                parameters[6] = new SqlParameter("@IsEditable", IsEditable);
                parameters[7] = new SqlParameter("@IsSearchFormSpecific", IsSearchFormSpecific);
                parameters[8] = new SqlParameter("@TempEmails", TemplateEmails);
                noOfEffectedRows = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                if (noOfEffectedRows > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;

        }
        /// <summary>
        /// This method is used to delete record from Evo_SkillSetRelations.
        /// </summary>
        /// <returns></returns>
        public bool DeleteSkillSetRelationsls(int formID)
        {
            bool result = false;
            int noOfEffectedRows = 0;
            try
            {
                string spName = "EVO_Delete_SkillSetRelations";
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@FormID", formID);
                noOfEffectedRows = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                if (noOfEffectedRows > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;

        }
        /// <summary>
        /// This method is used to add or Delete record into Evo_SkillSetRelations table as per param IsDelete.
        /// </summary>
        /// <returns></returns>
        public bool AddSkillSetDetails()
        {
            bool result = false;
            int rowsEffected = 0;
            try
            {
                string spName = "EVO_Insert_SkillSetRelations";
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@SkillSetID", SkillSetId);
                parameters[1] = new SqlParameter("@FormID", FormId);
                parameters[2] = new SqlParameter("@AddedBy", AddedBy);
                rowsEffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                if (rowsEffected > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;

        }


        public bool ActivateFormVersion(int VersionID, string userName)
        {
            bool result = false;
            int noOfEffectedRows = 0;

            try
            {
                EvoGeneral gen = new EvoGeneral();
                string AddedBy = userName;
                string spName = "EVO_Update_Activation";
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@VersionID", VersionID);
                parameters[1] = new SqlParameter("@AddedBy", AddedBy);
                noOfEffectedRows = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                if (noOfEffectedRows > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;

        }


        public bool DeActivateFormVersion(int VersionID, string userName)
        {
            bool result = false;
            int noOfEffectedRows = 0;

            try
            {
                EvoGeneral gen = new EvoGeneral();
                string AddedBy = userName;
                string spName = "EVO_Update_DeActivation";
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@VersionID", VersionID);
                parameters[1] = new SqlParameter("@AddedBy", AddedBy);
                noOfEffectedRows = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                if (noOfEffectedRows > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;

        }

        public DataSet CheckForIsEditable(int FormId)
        {
            DataSet objds = new DataSet();
            try
            {
                string spName = "EVO_CheckForIsEditableForm";
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@FormId", FormId);

                objds = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return objds;
        }

        public bool UpdateIsSrabblePad(int VersionID, string userName, string IsScrabblePad)
        {
            bool result = false;
            int noOfEffectedRows = 0;

            try
            {
                EvoGeneral gen = new EvoGeneral();
                string AddedBy = userName;
                string spName = "EVO_Update_IsScrabblePad";
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@VersionID", VersionID);
                parameters[1] = new SqlParameter("@AddedBy", AddedBy);
                parameters[2] = new SqlParameter("@IsScrabblePad", Convert.ToBoolean(IsScrabblePad));
                noOfEffectedRows = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                if (noOfEffectedRows > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;

        }

        #endregion
    }
}
