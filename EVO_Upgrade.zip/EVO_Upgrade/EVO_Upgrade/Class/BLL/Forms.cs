﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DAL;

/// <summary>
/// Summary description for Forms
/// </summary>

namespace EVOLib
{
    public class Forms
    {
        public Forms()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Declare Properties

        private int formID;
        private int versionID;
        private string fieldID;
        private string dataCapture;
        private int transID;
        private string fieldName;
        private Int64 userID;
        private string addedBy;
        private string fieldDisplayType;
        private string controlName;
        private string costCentreID;
        private string skillSetID;
        private int controlID;
        private string controlType;
        private string loggedInUser;
        private string sqlQueryForCustomControlOne;
        private string sqlQueryForCustomControlTwo;
        private Int32 timeTaken;


        public int FormID
        {
            get
            {
                return formID;
            }
            set
            {
                formID = value;
            }
        }
        public int VersionID
        {
            get
            {
                return versionID;
            }
            set
            {
                versionID = value;
            }
        }
        public string FieldID
        {
            get
            {
                return fieldID;
            }
            set
            {
                fieldID = value;
            }
        }
        public string DataCapture
        {
            get
            {
                return dataCapture;
            }
            set
            {
                dataCapture = value;
            }
        }
        public int TransID
        {
            get
            {
                return transID;
            }
            set
            {
                transID = value;
            }
        }
        public string FieldName
        {
            get
            {
                return fieldName;
            }
            set
            {
                fieldName = value;
            }
        }
        public Int64 UserID
        {
            get
            {
                return userID;
            }
            set
            {
                userID = value;
            }
        }
        public string AddedBy
        {
            get
            {
                return addedBy;
            }
            set
            {
                addedBy = value;
            }
        }
        public string FieldDisplayType
        {
            get
            {
                return fieldDisplayType;
            }
            set
            {
                fieldDisplayType = value;
            }
        }
        public string ControlName
        {
            get
            {
                return controlName;
            }
            set
            {
                controlName = value;
            }
        }
        public string CostCentreID
        {
            get
            {
                return costCentreID;
            }
            set
            {
                costCentreID = value;
            }
        }
        public string SkillSetID
        {
            get
            {
                return skillSetID;
            }
            set
            {
                skillSetID = value;
            }
        }
        public int ControlID
        {
            get
            {
                return controlID;
            }
            set
            {
                controlID = value;
            }
        }
        public string ControlType
        {
            get
            {
                return controlType;
            }
            set
            {
                controlType = value;
            }
        }
        public string LoggedInUser
        {
            get
            {
                return loggedInUser;
            }
            set
            {
                loggedInUser = value;
            }
        }



        //public string SqlQueryForCustomControlOne
        //{
        //    get
        //    {
        //        sqlQueryForCustomControlOne = " SELECT EmpUserID, CONVERT(VARCHAR(50),EmployeeID) +','+FirstName + ' ' + LastName AS EmployeeNameWithID, FirstName, LastName, FirstName + ' ' + LastName +'['+CONVERT(VARCHAR(50),EmployeeID)+']' AS EmployeeName, Location FROM Central_Employee_Main ";
        //        return sqlQueryForCustomControlOne;
        //    }
        //}
        //public string SqlQueryForCustomControlTwo
        //{
        //    get
        //    {
        //        sqlQueryForCustomControlTwo = " SELECT EmpUserID, CONVERT(VARCHAR(50),EmployeeID) +','+FirstName + ' ' + LastName AS EmployeeNameWithID, FirstName, LastName, FirstName + ' ' + LastName +'['+CONVERT(VARCHAR(50),EmployeeID)+']' AS EmployeeName, Location FROM Central_Employee_Main ";
        //        return sqlQueryForCustomControlTwo;
        //    }
        //}
        public Int32 TimeTaken
        {
            get
            {
                return timeTaken;
            }
            set
            {
                timeTaken = value;
            }
        }
        #endregion

        #region Declare Handlers

        public DataSet GetFormsFieldsWithVersions(DataSet objDataSet, bool showTemplateFields)
        {
            string procName = "[EVO_Select_FormFields]";
            try
            {
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@FormID", SqlDbType.Int);
                parameters[0].Value = this.FormID;
                parameters[1] = new SqlParameter("@VersionID", SqlDbType.Int);
                parameters[1].Value = this.VersionID;
                parameters[2] = new SqlParameter("@ShowTemplateFields", SqlDbType.Bit);
                parameters[2].Value = showTemplateFields;

                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters);

                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Generate Transaction ID before inserting captured values.
        /// </summary>
        /// <returns></returns>
        public int GenerateTransationID(SqlTransaction objSqlTransaction, out Int64 uniqueId)
        {
            string spName = "[Evo_Insert_Transaction]";
            int returnValue = 0;
            uniqueId = 0;
            try
            {
                SqlParameter[] parameters = new SqlParameter[7];
                parameters[0] = new SqlParameter("@FormID", SqlDbType.Int);
                parameters[0].Value = this.FormID;
                parameters[1] = new SqlParameter("@VersionID", SqlDbType.Int);
                parameters[1].Value = this.VersionID;
                parameters[2] = new SqlParameter("@UserID", SqlDbType.BigInt);
                parameters[2].Value = this.UserID;
                parameters[3] = new SqlParameter("@TimeTaken", SqlDbType.Int);
                parameters[3].Value = this.TimeTaken;
                parameters[4] = new SqlParameter("@AddedBy", SqlDbType.VarChar);
                parameters[4].Value = this.AddedBy;
                parameters[5] = new SqlParameter("@Identity", SqlDbType.Int);
                parameters[5].Direction = ParameterDirection.Output;
                parameters[6] = new SqlParameter("@TransactionId", SqlDbType.Int);
                parameters[6].Value = this.TransID;

                //SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                SqlHelper.ExecuteNonQuery(objSqlTransaction, CommandType.StoredProcedure, spName, parameters);
                returnValue = Convert.ToInt32(parameters[5].Value);

                try
                {
                    //UniqueIdentifierService.UniqueIdentifierServiceClient uis = new UniqueIdentifierService.UniqueIdentifierServiceClient();
                    //uis.Open();
                    //uniqueId = uis.GetUniqueAppId(returnValue, Convert.ToInt32(ConfigurationManager.AppSettings["UniqueIdentifierAppId"]));
                    //uis.Close();
                }
                catch (Exception ex)
                {
                    LogExceptionInDatabase(ex, returnValue);
                }

                return returnValue;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Insert captured values for the form.
        /// </summary>
        /// <returns></returns>
        public int InsertFormDetails(SqlTransaction objSqlTransaction)
        {
            string spName = "[Evo_Insert_FormDetails]";
            int returnValue = 0;
            try
            {
                SqlParameter[] parameters = new SqlParameter[5];
                parameters[0] = new SqlParameter("@FormID", SqlDbType.Int);
                parameters[0].Value = this.FormID;
                parameters[1] = new SqlParameter("@FieldID", SqlDbType.Int);
                parameters[1].Value = this.FieldID;
                parameters[2] = new SqlParameter("@DataCapture", SqlDbType.VarChar);
                parameters[2].Value = this.DataCapture;
                parameters[3] = new SqlParameter("@TransID", SqlDbType.Int);
                parameters[3].Value = this.TransID;
                parameters[4] = new SqlParameter("@Identity", SqlDbType.Int);
                parameters[4].Direction = ParameterDirection.Output;

                //SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                SqlHelper.ExecuteNonQuery(objSqlTransaction, CommandType.StoredProcedure, spName, parameters);
                returnValue = Convert.ToInt32(parameters[4].Value);
                return returnValue;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void LogExceptionInDatabase(Exception ex, int returnValue)
        {
            string errMessage = null;
            string errInnerException = null;
            string errSource = null;
            string errStackTrace = null;
            string errTargetSite = null;
            string errHelpLink = null;
            string refEmpUserId = null;
            string refCostCentreID = null;
            string refDepartmentID = null;
            string refDesignationID = null;

            #region Configure Exception Info
            if (ex.Message != null)
                errMessage = ex.Message;
            if (ex.InnerException != null)
                errInnerException = ex.InnerException.Message;
            if (ex.Source != null)
                errSource = ex.Source;
            if (ex.StackTrace != null)
                errStackTrace = ex.StackTrace;
            if (ex.TargetSite != null)
                errTargetSite = ex.TargetSite.ToString();
            if (ex.HelpLink != null)
                errHelpLink = ex.HelpLink;
            #endregion

            if (H3GS.Web.Security.PassportIdentity.Current.Employee != null)
            {
                #region Configure Session / User Info
                refEmpUserId = H3GS.Web.Security.PassportIdentity.Current.Employee.UserId.ToString();
                refCostCentreID = H3GS.Web.Security.PassportIdentity.Current.Employee.CostCentreId.ToString();
                refDepartmentID = H3GS.Web.Security.PassportIdentity.Current.Employee.DepartmentId.ToString();
                refDesignationID = H3GS.Web.Security.PassportIdentity.Current.Employee.DesignationId.ToString();
                #endregion
            }
            SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), "InsertErrorLog", returnValue, refEmpUserId, refCostCentreID, refDepartmentID, refDesignationID, errMessage, errInnerException, errSource, errStackTrace, errTargetSite, errHelpLink);
        }

        //-------START Added by Sagar CR Client Requirement For Wrap Note Hits   
        /// <summary>
        /// 
        /// </summary>
        /// <param name="objDataSet"></param>
        /// <returns></returns>
        public void InsertFormWrapNoteUsers()
        {
            SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), "EVO_Insert_FormWrapNoteUsers", FormID, VersionID, UserID);
        }
        //-------END Added by Sagar CR Client Requirement For Wrap Note Hits   

        /// <summary>
        /// Select employee details for custom control(CC1Employees).
        /// </summary>
        /// <param name="objDataSet"></param>
        /// <returns></returns>
        //public DataSet SelectEmployeesForCustomControl(DataSet objDataSet, string commandText)
        //{
        //    /* Commented By Imran */
        //    //string commandText = "SELECT EmpUserID, CONVERT(VARCHAR(50),EmployeeID) +','+FirstName + ' ' + LastName AS EmployeeNameWithID, FirstName, LastName, FirstName + ' ' + LastName AS EmployeeName, Location FROM Central_Employee_Main ";
        //    //commandText += whereClause + " AND Status = 'True'";
        //    try
        //    {
        //        objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, commandText);
        //        return objDataSet;
        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        // changed on 11 aug 2017 

        public DataSet SelectEmployeesForCustomControl(DataSet objDataSet, string CC, string dept)
        {
            /* Commented By Imran */
            //string commandText = "SELECT EmpUserID, CONVERT(VARCHAR(50),EmployeeID) +','+FirstName + ' ' + LastName AS EmployeeNameWithID, FirstName, LastName, FirstName + ' ' + LastName AS EmployeeName, Location FROM Central_Employee_Main ";
            //commandText += whereClause + " AND Status = 'True'";
            string spName = "[EVO_SqlQueryForCustomControlOne]";
            try
            {
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@CostCenterIds", SqlDbType.VarChar);
                parameters[0].Value = CC;
                parameters[1] = new SqlParameter("@DeptIds", SqlDbType.VarChar);
                parameters[1].Value = dept;


                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get the global conotrol data with specified CostCentre and Skillsets.
        /// </summary>
        /// <param name="objDataSet"></param>
        /// <returns></returns>
        public DataSet SelectGlobalControlData(DataSet objDataSet)
        {
            string spName = "[EVO_Select_GlobalData]";
            try
            {
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@ControlID", SqlDbType.Int);
                parameters[0].Value = this.ControlID;
                parameters[1] = new SqlParameter("@CCID", SqlDbType.VarChar);
                parameters[1].Value = this.CostCentreID;
                parameters[2] = new SqlParameter("@SSID", SqlDbType.VarChar);
                parameters[2].Value = this.SkillSetID;

                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get global control id from fromfields table.
        /// </summary>
        /// <returns></returns>
        public int GetGlobalControlID()
        {
            //int cntrlID = 0;
            //string commandText = " SELECT ControlID FROM Evo_FormFields WHERE FormID = " + this.FormID + " AND VersionID = " + this.VersionID + " AND FieldName + FieldDisplayType ='" + this.FieldName + "' AND IsActive = 1";
            //try
            //{
            //    cntrlID = Convert.ToInt32(SqlHelper.ExecuteScalar(SqlHelper.GetConnectionString(), CommandType.Text, commandText));
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
            //return cntrlID;

            int cntrlID = 0;
            DataSet ds;
            try
            {

                string spName = "EVO_GetGlobalControlID";
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@formId", this.FormID);
                parameters[1] = new SqlParameter("@versionId", this.VersionID);
                parameters[2] = new SqlParameter("@fieldName", this.FieldName);
                ds = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (ds != null && ds.Tables.Count > 0)
                {
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        cntrlID = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());
                    }

                }
                else
                    cntrlID = 0;
            }
            catch (Exception ex)
            {
                throw new Exception("GetCostCentresDepartments" + ex.Message);
            }
            return cntrlID;
        }


        /// <summary>
        /// Get all global controls
        /// </summary>
        /// <param name="objDataSet"></param>
        /// <returns></returns>
        public DataSet GetCustomGlobalControls(DataSet objDataSet)
        {
            string spName = "[EVO_Select_CustomGlobalControls]";

            try
            {
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@FormID", SqlDbType.Int);
                parameters[0].Value = this.FormID;
                parameters[1] = new SqlParameter("@VersionID", SqlDbType.Int);
                parameters[1].Value = this.VersionID;
                parameters[2] = new SqlParameter("@ContorlType", SqlDbType.VarChar);
                parameters[2].Value = this.ControlType;

                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Get all forms names as per logged in user depending on skillsetid.
        /// </summary>
        /// <param name="objDataSet"></param>
        /// <returns></returns>
        public DataSet GetFormsAsPerUser(DataSet objDataSet)
        {
            string spName = "[EVO_Select_FormsAsPerUser]";
            try
            {
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@Login", SqlDbType.VarChar);
                parameters[0].Value = this.LoggedInUser;

                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        /// <summary>
        /// Send mail for Logger .
        /// </summary>
        /// <returns></returns>
        public void SendMailForLogger(string TransId, SqlTransaction objSqlTransaction)
        {
            string spName = "[EVO_SendMailForLogger]";

            try
            {
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@TransId", SqlDbType.VarChar);
                parameters[0].Value = TransId;


                SqlHelper.ExecuteNonQuery(objSqlTransaction, CommandType.StoredProcedure, spName, parameters);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }


        public DataSet GetControls(string FormId, string VersionId)
        {
            string spName = "[EVO_Get_Controls]";
            DataSet dscontrol = new DataSet();
            try
            {
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@FormId", SqlDbType.Int);
                parameters[0].Value = FormId;
                parameters[1] = new SqlParameter("@VersionId", SqlDbType.Int);
                parameters[1].Value = VersionId;

                dscontrol = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
            }
            catch (Exception ex)
            {

            }
            return dscontrol;
        }

        public DataSet GetTransDetails(string FormId, string VersionId, string TransId, string TransIdArchived)
        {
            string spName = "[EVO_Get_TransDetails]";
            DataSet dstransdetails = new DataSet();
            try
            {
                SqlParameter[] parameters = new SqlParameter[4];
                parameters[0] = new SqlParameter("@FormId", SqlDbType.Int);
                parameters[0].Value = FormId;
                parameters[1] = new SqlParameter("@VersionId", SqlDbType.Int);
                parameters[1].Value = VersionId;
                parameters[2] = new SqlParameter("@TransIds", SqlDbType.VarChar, 2000);
                parameters[2].Value = TransId;
                parameters[3] = new SqlParameter("@TransIdsArchived", SqlDbType.VarChar, 2000);
                parameters[3].Value = TransIdArchived;


                dstransdetails = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
            }
            catch (Exception ex)
            {

            }
            return dstransdetails;
        }

        public DataSet GetFormFieldsWithData(string FormId, string VersionId, string TransId)
        {
            string spName = "[EVO_Select_FormFieldsWithData]";
            DataSet dstransdetails = new DataSet();
            try
            {
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@FormId", SqlDbType.Int);
                parameters[0].Value = FormId;
                parameters[1] = new SqlParameter("@VersionId", SqlDbType.Int);
                parameters[1].Value = VersionId;
                parameters[2] = new SqlParameter("@TransId", SqlDbType.Int);
                parameters[2].Value = TransId;

                dstransdetails = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dstransdetails;
        }


        public DataSet GetTransIds(string FieldId, string value, string Userid, string FormId, string Versionid)
        {
            string spName = "[EVO_GetTransIds]";
            DataSet dstransdetails = new DataSet();
            try
            {
                SqlParameter[] parameters = new SqlParameter[5];
                parameters[0] = new SqlParameter("@FieldId", SqlDbType.VarChar, 2000);
                parameters[0].Value = FieldId;
                parameters[1] = new SqlParameter("@value", SqlDbType.VarChar, 2000);
                parameters[1].Value = value;
                parameters[2] = new SqlParameter("@UserId", SqlDbType.Int);
                parameters[2].Value = Userid;
                parameters[3] = new SqlParameter("@FormId", SqlDbType.Int);
                parameters[3].Value = FormId;
                parameters[4] = new SqlParameter("@VersionId", SqlDbType.Int);
                parameters[4].Value = Versionid;

                dstransdetails = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
            }
            catch (Exception ex)
            {

            }
            return dstransdetails;
        }

        public DataSet GetFieldDetailsForTrans(string TransId)
        {
            string spName = "[EVO_GetFieldDetailsForTrans]";
            DataSet dstransdetails = new DataSet();
            try
            {
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@TransId", SqlDbType.Int);
                parameters[0].Value = TransId;


                dstransdetails = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
            }
            catch (Exception ex)
            {

            }
            return dstransdetails;
        }

        public DataSet GetFormDetails(DataSet objDataSet)
        {
            string procName = "[EVO_GetFormDetails]";
            try
            {
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@FormID", SqlDbType.Int);
                parameters[0].Value = this.FormID;
                parameters[1] = new SqlParameter("@VersionID", SqlDbType.Int);
                parameters[1].Value = this.VersionID;
                parameters[2] = new SqlParameter("@FieldId", SqlDbType.VarChar, 200);
                parameters[2].Value = this.fieldID;

                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters);

                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetControlType(string FieldId)
        {
            DataSet objDataSet = new DataSet();
            string procName = "[EVO_GetControlType]";
            try
            {
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@FieldId", SqlDbType.Int);
                parameters[0].Value = FieldId;

                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters);

                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetVersionForTrans(string TransId)
        {
            DataSet objDataSet = new DataSet();
            string procName = "[EVO_GetVersionForTransId]";
            try
            {
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@TransId", SqlDbType.Int);
                parameters[0].Value = TransId;

                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters);

                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public DataSet GetShowHideControlsDS(string FieldNameValues, string FormId, string VersionId)
        {
            string procName = "[EVO_GetDisplayControls]";
            DataSet objDataSet = new DataSet();
            try
            {
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@FormID", SqlDbType.Int);
                parameters[0].Value = FormId;
                parameters[1] = new SqlParameter("@VersionID", SqlDbType.Int);
                parameters[1].Value = VersionId;
                parameters[2] = new SqlParameter("@FieldNameValues", SqlDbType.VarChar, 8000);
                parameters[2].Value = FieldNameValues;

                objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters);

                return objDataSet;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// Insert Control Management
        /// </summary>
        /// <returns></returns>
        public int InsertControlMgm(string FieldNameValue, string ToShowControl, string VersionId, string FormId, string ParentId, string AddedBy)
        {

            string spName = "[EVO_Insert_ControlMgm]";
            int returnValue = 0;
            try
            {
                SqlParameter[] parameters = new SqlParameter[6];
                parameters[0] = new SqlParameter("@FieldName", SqlDbType.VarChar);
                parameters[0].Value = FieldNameValue;
                parameters[1] = new SqlParameter("@ToShowControls", SqlDbType.VarChar);
                parameters[1].Value = ToShowControl;
                parameters[2] = new SqlParameter("@VersionId", SqlDbType.Int);
                parameters[2].Value = Convert.ToInt32(VersionId);
                parameters[3] = new SqlParameter("@FormId", SqlDbType.Int);
                parameters[3].Value = Convert.ToInt32(FormId);
                parameters[4] = new SqlParameter("@ParentId", SqlDbType.Int);
                parameters[4].Value = Convert.ToInt32(ParentId);
                parameters[5] = new SqlParameter("@AddedBy", SqlDbType.Int);
                parameters[5].Value = Convert.ToInt32(AddedBy);

                //SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                returnValue = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                return returnValue;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }

        /// <summary>
        /// Get assign hidden controls of visible control values
        /// </summary>
        /// <param name="TemplateID">Form ID of the template</param>
        /// <returns></returns>
        public DataSet GetVisibleToHiddenControlValues(int FormId, int versionid, int forParent)
        {
            DataSet dsControls = null;

            SqlParameter[] oParams = new SqlParameter[3];
            oParams[0] = new SqlParameter("@FormId", FormId);
            oParams[1] = new SqlParameter("@VersionId", versionid);
            oParams[2] = new SqlParameter("@ForParent", forParent);

            dsControls = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, "EVO_GetVisibleToHiddenControlValues", oParams);

            if (dsControls != null && dsControls.Tables[0].Rows.Count > 0)
            {
                return dsControls;
            }
            else
            {
                return null;
            }
        }

        public DataSet GetControlsforEncrypt(int FormId, int versionid)
        {
            DataSet dsControls = null;

            SqlParameter[] oParams = new SqlParameter[2];
            oParams[0] = new SqlParameter("@FormId", FormId);
            oParams[1] = new SqlParameter("@VersionId", versionid);

            dsControls = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, "EVO_GetControlsForEncrypt", oParams);

            if (dsControls != null && dsControls.Tables[0].Rows.Count > 0)
            {
                return dsControls;
            }
            else
            {
                return null;
            }


        }

        public bool AddEncryptControlDetails(int FormID, int VersionID, String items, string AddedBy)
        {
            bool result = false;
            int rowsEffected = 0;
            try
            {
                string spName = "EVO_Insert_EncryptControlDetails";
                SqlParameter[] parameters = new SqlParameter[6];
                parameters[0] = new SqlParameter("@FormID", FormID);
                parameters[1] = new SqlParameter("@VersionID", VersionID);
                parameters[2] = new SqlParameter("@FieldItems", items);
                parameters[3] = new SqlParameter("@AddedBy", AddedBy);
                //parameters[4] = new SqlParameter("@flag", flag);
                rowsEffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                if (rowsEffected > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;

        }


        public void DeleteEncryptControlDetails(int formID, int versionID)
        {
            bool result = false;
            int noOfEffectedRows = 0;
            try
            {
                string spName = "EVO_Delete_EncryptControlDetails";
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@FormID", formID);
                parameters[1] = new SqlParameter("@VersionID", versionID);
                noOfEffectedRows = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                //if (noOfEffectedRows > 0)
                //{
                //    result = true;
                //}
            }
            catch (Exception ex)
            {
                throw ex;
            }
            //return result;

        }
        /// <summary>
        /// Delete assign control mgm
        /// </summary>
        /// <param name="TemplateID">CMID </param>
        /// <returns></returns>
        public void DeleteControlMgm(int CMID)
        {

            SqlParameter[] oParams = new SqlParameter[1];
            oParams[0] = new SqlParameter("@CMID", CMID);

            DAL.SqlHelper.ExecuteNonQuery(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, "EVO_DeleteControlMgm", oParams);


        }


        /// <summary>
        /// Send mail to template assigned mail ids
        /// </summary>
        /// <param name="TransId">TransId </param>
        /// <returns></returns>
        public void EVOSendMailForTemplate(int TransId)
        {

            SqlParameter[] oParams = new SqlParameter[1];
            oParams[0] = new SqlParameter("@TransId", TransId);

            DAL.SqlHelper.ExecuteNonQuery(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, "EVO_SendMailTemplate", oParams);
            //DAL.SqlHelper.ExecuteNonQuery(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, "EVO_SendMailForTemplate", oParams);

        }

        /// <summary>
        /// Check for control having hidden fields
        /// </summary>
        /// <param name="TransId">TransId </param>
        /// <returns></returns>
        public int EVOControlExistsForHidden(int Formid, int VersionId, string ControlName)
        {
            int result = 0;
            DataSet ds = new DataSet();
            SqlParameter[] oParams = new SqlParameter[3];
            oParams[0] = new SqlParameter("@FormId", Formid);
            oParams[1] = new SqlParameter("@VersionId", VersionId);
            oParams[2] = new SqlParameter("@ControlName", ControlName);

            ds = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, "EVO_ControlExistsForHidden", oParams);

            result = Convert.ToInt16(ds.Tables[0].Rows[0]["Result"].ToString());

            return result;
        }

        #endregion
    }

}