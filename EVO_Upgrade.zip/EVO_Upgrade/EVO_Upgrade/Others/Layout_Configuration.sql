USE [Relish_EVO]
GO

/****** Object:  Table [dbo].[Layout_Configuration]    Script Date: 29-05-2019 10:35:54 ******/
DROP TABLE [dbo].[Layout_Configuration]
GO

/****** Object:  Table [dbo].[Layout_Configuration]    Script Date: 29-05-2019 10:35:54 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Layout_Configuration](
	[LayoutID] [bigint] IDENTITY(1,1) NOT NULL,
	[FormID] [bigint] NULL,
	[VersionID] [bigint] NULL,
	[TempleteID] [bigint] NULL,
	[BackgroundImage] [varchar](500) NULL,
	[BackgroundColor] [varchar](50) NULL,
	[FontFamily] [varchar](100) NULL,
	[FontSize] [varchar](50) NULL,
	[FontColor] [varchar](50) NULL,
 CONSTRAINT [PK_Layout_Configuration] PRIMARY KEY CLUSTERED 
(
	[LayoutID] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]
GO


