USE [Relish_EVO]
GO

/****** Object:  StoredProcedure [dbo].[EVO_Select_FormsForReports]    Script Date: 06-05-2019 16:33:18 ******/
DROP PROCEDURE [dbo].[EVO_Select_FormsForReports]
GO

/****** Object:  StoredProcedure [dbo].[EVO_Select_FormsForReports]    Script Date: 06-05-2019 16:33:18 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--sp_helptext 'EVO_Select_FormsForReports'

--exec EVO_Select_FormsForReports 1,'FormVersions',1268,null,null,'',0
        
        
CREATE PROCEDURE [dbo].[EVO_Select_FormsForReports]        
(        
 @UserID AS Int,         
 @Module AS Varchar(50),        
 @FormID AS Int,        
 @StartDate AS Varchar(50) = NULL,         
 @EndDate AS Varchar(50) = NULL,        
 @EmpName AS VARCHAR(50)= NULL,        
 @IsDTMS INT =0        
)        
/*        
 Created By: Imran Momin        
 Created Date: 29-JAN-2008        
 Modified By: Imran Momin        
 Modified Date: 02-JUL-2008        
 Modified By : Aarti Barve        
 Modified Date: 4-May-2011        
 Modified By:Koshal Goswami        
 Modified Date:05-JUN-2013        
 Description: Modified for when @Module = FormVersionsA it will check form is iseditable or not if yes then data return from EVO_Transaction_Archived,        
     Added New Module FormVersionsViewLog for view log report. It will select all the version from EVO_Transaction and EVO_Transaction_ProcessFlow        
     Changes in Module FormVersions added UNION with EVO_Transaction_ProcessFlow            
         
*/        
AS        
BEGIN         
IF(@EmpName IS NULL)        
BEGIN        
SET @EmpName = ''         
END         
DECLARE @IsEditable INT         
SET @IsEditable = 0        
        
SELECT @IsEditable = ISNULL(IsEditable,0) FROM EVO_Main WHERE FormID = @FormID         
        
 IF (@Module = 'FormVersions')        
  --Get Forms details as per its ID        
  BEGIN  
  IF(@StartDate IS NULL OR @EndDate IS NULL) 
  BEGIN 
   SELECT DISTINCT EFV.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName,         
     EFV.AddedBy,(CONVERT(VARCHAR,EFV.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EFV.AddedWhen,114)) AS AddedWhen, EFV.IsActive, EFV.IsActive As Status        
   FROM EVO_Main EM        
     INNER JOIN EVO_Transaction ET ON ET.FormID = EM.FormID        
     INNER JOIN EVO_FormVersions EFV ON EFV.VersionID = ET.VersionID        
     INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
   WHERE EM.FormID = @FormID        
     AND ET.IsActive = 1 AND EM.IsActive = 1           
   --ORDER BY EFV.FormID Desc,EFV.VersionId Desc        
   UNION        
   SELECT DISTINCT EFV.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName,         
     EFV.AddedBy,(CONVERT(VARCHAR,EFV.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EFV.AddedWhen,114)) AS AddedWhen, EFV.IsActive, EFV.IsActive As Status        
   FROM EVO_Main EM        
     INNER JOIN EVO_Transaction_ProcessFlow ET ON ET.FormID = EM.FormID        
     INNER JOIN EVO_FormVersions EFV ON EFV.VersionID = ET.VersionID        
     INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
   WHERE EM.FormID = @FormId        
     AND ET.IsActive = 1 AND EM.IsActive = 1  
	 AND ET.AddedWhen >= DATEADD(DAY,-3,GETDATE()) AND ET.AddedWhen <= GETDATE()       
   ORDER BY EFV.FormID Desc,EFV.VersionId Desc     
  END
  ELSE
  BEGIN
  SELECT DISTINCT EFV.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName,         
     EFV.AddedBy,(CONVERT(VARCHAR,ET.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),ET.AddedWhen,114)) AS AddedWhen, EFV.IsActive, EFV.IsActive As Status        
   FROM EVO_Main EM        
     INNER JOIN EVO_Transaction ET ON ET.FormID = EM.FormID        
     INNER JOIN EVO_FormVersions EFV ON EFV.VersionID = ET.VersionID        
     INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
   WHERE EM.FormID = @FormID        
     AND ET.IsActive = 1 AND EM.IsActive = 1    
  --Added by Bappa  
  AND ET.AddedWhen >= @StartDate AND ET.AddedWhen <= @EndDate    
  --End             
   UNION        
   SELECT DISTINCT EFV.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName,         
     EFV.AddedBy,(CONVERT(VARCHAR,ET.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),ET.AddedWhen,114)) AS AddedWhen, EFV.IsActive, EFV.IsActive As Status        
   FROM EVO_Main EM        
     INNER JOIN EVO_Transaction_ProcessFlow ET ON ET.FormID = EM.FormID        
     INNER JOIN EVO_FormVersions EFV ON EFV.VersionID = ET.VersionID        
     INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
   WHERE EM.FormID = @FormId        
     AND ET.IsActive = 1 AND EM.IsActive = 1           
  --Added by Bappa  
  AND ET.AddedWhen >= @StartDate AND ET.AddedWhen <= @EndDate    
  --End     
   ORDER BY EFV.FormID Desc,EFV.VersionId Desc   
  END   
   Print -2        
  END        
 IF (@Module = 'FormVersionsViewLog')        
  --Get Forms details as per its ID        
  BEGIN        
   SELECT DISTINCT EFV.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName,         
     EFV.AddedBy,(CONVERT(VARCHAR,EFV.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EFV.AddedWhen,114)) AS AddedWhen, EFV.IsActive, EFV.IsActive As Status        
   FROM EVO_Main EM        
     INNER JOIN EVO_Transaction ET ON ET.FormID = EM.FormID        
     INNER JOIN EVO_FormVersions EFV ON EFV.VersionID = ET.VersionID        
     INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
   WHERE EM.FormID = @FormID        
     AND ET.IsActive = 1 AND EM.IsActive = 1        
   --ORDER BY EFV.FormID Desc,EFV.VersionId Desc        
   UNION         
   SELECT DISTINCT EFV.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName,         
     EFV.AddedBy,(CONVERT(VARCHAR,EFV.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EFV.AddedWhen,114)) AS AddedWhen, EFV.IsActive, EFV.IsActive As Status        
   FROM EVO_Main EM        
     INNER JOIN EVO_Transaction_ProcessFlow ET ON ET.FormID = EM.FormID        
     INNER JOIN EVO_FormVersions EFV ON EFV.VersionID = ET.VersionID        
     INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
   WHERE EM.FormID = @FormID        
     AND ET.IsActive = 1 AND EM.IsActive = 1        
   ORDER BY EFV.FormID Desc,EFV.VersionId Desc        
   Print -8        
  END        
 ELSE IF(@Module = 'FormVersionsA')        
  BEGIN        
   IF(@IsEditable <> 1)        
    BEGIN        
     SELECT DISTINCT EFV.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName,         
       EFV.AddedBy,(CONVERT(VARCHAR,EFV.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EFV.AddedWhen,114)) AS AddedWhen, EFV.IsActive, EFV.IsActive As Status        
     FROM EVO_Main EM        
       INNER JOIN EVO_Transaction_Archived ETA ON ETA.FormID = EM.FormID        
       INNER JOIN EVO_FormVersions EFV ON EFV.VersionID = ETA.VersionID        
       INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
     WHERE EM.FormID = @FormID        
       AND ETA.IsActive = 1 AND EM.IsActive = 1        
     ORDER BY EFV.FormID Desc,EFV.VersionId Desc        
    END         
   ELSE         
    BEGIN        
     SELECT DISTINCT EFV.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName,         
       EFV.AddedBy,(CONVERT(VARCHAR,EFV.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EFV.AddedWhen,114)) AS AddedWhen, EFV.IsActive, EFV.IsActive As Status        
     FROM EVO_Main EM        
       INNER JOIN EVO_Transaction_ProcessFlow ETA ON ETA.FormID = EM.FormID        
       INNER JOIN EVO_FormVersions EFV ON EFV.VersionID = ETA.VersionID        
       INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
     WHERE EFV.FormID = @FormID        
       AND ETA.IsActive = 1 AND EM.IsActive = 1        
     ORDER BY EFV.FormID Desc,EFV.VersionId Desc        
    END         
   Print -1        
  END        
 ELSE IF (@Module = 'ModifyFormVersions')        
  BEGIN        
        
   SELECT EFV.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName, EFV.XMLFileName,        
     EFV.AddedBy,EFV.AddedWhen, (CONVERT(VARCHAR,EFV.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EFV.AddedWhen,114)) AS AddedWhen, EM.IsActive, EFV.IsActive As Status,        
     EFV.IsScrabblePad         
   FROM EVO_Main EM         
      INNER JOIN EVO_FormVersions EFV ON EFV.FormID = EM.FormID        
      INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
      INNER JOIN Central_Employee_main CE ON CE.EmpUserID = EM.EmpUserID        
   WHERE EM.FormID = @FormID         
     AND EM.IsActive = 'True'        
     AND (((CAST(CE.Employeeid AS VARCHAR(50)) like '%' +@EmpName + '%' OR EM.AddedBy like '%' +@EmpName + '%' OR CE.FirstName like '%' +@EmpName + '%') AND @EmpName <> '') OR (@EmpName =''))         
   ORDER BY EM.FormID Desc,EFV.VersionID Desc        
   Print 0        
  END        
        
 ELSE        
 IF ((SELECT UserID FROM EVO_AdminUserRights WHERE UserID = @UserID AND RoleID = 1 AND IsActive = 'true') > 0)        
  --If Super Admin users (Role = 1)        
  BEGIN        
   IF ( @Module = 'Reports' )        
    BEGIN            
     SELECT EFV.FormID, EM.FormName,  EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName,         
       EFV.AddedBy, (CONVERT(VARCHAR,EFV.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EFV.AddedWhen,114)) AS AddedWhen, EM.IsActive,EM.IsEditable        
     FROM EVO_Main EM         
        INNER JOIN EVO_FormVersions EFV On EFV.FormID = EM.FormID        
        INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
     WHERE EM.IsActive = 'True'         
       AND EFV.IsActive = 'True'        
       AND EM.CategoryID<>4        
       AND ISNULL(EM.IsDTMS,0) = @IsDTMS        
     ORDER BY EM.FormID Desc,EFV.VersionID Desc        
     Print 1        
    END        
   ELSE IF ( @Module = 'ModifyForm' )        
    BEGIN        
     SELECT EM.FormID, EM.FormName,  EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName,         
        EM.AddedBy, (CONVERT(VARCHAR,EM.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EM.AddedWhen,114)) AS AddedWhen, EM.IsActive,EFV.IsActive        
      FROM EVO_Main EM         
         INNER JOIN EVO_FormVersions EFV On EFV.FormID = EM.FormID        
         INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
         INNER JOIN Central_Employee_main CE ON CE.EmpUserID = EM.EmpUserID        
      WHERE --EM.IsActive = 'True'         
      EFV.IsActive = 'True'        
      AND (((CAST(CE.Employeeid AS VARCHAR(50)) like '%' +@EmpName + '%' OR EM.AddedBy like '%' +@EmpName + '%' OR CE.FirstName like '%' +@EmpName + '%') AND @EmpName <> '') OR (@EmpName =''))             
      AND ( (EM.AddedWhen>=@Startdate AND EM.AddedWhen<=@Enddate  AND @Startdate IS NOT NULL ) OR (@Startdate IS NULL))        
                
     UNION        
        
     SELECT EM.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName,EM.FormDesc,        
     (SELECT MAX(VersionID) FROM EVO_FormVersions WHERE FormID = EM.FormID AND IsActive = 0) AS VersionID,        
     (SELECT MAX(VersionName) FROM EVO_FormVersions WHERE FormID = EM.FormID AND IsActive = 0) AS VersionName,        
       EM.AddedBy, (CONVERT(VARCHAR,EM.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EM.AddedWhen,114)) AS AddedWhen, EM.IsActive,EFV.IsActive        
     FROM EVO_Main EM        
        INNER JOIN EVO_FormVersions EFV On EFV.FormID = EM.FormID        
        INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
        INNER JOIN Central_Employee_main CE ON CE.EmpUserID = EM.EmpUserID        
     WHERE EM.FormID NOT IN( SELECT FormID FROM EVO_FormVersions WHERE IsActive = 1)        
       --AND EM.IsActive = 'True'         
       AND EFV.IsActive = 'False'          
       AND (((CAST(CE.Employeeid AS VARCHAR(50)) like '%' +@EmpName + '%' OR EM.AddedBy like '%' +@EmpName + '%' OR CE.FirstName like '%' +@EmpName + '%') AND @EmpName <> '') OR (@EmpName =''))          
       AND ( (EM.AddedWhen>=@Startdate AND EM.AddedWhen<=@Enddate  AND @Startdate IS NOT NULL ) OR (@Startdate IS NULL))        
     GROUP BY EM.FormID,EM.FormName, EM.CategoryID, ECM.CategoryName,EM.FormDesc,         
       EM.AddedBy, EM.AddedWhen, EM.IsActive, EFV.IsActive        
     ORDER BY EM.FormID Desc,EFV.VersionID Desc        
        
     Print 1.1        
    END        
   ELSE        
    BEGIN        
     SELECT EFV.FormID, EM.FormName,  EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName,         
       EM.AddedBy, (CONVERT(VARCHAR,EM.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EM.AddedWhen,114)) AS AddedWhen, EM.IsActive        
     FROM EVO_Main EM         
        INNER JOIN EVO_FormVersions EFV On EFV.FormID = EM.FormID        
        INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
     --WHERE EM.IsActive = 'True'        
     ORDER BY EM.FormID Desc,EFV.VersionID Desc        
     Print 1.2        
    END        
  END        
 ELSE IF ((SELECT UserID FROM EVO_AdminUserRights WHERE UserID = @UserID AND RoleID = 2 AND IsActive = 'true') > 0)        
  --If Admin user (Role = 2)        
  BEGIN        
        
   IF ( @Module = 'Reports' )        
   BEGIN        
    SELECT EM.FormID, EM.FormName,  EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName,         
      EFV.AddedBy, (CONVERT(VARCHAR,EFV.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EFV.AddedWhen,114)) AS AddedWhen, EM.IsActive,EM.IsEditable        
    FROM EVO_Main EM        
       INNER JOIN EVO_AdminUserRights EAUR On EAUR.UserID = EM.EmpUserID          
       INNER JOIN EVO_FormVersions EFV On EFV.FormID = EM.FormID        
       INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
    WHERE EAUR.UserID = @UserID        
      AND EAUR.RoleID = 2        
      AND EM.IsActive = 'True'         
      AND EFV.IsActive = 'True'        
      AND ISNULL(EM.IsDTMS,0) = @IsDTMS        
    --ORDER BY EM.FormID Desc,EFV.VersionID Desc - COMMENTED BY AARTI AND ADDED UNION.. AS THE ADMIN WITH REPORTS ACCESS WAS NOT ABLE TO VIEW ALL THE LOGGERS        
        
    UNION        
        
    SELECT EM.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName,         
      EFV.AddedBy, (CONVERT(VARCHAR,EFV.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EFV.AddedWhen,114)) AS AddedWhen, EM.IsActive,EM.IsEditable        
    FROM EVO_AccessRights EAR        
       INNER JOIN EVO_Main EM On EM.FormID = EAR.FormID        
       INNER JOIN EVO_FormVersions EFV On EFV.FormID = EM.FormID        
       INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
WHERE UserID = @UserID         
      AND (EAR.IsReportLimerickAccess  = 'True' OR IsReportWaterFordAccess = 'True' OR IsReportMumbaiAccess ='True')      
      AND EAR.IsActive = 'True'         
      AND EFV.IsActive = 'True'         
      AND EM.IsActive = 'True'        
      AND ISNULL(EM.IsDTMS,0) = @IsDTMS        
    ORDER BY EM.FormID Desc,EFV.VersionID Desc        
        
    Print 2        
   END        
   ELSE IF ( @Module = 'ModifyForm' ) -- SP UPDATED BY AARTI ON 12-APR-2011 -- Again updated on 04/5/2011  AS BUG RAISED BY FLAVIA DURING INTERNAL CR TESTING        
   BEGIN        
     SELECT EM.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName,EM.FormDesc, EFV.VersionId as VersionId, EFV.VersionName ,         
        EM.AddedBy, (CONVERT(VARCHAR,EM.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EM.AddedWhen,114)) AS AddedWhen, EM.IsActive,EFV.IsActive         
     FROM  EVO_Main EM         
           INNER JOIN EVO_AdminUserRights EAUR On EAUR.UserID = EM.EmpUserID        
           INNER JOIN EVO_FormVersions EFV On EFV.FormID = EM.FormID        
           INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
           INNER JOIN Central_Employee_main CE ON CE.EmpUserID = EM.EmpUserID        
     WHERE EAUR.UserID = @UserID        
     AND EAUR.RoleID = 2 AND EAUR.IsActive = 'True'        
     --AND EM.IsActive = 'True'         
     AND EFV.IsActive = 'True'  -- CREATED BY THE USER        
     AND (((CAST(CE.Employeeid AS VARCHAR(50)) like '%' +@EmpName + '%' OR EM.AddedBy like '%' +@EmpName + '%' OR CE.FirstName like '%' +@EmpName + '%') AND @EmpName <> '') OR (@EmpName =''))          
     AND ( (EM.AddedWhen>=@Startdate AND EM.AddedWhen<=@Enddate  AND @Startdate IS NOT NULL ) OR (@Startdate IS NULL))        
     UNION        
        
     SELECT EM.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName,EM.FormDesc,        
     (SELECT MAX(VersionID) FROM EVO_FormVersions WHERE FormID = EM.FormID AND IsActive = 1) AS VersionID,        
     (SELECT MAX(VersionName) FROM EVO_FormVersions WHERE FormID = EM.FormID AND IsActive = 1) AS VersionName,        
        EM.AddedBy, (CONVERT(VARCHAR,EM.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EM.AddedWhen,114)) AS AddedWhen, EM.IsActive,EFV.IsActive        
     FROM  EVO_AccessRights EAR         
        LEFT JOIN EVO_Main EM ON EM.FormID = EAR.FormID        
        LEFT JOIN EVO_FormVersions EFV On EFV.FormID = EM.FormID        
        INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
        INNER JOIN Central_Employee_main CE ON CE.EmpUserID = EM.EmpUserID        
     WHERE UserID = @UserID         
      AND EM.FormID NOT IN( SELECT FormID FROM EVO_Main WHERE EmpUserId=@UserID)        
      AND EFV.IsActive = 1        
      AND EAR.CanManage = 1        
      --AND EM.IsActive = 'True'      -- USER SUB ADMIN OF AND VERSION ACTIVE        
      AND (((CAST(CE.Employeeid AS VARCHAR(50)) like '%' +@EmpName + '%' OR EM.AddedBy like '%' +@EmpName + '%' OR CE.FirstName like '%' +@EmpName + '%') AND @EmpName <> '') OR (@EmpName =''))          
      AND ( (EM.AddedWhen>=@Startdate AND EM.AddedWhen<=@Enddate  AND @Startdate IS NOT NULL ) OR (@Startdate IS NULL))        
        
     UNION        
        
     SELECT EM.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName,EM.FormDesc, 0 as VersionId,         
      (SELECT MAX(VersionName) FROM EVO_FormVersions WHERE FormID = EM.FormID AND IsActive = 0) AS VersionName,         
         EM.AddedBy, (CONVERT(VARCHAR,EM.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EM.AddedWhen,114)) AS AddedWhen, EM.IsActive,EM.IsActive         
      FROM  EVO_Main EM         
         INNER JOIN EVO_AdminUserRights EAUR On EAUR.UserID = EM.EmpUserID        
         INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
         INNER JOIN Central_Employee_main CE ON CE.EmpUserID = EM.EmpUserID        
      WHERE EM.EmpUserID = @UserID        
      AND EM.FormID NOT IN( SELECT FormID FROM EVO_FormVersions WHERE IsActive = 1)        
      AND EAUR.RoleID = 2        
      --AND EM.IsActive = 'True'     -- USER ADMIN OF THE FORM AND VERSION NOT ACTIVE        
      AND (((CAST(CE.Employeeid AS VARCHAR(50)) like '%' +@EmpName + '%' OR EM.AddedBy like '%' +@EmpName + '%' OR CE.FirstName like '%' +@EmpName + '%') AND @EmpName <> '') OR (@EmpName =''))          
      AND ( (EM.AddedWhen>=@Startdate AND EM.AddedWhen<=@Enddate  AND @Startdate IS NOT NULL ) OR (@Startdate IS NULL))        
        
        
     UNION        
        
     SELECT EM.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName,EM.FormDesc,        
     (SELECT MAX(VersionID) FROM EVO_FormVersions WHERE FormID = EM.FormID AND IsActive = 0) AS VersionID,        
     (SELECT MAX(VersionName) FROM EVO_FormVersions WHERE FormID = EM.FormID AND IsActive = 0) AS VersionName,        
        EM.AddedBy, (CONVERT(VARCHAR,EM.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EM.AddedWhen,114)) AS AddedWhen, EM.IsActive,EFV.IsActive        
     FROM  EVO_AccessRights EAR         
        LEFT JOIN EVO_Main EM ON EM.FormID = EAR.FormID        
        LEFT JOIN EVO_FormVersions EFV On EFV.FormID = EM.FormID        
        INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
        INNER JOIN Central_Employee_main CE ON CE.EmpUserID = EM.EmpUserID        
     WHERE UserID = @UserID         
      AND EM.FormID NOT IN(  SELECT FormID FROM EVO_FormVersions WHERE IsActive = 1)        
      AND EAR.CanManage = 1        
      --AND EM.IsActive = 'True'      -- USER SUB ADMIN OF AND VERSION NOT ACTIVE        
      AND (((CAST(CE.Employeeid AS VARCHAR(50)) like '%' +@EmpName + '%' OR EM.AddedBy like '%' +@EmpName + '%' OR CE.FirstName like '%' +@EmpName + '%') AND @EmpName <> '') OR (@EmpName =''))          
      AND ( (EM.AddedWhen>=@Startdate AND EM.AddedWhen<=@Enddate  AND @Startdate IS NOT NULL ) OR (@Startdate IS NULL))        
        
        
     GROUP BY EM.FormID,EM.FormName, EM.CategoryID, ECM.CategoryName,EM.FormDesc,         
        EM.AddedBy, EM.AddedWhen, EM.IsActive, EFV.IsActive        
     ORDER BY EM.FormID Desc --, EFV.VersionID Desc        
    Print 2.1        
   END       -- UPDATED TILL HERE        
  END        
  ELSE        
   --If admin for particular forms        
  BEGIN        
   IF ( @Module = 'Reports' )        
   BEGIN        
    SELECT EM.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName,         
      EFV.AddedBy, (CONVERT(VARCHAR,EFV.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EFV.AddedWhen,114)) AS AddedWhen, EM.IsActive,EM.IsEditable        
    FROM EVO_AccessRights EAR        
       INNER JOIN EVO_Main EM On EM.FormID = EAR.FormID        
       INNER JOIN EVO_FormVersions EFV On EFV.FormID = EM.FormID        
       INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
    WHERE UserID = @UserID        
      AND (EAR.IsReportLimerickAccess  = 'True' OR IsReportWaterFordAccess = 'True' OR IsReportMumbaiAccess ='True')      
      AND EAR.IsActive = 'True'        
      AND EFV.IsActive = 'True'        
      AND EM.IsActive = 'True'        
      AND ISNULL(EM.IsDTMS,0) = @IsDTMS        
    ORDER BY EM.FormID Desc,EFV.VersionID Desc        
    Print 3        
   END        
   ELSE IF ( @Module = 'ModifyForm' )  -- Again updated on 28/4/2011  AS BUG RAISED BY FLAVIA DURING INTERNAL CR TESTING        
   BEGIN        
     SELECT EM.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName, EM.FormDesc, EFV.VersionId, EFV.VersionName,         
       EM.AddedBy, (CONVERT(VARCHAR,EM.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EM.AddedWhen,114)) AS AddedWhen, EM.IsActive,EFV.IsActive        
     FROM EVO_AccessRights EAR        
        INNER JOIN EVO_Main EM On EM.FormID = EAR.FormID        
        INNER JOIN EVO_FormVersions EFV On EFV.FormID = EM.FormID      
        INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
        INNER JOIN Central_Employee_main CE ON CE.EmpUserID = EM.EmpUserID        
     WHERE UserID = @UserID        
       AND EAR.CanManage = 'True'        
       AND EAR.IsActive = 'True'        
       AND EFV.IsActive = 'True'        
       --AND EM.IsActive = 'True'        
       AND (((CAST(CE.Employeeid AS VARCHAR(50)) like '%' +@EmpName + '%' OR EM.AddedBy like '%' +@EmpName + '%' OR CE.FirstName like '%' +@EmpName + '%') AND @EmpName <> '') OR (@EmpName =''))          
       AND ( (EM.AddedWhen>=@Startdate AND EM.AddedWhen<=@Enddate  AND @Startdate IS NOT NULL ) OR (@Startdate IS NULL))        
        
 UNION        
        
     SELECT EM.FormID, EM.FormName, EM.CategoryID, ECM.CategoryName, EM.FormDesc, 0,        
     (SELECT MAX(VersionName) FROM EVO_FormVersions WHERE FormID = EM.FormID AND IsActive = 0) AS VersionName,        
       EM.AddedBy, (CONVERT(VARCHAR,EM.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EM.AddedWhen,114)) AS AddedWhen, EM.IsActive,EM.IsActive        
     FROM EVO_AccessRights EAR        
        INNER JOIN EVO_Main EM On EM.FormID = EAR.FormID        
        INNER JOIN EVO_CategoryMain ECM ON ECM.CategoryID = EM.CategoryID        
        INNER JOIN Central_Employee_main CE ON CE.EmpUserID = EM.EmpUserID        
     WHERE UserID = @UserID        
       AND EM.FormID NOT IN( SELECT FormID FROM EVO_FormVersions WHERE IsActive = 1)        
       AND EAR.CanManage = 'True'        
       AND EAR.IsActive = 'True'        
       --AND EM.IsActive = 'True'        
       AND (((CAST(CE.Employeeid AS VARCHAR(50)) like '%' +@EmpName + '%' OR EM.AddedBy like '%' +@EmpName + '%' OR CE.FirstName like '%' +@EmpName + '%') AND @EmpName <> '') OR (@EmpName =''))          
       AND ( (EM.AddedWhen>=@Startdate AND EM.AddedWhen<=@Enddate  AND @Startdate IS NOT NULL ) OR (@Startdate IS NULL))        
     ORDER BY EM.FormID Desc,EFV.VersionID Desc        
    Print 4        
   END        
  END        
END
GO


