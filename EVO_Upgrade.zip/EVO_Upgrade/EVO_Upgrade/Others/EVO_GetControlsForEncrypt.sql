USE [Relish_EVO]
GO

/****** Object:  StoredProcedure [dbo].[EVO_GetControlsForEncrypt]    Script Date: 19-03-2019 19:56:07 ******/
DROP PROCEDURE [dbo].[EVO_GetControlsForEncrypt]
GO

/****** Object:  StoredProcedure [dbo].[EVO_GetControlsForEncrypt]    Script Date: 19-03-2019 19:56:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [dbo].[EVO_GetControlsForEncrypt](@FormId INT,@VersionId INT) --210,1269
AS 
SELECT  FieldID, Alias AS FieldName    
FROM EVO_FormFields FF JOIN EVO_FormVersions FV 
ON FF.FormId = FV.FormId AND FF.VersionId = FV.VersionId
WHERE  FV.FormId =@FormId 
       AND FV.VersionId = @VersionId
       --AND FieldDisplayType = 'TextBox'
	   AND ControlID IN (1,1046)


SELECT EF.FieldID, Alias AS FieldName  
FROM EVO_Encryptfielddetails EF
LEFT OUTER JOIN EVO_FormFields FF ON EF.FieldID = FF.FieldID
WHERE EF.FormID = @FormId
	  AND EF.VersionId = @VersionId

GO


