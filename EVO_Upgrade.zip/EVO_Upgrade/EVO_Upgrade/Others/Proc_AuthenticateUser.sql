USE [Relish_EVO]
GO

/****** Object:  StoredProcedure [dbo].[Proc_AuthenticateUser]    Script Date: 15-04-2019 11:55:33 ******/
DROP PROCEDURE [dbo].[Proc_AuthenticateUser]
GO

/****** Object:  StoredProcedure [dbo].[Proc_AuthenticateUser]    Script Date: 15-04-2019 11:55:33 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[Proc_AuthenticateUser]
(
  @NTLogin VARCHAR(MAX)=''
)
AS
BEGIN

	--SELECT   UA.NTLogin
	--		,RT.RoleName
	--		,UA.RoleType
	--		,CEM.EmployeeID
	--		,CEM.FirstName
	--		,CEM.LastName
	--		,CEM.Email
	--		,CEM.DesignationID
	--		,Desg.name AS DesignationName
	--		,CEM.DepartmentID
	--		,EmpDep.name AS DepartmentName
	--		,CEM.Location
	--		,ISNULL(CEMBoss1.EmployeeID,0) AS Boss1Id
	--		,ISNULL(CEMBoss1.FirstName+' '+CEMBoss1.LastName,'') AS Boss1Name
	--		,ISNULL(CEMBoss2.EmployeeID,0) AS Boss2Id
	--		,ISNULL(CEMBoss2.FirstName+' '+CEMBoss2.LastName,'') AS Boss2Name
	--FROM TRN_UserAccess UA
	--INNER JOIN MST_RoleTypes RT ON RT.Id=UA.RoleType
	--LEFT JOIN Central_Employee_Main CEM  ON CEM.Login=UA.NTLogin
	--LEFT JOIN Departments EmpDep ON EmpDep.id=CEM.DepartmentID
	--LEFT JOIN Designations Desg ON Desg.id=CEM.DesignationID
	--LEFT JOIN Central_Employee_Main CEMBoss1 ON CEMBoss1.EmployeeID=CEM.BossID
	--LEFT JOIN Central_Employee_Main CEMBoss2 ON CEMBoss2.EmployeeID=CEMBoss1.BossID
	--WHERE  CEM.Status=1 AND UA.IsActive=1
	--AND UA.NTLogin=@NTLogin

SELECT CEM.Login AS NTLogin
	,CEM.EmployeeID
	,CEM.FirstName
	,'' AS MiddleName
	,CEM.LastName
	,CEM.Email
	,CEM.CostCentreID
	,CEM.Location
	,'' AS RoleName
	,'' AS RoleType
	,CEM.DesignationID
	,'' AS DesignationName
	,CEM.DepartmentID
	,'' AS DepartmentName
	,CEM.Location
	,0 AS Boss1Id
	,'' AS Boss1Name
	,0 AS Boss2Id
	,'' AS Boss2Name
FROM Central_Employee_Main CEM
WHERE  CEM.Status=1 AND CEM.Login=@NTLogin

END
GO


