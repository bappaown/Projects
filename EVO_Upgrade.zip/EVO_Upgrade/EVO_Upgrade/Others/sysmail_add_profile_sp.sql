USE [Relish_EVO]
GO
-- Create a Database Mail profile  
EXECUTE msdb.dbo.sysmail_add_profile_sp  
    @profile_name = 'Relish_EVO',  
    @description = 'Profile used for administrative mail.' ;  