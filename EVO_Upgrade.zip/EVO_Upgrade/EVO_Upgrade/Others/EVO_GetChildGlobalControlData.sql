USE [Relish_EVO]
GO

/****** Object:  StoredProcedure [dbo].[EVO_GetChildGlobalControlData]    Script Date: 20-12-2018 15:17:38 ******/
DROP PROCEDURE [dbo].[EVO_GetChildGlobalControlData]
GO

/****** Object:  StoredProcedure [dbo].[EVO_GetChildGlobalControlData]    Script Date: 20-12-2018 15:17:38 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[EVO_GetChildGlobalControlData]
(
@DependentControlId INT,
@SkillSetId VARCHAR(200),
@CostCentreId INT
)
AS
BEGIN

select * from Evo_GlobalControlDataStore where DependentId =@DependentControlId and
 CostCentreID = @CostCentreId and DataStoreID in (select datastoreId from 
Evo_GlobalControlDataSkillSetRelation where SkillSetId in (select * from fnSplitStringAsTable(@SkillSetId,','))  and IsActive = 1)

END




GO


