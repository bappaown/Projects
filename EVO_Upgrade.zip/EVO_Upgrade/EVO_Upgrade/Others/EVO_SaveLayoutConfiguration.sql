USE [Relish_EVO]
GO

/****** Object:  StoredProcedure [dbo].[EVO_SaveLayoutConfiguration]    Script Date: 28-05-2019 17:21:11 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROC [dbo].[EVO_SaveLayoutConfiguration]  
(
@FormId INT,
@VersionId INT,
@TempleteId INT,
@BackgroundImage varchar(500),
@BackgroundColor varchar(50),
@FontFamily varchar(100),
@FontSize varchar(50),
@FontColor varchar(50)
)
AS

BEGIN  

If Exists(Select * from Layout_Configuration Where FormID = @FormId and VersionID = @VersionId)
Begin
	Update Layout_Configuration Set TempleteID = @TempleteId, BackgroundImage = @BackgroundImage, BackgroundColor = @BackgroundColor, FontFamily = @FontFamily, FontSize = @FontSize, FontColor = @FontColor
	Where FormID=@FormId and VersionID=@VersionId
End
Else
Begin
	Insert Into Layout_Configuration Values (@FormId, @VersionId, @TempleteId, @BackgroundImage, @BackgroundColor, @FontFamily, @FontSize, @FontColor)
End

END  
  



GO


