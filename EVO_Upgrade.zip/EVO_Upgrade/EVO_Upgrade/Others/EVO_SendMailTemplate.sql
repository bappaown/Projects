USE [Relish_EVO]
GO

/****** Object:  StoredProcedure [dbo].[EVO_SendMailTemplate]    Script Date: 01-04-2019 17:04:32 ******/
DROP PROCEDURE [dbo].[EVO_SendMailTemplate]
GO

/****** Object:  StoredProcedure [dbo].[EVO_SendMailTemplate]    Script Date: 01-04-2019 17:04:32 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [dbo].[EVO_SendMailTemplate]
(@TransId VARCHAR(50))
AS

DECLARE @FormID AS Int,  
 @VersionID AS Int

 DECLARE @EmployeeId VARCHAR(50),
@EmpName VARCHAR(200),
@FormName VARCHAR(50),
@VersionName VARCHAR(50),
@TimeTaken VARCHAR(10),
@AddedBy VARCHAR(50),
@AddedWhen VARCHAR(50)

 
SELECT @FormID = FormID,@VersionID = VersionID FROM EVO_Transaction WHERE TransId = @TransId

DECLARE @SendFor VARCHAR(2000)
SET @SendFor = ''
SELECT @SendFor = TemplateEmails FROM EVO_Main WHERE FormId = @FormID 

IF(@SendFor <> '')
BEGIN
	SET @SendFor =REPLACE(@SendFor,',',';')

SELECT DISTINCT @EmployeeId = EmployeeID,@EmpName =FirstName +' '+LastName ,@FormName =EM.FormName,
@VersionName = EFV.VersionName,@AddedBy=ET.AddedBy,@AddedWhen = (CONVERT(VARCHAR,ET.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),ET.AddedWhen,114))
   FROM Evo_FormDetails EFD  
    INNER JOIN Evo_FormFields EFF ON EFF.FieldID = EFD.FieldID  
    INNER JOIN Evo_Transaction ET ON ET.TransID = EFD.TransID  
    INNER JOIN Evo_FormVersions EFV ON EFV.VersionID = ET.VersionID  
    INNER JOIN Evo_Main EM ON EM.FormID = EFD.FormID  
    INNER JOIN Central_Employee_Main CEM ON CEM.EmpUserID = ET.UserID  
    INNER JOIN Central_Department_Main CDM ON CDM.DepartmentID = CEM.DepartmentID
    INNER JOIN Evo_Main EM2 ON EM2.FormID = EFF.FormID  
    
   WHERE 
      EFD.FormID = @FormID  
    AND ET.VersionID = @VersionID  
    AND ET.TransID = @TransId 
    AND ET.IsActive = 1 AND EM.IsActive = 1

DECLARE @CapTblValue VARCHAR(MAX),@CapTblCol VARCHAR(MAX)
set @CapTblValue = ''
set @CapTblCol = ''
DECLARE @EmailBody VARCHAR(MAX)
SET @EmailBody = ''


SELECT   @CapTblValue = @CapTblValue + '' + 
  '<td bgcolor=''#EAEAEA'' align=''center''>
                <font face=''Arial''>'  + CASE WHEN EM2.CategoryID=4 THEN 't:' + EFF.Alias ELSE EFF.Alias END + ' </font>
            </td>'    , @CapTblCol = @CapTblCol + '' + '<td>' + CASE WHEN EFD.IsEncrypted = 1 THEN CAST(DECRYPTBYPASSPHRASE('Test',CONVERT(VARBINARY(MAX), EFD.DataCapture,1)) AS VARCHAR(MAX)) WHEN EFD.IsEncrypted = 0 THEN EFD.DataCapture END + '</td>'
   FROM Evo_FormDetails EFD  
    INNER JOIN Evo_FormFields EFF ON EFF.FieldID = EFD.FieldID  
    INNER JOIN Evo_Transaction ET ON ET.TransID = EFD.TransID  
    INNER JOIN Evo_FormVersions EFV ON EFV.VersionID = ET.VersionID  
    INNER JOIN Evo_Main EM ON EM.FormID = EFD.FormID  
    INNER JOIN Evo_Main EM2 ON EM2.FormID = EFF.FormID  
    
   WHERE 
      EFD.FormID = @FormID  
    AND ET.VersionID = @VersionID  
    AND ET.IsActive = 1 AND EM.IsActive = 1
    AND ET.TransId = @TransId

    
SET @EmailBody =' <html> <div style=''font-family:Arial''><div> Hi, <br/><br/> Template is logged. Details Below. </div> <br/>
                  <table border=''1'' width=''100%'' bordercolor=''#808080'' cellspacing=''0'' cellpadding=''0'' font-family=''Arial''>
                  
          
        <tr>
            <td bgcolor=''#EAEAEA'' align=''center''>
                <font face=''Arial''>TransactionID</font>
            </td>   
			<td bgcolor=''#EAEAEA'' align=''center''>
                <font face=''Arial''>Form Name</font>
            </td>          
            <td bgcolor=''#EAEAEA'' align=''center''>
                <font face=''Arial''>Version Name</font>
            </td>' + @CapTblValue + '  
			<td bgcolor=''#EAEAEA'' align=''center''>
                <font face=''Arial''>Employee Id</font>
            </td>
            <td bgcolor=''#EAEAEA'' align=''center''>
                <font face=''Arial''>Employee Name</font>
            </td>  
			<td bgcolor=''#EAEAEA'' align=''center''>
                <font face=''Arial''>Added By</font>
            </td> 
			<td bgcolor=''#EAEAEA'' align=''center''>
                <font face=''Arial''>Added When</font>
            </td>      
        </tr>
        <tr style=''font-family:Arial''>
             <td>
               '+@TransId+'
            </td>    
			<td>
               '+@FormName+'
            </td>      
            <td>
                '+ @VersionName+'
            </td> ' + @CapTblCol + ' 
			 <td>
               '+ @EmployeeId+'
            </td>
            <td>
                '+@EmpName+'
            </td> 
			<td>
                '+ @AddedBy+'
            </td> 
			 <td>
                '+ @AddedWhen+'
            </td>         
        </tr>      
    </table>
<br/>
<div> P.S: Please do not reply to this mail as this is an auto generated mail.</div> </div>
</html>'


exec msdb.dbo.sp_send_dbmail
                        @profile_name			= 'Relish_EVO' -- mail to be sent from.
                        --, @recipients           = 'Foram.Shah@TechMahindra.com;YJ00573812@TechMahindra.com;bm00563793@techmahindra.com;Kajal.Teli@TechMahindra.com'
                        , @recipients           = @SendFor
						, @subject              = 'EVO Template Details'
                        , @body                 = @EmailBody
                        , @importance           = 'High'
                        , @body_format          = 'HTML';
                        

END


GO


