USE [Relish_EVO]
GO

/****** Object:  StoredProcedure [dbo].[EVO_Select_FormFieldsWithData]    Script Date: 04-06-2019 18:08:07 ******/
DROP PROCEDURE [dbo].[EVO_Select_FormFieldsWithData]
GO

/****** Object:  StoredProcedure [dbo].[EVO_Select_FormFieldsWithData]    Script Date: 04-06-2019 18:08:07 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--Exec EVO_Select_FormFieldsWithData 1328,4494,10167761

CREATE PROC [dbo].[EVO_Select_FormFieldsWithData]  
(  
 @FormId AS int,  
 @VersionId AS int,  
 @TransId AS int  
)  
AS  
BEGIN  
 IF @TransId=0  
 BEGIN  

  SELECT EF.FieldID,EF.FormID,EF.VersionID,0 AS TransID,EF.FieldName,EF.Alias,
  (CASE WHEN CM.ControlType='Custom' OR CM.ControlType='Global' THEN ControlType +' '+ FieldDisplayType ELSE EF.FieldDisplayType END) AS FieldDisplayType,
  '' AS DataCapture,EF.ControlID,CM.ControlType,EF.PositionID,EF.IsActive 
  FROM EVO_FormFields EF  LEFT JOIN
  EVO_ControlMain CM ON EF.ControlID=CM.ControlID
  WHERE FormID = @FormId AND VersionID = @VersionID 

 END
 ELSE
 BEGIN

  SELECT DISTINCT FF.FieldID,FF.FormID,FF.VersionID,FD.TransID,FF.FieldName, FF.Alias, 
  (CASE WHEN CM.ControlType='Custom' OR CM.ControlType='Global' THEN ControlType +' '+ FieldDisplayType ELSE FF.FieldDisplayType END) AS FieldDisplayType,
  (CASE WHEN FD.IsEncrypted = 1 THEN CAST(DECRYPTBYPASSPHRASE('Test',CONVERT(VARBINARY(MAX), FD.DataCapture,1)) AS VARCHAR(MAX)) WHEN FD.IsEncrypted = 0 THEN FD.DataCapture END) AS DataCapture,  
  FF.ControlID,CM.ControlType,FF.PositionID,FF.IsActive
  FROM EVO_FormDetails AS FD INNER JOIN  
  EVO_FormFields AS FF ON FD.FieldID = FF.FieldID LEFT JOIN
  EVO_ControlMain CM ON FF.ControlID=CM.ControlID
  WHERE  FF.FormID = @FormId AND FF.VersionID = @VersionId AND FD.TransID = @TransId

 END
END  
   
GO


