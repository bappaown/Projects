USE [Relish_EVO]
GO

/****** Object:  StoredProcedure [dbo].[proc_GetAuthenticate]    Script Date: 23-05-2019 16:24:25 ******/
DROP PROCEDURE [dbo].[proc_GetAuthenticate]
GO

/****** Object:  StoredProcedure [dbo].[proc_GetAuthenticate]    Script Date: 23-05-2019 16:24:25 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

        
    
CREATE PROCEDURE[dbo].[proc_GetAuthenticate] 
(        
 @UserID Varchar(50),
 @Password Varchar(50)
)        
AS BEGIN        
         
 DECLARE @PWD VARCHAR(MAX)
 SELECT @PWD = dbo.ENCRYPT(@Password)

 SELECT CEM.Login AS NTLogin
	,CEM.EmployeeID
	,CEM.FirstName
	,'' AS MiddleName
	,CEM.LastName
	,CEM.Email
	,CEM.CostCentreID
	,CEM.Location
	,'' AS RoleName
	,'' AS RoleType
	,CEM.DesignationID
	,'' AS DesignationName
	,CEM.DepartmentID
	,'' AS DepartmentName
	,CEM.Location
	,0 AS Boss1Id
	,'' AS Boss1Name
	,0 AS Boss2Id
	,'' AS Boss2Name
FROM Central_Employee_Main CEM
WHERE  CEM.Status=1 AND CEM.Login=@UserID AND CEM.Password=@PWD

                 
END
GO


