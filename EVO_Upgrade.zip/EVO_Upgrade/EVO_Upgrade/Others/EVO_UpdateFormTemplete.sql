USE [Relish_EVO]
GO

/****** Object:  StoredProcedure [dbo].[EVO_UpdateFormTemplete]    Script Date: 02-04-2019 15:59:39 ******/
DROP PROCEDURE [dbo].[EVO_UpdateFormTemplete]
GO

/****** Object:  StoredProcedure [dbo].[EVO_UpdateFormTemplete]    Script Date: 02-04-2019 15:59:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROC [dbo].[EVO_UpdateFormTemplete]  
(
@formId INT,
@versionId INT,
@templeteID INT
)
AS

BEGIN  

UPDATE EVO_FormVersions SET TempleteID=@templeteID WHERE FormID=@formId AND VersionID = @versionId 

END  
  



GO


