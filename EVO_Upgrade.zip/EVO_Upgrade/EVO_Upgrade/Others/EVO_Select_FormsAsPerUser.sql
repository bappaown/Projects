USE [Relish_EVO]
GO

/****** Object:  StoredProcedure [dbo].[EVO_Select_FormsAsPerUser]    Script Date: 01-04-2019 17:49:28 ******/
DROP PROCEDURE [dbo].[EVO_Select_FormsAsPerUser]
GO

/****** Object:  StoredProcedure [dbo].[EVO_Select_FormsAsPerUser]    Script Date: 01-04-2019 17:49:28 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





  
CREATE Procedure [dbo].[EVO_Select_FormsAsPerUser]  
(  
 @Login As varchar(50),
 @FormName as varchar(50)='',
 @IsDTMS INT =0  
)  
AS  
/*  
 Created By: Imran Momin  
 Created Date: 21-JAN-2008  
 Modified By: Imran Momin  
 Modified Date: 23-FEB-2009  
 Modified By: Aarti Barve  
 Modified Date : 24-06-2011  
 Desctipion: Added Skill Set Is Active relation.  
*/  
BEGIN  
 --If logged in user is from ASD then view all active forms  
 IF ((SELECT TOP 1 DepartmentID FROM Central_Employee_Main WHERE login = @Login AND Status = 1) = 46)  
  BEGIN  
   SELECT  EM.FormID, EM.FormName, EM.FormDesc, ECM.CategoryID, ECM.CategoryName, EFV.VersionId, EFV.VersionName, EFV.XMLConfigID,  
     EFV.XMLFileName, EM.AddedBy, (CONVERT(VARCHAR,EM.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EM.AddedWhen,114)) AS AddedWhen ,IsEditable,IsScrabblePad 
   FROM EVO_Main EM   
    INNER JOIN EVO_FormVersions EFV On EFV.FormID = EM.FormID  
    INNER JOIN EVO_CategoryMain ECM On ECM.CategoryID = EM.CategoryID  
   WHERE     EFV.IsActive = 'True' AND EM.IsActive = 'True'  
   AND EM.FormName like @FormName + '%'
   AND EM.CategoryID<>4 
   AND ISNULL(EM.IsDTMS,0) = @IsDTMS 
   ORDER BY EM.FormID Desc,EFV.VersionID Desc  
  END  
 ELSE  
  BEGIN  
   SELECT  EM.EmpUserID, ESSR.FormID, EM.FormName, EM.FormDesc, ECM.CategoryID, ECM.CategoryName, EFV.VersionId, EFV.VersionName, EFV.XMLConfigID,  
     EFV.XMLFileName, EmployeeID, FirstName +' '+ LastName As EmpName, DesignationID,   
     CostCentreID, DepartmentID, Login, Location, Status, EFV.AddedBy, (CONVERT(VARCHAR,EFV.AddedWhen,103) + ' ' + CONVERT(VARCHAR(8),EFV.AddedWhen,114)) AS AddedWhen ,IsEditable,IsScrabblePad 
   FROM    Central_Employee_Main   
    INNER JOIN EVO_SkillSetRelations ESSR On ESSR.SkillSetID = Central_Employee_Main.DepartmentID  
    INNER JOIN EVO_Main EM On EM.FormID = ESSR.FormID  
    INNER JOIN EVO_FormVersions EFV On EFV.FormID = EM.FormID  
    INNER JOIN EVO_CategoryMain ECM On ECM.CategoryID = EM.CategoryID  
   WHERE     (Login = @Login) AND EFV.IsActive = 'True' AND EM.IsActive = 'True' AND ESSR.IsActive = 'True'  
   AND EM.FormName like @FormName + '%'
   AND EM.CategoryID<>4
   AND ISNULL(EM.IsDTMS,0) = @IsDTMS 
   ORDER BY EM.FormID Desc,EFV.VersionID Desc  
  END  
END  
  



GO


