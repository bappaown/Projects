USE [Relish_EVO]
GO

/****** Object:  StoredProcedure [dbo].[EVO_GetFormLayoutConfiguration]    Script Date: 28-05-2019 17:20:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO





CREATE PROC [dbo].[EVO_GetFormLayoutConfiguration]  
(
@FormId INT,
@VersionId INT
)
AS

BEGIN  

	SELECT FormID,VersionID,TempleteID,BackgroundImage,BackgroundColor,FontFamily,FontSize,FontColor
	FROM Layout_Configuration WHERE FormID=@FormId and VersionID=@VersionId

END  
  



GO


