USE [Relish_EVO]
GO

/****** Object:  StoredProcedure [dbo].[EVO_GetTransIds]    Script Date: 01-04-2019 11:39:40 ******/
DROP PROCEDURE [dbo].[EVO_GetTransIds]
GO

/****** Object:  StoredProcedure [dbo].[EVO_GetTransIds]    Script Date: 01-04-2019 11:39:40 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


--disable trigger all on database
--exec EVO_GetTransIds '','','52712',220,845

CREATE PROCEDURE [dbo].[EVO_GetTransIds](@FieldId VARCHAR(200),@Value VARCHAR(200),@UserId INT =0,@FormId INT,@VersionId INT )
AS 
/*
	Created By: Koshal Goswami
	Created Date: 15-Apr-2013
	Modified By: Koshal Goswami
	Modified Date: 05-JUN-2013
	Description: Modified for getting TransIds from EVO_Transaction_ProcessFlow table also 
*/

DECLARE @TransIds VARCHAR(2000),@TransIdsArchived VARCHAR(2000)
SET @TransIds = ''
SET @TransIdsArchived = ''
--SELECT @TransIds = CASE @TransIds WHEN '' THEN CAST(TransId AS VARCHAR(10)) ELSE @TransIds + ',' + CAST(TransId AS VARCHAR(10)) END  FROM dbo.EVO_FormDetails 
--WHERE Fieldid =@FieldId 
--AND ((DataCapture = @Value AND @Value <> '') OR (DataCapture = 'Not Selected.' AND @Value = ''))

DECLARE @IsSearchFormSpecific INT 
SET @IsSearchFormSpecific =0
--SELECT @IsSearchFormSpecific = ISNULL(IsSearchFormSpecific,0) FROM EVO_Main WHERE FormId = @FormId 

SELECT @TransIds = CASE @TransIds WHEN '' THEN CAST(TransId AS VARCHAR(10)) ELSE @TransIds + ',' + CAST(TransId AS VARCHAR(10)) END  
FROM (
SELECT Distinct EFD.TransId 
FROM dbo.EVO_FormDetails EFD 
JOIN EVO_transaction ET ON EFD.TransId=ET.TransID

WHERE ((EFD.Fieldid IN (SELECT Value FROM dbo.fnSplitStringAsTable(@FieldId,',')) 
AND ((CASE WHEN EFD.IsEncrypted = 1 THEN CAST(DECRYPTBYPASSPHRASE('Test',CONVERT(VARBINARY(MAX), EFD.DataCapture,1)) AS VARCHAR(MAX)) WHEN EFD.IsEncrypted = 0 THEN EFD.DataCapture END  = @Value AND @Value <> '') 
OR (CASE WHEN EFD.IsEncrypted = 1 THEN CAST(DECRYPTBYPASSPHRASE('Test',CONVERT(VARBINARY(MAX), EFD.DataCapture,1)) AS VARCHAR(MAX)) WHEN EFD.IsEncrypted = 0 THEN EFD.DataCapture END  = 'Not Selected.' AND @Value = '')) AND @FieldId <>'')
OR (@FieldId = ''))
AND  (((UserId = @UserId AND @UserId <> 0) ) OR (@UserId =0 ))
AND ET.FormId = @FormId AND ((ET.VersionId = @VersionId AND @IsSearchFormSpecific <> 1) OR (@IsSearchFormSpecific = 1))
) as T

SELECT @TransIdsArchived = CASE @TransIdsArchived WHEN '' THEN CAST(TransId AS VARCHAR(10)) ELSE @TransIdsArchived + ',' + CAST(TransId AS VARCHAR(10)) END  
FROM (
SELECT Distinct EFD.TransId 
FROM dbo.EVO_FormDetails_ProcessFlow EFD 
JOIN EVO_Transaction_ProcessFlow ET ON EFD.TransId=ET.TransID

WHERE ((EFD.Fieldid IN (SELECT Value FROM dbo.fnSplitStringAsTable(@FieldId,',')) 
AND ((CASE WHEN EFD.IsEncrypted = 1 THEN CAST(DECRYPTBYPASSPHRASE('Test',CONVERT(VARBINARY(MAX), EFD.DataCapture,1)) AS VARCHAR(MAX)) WHEN EFD.IsEncrypted = 0 THEN EFD.DataCapture END  = @Value AND @Value <> '') 
OR (CASE WHEN EFD.IsEncrypted = 1 THEN CAST(DECRYPTBYPASSPHRASE('Test',CONVERT(VARBINARY(MAX), EFD.DataCapture,1)) AS VARCHAR(MAX)) WHEN EFD.IsEncrypted = 0 THEN EFD.DataCapture END  = 'Not Selected.' AND @Value = '')) AND @FieldId <>'')
OR (@FieldId = ''))
AND  (((UserId = @UserId AND @UserId <> 0) ) OR (@UserId =0 ))
AND ET.FormId = @FormId AND ((ET.VersionId = @VersionId AND @IsSearchFormSpecific <> 1) OR (@IsSearchFormSpecific = 1))
) as T


IF(@UserId <>0)
	BEGIN
			
			;WITH TransTable AS
			(
			SELECT  ROW_NUMBER()OVER(PARTITION BY ETL.TransId ORDER BY ETL.AddedWhen)AS RowID,ETL.* FROM EVO_transaction_Log ETL
			JOIN EVO_Transaction ET ON ET.TransId= ETL.TransId AND ET.FormID = ETL.FormID
			JOIN EVO_FormDetails EF ON EF.TransID = ET.TransID
			
			WHERE ETL.UserId = @UserId
			AND ET.UserId <> @UserId
			AND ETL.FormId = @FormId AND ((ETL.VersionId = @VersionId AND @IsSearchFormSpecific <> 1) OR (@IsSearchFormSpecific = 1))
			AND ((EF.Fieldid IN (SELECT Value FROM dbo.fnSplitStringAsTable(@FieldId,',')) 
			AND ((CASE WHEN EF.IsEncrypted = 1 THEN CAST(DECRYPTBYPASSPHRASE('Test',CONVERT(VARBINARY(MAX), EF.DataCapture,1)) AS VARCHAR(MAX)) WHEN EF.IsEncrypted = 0 THEN EF.DataCapture END  = @Value AND @Value <> '') 
			OR (CASE WHEN EF.IsEncrypted = 1 THEN CAST(DECRYPTBYPASSPHRASE('Test',CONVERT(VARBINARY(MAX), EF.DataCapture,1)) AS VARCHAR(MAX)) WHEN EF.IsEncrypted = 0 THEN EF.DataCapture END  = 'Not Selected.' AND @Value = '')) AND @FieldId <>'')
			OR (@FieldId = ''))

			)
			SELECT @TransIds = CASE @TransIds WHEN '' THEN CAST(TransId AS VARCHAR(10)) ELSE @TransIds + ',' + CAST(TransId AS VARCHAR(10)) END  
			FROM (
					SELECT DISTINCT TransId FROM TransTable WHERE RowId = 1
			) AS T

			;WITH TransTableProcessFlow AS
			(
			SELECT  ROW_NUMBER()OVER(PARTITION BY ETL.TransId ORDER BY ETL.AddedWhen)AS RowID,ETL.* FROM EVO_transaction_Log ETL
			JOIN EVO_Transaction_ProcessFlow ET ON ET.TransId= ETL.TransId AND ET.FormID = ETL.FormID
			JOIN EVO_FormDetails_ProcessFlow EF ON EF.TransID = ET.TransID
			
			WHERE ETL.UserId = @UserId
			AND ET.UserId <> @UserId
			AND ETL.FormId = @FormId AND ((ETL.VersionId = @VersionId AND @IsSearchFormSpecific <> 1) OR (@IsSearchFormSpecific = 1))
			AND ((EF.Fieldid IN (SELECT Value FROM dbo.fnSplitStringAsTable(@FieldId,',')) 
			AND ((CASE WHEN EF.IsEncrypted = 1 THEN CAST(DECRYPTBYPASSPHRASE('Test',CONVERT(VARBINARY(MAX), EF.DataCapture,1)) AS VARCHAR(MAX)) WHEN EF.IsEncrypted = 0 THEN EF.DataCapture END = @Value AND @Value <> '') 
			OR (CASE WHEN EF.IsEncrypted = 1 THEN CAST(DECRYPTBYPASSPHRASE('Test',CONVERT(VARBINARY(MAX), EF.DataCapture,1)) AS VARCHAR(MAX)) WHEN EF.IsEncrypted = 0 THEN EF.DataCapture END = 'Not Selected.' AND @Value = '')) AND @FieldId <>'')
			OR (@FieldId = ''))

			)
			SELECT @TransIdsArchived = CASE @TransIdsArchived WHEN '' THEN CAST(TransId AS VARCHAR(10)) ELSE @TransIdsArchived + ',' + CAST(TransId AS VARCHAR(10)) END  
			FROM (
					SELECT * FROM TransTableProcessFlow WHERE RowId = 1
			) AS T
			
	END 
SELECT @TransIds  AS TransIds,@TransIdsArchived AS TransIdsArchived



GO


