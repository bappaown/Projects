USE [Relish_EVO]
GO

/****** Object:  StoredProcedure [dbo].[EVO_GetSelectedControlData]    Script Date: 20-12-2018 14:35:58 ******/
DROP PROCEDURE [dbo].[EVO_GetSelectedControlData]
GO

/****** Object:  StoredProcedure [dbo].[EVO_GetSelectedControlData]    Script Date: 20-12-2018 14:35:58 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE PROCEDURE [dbo].[EVO_GetSelectedControlData]
(
@ControlId INT,
@SkillSetId VARCHAR(200)
)
AS
BEGIN

select distinct * from Evo_GlobalControlDataStore where ControlId =@ControlId and DataStoreID in 
(select datastoreId from Evo_GlobalControlDataSkillSetRelation where SkillSetId in (select * from fnSplitStringAsTable(@SkillSetId,',')) and IsActive = 1)

END




GO


