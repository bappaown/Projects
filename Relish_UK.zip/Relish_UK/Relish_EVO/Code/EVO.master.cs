﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using H3GS.Web.Security;

public partial class EVO : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ////Windows Authentication : Bappa
            //string userName = PassportIdentity.Current.Employee.FullName;
            string userName = HttpContext.Current.Request.Cookies["EVO"] != null ? HttpContext.Current.Request.Cookies["EVO"]["userFullName"] : string.Empty;
            ////End
            lblName.Text = "Welcome " + userName;
            this.Page.Title = "" + ConfigurationKeys.ApplicationName + " - " + ConfigurationKeys.ApplicationVersion;
        }
    }

    //Logout Functionalily : Bappa
    protected void LogoutButton_Click(object sender, ImageClickEventArgs e)
    {
        int AuthType = Convert.ToInt32(HttpContext.Current.Request.Cookies["EVO"]["AuthenticationType"]);
        Response.Cookies["EVO"].Expires = DateTime.Now.AddDays(-1);
        Session.Abandon();
        Response.Redirect("../LogOut.aspx");
    }
    //End
}
