/*
How to use:
################################
Step# 1	Add the following line, within the script tags

<script language="JavaScript">
	// Format:	mm/DD/YYYY HH:MM AM-PM
	// Set future date for Backward timer or count-down; Else past-date for Forward timer or count-ahead (time that has passed)
	targetDate = "06/24/2010 10:00 AM";
	backColorForSpan = "lightgrey";
	foreColorForSpan = "teal";
	isCountActive = true;
	countingStep = -1;	// Define timer or count-down direction; [Backward: -1] | [Forward: 1]
	leadingZero = true;
	displayFormat = "%%D%% Days, %%H%% Hours, %%M%% Minutes, %%S%% Seconds.";
	displayMessageOnCompletion = "Count-down over";
</script>
--------------------------------
Step# 2	Add the following line of script reference to this file
<script language="JavaScript" src="http://scripts.hashemian.com/js/countdown.js"></script>
--------------------------------
Step# 3	Call the following method with the script tags (at the end of the web-page)
<script language="JavaScript">
	// Initiation: Call calulation and display method
	StartTimerCounting(globalSeconds);
</script>
*/

var displayLabelName;	// Id of the label in which the countdown value needs to be displayed
var displayLabel = document.getElementById(displayLabelName);

displayLabel.style.color = foreColorForSpan;

function CalculateAge(seconds, num1, num2) 
{
	seconds = ((Math.floor(seconds / num1)) % num2).toString();
	
	if (leadingZero && seconds.length < 2)
		seconds = "0" + seconds;

	return "<b>" + seconds + "</b>";
}

function StartTimerCounting(seconds) 
{
	if (seconds < 0) 
	{
		if(displayLabel)
			displayLabel.innerHTML = displayMessageOnCompletion;
		return;
	}

	contentToDisplay = displayFormat.replace(/%%D%%/g, CalculateAge(seconds, 86400, 100000));
	contentToDisplay = contentToDisplay.replace(/%%H%%/g, CalculateAge(seconds, 3600, 24));
	contentToDisplay = contentToDisplay.replace(/%%M%%/g, CalculateAge(seconds, 60, 60));
	contentToDisplay = contentToDisplay.replace(/%%S%%/g, CalculateAge(seconds, 1, 60));

	if(displayLabel)
			displayLabel.innerHTML = contentToDisplay;

	if (isCountActive)
		setTimeout("StartTimerCounting(" + (seconds + countingStep) + ")", SetTimeOutPeriod);
}

function AddSpanTag(backcolor, forecolor) 
{
	document.write("<span id='spnCountDown' style='background-color:" + backcolor + "; color:" + forecolor + "'></span>");
}

// Initializtion setting checks
if (typeof(backColorForSpan) == "undefined")
	backColorForSpan = "white";
if (typeof(foreColorForSpan) == "undefined")
	foreColorForSpan= "black";
if (typeof(targetDate) == "undefined")
	targetDate = "12/31/2020 5:00 AM";
if (typeof(displayFormat) == "undefined")
	displayFormat = "%%D%% Days, %%H%% Hours, %%M%% Minutes, %%S%% Seconds.";
if (typeof(isCountActive) == "undefined")
	isCountActive = true;
if (typeof(displayMessageOnCompletion) == "undefined")
	displayMessageOnCompletion = "";
if (typeof(countingStep) != "number")
	countingStep = -1;
if (typeof(leadingZero) == "undefined")
	leadingZero = true;

countingStep = Math.ceil(countingStep);

if (countingStep == 0)
	isCountActive = false;

var SetTimeOutPeriod = (Math.abs(countingStep) - 1) * 1000 + 990;

AddSpanTag(backColorForSpan, foreColorForSpan);

var dateTarget = new Date(targetDate);
var dateNow = new Date();

if(countingStep > 0)	// Check if forward or backward countdown is required
	dateDifference = new Date(dateNow - dateTarget);
else
	dateDifference = new Date(dateTarget - dateNow);

globalSeconds = Math.floor(dateDifference.valueOf() / 1000);
