﻿// JScript File

//**********************************************Functions to handle the sliding of the properties tab - START**********************************************
function ToggleBasic()
{
     if(document.getElementById('ctl00_ContentPlaceHolder1_BasicToolsListView').style.display == '')
     {
        document.getElementById('ctl00_ContentPlaceHolder1_BasicToolsListView').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_BasicControlsLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_BasicControlsLabel').style.width='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_CustomToolsListView').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_CustomControlLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_CustomControlLabel').style.width='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalToolsListView').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalControlLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalControlLabel').style.width='0px';
     }
     else if(document.getElementById('ctl00_ContentPlaceHolder1_BasicToolsListView').style.display == 'none')
     {
        document.getElementById('ctl00_ContentPlaceHolder1_BasicToolsListView').style.display = '';
        document.getElementById('ctl00_ContentPlaceHolder1_BasicControlsLabel').style.height='100px';
        document.getElementById('ctl00_ContentPlaceHolder1_BasicControlsLabel').style.width='285px';
        document.getElementById('ctl00_ContentPlaceHolder1_BasicControlsLabel').style.overflow = 'auto';
        document.getElementById('ctl00_ContentPlaceHolder1_CustomToolsListView').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_CustomControlLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_CustomControlLabel').style.width='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalToolsListView').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_GlobalControlLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalControlLabel').style.width='0px';
     }
}

function ToggleCustom()
{
    
     if(document.getElementById('ctl00_ContentPlaceHolder1_CustomToolsListView').style.display == '')
     {
         document.getElementById('ctl00_ContentPlaceHolder1_BasicToolsListView').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_BasicControlsLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_BasicControlsLabel').style.width='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_CustomToolsListView').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_CustomControlLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_CustomControlLabel').style.width='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalToolsListView').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalControlLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalControlLabel').style.width='0px';
     }
     else if(document.getElementById('ctl00_ContentPlaceHolder1_CustomToolsListView').style.display == 'none')
     {
        document.getElementById('ctl00_ContentPlaceHolder1_BasicToolsListView').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_BasicControlsLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_BasicControlsLabel').style.width='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_CustomToolsListView').style.display = '';
        document.getElementById('ctl00_ContentPlaceHolder1_CustomControlLabel').style.height='100px';
        document.getElementById('ctl00_ContentPlaceHolder1_CustomControlLabel').style.width='285px';
         document.getElementById('ctl00_ContentPlaceHolder1_CustomControlLabel').style.overflow = 'auto';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalToolsListView').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_GlobalControlLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalControlLabel').style.width='0px';
     }
}

function ToggleGlobal()
{
    
     if(document.getElementById('ctl00_ContentPlaceHolder1_GlobalToolsListView').style.display == '')
     {
         document.getElementById('ctl00_ContentPlaceHolder1_BasicToolsListView').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_BasicControlsLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_BasicControlsLabel').style.width='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_CustomToolsListView').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_CustomControlLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_CustomControlLabel').style.width='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalToolsListView').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalControlLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalControlLabel').style.width='0px';
     }
     else if(document.getElementById('ctl00_ContentPlaceHolder1_GlobalToolsListView').style.display == 'none')
     {
        document.getElementById('ctl00_ContentPlaceHolder1_BasicToolsListView').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_BasicControlsLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_BasicControlsLabel').style.width='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_CustomToolsListView').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_CustomControlLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_CustomControlLabel').style.width='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalToolsListView').style.display = '';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalControlLabel').style.height='100px';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalControlLabel').style.width='285px';
         document.getElementById('ctl00_ContentPlaceHolder1_GlobalControlLabel').style.overflow = 'auto';
     }
}


function HideProperties()
{
    document.getElementById('HideTableImg').style.display = 'none';
   // document.getElementById('ctl00_ContentPlaceHolder1_ViewInnerHTML').style.display = 'none';
    document.getElementById('PropertiesTable').style.display = 'none';
    document.getElementById('ctl00_ContentPlaceHolder1_BasicToolsListView').style.display = 'none';
    document.getElementById('ctl00_ContentPlaceHolder1_GlobalToolsListView').style.display = 'none';
    document.getElementById('ctl00_ContentPlaceHolder1_CustomToolsListView').style.display = 'none';
    document.getElementById('ctl00_ContentPlaceHolder1_DeleteButton').style.display = 'none';
    document.getElementById('BasicControlsDIV').style.display = 'none';
    document.getElementById('CustomControlsDIV').style.display = 'none';
    document.getElementById('GlobalControlsDIV').style.display = 'none';
    document.getElementById('ShowTableImg').style.display = 'block';
    hideit = setInterval("Hide()",8);

}

function ShowProperties()
{
    showit = setInterval("Show()",8);
}

function Hide()
{
     var width = document.getElementById('ToolsTable').style.width;
     var left = document.getElementById('ToolsTable').style.left;
     if( parseInt((document.getElementById('ToolsTable').style.width).substring(0,width.length-2)) > 10 && parseInt((document.getElementById('ToolsTable').style.left).substring(0,left.length-2)) < 1200)
    {
        document.getElementById('ToolsTable').style.left = parseInt(document.getElementById('ToolsTable').style.left) + 50;
        document.getElementById('ToolsTable').style.width = parseInt(document.getElementById('ToolsTable').style.width)- 50;
    }
    else
    {
    
      clearInterval(hideit);
    }
       

}

function Show()
{
     var width = document.getElementById('ToolsTable').style.width;
     var left = document.getElementById('ToolsTable').style.left;
       
    if(parseInt((document.getElementById('ToolsTable').style.width).substring(0,width.length-2)) != 295 && parseInt((document.getElementById('ToolsTable').style.left).substring(0,left.length-2)) != 955)
    { 
    
        document.getElementById('ToolsTable').style.left = parseInt(document.getElementById('ToolsTable').style.left) - 50;
        document.getElementById('ToolsTable').style.width = parseInt(document.getElementById('ToolsTable').style.width)+ 50;
        
     }
    else
    {
      clearInterval(showit);
      document.getElementById('HideTableImg').style.display = 'block';
    document.getElementById('ctl00_ContentPlaceHolder1_BasicToolsListView').style.display = 'block';
    document.getElementById('ctl00_ContentPlaceHolder1_GlobalToolsListView').style.display = 'block';
     document.getElementById('ctl00_ContentPlaceHolder1_CustomToolsListView').style.display = 'block';
     document.getElementById('ctl00_ContentPlaceHolder1_DeleteButton').style.display = 'none';
        document.getElementById('BasicControlsDIV').style.display = '';
    document.getElementById('CustomControlsDIV').style.display = '';
    document.getElementById('GlobalControlsDIV').style.display = '';
    document.getElementById('ShowTableImg').style.display = 'none';
    document.getElementById('PropertiesTable').style.display = 'none';
      document.getElementById('ctl00_ContentPlaceHolder1_BasicToolsListView').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_BasicControlsLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_BasicControlsLabel').style.width='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_CustomToolsListView').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_CustomControlLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_CustomControlLabel').style.width='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalToolsListView').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalControlLabel').style.height='0px';
        document.getElementById('ctl00_ContentPlaceHolder1_GlobalControlLabel').style.width='0px';
    //document.getElementById('ctl00_ContentPlaceHolder1_ViewInnerHTML').style.display = 'block';
    }

}

function CreateGUID() 
{
    return (((1+Math.random())*0x10000)|0).toString(16).substring(1);
}


//*********************************Functions to handle the sliding of the properties tab - END**********************************************

//************************************Functions handling the Drag and Drop of Elements - START*********************************************  
var dragapproved=false
var dragElement;
var dragElementx;
var dragElementy;

var dropDownFlag = false;
var listBoxFlag = false;
var radioListFlag = false;
var checkListFlag = false;
var textBoxFlag = false;
var labelFlag = false;
var buttonFlag = false;
var customFlag = false;
var globalFlag = false;

var radioButtonCount = 0;
var checkBoxCount = 0;

function move()
{
    var buffer = 5;
    if (event.button==1&&dragapproved)
    {
        var maxRight = parseInt(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').style.left) + parseInt(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').style.width) - dragElement.clientWidth - parseInt(buffer);
        var maxBottom = parseInt(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').style.top) + parseInt(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').style.height) - dragElement.clientHeight - parseInt(buffer);
       //alert(parseInt(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').style.width));
      // alert(maxBottom);
        if((event.clientX > parseInt(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').style.left)) && event.clientX < maxRight  && (event.clientY > parseInt(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').style.top)) && event.clientY < maxBottom)
        {   
            dragElement.style.pixelLeft=event.clientX - parseInt(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').style.left)
            dragElement.style.pixelTop=event.clientY - parseInt(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').style.top)
            var evt = window.event; 
            var obj = evt.srcElement;
            return true;
        }
        else
        {
          return false
        }
    }
}

function drags()
{

    if (!document.all)
    return
    if (event.srcElement.className=="drag")
    {
        dragapproved=true
        dragElement=event.srcElement
        dragElement.style.cursor = "move";
        dragElementLeft=dragElement.style.pixelLeft
        dragElementTop=dragElement.style.pixelTop
        dragElementx=event.clientX
        dragElementy=event.clientY
        document.onclick=new Function("dragapproved=false;");
        document.onmousemove=move;
    }
}

document.onmousedown=drags;
document.onmouseup=new Function("dragapproved=false;");


//************************************Functions handling the Drag and Drop of Elements - ENDS  *********************************************
var dropDownList ="";
var dropDownArray = new Array();
var dropDownIDList ="";
var dropDownIDArray = new Array();

var listBoxList ="";
var listBoxArray = new Array();
var listBoxIDList ="";
var listBoxIDArray = new Array();

 var iChars = "!@/&#$%^*()+=-[]\\\';{}|\:<>~_?.|,\"£'`"; 
 var iSizeChars = "!@&#$%^*()+=-[]\\\';{}|\:/<>~_£?.,|`QWERTYUIOPASDFGHJKLZXCVBNM\" "; 

function CreateDropDownList()
{
    var dropDownCount = document.getElementById('ctl00_ContentPlaceHolder1_dropDownCountHidden').value;
    var dropdownTitle = prompt("Enter the Drop Down Title");
    var dropdownString = "";
    var titleArray = new Array();
    var validTitle = true;
   
    if(dropdownTitle != null && dropdownTitle.substring(0,1) != " " && dropdownTitle.length < 45)
    {
        for (var i = 0; i < dropdownTitle.length; i++)
        {  
            if (iChars.indexOf(dropdownTitle.charAt(i)) != -1) 
             { 
               validTitle = false;
             } 
        }
        if(validTitle == false)
        {
            alert ("Please enter a valid title with less than 45 characters and no special characters."); 
        }
    }
    else
    {
        validTitle = false;
        alert ("Please enter a valid title with less than 45 characters and no special characters."); 
    }
   
    for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
    {
        titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
    }
    for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
    {
        if(dropdownTitle == titleArray[arrayCountx])
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "Exists"
            alert("A dropdown with the title " + dropdownTitle + " exists.");
        }
    }   
    
    if(document.getElementById('ctl00_ContentPlaceHolder1_FileModeHidden').value == "EDITMODE" && dropDownFlag == false)
    {
        if(document.getElementById('ctl00_ContentPlaceHolder1_dropDownCountHidden').value != "")
        {
            dropDownCount = parseInt(document.getElementById('ctl00_ContentPlaceHolder1_dropDownCountHidden').value) + parseInt(1);
            
        }
        if(document.getElementById('ctl00_ContentPlaceHolder1_dropDownCountHidden').value == "")
        {
            dropDownCount = parseInt(0);
        }
        dropDownFlag = true;
        dropDownList = document.getElementById('ctl00_ContentPlaceHolder1_DropDownArray').value;
        dropDownIDList = document.getElementById('ctl00_ContentPlaceHolder1_DropDownIDArray').value;
        
    }
 

    if(document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML != "Exists" && validTitle == true)
    {
        if((dropdownTitle != "undefined" ) && (dropdownTitle != "") &&  (dropdownTitle != null))
        { 
            //var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
            dropdownString += "<table id='ddl_" + dropDownCount + "DropDownTable' title='" + dropdownTitle + "' type='DropDown' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; width:200px; top:0px; left:0px;' align='right' onclick ='FillProperties(this)' controlid='2' controltype='basic' dependency='False' dependentid='' prevref='' isrequired='False' ismanageable='False' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False'>";
            dropdownString += "<tr class='drag'><td style='cursor:none;white-space:nowrap;' align='center' class='drag'>" + dropdownTitle + "</td>";
            dropdownString += "<td align='center'><img id='ddl_" + dropDownCount + "DropDown' title='" + dropdownTitle + "' style='z-index:-1;width:150px;cursor:none;' src='../Images/DropDownDes.jpg'/></td></tr></table>";//
            document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').innerHTML += dropdownString;
            dropDownList += dropdownTitle + ",";
            dropDownIDList += "ddl_" + dropDownCount + "DropDown" + ",";
            
        }
        else
        {
            alert("Please enter a valid title with less than 45 characters and no special characters.");
        }
    }
    document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "None";
   dropDownCount++;
   document.getElementById('ctl00_ContentPlaceHolder1_dropDownCountHidden').value = dropDownCount;
}



function CreateListBox()
{

    var listBoxCount = document.getElementById('ctl00_ContentPlaceHolder1_listBoxCountHidden').value;
    var listboxTitle = prompt("Enter the List Box Title");
    var listBoxString = "";
    var titleArray = new Array();  
    var validTitle = true; 
    
     if((listboxTitle != "undefined" ) && (listboxTitle != "") &&  (listboxTitle != null) && listboxTitle.substring(0,1) != " " && listboxTitle.length < 45)
     { 
         for (var i = 0; i < listboxTitle.length; i++)
        {  
            if (iChars.indexOf(listboxTitle.charAt(i)) != -1) 
             { 
               validTitle = false;
             } 
        }
        if(validTitle == false)
        {
            alert ("Please enter a valid title with less than 45 characters and no special characters."); 
        }
    }
    else
    {
         validTitle = false;
         alert ("Please enter a valid title with less than 45 characters and no special characters."); 
    }
    
    for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
    {
        titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
    }
    for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
    {
        if(listboxTitle == titleArray[arrayCountx])
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + listboxTitle + " exists.");
        }
    }
    if(document.getElementById('ctl00_ContentPlaceHolder1_FileModeHidden').value == "EDITMODE" && listBoxFlag == false)
    {
        if(document.getElementById('ctl00_ContentPlaceHolder1_listBoxCountHidden').value != "")
        {
            listBoxCount = parseInt(document.getElementById('ctl00_ContentPlaceHolder1_listBoxCountHidden').value) + parseInt(1);
        }
        if(document.getElementById('ctl00_ContentPlaceHolder1_listBoxCountHidden').value == "")
        {
            listBoxCount = parseInt(0);
        }
        listBoxList = document.getElementById('ctl00_ContentPlaceHolder1_ListBoxArray').value;
        listBoxIDList = document.getElementById('ctl00_ContentPlaceHolder1_ListBoxIDArray').value;
        listBoxFlag = true; 
    }
    
  

    if(document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML != "Exists" && validTitle == true)
    {
        if((listboxTitle != "undefined" ) && (listboxTitle != "") &&  (listboxTitle != null))
        { 
            //var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
            listBoxString += "<table id='lb_" + listBoxCount + "ListBoxTable' title='" + listboxTitle + "' type='ListBox' class='drag' style='position:absolute;border:dashed 4px #afafaf;background-color:White; width:100px;top:0px; left:0px;' align='right' onclick ='FillProperties(this)'  iswrap='False' controlid='5' controltype='basic' dependency='False' dependentid='' prevref='' isrequired='False' ismanageable='False' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False'>";
            listBoxString += "<tr ><td style='cursor:none;white-space:nowrap;' align='center'>" + listboxTitle + "</td></tr><tr>";
            listBoxString += "<td align='center'><img id='lb_" + listBoxCount  + "ListBox' title='" + listboxTitle + "' style='z-index:-1;width:200px;;height:120px;' src='../Images/ListBoxDes.jpg'/></td></tr></table>";
            document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').innerHTML += listBoxString;
            listBoxList += listboxTitle + ",";
            listBoxIDList += "lb_" + listBoxCount + "ListBox" + ",";
        }
        else
        {
            alert("Please enter a valid title with less than 45 characters and no special characters.");
        }
    }
    document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "None";
    listBoxCount++;
    document.getElementById('ctl00_ContentPlaceHolder1_listBoxCountHidden').value = listBoxCount;
}


function CreateRadioButtonList()
{
    var radioListCount =  document.getElementById('ctl00_ContentPlaceHolder1_radioButtonCountHidden').value;
    var radioButtonTitle = prompt("Enter the Radio Button Title.", "Enter RedioButtonList Title");
    var radioButtonSize = prompt("Enter the number of radio buttons in the list.", "Enter number of radio buttons");
    var radioButtonString = "";
    var titleArray = new Array();
    
    var totalWidth = radioButtonSize * 50;
    var avgWidth = parseInt((parseInt(totalWidth))/(parseInt(radioButtonSize)));
    
    var validTitle = true; 
    var validSize = true; 
    
    
    if((radioButtonTitle != "undefined" ) && (radioButtonTitle != "") &&  (radioButtonTitle != null) &&  (radioButtonTitle != "Enter RedioButtonList Title") && radioButtonTitle.substring(0,1) != " " && radioButtonTitle.length < 45)
    {
        for (var i = 0; i < radioButtonTitle.length; i++)
        {  
            if (iChars.indexOf(radioButtonTitle.charAt(i)) != -1) 
             { 
               validTitle = false;
             } 
        }
    }
    else
    {
        validTitle = false;
        alert ("Please enter a valid title with less than 45 characters and no special characters."); 
    }
    
//    if(validTitle == false)
//    {
//        alert ("Please enter a valid title with less than 45 characters and no special characters."); 
//    }
     if(radioButtonSize != null)
    {
        if((radioButtonSize != "undefined" ) && (radioButtonSize != "") &&  (radioButtonSize != null) &&  (radioButtonSize != "Enter number of radio buttons"))
        {
            for (var i = 0; i < radioButtonSize.length; i++)
            {  
                if (iSizeChars.indexOf(radioButtonSize.charAt(i)) != -1) 
                 { 
                   validSize = false;
                 } 
            }
            if(validSize == false)
            {
                alert ("The number of radio button has some special characters."); 
            }
        }
    }
    else
    {
        validSize = false;
        alert ("The number of radio button has some special characters.");
    }
    
    if(radioButtonSize<parseInt(8) && radioButtonSize>parseInt(1))
    {
         for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
        {
            titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
        }
        for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
        {
            if(radioButtonTitle == titleArray[arrayCountx])
            {
                document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "Exists"
                alert("A control with the title " + radioButtonTitle + " exists.");
            }
        }
        
        if(document.getElementById('ctl00_ContentPlaceHolder1_FileModeHidden').value == "EDITMODE" && radioListFlag == false)
        {
            
            if(document.getElementById('ctl00_ContentPlaceHolder1_radioButtonCountHidden').value != "")
            {
                radioListCount = parseInt(document.getElementById('ctl00_ContentPlaceHolder1_radioButtonCountHidden').value) + parseInt(1);
            }
             if(document.getElementById('ctl00_ContentPlaceHolder1_radioButtonCountHidden').value == "")
            {
                radioListCount = parseInt(0);
            }
            radioListFlag = true;
        }
        
         if(document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML != "Exists" && validSize == true && validTitle == true)
        {
            if((radioButtonTitle != "undefined" ) && (radioButtonTitle != "") &&  (radioButtonTitle != null) &&  (radioButtonTitle != "Enter RedioButtonList Title"))
            { 
               // var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
                radioButtonString += "<table id='rbl_" + radioListCount + "RadioButton' title='" + radioButtonTitle + "' type='RadioButtonList' class='drag' style='position:absolute;border:dashed 4px #afafaf;background-color:White;width:200px; top:0px; left:0px;' align='right' onclick ='FillProperties(this)'  iswrap='False' controlid='3' controltype='basic' dependency='False' isrequired='False' ismanageable='False' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False'><tr style='width:50px'><td style='white-space:nowrap;'>" + radioButtonTitle + "</td>";
                for(var radioCount =0 ; radioCount < parseInt(radioButtonSize); radioCount++)
                {   
                    //+ radioButtonTitle
                    radioButtonString += "<td style='width:150px;;cursor:hand;white-space:nowrap;vertical-align:top' align='right'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + radioButtonCount + "<input id='rbl_" + radioListCount  +"RadioButton'  title='" + radioButtonCount  + "' type='radio'  name='" + radioButtonTitle + "' repeatdirection='horizontal' repeatcolumns='1' /></td>";
                    //document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').innerHTML += "<label id='" + radioButtonCount + "RadioButton'  title='" + radioButtonTitle + "' type='radio' controlid='3' controltype='basic' dependency='No' isrequired='' iswrap='No' prewrap='' postwrap='' style='z-index:-1;width:100px;position:absolute;top:0px;left:0px' ispostback='false' onclick='FillProperties();' onmouseover='FillProperties();' class='drag'>adadsad</label>";
                    radioButtonCount++;
                }
                radioButtonString +="</tr></table>";
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').innerHTML += radioButtonString;
            }
            else
            {
                alert("Please enter a valid title with less than 45 characters and no special characters.");
            }
        }
        document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "None";
        radioButtonCount = 0;
        radioListCount++;
        document.getElementById('ctl00_ContentPlaceHolder1_radioButtonCountHidden').value = radioListCount;
      }
      else
      {
        alert("The number of radio buttons cannot be more than 5 and less than 1.");
      }  
}


function CreateCheckBoxList()
{
    var  checkListCount = document.getElementById('ctl00_ContentPlaceHolder1_checkBoxCountHidden').value;
    var checkBoxTitle = prompt("Enter the Check Box List Title.", "Enter CheckBoxList Title");
    var checkBoxSize = prompt("Enter the number of check box in the list.", "Enter number of check boxes");
    var checkBoxString = "";
    var titleArray = new Array();
    var totalWidth = checkBoxSize * 50;
    var avgWidth = parseInt((parseInt(totalWidth))/(parseInt(checkBoxSize)));
    
    var validTitle = true; 
    var validSize = true; 
  
    if(checkBoxTitle != null)
    {
        if((checkBoxTitle != "undefined") && (checkBoxTitle != "") &&  (checkBoxTitle.substring(0,1) != " ") && (checkBoxTitle != null) &&  (checkBoxTitle != "Enter number of check boxes") && (checkBoxTitle.length < 45)) //Earlier it was checkBoxTitle < 45. Imran
        {      
            for (var i = 0; i < checkBoxTitle.length; i++)
            {  
                if (iChars.indexOf(checkBoxTitle.charAt(i)) != -1) 
                 {
                    validTitle = false;
                 } 
            }
        }
        else
        {
            validTitle = false;
            
        }
    }
    else
    {
        validTitle = false;
        alert ("Please enter a valid title with less than 45 characters and no special characters."); 
    }
    
   
//    if(validTitle == false)
//    {
//        alert ("Please enter a valid title with less than 45 characters and no special characters."); 
//    }
    
    if((checkBoxSize != "undefined" ) && (checkBoxSize != "") &&  (checkBoxSize != null) &&  (checkBoxSize != "Enter number of check boxes"))
    {
        for (var i = 0; i < checkBoxSize.length; i++)
        {  
            if (iSizeChars.indexOf(checkBoxSize.charAt(i)) != -1) 
             { 
               validSize = false;
             } 
        }
        if(validSize == false)
        {
            alert ("The number of check boxes has some special characters."); 
        }
    }
    else
    {
        validSize = false;
         alert ("The number of check boxes has some special characters."); 
    } 
  
  if(checkBoxSize<parseInt(6) && checkBoxSize>parseInt(1))
  {
     for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
    {
        titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
    }
    for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
    {
        if(checkBoxTitle == titleArray[arrayCountx])
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + checkBoxTitle + " exists.");
        }
    }
    if(document.getElementById('ctl00_ContentPlaceHolder1_FileModeHidden').value == "EDITMODE" && checkListFlag == false)
    {   
        if(document.getElementById('ctl00_ContentPlaceHolder1_checkBoxCountHidden').value != "")
        {
            checkListCount = parseInt(document.getElementById('ctl00_ContentPlaceHolder1_checkBoxCountHidden').value) + parseInt(1);
            
        }
        if(document.getElementById('ctl00_ContentPlaceHolder1_checkBoxCountHidden').value == "")
        {
            checkListCount = parseInt(0);
        }
        checkListFlag = true;
    }
    
    
     if(document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML != "Exists" && validSize == true && validTitle == true)
    {
        if((checkBoxTitle != "undefined" ) && (checkBoxTitle != "") &&  (checkBoxTitle != null) &&  (checkBoxTitle != "Enter CheckBoxList Title"))
        { 
           // var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
            checkBoxString += "<table id='cbl_" + checkListCount + "CheckBox' title='" + checkBoxTitle + "' type='CheckBoxList' class='drag' style='position:absolute;border:dashed 4px #afafaf;background-color:White; width:200px; top:0px; left:0px;' align='right' onclick ='FillProperties(this)'  iswrap='False' controlid='4' controltype='basic' dependency='False' isrequired='False' ismanageable='False' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False'><tr style='width:50px'><td style='white-space:nowrap;'>" + checkBoxTitle + "</td>";
            for(var checkCount =0 ; checkCount < parseInt(checkBoxSize); checkCount++)
            {   
                //" + parseInt(checkBoxCount) +" //checkBoxTitle
                checkBoxString += "<td style='cursor:hand;white-space:nowrap; width:150px; vertical-align:top' align='right'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + parseInt(checkBoxCount) +"<input id='cbl_" + checkListCount  +"CheckBox'  title='" + parseInt(checkBoxCount) + "' type='checkbox'  name='" + checkBoxTitle + "' repeatdirection='horizontal' repeatcolumns='1' /></td>";
                //document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').innerHTML += "<label id='" + radioButtonCount + "RadioButton'  title='" + radioButtonTitle + "' type='radio' controlid='3' controltype='basic' dependency='No' isrequired='' iswrap='No' prewrap='' postwrap='' style='z-index:-1;width:100px;position:absolute;top:0px;left:0px' ispostback='False' onclick='FillProperties();' onmouseover='FillProperties();' class='drag'>adadsad</label>";
                checkBoxCount++;
            }
            checkBoxString +="</tr></table>";
            document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').innerHTML += checkBoxString;
        }
        else
        {
            alert("Please enter a valid title with less than 45 characters and no special characters.");
        }
    }
    document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "None";
    checkBoxCount= parseInt(0);
    checkListCount++;
    document.getElementById('ctl00_ContentPlaceHolder1_checkBoxCountHidden').value = checkListCount;
   }
   else
   {
    alert("The number of check boxes cannot be more than 5 and less than 1.");
   }
}

function CreateTextBox()
{
    var  textBoxCount = document.getElementById('ctl00_ContentPlaceHolder1_textBoxCountHidden').value;
    var textboxTitle = prompt("Enter the Text Box Title");
    var textboxString = "";
    var titleArray = new Array();
    
    var validTitle = true; 
    
    
    if((textboxTitle != "undefined" ) && (textboxTitle != "") &&  (textboxTitle != null) &&  textboxTitle.substring(0,1) != " " && textboxTitle.length < 45)
    { 
        for (var i = 0; i < textboxTitle.length; i++)
        {  
            if (iChars.indexOf(textboxTitle.charAt(i)) != -1) 
             { 
               validTitle = false;
             } 
        }
        if(validTitle == false)
        {
            alert ("Please enter a valid title with less than 45 characters and no special characters."); 
        }
    }
    else
    {
        validTitle = false;
        alert ("Please enter a valid title with less than 45 characters and no special characters."); 
    }
    
    
    for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
    {
        titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
    }
    for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
    {
        if(textboxTitle == titleArray[arrayCountx])
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + textboxTitle + " exists.");
        }
    }
    
    if(document.getElementById('ctl00_ContentPlaceHolder1_FileModeHidden').value == "EDITMODE" && textBoxFlag == false)
    {
        if(document.getElementById('ctl00_ContentPlaceHolder1_textBoxCountHidden').value != "")
        {
            textBoxCount = parseInt(document.getElementById('ctl00_ContentPlaceHolder1_textBoxCountHidden').value) + parseInt(1);
        }
        if(document.getElementById('ctl00_ContentPlaceHolder1_textBoxCountHidden').value == "")
        {
            textBoxCount = parseInt(0);
        }
        textBoxFlag = true;
    }

    if(document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML != "Exists" && validTitle == true)
    {
        if((textboxTitle != "undefined" ) && (textboxTitle != "") &&  (textboxTitle != null))
        { 
           // var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
            textboxString += "<table id='txt_" + textBoxCount + "TextBoxTable' title='" + textboxTitle + "' type='TextBox' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; width:200px; top:0px; left:0px;' align='right' onclick ='FillProperties(this)'    controlid='1' controltype='basic' dependency='False' isrequired='False' ismanageable='False' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False'  maxlength='20' textmode='Singleline' istype='Numeric'>";
            textboxString += "<tr ><td style='cursor:none;white-space:nowrap;' align='center'>" + textboxTitle + "</td>";
            textboxString += "<td align='center'><input id='txt_" + textBoxCount + "TextBox' title='" + textboxTitle + "' style='z-index:-1;width:150px;cursor:none' type='text'/></td></tr></table>";
            document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').innerHTML += textboxString;
           // dropDownList += dropdownTitle + ",";
        }
        else
        {
            alert("Please enter a valid title with less than 45 characters and no special characters.");
        }
    }
    document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "None";
    textBoxCount++;
    document.getElementById('ctl00_ContentPlaceHolder1_textBoxCountHidden').value = textBoxCount;
}

function CreateLabel()
{
    var labelCount = document.getElementById('ctl00_ContentPlaceHolder1_labelCountHidden').value;
    var labelTitle = prompt("Enter the Label Title");
    var labelString = "";
    var titleArray = new Array();
    
    var validTitle = true; 
    
    if((labelTitle != "undefined" ) && (labelTitle != "") &&  (labelTitle != null) &&  labelTitle.substring(0,1) != " " && labelTitle.length < 45)
    { 
        for (var i = 0; i < labelTitle.length; i++)
        {  
            if (iChars.indexOf(labelTitle.charAt(i)) != -1) 
             { 
               validTitle = false;
             } 
        }
        if(validTitle == false)
        {
            alert ("Please enter a valid title with less than 45 characters and no special characters.");  
        }
    }
    else
    {
        validTitle = false;
        alert ("Please enter a valid title with less than 45 characters and no special characters.");
    }
    
    
    for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
    {
        titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
    }
    for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
    {
        if(labelTitle == titleArray[arrayCountx])
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + labelTitle + " exists.");
        }
    }
    if(document.getElementById('ctl00_ContentPlaceHolder1_FileModeHidden').value == "EDITMODE" && labelFlag == false)
    {
        if(document.getElementById('ctl00_ContentPlaceHolder1_labelCountHidden').value != "")
        {
            labelCount = parseInt(document.getElementById('ctl00_ContentPlaceHolder1_labelCountHidden').value) + parseInt(1);
         }   
        if(document.getElementById('ctl00_ContentPlaceHolder1_labelCountHidden').value == "")
        {
            labelCount = parseInt(0);
        }
        labelFlag = true;
    }

    if(document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML != "Exists" && validTitle ==true)
    {
        if((labelTitle != "undefined" ) && (labelTitle != "") &&  (labelTitle != null))
        { 
            //var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
            labelString += "<table id='lbl_" + labelCount + "LabelTable' title='" + labelTitle + "' type='Label' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; width:200px; top:0px; left:0px;' align='right' onclick ='FillProperties(this)'    controlid='1' controltype='basic' dependency='False' isrequired='False' ismanageable='False' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False'>";
            labelString += "<tr ><td style='cursor:none;white-space:nowrap;' align='center'>"+labelTitle+"</td>";
            labelString += "<td align='center'><label id='lbl_" + labelCount + "Label' title='" + labelTitle + "' style='z-index:-1;width:150px;cursor:none'></label></td></tr></table>";
            document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').innerHTML += labelString;
           // dropDownList += dropdownTitle + ",";
        }
        else
        {
            alert("Please enter a valid title with less than 45 characters and no special characters.");
        }
    }
    document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "None";
    labelCount++;
    document.getElementById('ctl00_ContentPlaceHolder1_labelCountHidden').value = labelCount;
}

function CreateButton()
{
    var buttonCount = document.getElementById('ctl00_ContentPlaceHolder1_buttonCountHidden').value;
    var buttonTitle = prompt("Enter the Button Title");
    var buttonString = "";
    var titleArray = new Array();
    
    var validTitle = true; 
    
    if((buttonTitle != "undefined" ) && (buttonTitle != "") &&  (buttonTitle != null) &&  buttonTitle.substring(0,1) != " " && buttonTitle.length < 45)
    { 
        for (var i = 0; i < buttonTitle.length; i++)
        {  
            if (iChars.indexOf(buttonTitle.charAt(i)) != -1) 
             { 
               validTitle = false;
             } 
        }
        if(validTitle == false)
        {
            alert ("Please enter a valid title with less than 45 characters and no special characters.");  
        }
    }
    else
    {
         validTitle = false;
          alert ("Please enter a valid title with less than 45 characters and no special characters.");
    }
    
    for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
    {
        titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
    }
    for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
    {
        if(buttonTitle == titleArray[arrayCountx])
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + buttonTitle + " exists.");
        }
    }
    if(document.getElementById('ctl00_ContentPlaceHolder1_FileModeHidden').value == "EDITMODE" && buttonFlag == false)
    {
        if(document.getElementById('ctl00_ContentPlaceHolder1_buttonCountHidden').value != "")
        {
            buttonCount = parseInt(document.getElementById('ctl00_ContentPlaceHolder1_buttonCountHidden').value) + parseInt(1);
        }
        if(document.getElementById('ctl00_ContentPlaceHolder1_buttonCountHidden').value == "")
        {
            buttonCount = parseInt(0);
        }
        buttonFlag = true;
    }

    if(document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML != "Exists" && validTitle == true)
    {
        if((buttonTitle != "undefined" ) && (buttonTitle != "") &&  (buttonTitle != null))
        { 
           // var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
            buttonString += "<table id='but_" + buttonCount + "ButtonTable' title='" + buttonTitle + "' type='BButton' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; width:200px;top:0px; left:0px;' align='right' onclick ='FillProperties(this)'    controlid='1' controltype='basic' dependency='False' isrequired='False' ismanageable='False' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False'>";
            buttonString += "<tr ><td style='cursor:none;white-space:nowrap;' align='center'></td>";
            buttonString += "<td align='center'><input id='but_" + buttonCount + "Button' title='" + buttonTitle + "' style='z-index:-1;width:100px;cursor:none' type='button' readonly='true' value='" + buttonTitle + "'/></td></tr></table>";
            document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').innerHTML += buttonString;
           // dropDownList += dropdownTitle + ",";
        }
        else
        {
            alert("Please enter a valid title with less than 45 characters and no special characters.");
        }
    }
    document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "None";
    buttonCount++;
    document.getElementById('ctl00_ContentPlaceHolder1_buttonCountHidden').value = buttonCount;
}

//******************************************Region for Employee Custom Control - Starts **************************************************//

function CreateCC1Employees()
{
   // alert();
    var customCount = document.getElementById('ctl00_ContentPlaceHolder1_customCountHidden').value;
    var empDropDownTitle = prompt("Enter the Emp Drop Down Title");
    var empDropDownString = "";
    var titleArray = new Array();
    
    var validTitle = true; 
    
    
    if((empDropDownTitle != "undefined" ) && (empDropDownTitle != "") &&  (empDropDownTitle != null) &&  empDropDownTitle.substring(0,1) != " " && empDropDownTitle.length < 45)
    { 
        for (var i = 0; i < empDropDownTitle.length; i++)
        {  
            if (iChars.indexOf(empDropDownTitle.charAt(i)) != -1) 
             { 
               validTitle = false;
             } 
        }
        if(validTitle == false)
        {
            alert ("Please enter a valid title with less than 45 characters and no special characters.");  
        }
    }
    else
    {
        validTitle = false;
         alert ("Please enter a valid title with less than 45 characters and no special characters.");
    }
    
    for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
    {
        titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
    }
    for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
    {
        if(empDropDownTitle == titleArray[arrayCountx])
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + empDropDownTitle + " exists.");
        }
    }
    if(document.getElementById('ctl00_ContentPlaceHolder1_FileModeHidden').value == "EDITMODE" && customFlag == false)
    {
        if(document.getElementById('ctl00_ContentPlaceHolder1_customCountHidden').value != "")
        {
            customCount = parseInt(document.getElementById('ctl00_ContentPlaceHolder1_customCountHidden').value) + parseInt(1);
         }  
         if(document.getElementById('ctl00_ContentPlaceHolder1_customCountHidden').value == "")
        {
            customCount = parseInt(0);
        } 
        customFlag = true;
    }
     
    if(document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML != "Exists" && validTitle == true)
    {
        if((empDropDownTitle != "undefined" ) && (empDropDownTitle != "") &&  (empDropDownTitle != null))
        { 
            //var GUID = (CreateGUID()+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+"-"+CreateGUID()+CreateGUID()+CreateGUID()).toUpperCase()
            empDropDownString += "<table id='cc_" + customCount + "DropDownTable' title='" + empDropDownTitle + "' type='EmpDropDown' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:0px; left:0px;' align='right' onclick ='FillProperties(this)'  iswrap='False' controlid='4' controltype='custom' isrequired='False' datasource='DB' skillset='None' skillsetvalues='None' costcentre='None' costcentrevalues='None' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False'>";
            empDropDownString += "<tr ><td style='cursor:none;white-space:nowrap;' align='left'>" + empDropDownTitle + "</td>";
            empDropDownString += "<td align='right'><img id='cc_" + customCount + "DropDown' title='" + empDropDownTitle + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/></td>";
            empDropDownString += "<td><img id='ShowCustPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
             empDropDownString += "cursor: hand; padding-left: 5px;' onclick='ShowCustProps(event, this);' align='left' /></td></tr></table>";
            document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').innerHTML += empDropDownString;
            //dropDownList += dropdownTitle + ",";
        }
        else
        {
            alert("Please enter a valid title with less than 45 characters and no special characters.");
        }
    }
    document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "None";
    customCount++;
    document.getElementById('ctl00_ContentPlaceHolder1_customCountHidden').value = customCount;
}



var controlID = "";

function ShowCustProps(e, element)
{ 
    var height = e.clientY + parseInt('2');
    var offsetHeight = parseInt(e.offsetY);
    height = height - offsetHeight;
    var width = e.clientX
    var offsetWidth = parseInt(e.offsetX);
    width = width - offsetWidth;
    var div = document.getElementById('ctl00_ContentPlaceHolder1_EmpCtrlDiv');
    div.style.display = 'block';
    var rightedge = parseInt(document.body.clientWidth) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientX) - 2;
    var bottomedge = parseInt(document.body.clientHeight) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientY) + 2;
    lefter = (rightedge < width)?event.srcElement.parentNode.parentNode.parentNode.parentNode.clientX - 200:event.clientX - 0;
    topper = (bottomedge < height)?event.srcElement.parentNode.parentNode.parentNode.parentNode.clientY - 200:event.clientY - 0;
    if(parseInt(width) >= 1000)
    {
        lefter = parseInt(event.clientX) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientWidth) - 200;
    }
    if(parseInt(height) >= 550)
    {
        topper = parseInt(event.clientY) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientHeight) - 250;
    }
    div.style.top = topper;
    div.style.left = lefter;
    document.getElementById('ctl00_ContentPlaceHolder1_SkillSetSelect').options.length = 0;
   document.getElementById('ctl00_ContentPlaceHolder1_IdLabel').innerHTML = event.srcElement.parentNode.parentNode.parentNode.parentNode.title;
   controlID = event.srcElement.parentNode.parentNode.parentNode.parentNode.id;
  
   var empCustObject = event.srcElement.parentNode.parentNode.parentNode.parentNode;
   
   if(empCustObject.costcentre != "None")
   {
       var costCentreArray = new Array();
       costCentreArray = empCustObject.getAttribute('costcentre').split(',');
       costCentreArray.pop(costCentreArray.length - 1);
       document.getElementById('ctl00_ContentPlaceHolder1_ChangeCCLabel').style.display = 'block';
       document.getElementById('ctl00_ContentPlaceHolder1_CostCentreSelect').style.display = 'none';
       document.getElementById('ctl00_ContentPlaceHolder1_CCLabel').innerHTML = costCentreArray;
//       if(document.getElementById('ctl00_ContentPlaceHolder1_CostCentreSelect').options.selectedIndex == -1)
//       {
//        event.srcElement.parentNode.parentNode.parentNode.parentNode.costcentre = "None";
//        alert();
//       }
    }
    if(empCustObject.costcentre == "None" || empCustObject.costcentre == null)
    {
        document.getElementById('ctl00_ContentPlaceHolder1_CostCentreSelect').options.selectedIndex = -1;
        document.getElementById('ctl00_ContentPlaceHolder1_ChangeCCLabel').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_CostCentreSelect').style.display = 'block';
    }
  
    if(empCustObject.skillset != "None")
   {
        var skillSetArray = new Array();
        skillSetArray = empCustObject.getAttribute('skillset').split(',');
        skillSetArray.pop(skillSetArray.length - 1);
        document.getElementById('ctl00_ContentPlaceHolder1_ChangeSSLabel').style.display = 'block';
        document.getElementById('ctl00_ContentPlaceHolder1_SkillSetSelect').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_SSLabel').innerHTML = skillSetArray;
        //document.getElementById('ctl00_ContentPlaceHolder1_SSLabel').style.display = 'block';
//         if(document.getElementById('ctl00_ContentPlaceHolder1_SkillSetSelect').options.selectedIndex == -1)
//       {
//        event.srcElement.parentNode.parentNode.parentNode.parentNode.skillset = "None";
//       }
   }
   
   if(empCustObject.skillset == "None" || empCustObject.skillset == null)
   {
        document.getElementById('ctl00_ContentPlaceHolder1_SkillSetSelect').options.selectedIndex = -1;
        document.getElementById('ctl00_ContentPlaceHolder1_ChangeSSLabel').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_SkillSetSelect').style.display = 'block';
   }
   
//   if(document.getElementById('ctl00_ContentPlaceHolder1_SkillSetSelect').style.display == 'none')
//   {
//    document.getElementById('ctl00_ContentPlaceHolder1_ChangeSSLabel').style.display = 'block';
//   }
//   
//   if(document.getElementById('ctl00_ContentPlaceHolder1_SkillSetSelect').style.display == 'block')
//   {
//    document.getElementById('ctl00_ContentPlaceHolder1_ChangeSSLabel').style.display = 'none';
//   }
//    if(document.getElementById('ctl00_ContentPlaceHolder1_CostCentreSelect').style.display == 'none')
//   {
//    document.getElementById('ctl00_ContentPlaceHolder1_ChangeCCLabel').style.display = 'block';
//   }
//   
//   if(document.getElementById('ctl00_ContentPlaceHolder1_CostCentreSelect').style.display == 'block')
//   {
//    document.getElementById('ctl00_ContentPlaceHolder1_ChangeCCLabel').style.display = 'none';
//   }

}

function ChangeSSSelect()
{
    document.getElementById('ctl00_ContentPlaceHolder1_CostCentreSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.costcentre = "None";
    document.getElementById('ctl00_ContentPlaceHolder1_CostCentreSelect').style.display = 'block';
    document.getElementById('ctl00_ContentPlaceHolder1_ChangeCCLabel').style.display = 'none';
    document.getElementById('ctl00_ContentPlaceHolder1_CCLabel').innerHTML = "";
    
    document.getElementById('ctl00_ContentPlaceHolder1_SkillSetSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.skillset = "None";
    document.getElementById('ctl00_ContentPlaceHolder1_SkillSetSelect').style.display = 'block';
    document.getElementById('ctl00_ContentPlaceHolder1_ChangeSSLabel').style.display = 'none';
    document.getElementById('ctl00_ContentPlaceHolder1_SSLabel').innerHTML = "";
    
    
}

function ChangeCCSelect()
{
    document.getElementById('ctl00_ContentPlaceHolder1_CostCentreSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.costcentre = "None";
    document.getElementById('ctl00_ContentPlaceHolder1_CostCentreSelect').style.display = 'block';
    document.getElementById('ctl00_ContentPlaceHolder1_ChangeCCLabel').style.display = 'none';
    document.getElementById('ctl00_ContentPlaceHolder1_CCLabel').innerHTML = "";
    
    document.getElementById('ctl00_ContentPlaceHolder1_SkillSetSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.skillset = "None";
    document.getElementById('ctl00_ContentPlaceHolder1_SkillSetSelect').style.display = 'block';
    document.getElementById('ctl00_ContentPlaceHolder1_ChangeSSLabel').style.display = 'none';
    document.getElementById('ctl00_ContentPlaceHolder1_SSLabel').innerHTML = "";
}


function HideShowProps()
{
    var costcentreString = "";
    var costcentreValues = "";
    var skillsetString = "";
    var skillsetValues = "";
    document.getElementById('ctl00_ContentPlaceHolder1_EmpCtrlDiv').style.display='none';
    var controlILabel = document.getElementById('ctl00_ContentPlaceHolder1_IdLabel').innerHTML;
    for(var selectCC = 0 ; selectCC < document.getElementById('ctl00_ContentPlaceHolder1_CostCentreSelect').options.length; selectCC++)
    {
        if(document.getElementById('ctl00_ContentPlaceHolder1_CostCentreSelect').options[selectCC].selected)
        {
            costcentreString += document.getElementById('ctl00_ContentPlaceHolder1_CostCentreSelect').options[selectCC].innerText;
            costcentreString += ",";
            costcentreValues += document.getElementById('ctl00_ContentPlaceHolder1_CostCentreSelect').options[selectCC].value;
            costcentreValues += ",";
        }
    }
    for(var selectSS = 0 ; selectSS < document.getElementById('ctl00_ContentPlaceHolder1_SkillSetSelect').options.length; selectSS++)
    {
        if(document.getElementById('ctl00_ContentPlaceHolder1_SkillSetSelect').options[selectSS].selected)
        {
            skillsetString += document.getElementById('ctl00_ContentPlaceHolder1_SkillSetSelect').options[selectSS].innerText;
            skillsetString += ",";
            skillsetValues += document.getElementById('ctl00_ContentPlaceHolder1_SkillSetSelect').options[selectSS].value;
            skillsetValues += ",";
        }
    }
    if(skillsetValues == "")
    {   
        document.getElementById('ctl00_ContentPlaceHolder1_EmpCtrlDiv').style.display = '';
        alert("Please select a skillset");
        return false;
    }

    document.getElementById(controlID).setAttribute('costcentre',costcentreString);
    document.getElementById(controlID).setAttribute('costcentrevalues',costcentreValues);
    document.getElementById(controlID).setAttribute('skillset',skillsetString);
    document.getElementById(controlID).setAttribute('skillsetvalues',skillsetValues);
    
    if(costcentreString == "")
    {
        document.getElementById(controlID).costcentre = 'None';
        document.getElementById(controlID).costcentrevalues = 'None';
    }
     if(costcentreValues == "")
    {
        document.getElementById(controlID).costcentrevalues = 'None';
    }
     if(skillsetString == "")
    {
        document.getElementById(controlID).skillset='None';
        document.getElementById(controlID).skillsetvalues = 'None';
    }
    if(skillsetValues == "")
    {
        document.getElementById(controlID).skillsetvalues='None';
    }
    
    
   
    
  
}
//******************************************Region for Employee Custom Control - Ends **************************************************//

//******************************************Region for Employee Global Control - Starts **************************************************//


function CreateMultipleGlobal(element)
{
//    alert(element.innerHTML);//Error in element.

    var globalCount = document.getElementById('ctl00_ContentPlaceHolder1_globalCountHidden').value;
    var  elementArray =  new Array();
    elementArray = element.innerHTML.split('/');
    
    var globalMDropDownTitle = prompt("Enter the "+ element.innerHTML +" Title");
    var globalMDropDownString = "";
    var titleArray = new Array();
    
    var validTitle = true; 
    
    if((globalMDropDownTitle != "undefined" ) && (globalMDropDownTitle != "") &&  (globalMDropDownTitle != null) &&  globalMDropDownTitle.substring(0,1) != " " && globalMDropDownTitle.length < 45)
    { 
        for (var i = 0; i < globalMDropDownTitle.length; i++)
        {  
            if (iChars.indexOf(globalMDropDownTitle.charAt(i)) != -1) 
             { 
               validTitle = false;
             } 
        }
        if(validTitle == false)
        {
            alert ("Please enter a valid title with less than 45 characters and no special characters.");  
        }
    }
    else
    {
         validTitle = false;
          alert ("Please enter a valid title with less than 45 characters and no special characters.");
    }
    for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
    {
        titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
    }
    for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
    {
        if(globalMDropDownTitle == titleArray[arrayCountx])
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + globalMDropDownTitle + " exists.");
        }
    }
    
    if(document.getElementById('ctl00_ContentPlaceHolder1_FileModeHidden').value == "EDITMODE" && globalFlag == false)
    {
        if(document.getElementById('ctl00_ContentPlaceHolder1_globalCountHidden').value != "")
        {
            globalCount = parseInt(document.getElementById('ctl00_ContentPlaceHolder1_globalCountHidden').value) + parseInt(1);
        }
        if(document.getElementById('ctl00_ContentPlaceHolder1_globalCountHidden').value == "")
        {
            globalCount = parseInt(0);
        }
        globalFlag = true;
    }

    if(document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML != "Exists" && validTitle == true)
    {
        if((globalMDropDownTitle != "undefined" ) && (globalMDropDownTitle != "") &&  (globalMDropDownTitle != null))
        {  
            globalMDropDownString += "<table id='gc_" + globalCount + "_" + elementArray[0] +"DropDownTable' title='" + globalMDropDownTitle + "' type='GlobalMControl' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:0px; left:0px;' align='right' onclick ='FillProperties(this)'  iswrap='False'  controltype='global' isrequired='False' datasource='DB' skillset='None' skillsetvalues='None' costcentre='None' costcentrevalues='None' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False' dependentid='gc_" + globalCount  + "_" + elementArray[1] + "DropDown' controlid='" + element.getAttribute('ctrlid')+ "' depctrlid='" + element.getAttribute('depctrlid')+ "'>";//
            globalMDropDownString += "<tr ><td style='cursor:none;white-space:nowrap;' align='left'>" + globalMDropDownTitle + "</td>";
            globalMDropDownString += "<td align='right'><img id='gc_" + globalCount + "_" + elementArray[0] + "DropDown' title='" + globalMDropDownTitle + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/>&nbsp;&nbsp;";
            globalMDropDownString +="<td><img id='gc_" + globalCount + "_" + elementArray[1] + "DropDown' title='" + globalMDropDownTitle + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/></td>";
            globalMDropDownString += "</td>";
            globalMDropDownString += "<td><img id='ShowGlobalPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
            globalMDropDownString += "cursor: hand; padding-left: 5px;' onclick='ShowGlobalProps(event, this, " + element.getAttribute('ctrlid') + ", CCArray);' align='left'/></td></tr></table>";
            document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').innerHTML += globalMDropDownString;
            //dropDownList += dropdownTitle + ",";
        }
        else
        {
            alert("Please enter a valid title with less than 45 characters and no special characters.");
        }
    }
    document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "None";
    globalCount++;
    document.getElementById('ctl00_ContentPlaceHolder1_globalCountHidden').value = globalCount;
}



function CreateSingleGlobal(element)
{
     var globalCount= document.getElementById('ctl00_ContentPlaceHolder1_globalCountHidden').value;
    var globalSDropDownTitle = prompt("Enter the "+ element.innerHTML +" Title");
    var globalSDropDownString = "";
    var titleArray = new Array();
    
     var validTitle = true; 
    
   if((globalSDropDownTitle != "undefined" ) && (globalSDropDownTitle != "") &&  (globalSDropDownTitle != null) &&  globalSDropDownTitle.substring(0,1) != " " && globalSDropDownTitle.length < 45)
   {
        for (var i = 0; i < globalSDropDownTitle.length; i++)
        {  
            if (iChars.indexOf(globalSDropDownTitle.charAt(i)) != -1) 
             { 
               validTitle = false;
             } 
        }
        if(validTitle == false)
        {
            alert ("Please enter a valid title with less than 45 characters and no special characters."); 
        }
    }
    else
    {
        validTitle = false;
        alert ("Please enter a valid title with less than 45 characters and no special characters."); 
    }
    
    
    for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
    {
        titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
    }
    for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
    {
        if(globalSDropDownTitle == titleArray[arrayCountx])
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "Exists"
            alert("A control with the title " + globalSDropDownTitle + " exists.");
        }
    }
    
    var ctrlid = element.getAttribute('ctrlid');
    
    if(document.getElementById('ctl00_ContentPlaceHolder1_FileModeHidden').value == "EDITMODE" && globalFlag == false)
    {
         if(document.getElementById('ctl00_ContentPlaceHolder1_globalCountHidden').value != "")
        {
            globalCount = parseInt(document.getElementById('ctl00_ContentPlaceHolder1_globalCountHidden').value) + parseInt(1);
        }
        if(document.getElementById('ctl00_ContentPlaceHolder1_globalCountHidden').value == "")
        {
            globalCount = parseInt(0);
        }
        globalFlag = true;
    }
    
    if(document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML != "Exists" && validTitle ==true)
    {
        if((globalSDropDownTitle != "undefined" ) && (globalSDropDownTitle != "") &&  (globalSDropDownTitle != null))
        {  
            globalSDropDownString += "<table id='gc_" + globalCount + "_"  + element.innerHTML +"DropDownTable' title='" + globalSDropDownTitle + "' type='GlobalSControl' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:0px; left:0px;' align='right' onclick ='FillProperties(this)'  iswrap='False'  controltype='global' isrequired='False' datasource='DB' skillset='None' skillsetvalues='None' costcentre='None' costcentrevalues='None' iswrap='False' prewrap='' postwrap='' style='z-index:-1;' ispostback='False' controlid='" + element.getAttribute('ctrlid')+ "'>";//
            globalSDropDownString += "<tr ><td style='cursor:none;white-space:nowrap;' align='left'>" + globalSDropDownTitle + "</td>";
            globalSDropDownString += "<td align='right'><img id='gc_" + globalCount + "_" + element.innerHTML + "DropDown' title='" + globalSDropDownTitle + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/>&nbsp;&nbsp;";
            globalSDropDownString += "<td><img id='ShowGlobalPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
            globalSDropDownString += "cursor: hand; padding-left: 5px;' onclick='ShowGlobalProps(event, this, " + ctrlid + ", CCArray);' align='left' /></td></tr></table>";
            document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').innerHTML += globalSDropDownString;
            
            //dropDownList += dropdownTitle + ",";
        }
        else
        {
            alert("Please enter a valid title with less than 45 characters and no special characters.");
        }
    }
   document.getElementById('ctl00_ContentPlaceHolder1_IdExistsDiv').innerHTML = "None";
    globalCount++;
    document.getElementById('ctl00_ContentPlaceHolder1_globalCountHidden').value = globalCount;
}


var controlID = "";


function ShowGlobalProps(e, element, ctrlID, ccarray)
{    
    var height = e.clientY + parseInt('2');
    var offsetHeight = parseInt(e.offsetY);
    height = height - offsetHeight;
    var width = e.clientX
    var offsetWidth = parseInt(e.offsetX);
    width = width - offsetWidth;
    var div = document.getElementById('ctl00_ContentPlaceHolder1_HandsetDiv');
    div.style.display = 'block';
    var rightedge = parseInt(document.body.clientWidth) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientX) - 2;
    var bottomedge = parseInt(document.body.clientHeight) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientY) + 2;
    lefter = (rightedge < width)?event.srcElement.parentNode.parentNode.parentNode.parentNode.clientX - 200:event.clientX - 0;
    topper = (bottomedge < height)?event.srcElement.parentNode.parentNode.parentNode.parentNode.clientY - 200:event.clientY - 0;
    if(parseInt(width) >= 1000)
    {
        lefter = parseInt(event.clientX) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientWidth) - 200;
    }
    if(parseInt(height) >= 550)
    {
        topper = parseInt(event.clientY) - parseInt(event.srcElement.parentNode.parentNode.parentNode.parentNode.clientHeight) - 250;
    }
    div.style.top = topper;
    div.style.left = lefter;
    
    document.getElementById('ctl00_ContentPlaceHolder1_CostCentreGlobalSelect').length = 0;
    document.getElementById('ctl00_ContentPlaceHolder1_SkillSetGlobalSelect').length = 0;
   
    BindGlobalCostCentre(ctrlID, ccarray);
    document.getElementById('CtrlIDLabel').innerHTML = ctrlID;
    
   document.getElementById('ctl00_ContentPlaceHolder1_IdGlobalLabel').innerHTML = event.srcElement.parentNode.parentNode.parentNode.parentNode.title;
   controlID = event.srcElement.parentNode.parentNode.parentNode.parentNode.id;
  
   var empCustObject = event.srcElement.parentNode.parentNode.parentNode.parentNode;
   
   if(empCustObject.costcentre != "None")
   {
       var costCentreArray = new Array();
       costCentreArray = empCustObject.getAttribute('costcentre').split(',');
       costCentreArray.pop(costCentreArray.length - 1);
       document.getElementById('ctl00_ContentPlaceHolder1_ChangeCCGlobalLabel').style.display = 'block';
       document.getElementById('ctl00_ContentPlaceHolder1_CostCentreGlobalSelect').style.display = 'none';
       document.getElementById('ctl00_ContentPlaceHolder1_CCGlobalLabel').innerHTML = costCentreArray;
       document.getElementById('ctl00_ContentPlaceHolder1_CCGlobalLabel').style.display = 'block';
//       if(document.getElementById('ctl00_ContentPlaceHolder1_CostCentreGlobalSelect').options.selectedIndex == -1)
//       {
//        event.srcElement.parentNode.parentNode.parentNode.parentNode.costcentre = "None";
//       }
       
    }
    if(empCustObject.costcentre == "None" || empCustObject.costcentre == null)
    {
        document.getElementById('ctl00_ContentPlaceHolder1_CostCentreGlobalSelect').options.selectedIndex = -1;
        document.getElementById('ctl00_ContentPlaceHolder1_ChangeCCGlobalLabel').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_CCGlobalLabel').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_CostCentreGlobalSelect').style.display = 'block';
    }
    
    if(empCustObject.skillset != "None")
   {
        var skillSetArray = new Array();
        skillSetArray = empCustObject.getAttribute('skillset').split(',');
        skillSetArray.pop(skillSetArray.length - 1);
        document.getElementById('ctl00_ContentPlaceHolder1_ChangeSSGlobalLabel').style.display = 'block';
        document.getElementById('ctl00_ContentPlaceHolder1_SkillSetGlobalSelect').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_SSGlobalLabel').innerHTML = skillSetArray;
        document.getElementById('ctl00_ContentPlaceHolder1_SSGlobalLabel').style.display = 'block';
        //document.getElementById('ctl00_ContentPlaceHolder1_SSLabel').style.display = 'block';
//         if(document.getElementById('ctl00_ContentPlaceHolder1_SkillSetGlobalSelect').options.selectedIndex == -1)
//       {
//        event.srcElement.parentNode.parentNode.parentNode.parentNode.skillset = "None";
//       }
   }
   
   if(empCustObject.skillset == "None" || empCustObject.skillset == null)
   {
        document.getElementById('ctl00_ContentPlaceHolder1_SkillSetGlobalSelect').options.selectedIndex = -1;
        document.getElementById('ctl00_ContentPlaceHolder1_ChangeSSGlobalLabel').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_SSGlobalLabel').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_SkillSetGlobalSelect').style.display = 'block';
   }

}

function ChangeSSGlobalSelect()
{
    document.getElementById('ctl00_ContentPlaceHolder1_CostCentreGlobalSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.costcentre = "None";
    document.getElementById('ctl00_ContentPlaceHolder1_CostCentreGlobalSelect').style.display = 'block';
    document.getElementById('ctl00_ContentPlaceHolder1_ChangeCCGlobalLabel').style.display = 'none';
    document.getElementById('ctl00_ContentPlaceHolder1_CCGlobalLabel').innerHTML = "";
    
    document.getElementById('ctl00_ContentPlaceHolder1_SkillSetGlobalSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.skillset = "None";
    document.getElementById('ctl00_ContentPlaceHolder1_SkillSetGlobalSelect').style.display = 'block';
    document.getElementById('ctl00_ContentPlaceHolder1_ChangeSSGlobalLabel').style.display = 'none';
    document.getElementById('ctl00_ContentPlaceHolder1_SSGlobalLabel').innerHTML = "";
}

function ChangeCCGlobalSelect()
{
    document.getElementById('ctl00_ContentPlaceHolder1_CostCentreGlobalSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.costcentre = "None";
    document.getElementById('ctl00_ContentPlaceHolder1_CostCentreGlobalSelect').style.display = 'block';
    document.getElementById('ctl00_ContentPlaceHolder1_ChangeCCGlobalLabel').style.display = 'none';
    document.getElementById('ctl00_ContentPlaceHolder1_CCGlobalLabel').innerHTML = "";
    
    document.getElementById('ctl00_ContentPlaceHolder1_SkillSetGlobalSelect').options.selectedIndex = -1;
    event.srcElement.parentNode.parentNode.parentNode.parentNode.skillset = "None";
    document.getElementById('ctl00_ContentPlaceHolder1_SkillSetGlobalSelect').style.display = 'block';
    document.getElementById('ctl00_ContentPlaceHolder1_ChangeSSGlobalLabel').style.display = 'none';
    document.getElementById('ctl00_ContentPlaceHolder1_SSGlobalLabel').innerHTML = "";
}


function BindGlobalCostCentre(ctrlID, ccarray)
{   
    for(arrayCounter = 0; arrayCounter < ccarray.length; arrayCounter++)
    {
        if(ctrlID == ccarray[arrayCounter][2])
        {
            var opt = document.createElement("option");
            document.getElementById("ctl00_ContentPlaceHolder1_CostCentreGlobalSelect").options.add(opt);
            textVal = ccarray[arrayCounter][0];
            textDet = ccarray[arrayCounter][1];
            opt.text = textDet;
            opt.value = textVal;
        }
    }
}

function BindGlobalSkillSet(costCentre)
{  //alert(costCentre.options[costCentre.options.selectedIndex].value);
   // alert(ctrlid);
   //alert(event.srcElement.parentNode.parentNode.parentNode.parentNode.tagName);
    document.getElementById("ctl00_ContentPlaceHolder1_SkillSetGlobalSelect").length =0;
   for(var arrayCounter = 0; arrayCounter < document.getElementById("ctl00_ContentPlaceHolder1_CostCentreGlobalSelect").length; arrayCounter++)
    {
        if(document.getElementById("ctl00_ContentPlaceHolder1_CostCentreGlobalSelect").options[arrayCounter].selected)
        {
            for(ssarrayCounter = 0; ssarrayCounter < SSArray.length; ssarrayCounter++)
            {
                //checking if the costcentreid in skillset array matches with CCid in cost centre listbox
                if(document.getElementById("ctl00_ContentPlaceHolder1_CostCentreGlobalSelect").options[arrayCounter].value == SSArray[ssarrayCounter][3] && document.getElementById('CtrlIDLabel').innerHTML == SSArray[ssarrayCounter][2])
                {
                    var skillid = SSArray[ssarrayCounter][1];

                    var ssopt = document.createElement("option");
                    document.getElementById("ctl00_ContentPlaceHolder1_SkillSetGlobalSelect").options.add(ssopt);
                    
                    sstextDet = SSArray[ssarrayCounter][0];
                    sstextVal = SSArray[ssarrayCounter][1];
                    ssopt.text = sstextDet;
                    ssopt.value = sstextVal;
                }
            }
        }
    }
}


function HideShowGlobalProps()
{
    var costcentreString = "";
    var costcentreValues = "";
    var skillsetString = "";
    var skillsetValues = "";
    document.getElementById('ctl00_ContentPlaceHolder1_HandsetDiv').style.display='none';
    var controlILabel = document.getElementById('ctl00_ContentPlaceHolder1_IdGlobalLabel').innerHTML;
    for(var selectCC = 0 ; selectCC < document.getElementById('ctl00_ContentPlaceHolder1_CostCentreGlobalSelect').options.length; selectCC++)
    {
        if(document.getElementById('ctl00_ContentPlaceHolder1_CostCentreGlobalSelect').options[selectCC].selected)
        {
            costcentreString += document.getElementById('ctl00_ContentPlaceHolder1_CostCentreGlobalSelect').options[selectCC].innerText;
            costcentreString += ",";
            costcentreValues += document.getElementById('ctl00_ContentPlaceHolder1_CostCentreGlobalSelect').options[selectCC].value;
            costcentreValues += ",";
        }
    }
    for(var selectSS = 0 ; selectSS < document.getElementById('ctl00_ContentPlaceHolder1_SkillSetGlobalSelect').options.length; selectSS++)
    {
        if(document.getElementById('ctl00_ContentPlaceHolder1_SkillSetGlobalSelect').options[selectSS].selected)
        {
            skillsetString += document.getElementById('ctl00_ContentPlaceHolder1_SkillSetGlobalSelect').options[selectSS].innerText;
            skillsetString += ",";
            skillsetValues += document.getElementById('ctl00_ContentPlaceHolder1_SkillSetGlobalSelect').options[selectSS].value;
            skillsetValues += ",";
        }
    }
    
     if(skillsetValues == "")
    {   
        document.getElementById('ctl00_ContentPlaceHolder1_HandsetDiv').style.display = '';
        alert("Please select a skillset");
        return false;
    }
    
    document.getElementById(controlID).setAttribute('costcentre',costcentreString);
    document.getElementById(controlID).setAttribute('costcentrevalues',costcentreValues);
    document.getElementById(controlID).setAttribute('skillset',skillsetString);
    document.getElementById(controlID).setAttribute('skillsetvalues',skillsetValues);
    if(costcentreString == "")
    {
        document.getElementById(controlID).costcentre = 'None';
        document.getElementById(controlID).costcentrevalues = 'None';
    }
     if(costcentreValues == "")
    {
        document.getElementById(controlID).costcentrevalues = 'None';
    }
     if(skillsetString == "")
    {
        document.getElementById(controlID).skillset='None';
        document.getElementById(controlID).skillsetvalues = 'None';
    }
    if(skillsetValues == "")
    {
        document.getElementById(controlID).skillsetvalues='None';
    }
}

//******************************************Region for Employee Global Control - Ends **************************************************//



//This function is used to fill the properties of the clicked control in the design view.
function FillProperties(clickedElement)
{   
    clickedElement = event.srcElement; 
    document.getElementById('ctl00_ContentPlaceHolder1_storeControlTypeDiv').innerHTML = clickedElement.type;
    document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML = clickedElement.id;   

         
         
    if(clickedElement.type=="MainDiv")
    {
         document.getElementById('PropertiesTable').style.display='none';
         document.getElementById('ctl00_ContentPlaceHolder1_DeleteButton').style.display = 'none';
        for(var checkChild=0; checkChild < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; checkChild++)
        {
            document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[checkChild].style.border = "#afafaf 4px dashed";
        }
    }
    else
    {   
        if(document.getElementById('HideTableImg').style.display != 'none')
        {
            for(var checkChild=0; checkChild < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; checkChild++)
            {
                //clickedElement.style.border = "#40BF8C 4px dashed";
                if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[checkChild].id == clickedElement.id)
                {
                    document.getElementById('ctl00_ContentPlaceHolder1_DeleteButton').style.display = 'block';
                    clickedElement.style.border = "#40BF8C 4px dashed";
                   
                }
                else
                {
                    document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[checkChild].style.border = "#afafaf 4px dashed";
                    
                }
            }
            document.getElementById('PropertiesTable').style.display='block';
        }
    }
           
    

    if(clickedElement.type == 'DropDown' || clickedElement.type == 'ListBox' || clickedElement.type == 'EmpDropDown' || clickedElement.type == 'GlobalMControl' || clickedElement.type == 'GlobalSControl')
    {
        if(document.getElementById('ctl00_ContentPlaceHolder1_FileModeHidden').value == "EDITMODE" && dropDownFlag == false)
        {
            dropDownList = document.getElementById('ctl00_ContentPlaceHolder1_DropDownArray').value;
            dropDownIDList = document.getElementById('ctl00_ContentPlaceHolder1_DropDownIDArray').value;  
            dropDownFlag = true;
        }
         if(document.getElementById('ctl00_ContentPlaceHolder1_FileModeHidden').value == "EDITMODE" && listBoxFlag == false)
        {
            listBoxList = document.getElementById('ctl00_ContentPlaceHolder1_ListBoxArray').value;
            listBoxIDList = document.getElementById('ctl00_ContentPlaceHolder1_ListBoxIDArray').value;
            listBoxFlag = true;
        }

        document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value = clickedElement.title;
        document.getElementById('ctl00_ContentPlaceHolder1_textTextBox').style.display = "none";
        document.getElementById('ctl00_ContentPlaceHolder1_textLabel').style.display = "none";
        document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML = clickedElement.id;
        document.getElementById('ctl00_ContentPlaceHolder1_maxLengthLabel').style.display = "none";
        document.getElementById('ctl00_ContentPlaceHolder1_maxLengthTextBox').style.display = "none";
        document.getElementById('ctl00_ContentPlaceHolder1_topTextBox').value=clickedElement.style.top;
        document.getElementById('ctl00_ContentPlaceHolder1_leftTextBox').value=clickedElement.style.left;
        document.getElementById('ctl00_ContentPlaceHolder1_TextModeSelect').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_TextModeLabel').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_IsTypeSelect').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_IsTypeLabel').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_WidthText').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_WidthLabel').style.display = "none";
             document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredLabel').style.display = "inline";
            document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').style.display = "inline";
//        if(clickedElement.type == 'DropDown')
//        {
//            document.getElementById('ctl00_ContentPlaceHolder1_WidthText').value=clickedElement.style.width;
//        }
//        if(clickedElement.type == 'ListBox')
//        {
            document.getElementById('ctl00_ContentPlaceHolder1_WidthText').value=clickedElement.style.width;
   //     }
        
        document.getElementById('ctl00_ContentPlaceHolder1_IsDependentLabel').style.display = "inline";
        document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').style.display = "inline";
        document.getElementById('ctl00_ContentPlaceHolder1_ListItemsLabel').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_ListItemsSelect').style.display = 'none';
       

        if(clickedElement.iswrap == 'False' )
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex = 1;
            document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').value ='';
            document.getElementById('ctl00_ContentPlaceHolder1_PreWraplabel').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').value ='';
            document.getElementById('ctl00_ContentPlaceHolder1_PostWrapLabel').style.display ='none';
        }
        else
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex = 0;
            document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').style.display ='inline';
            document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').value =clickedElement.prewrap;
            document.getElementById('ctl00_ContentPlaceHolder1_PreWraplabel').style.display ='inline';
            document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').style.display ='inline';
            document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').value =clickedElement.postwrap;
            document.getElementById('ctl00_ContentPlaceHolder1_PostWrapLabel').style.display ='inline';
        }
        
        if(clickedElement.type == 'DropDown')
        {
            FillPrevRefAndDependentDDCtrl(clickedElement);
        }
        
        if(clickedElement.type == 'ListBox')
        {   
            FillPrevRefAndDependentLBCtrl(clickedElement);
        }

        if(clickedElement.dependency == 'False' )
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').options.selectedIndex = 1;
            document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options.selectedIndex = 0;
            document.getElementById('ctl00_ContentPlaceHolder1_DependentControlLabel').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').options.selectedIndex = 0;
            document.getElementById('ctl00_ContentPlaceHolder1_PreRefLabel').style.display ='none';
        }
        else
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').options.selectedIndex = 0;
            document.getElementById('ctl00_ContentPlaceHolder1_DependentControlLabel').style.display ='inline';
            document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').style.display ='inline';
            for(var depSelCount=0; depSelCount < document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options.length; depSelCount++)
            { 
                if(document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options[depSelCount].value == clickedElement.dependentid)
                {   
                    document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options[depSelCount].setAttribute('selected','true');
                }
            }
            document.getElementById('ctl00_ContentPlaceHolder1_PreRefLabel').style.display ='inline';
            document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').style.display ='inline';
            for(var refSelCount=0; refSelCount < document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').options.length; refSelCount++)
            { 
                if(document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').options[refSelCount].value == clickedElement.prevref)
                {   
                    document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').options[refSelCount].setAttribute('selected','true');
                }
            }
        }
         if(clickedElement.type == 'EmpDropDown' || clickedElement.type == 'GlobalMControl' || clickedElement.type == 'GlobalSControl')
        {
             document.getElementById('ctl00_ContentPlaceHolder1_IsDependentLabel').style.display = "none";
             document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').style.display = "none";
             document.getElementById('ctl00_ContentPlaceHolder1_PreRefLabel').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_DependentControlLabel').style.display ='none';
        }
        if(clickedElement.isrequired == 'False')
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').options.selectedIndex = 1;
        }
        else
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').options.selectedIndex = 0;
        }
        
         if(clickedElement.ismanageable == 'False')
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IsManageableSelect').options.selectedIndex = 1;
        }
        else
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IsManageableSelect').options.selectedIndex = 0;
        }
    }
    
    //Section to fill properties for RadioButtonList and CheckBoxList - Starts
    if(clickedElement.type == "RadioButtonList" || clickedElement.type == "CheckBoxList")
    {
    //alert(clickedElement.childNodes[0].childNodes[0].childNodes[1].childNodes[1].type)
        if(clickedElement.childNodes[0].childNodes[0].childNodes[1].childNodes[1].type == 'radio' || clickedElement.childNodes[0].childNodes[0].childNodes[1].childNodes[1].type == 'checkbox')
        {
            
            document.getElementById('ctl00_ContentPlaceHolder1_ListItemsLabel').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_ListItemsSelect').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value = clickedElement.title;
            document.getElementById('ctl00_ContentPlaceHolder1_textTextBox').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_textLabel').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML = clickedElement.id;
            document.getElementById('ctl00_ContentPlaceHolder1_maxLengthLabel').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_maxLengthTextBox').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_topTextBox').value=clickedElement.style.top;
            document.getElementById('ctl00_ContentPlaceHolder1_leftTextBox').value=clickedElement.style.left;
            document.getElementById('ctl00_ContentPlaceHolder1_WidthText').value=clickedElement.style.width;
            document.getElementById('ctl00_ContentPlaceHolder1_WidthText').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_WidthLabel').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredLabel').style.display = "inline";
            document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').style.display = "inline";
            document.getElementById('ctl00_ContentPlaceHolder1_IsDependentLabel').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_PreRefLabel').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_DependentControlLabel').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').style.display = "none";
             document.getElementById('ctl00_ContentPlaceHolder1_TextModeSelect').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_TextModeLabel').style.display = 'none';
         document.getElementById('ctl00_ContentPlaceHolder1_IsTypeSelect').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_IsTypeLabel').style.display = 'none';
            
             if(clickedElement.iswrap == 'False' )
            {
                document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex = 1;
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').style.display ='none';
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').value ='';
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraplabel').style.display ='none';
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').style.display ='none';
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').value ='';
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapLabel').style.display ='none';
            }
            else
            {
                document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex = 0;
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').style.display ='inline';
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').value =clickedElement.prewrap;
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraplabel').style.display ='inline';
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').style.display ='inline';
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').value =clickedElement.postwrap;
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapLabel').style.display ='inline';
            }
            
            for(var listItemCount=0; listItemCount < document.getElementById('ctl00_ContentPlaceHolder1_ListItemsSelect').options.length + 1; listItemCount++)
            { 
                document.getElementById('ctl00_ContentPlaceHolder1_ListItemsSelect').options.remove(1);
            }
            
            for(var controlCount =1; controlCount < clickedElement.childNodes[0].childNodes[0].childNodes.length; controlCount++)
            {
               // alert(clickedElement.childNodes[0].childNodes[0].childNodes[controlCount].childNodes[1].title);
                //alert(clickedElement.childNodes[0].childNodes[0].childNodes[controlCount].childNodes[0].value);
                var controlListItemOption = document.createElement("option");
                document.getElementById('ctl00_ContentPlaceHolder1_ListItemsSelect').options.add(controlListItemOption);
                controlListItemOption.innerText = clickedElement.childNodes[0].childNodes[0].childNodes[controlCount].childNodes[1].title;
                controlListItemOption.value = clickedElement.childNodes[0].childNodes[0].childNodes[controlCount].childNodes[1].title;
            }
            
            if(clickedElement.isrequired == 'False')
            {
                document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').options.selectedIndex = 1;
            }
            else
            {
                document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').options.selectedIndex = 0;
            }
            
             if(clickedElement.ismanageable == 'False')
            {
                document.getElementById('ctl00_ContentPlaceHolder1_IsManageableSelect').options.selectedIndex = 1;
            }
            else
            {
                document.getElementById('ctl00_ContentPlaceHolder1_IsManageableSelect').options.selectedIndex = 0;
            }
           
        }
    }
    //Section to fill properties for RadioButtonList and CheckBoxList - Ends
    
    if(clickedElement.type == 'TextBox')
    {
        document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value = clickedElement.title;
        document.getElementById('ctl00_ContentPlaceHolder1_textTextBox').style.display = "none";
        document.getElementById('ctl00_ContentPlaceHolder1_textLabel').style.display = "none";
        // document.getElementById('ctl00_ContentPlaceHolder1_textTextBox').value = clickedElement.value;
        document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML = clickedElement.id;
        document.getElementById('ctl00_ContentPlaceHolder1_maxLengthLabel').style.display = "inline";
        document.getElementById('ctl00_ContentPlaceHolder1_maxLengthTextBox').style.display = "inline";
        document.getElementById('ctl00_ContentPlaceHolder1_maxLengthTextBox').value = document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).getAttribute('maxlength');
        document.getElementById('ctl00_ContentPlaceHolder1_topTextBox').value=clickedElement.style.top;
        document.getElementById('ctl00_ContentPlaceHolder1_leftTextBox').value=clickedElement.style.left;
        document.getElementById('ctl00_ContentPlaceHolder1_IsDependentLabel').style.display = "none";
        document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').style.display = "none";
        document.getElementById('ctl00_ContentPlaceHolder1_IsManageableLabel').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_IsManageableSelect').style.display = 'none';
        document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').style.display = 'inline';
        document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredLabel').style.display = 'inline';
        document.getElementById('ctl00_ContentPlaceHolder1_TextModeSelect').style.display = 'inline';
        document.getElementById('ctl00_ContentPlaceHolder1_TextModeLabel').style.display = 'inline';
        document.getElementById('ctl00_ContentPlaceHolder1_IsTypeSelect').style.display = 'inline';
        document.getElementById('ctl00_ContentPlaceHolder1_IsTypeLabel').style.display = 'inline';
        document.getElementById('ctl00_ContentPlaceHolder1_IsDependentLabel').style.display = "none";
         document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').style.display = "none";
         document.getElementById('ctl00_ContentPlaceHolder1_PreRefLabel').style.display ='none';
        document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').style.display ='none';
        document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').style.display ='none';
        document.getElementById('ctl00_ContentPlaceHolder1_DependentControlLabel').style.display ='none';
        document.getElementById('ctl00_ContentPlaceHolder1_WidthText').value=clickedElement.style.width;
        document.getElementById('ctl00_ContentPlaceHolder1_WidthText').style.display = "none";
        document.getElementById('ctl00_ContentPlaceHolder1_WidthLabel').style.display = "none";


        if(clickedElement.isrequired == 'False')
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').options.selectedIndex = 1;
        }
        else
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').options.selectedIndex = 0;
        }

        if(clickedElement.textmode == 'Multiline')
        {
            document.getElementById('ctl00_ContentPlaceHolder1_TextModeSelect').options.selectedIndex = 1;
        }
        else
        {
            document.getElementById('ctl00_ContentPlaceHolder1_TextModeSelect').options.selectedIndex = 0;
        }

        if(clickedElement.istype == 'Numeric')
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IsTypeSelect').options.selectedIndex = 0;
        }
        if(clickedElement.istype == 'Alphabet')
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IsTypeSelect').options.selectedIndex = 1;
        }
        if(clickedElement.istype == 'AlphaNumeric')
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IsTypeSelect').options.selectedIndex = 2;
        }

        if(clickedElement.iswrap == 'False' )
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex = 1;
            document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').value ='';
            document.getElementById('ctl00_ContentPlaceHolder1_PreWraplabel').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').value ='';
            document.getElementById('ctl00_ContentPlaceHolder1_PostWrapLabel').style.display ='none';
        }
        else
        {
            document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex = 0;
            document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').style.display ='inline';
            document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').value =clickedElement.prewrap;
            document.getElementById('ctl00_ContentPlaceHolder1_PreWraplabel').style.display ='inline';
            document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').style.display ='inline';
            document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').value =clickedElement.postwrap;
            document.getElementById('ctl00_ContentPlaceHolder1_PostWrapLabel').style.display ='inline';
        }
      }
        if(clickedElement.type == 'Label')
        {
            document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value = clickedElement.title;
            document.getElementById('ctl00_ContentPlaceHolder1_textTextBox').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_textLabel').style.display = "none";
            // document.getElementById('ctl00_ContentPlaceHolder1_textTextBox').value = clickedElement.value;
            document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML = clickedElement.id;
            document.getElementById('ctl00_ContentPlaceHolder1_maxLengthLabel').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_maxLengthTextBox').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_topTextBox').value=clickedElement.style.top;
            document.getElementById('ctl00_ContentPlaceHolder1_leftTextBox').value=clickedElement.style.left;
            document.getElementById('ctl00_ContentPlaceHolder1_IsDependentLabel').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_IsManageableLabel').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_IsManageableSelect').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredLabel').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_TextModeSelect').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_TextModeLabel').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_IsTypeSelect').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_IsTypeLabel').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_IsDependentLabel').style.display = "none";
             document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').style.display = "none";
             document.getElementById('ctl00_ContentPlaceHolder1_PreRefLabel').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_DependentControlLabel').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_WidthText').value=clickedElement.style.width;
            document.getElementById('ctl00_ContentPlaceHolder1_WidthText').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_WidthLabel').style.display = "none";
                
            if(clickedElement.iswrap == 'False' )
            {
                document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex = 1;
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').style.display ='none';
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').value ='';
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraplabel').style.display ='none';
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').style.display ='none';
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').value ='';
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapLabel').style.display ='none';
            }
            else
            {
                document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex = 0;
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').style.display ='inline';
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').value =clickedElement.prewrap;
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraplabel').style.display ='inline';
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').style.display ='inline';
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').value =clickedElement.postwrap;
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapLabel').style.display ='inline';
            }
    }
    
    if(clickedElement.type == 'BButton')
        {
            document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value = clickedElement.title;
            document.getElementById('ctl00_ContentPlaceHolder1_textTextBox').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_textLabel').style.display = "none";
            // document.getElementById('ctl00_ContentPlaceHolder1_textTextBox').value = clickedElement.value;
            document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML = clickedElement.id;
            document.getElementById('ctl00_ContentPlaceHolder1_maxLengthLabel').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_maxLengthTextBox').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_topTextBox').value=clickedElement.style.top;
            document.getElementById('ctl00_ContentPlaceHolder1_leftTextBox').value=clickedElement.style.left;
            document.getElementById('ctl00_ContentPlaceHolder1_IsDependentLabel').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_IsManageableLabel').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_IsManageableSelect').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredLabel').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_TextModeSelect').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_TextModeLabel').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_IsTypeSelect').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_IsTypeLabel').style.display = 'none';
            document.getElementById('ctl00_ContentPlaceHolder1_IsDependentLabel').style.display = "none";
             document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').style.display = "none";
             document.getElementById('ctl00_ContentPlaceHolder1_PreRefLabel').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_DependentControlLabel').style.display ='none';
            document.getElementById('ctl00_ContentPlaceHolder1_WidthText').value=clickedElement.style.width;
            document.getElementById('ctl00_ContentPlaceHolder1_WidthText').style.display = "none";
            document.getElementById('ctl00_ContentPlaceHolder1_WidthLabel').style.display = "none";
            if(clickedElement.iswrap == 'False' )
            {
                document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex = 1;
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').style.display ='none';
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').value ='';
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraplabel').style.display ='none';
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').style.display ='none';
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').value ='';
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapLabel').style.display ='none';
            }
            else
            {
                document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex = 0;
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').style.display ='inline';
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').value =clickedElement.prewrap;
                document.getElementById('ctl00_ContentPlaceHolder1_PreWraplabel').style.display ='inline';
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').style.display ='inline';
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').value =clickedElement.postwrap;
                document.getElementById('ctl00_ContentPlaceHolder1_PostWrapLabel').style.display ='inline';
            }
         }
}
     

//This function is called when the update button is clicked in the Propertie Panel and updates the changed properties of the selected control.     
function UpdateProperties()
{ 
    if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length != 0)
    {   
        if(document.getElementById('ctl00_ContentPlaceHolder1_storeControlTypeDiv').innerHTML == "DropDown" || document.getElementById('ctl00_ContentPlaceHolder1_storeControlTypeDiv').innerHTML == "ListBox" || document.getElementById('ctl00_ContentPlaceHolder1_storeControlTypeDiv').innerHTML == "EmpDropDown" || document.getElementById('ctl00_ContentPlaceHolder1_storeControlTypeDiv').innerHTML == "GlobalMControl" || document.getElementById('ctl00_ContentPlaceHolder1_storeControlTypeDiv').innerHTML == 'GlobalSControl')
        {
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).title = document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value;
           // alert(document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).childNodes[2].innerHTML); //= document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).style.top = document.getElementById('ctl00_ContentPlaceHolder1_topTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).style.left = document.getElementById('ctl00_ContentPlaceHolder1_leftTextBox').value;
     
            
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).style.width = document.getElementById('ctl00_ContentPlaceHolder1_WidthText').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).prewrap = document.getElementById('ctl00_ContentPlaceHolder1_PreWrapTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).postwrap = document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).iswrap = document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options[document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex].text;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).dependency = document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').options[document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').options.selectedIndex].text;
             document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).isrequired = document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').options[document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').options.selectedIndex].text;
             document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).ismanageable = document.getElementById('ctl00_ContentPlaceHolder1_IsManageableSelect').options[document.getElementById('ctl00_ContentPlaceHolder1_IsManageableSelect').options.selectedIndex].text;
            
           // alert(document.getElementById('ctl00_ContentPlaceHolder1_storeControlTypeDiv').innerHTML);
            if(document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options.selectedIndex != 0)
            {   
                document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).dependentid = document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options[document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options.selectedIndex].value;
            }
            else
            {
                 document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).dependentid = "";
            }
            if(document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').options.selectedIndex != 0)
            {
                document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).prevref = document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').options[document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').options.selectedIndex].value;
            }
            else
            {
                document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).prevref = "";
            }
        }
        
        
        if(document.getElementById('ctl00_ContentPlaceHolder1_storeControlTypeDiv').innerHTML == "RadioButtonList" || document.getElementById('ctl00_ContentPlaceHolder1_storeControlTypeDiv').innerHTML == "CheckBoxList")
        {
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).title = document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).style.top = document.getElementById('ctl00_ContentPlaceHolder1_topTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).style.left = document.getElementById('ctl00_ContentPlaceHolder1_leftTextBox').value;
            if(parseInt(document.getElementById('ctl00_ContentPlaceHolder1_WidthText').value) <= 500)
            {
                document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).style.width = document.getElementById('ctl00_ContentPlaceHolder1_WidthText').value;
            }
             else
            {
                alert('Width cannot be more than 500');
            }
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).prewrap = document.getElementById('ctl00_ContentPlaceHolder1_PreWrapTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).postwrap = document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).iswrap = document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options[document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex].text;
            //document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).dependency = document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').options[document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').options.selectedIndex].text;
             document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).isrequired = document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').options[document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').options.selectedIndex].text;
             document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).ismanageable = document.getElementById('ctl00_ContentPlaceHolder1_IsManageableSelect').options[document.getElementById('ctl00_ContentPlaceHolder1_IsManageableSelect').options.selectedIndex].text;
            
        }
        
        if(document.getElementById('ctl00_ContentPlaceHolder1_storeControlTypeDiv').innerHTML == "TextBox")
        {
            
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).title = document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).style.top = document.getElementById('ctl00_ContentPlaceHolder1_topTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).style.left = document.getElementById('ctl00_ContentPlaceHolder1_leftTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).isrequired = document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').options[document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').options.selectedIndex].text;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).style.width = document.getElementById('ctl00_ContentPlaceHolder1_WidthText').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).prewrap = document.getElementById('ctl00_ContentPlaceHolder1_PreWrapTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).postwrap = document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).iswrap = document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options[document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex].text;
            if(document.getElementById('ctl00_ContentPlaceHolder1_maxLengthTextBox').value == 0)
            {  
                document.getElementById('ctl00_ContentPlaceHolder1_maxLengthTextBox').value = 20;
                document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).maxlength = 20;
                
            }
            else
            {
                document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).maxlength = document.getElementById('ctl00_ContentPlaceHolder1_maxLengthTextBox').value;
            }
          
        }
        
        if(document.getElementById('ctl00_ContentPlaceHolder1_storeControlTypeDiv').innerHTML == "Label" || document.getElementById('ctl00_ContentPlaceHolder1_storeControlTypeDiv').innerHTML == "BButton")
        {
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).title = document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).style.top = document.getElementById('ctl00_ContentPlaceHolder1_topTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).style.left = document.getElementById('ctl00_ContentPlaceHolder1_leftTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).style.width = document.getElementById('ctl00_ContentPlaceHolder1_WidthText').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).prewrap = document.getElementById('ctl00_ContentPlaceHolder1_PreWrapTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).postwrap = document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').value;
            document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML).iswrap = document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options[document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex].text;
        }
     }
  }

function DeleteControl()
{
  if(document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').childNodes.length != 0)
  {
      var controlID = document.getElementById('ctl00_ContentPlaceHolder1_storeIdDiv').innerHTML;
      var childToRemove = document.getElementById(controlID);
   
      var dropDownDelArray = new Array();
      dropDownDelArray = dropDownList.split(',')
      dropDownDelArray.pop(dropDownArray.length - 1);
   
      if(childToRemove.type == "DropDown")
      {
         for(var depArrayCount=0 ; depArrayCount <  dropDownDelArray.length; depArrayCount++)
        {
           
          if(childToRemove.title == dropDownDelArray[depArrayCount])
          { 
            var textToRemove = childToRemove.title + ",";
            dropDownList = dropDownList.replace(textToRemove,'');
            document.getElementById('ctl00_ContentPlaceHolder1_DropDownArray').value = dropDownList;
            dropDownFlag = false;
           } 
         }
         FillPrevRefAndDependentDDCtrlAfterDel();
      }
      
      var listBoxDelArray = new Array();
      listBoxDelArray = listBoxList.split(',')
      listBoxDelArray.pop(listBoxDelArray.length - 1);
        
      if(childToRemove.type == "ListBox")
      {
        for(var depArrayCount=0 ; depArrayCount <  listBoxDelArray.length; depArrayCount++)
        {
          if(childToRemove.title == listBoxDelArray[depArrayCount])
          {
            document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options.removeChild(document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options[depArrayCount]);
            var textToRemove = childToRemove.title + ",";
            listBoxList = listBoxList.replace(textToRemove,'');
             document.getElementById('ctl00_ContentPlaceHolder1_ListBoxArray').value = listBoxList;
            listBoxFlag = false;
           } 
         } 
         FillPrevRefAndDependentLBCtrlAfterDel();
     }
      document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').removeChild(childToRemove); 
      document.getElementById('PropertiesTable').style.display = 'none';
      document.getElementById('ctl00_ContentPlaceHolder1_DeleteButton').style.display = 'none';
    } 
}

function SetTextMode() 
 {
    var titleArray = new Array();
      
    if(document.getElementById('ctl00_ContentPlaceHolder1_TextModeSelect').options.selectedIndex == "0" )
    { 
        for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
        {
            titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
        }
        for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
        {
            if(document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value == titleArray[arrayCountx])
            {
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].textmode ='Singleline';
            }
        }   
    }
     if(document.getElementById('ctl00_ContentPlaceHolder1_TextModeSelect').options.selectedIndex == "1" )
    { 
         for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
        {
            titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
        }
        for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
        {
            if(document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value == titleArray[arrayCountx])
            {
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].textmode ='Multiline';
            }
        }  
    }
 }     
 
 function IsType() 
 {
    var titleArray = new Array();
      
    if(document.getElementById('ctl00_ContentPlaceHolder1_IsTypeSelect').options.selectedIndex == "0" )
    { 
        for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
        {
            titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
        }
        for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
        {
            if(document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value == titleArray[arrayCountx])
            {
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].istype ='Numeric';
            }
        }   
    }
     if(document.getElementById('ctl00_ContentPlaceHolder1_IsTypeSelect').options.selectedIndex == "1" )
    { 
         for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
        {
            titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
        }
        for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
        {
            if(document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value == titleArray[arrayCountx])
            {
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].istype ='Alphabet';
            }
        }  
    }
     if(document.getElementById('ctl00_ContentPlaceHolder1_IsTypeSelect').options.selectedIndex == "2" )
    { 
         for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
        {
            titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
        }
        for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
        {
            if(document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value == titleArray[arrayCountx])
            {
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].istype ='AlphaNumeric';
            }
        }  
    }
 } 

 function SetIsManageable() 
 {
    var titleArray = new Array();
      
    if(document.getElementById('ctl00_ContentPlaceHolder1_IsManageableSelect').options.selectedIndex == "0" )
    { 
        for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
        {
            titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
        }
        for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
        {
            if(document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value == titleArray[arrayCountx])
            {
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].ismanageable ='True';
            }
        }   
    }
     if(document.getElementById('ctl00_ContentPlaceHolder1_IsManageableSelect').options.selectedIndex == "1" )
    { 
         for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
        {
            titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
        }
        for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
        {
            if(document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value == titleArray[arrayCountx])
            {
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].ismanageable ='False';
            }
        }  
    }
 }   
     
 function SetIsRequired() 
 {
    var titleArray = new Array();
      
    if(document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').options.selectedIndex == "0" )
    { 
        for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
        {
            titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
        }
        for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
        {
            if(document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value == titleArray[arrayCountx])
            {
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].isrequired ='True';
            }
        }   
    }
     if(document.getElementById('ctl00_ContentPlaceHolder1_IsRequiredSelect').options.selectedIndex == "1" )
    { 
         for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
        {
            titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
        }
        for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
        {
            if(document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value == titleArray[arrayCountx])
            {
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].isrequired ='False';
            }
        }  
    }
 }   
 
function SetWrap()
{
    var titleArray = new Array();

    if(document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex == "0" )
    { 
        document.getElementById('ctl00_ContentPlaceHolder1_PreWrapTextBox').style.display ='inline';
        document.getElementById('ctl00_ContentPlaceHolder1_PreWrapLabel').style.display ='inline';
        document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').style.display ='inline';
        document.getElementById('ctl00_ContentPlaceHolder1_PostWrapLabel').style.display ='inline';
        for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
        {
            titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
        }
        for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
        {
            if(document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value == titleArray[arrayCountx])
            {
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].iswrap ='True';
            }
        }
    }
    if(document.getElementById('ctl00_ContentPlaceHolder1_IsWrapLabelSelect').options.selectedIndex == "1")
    {
        document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').style.display ='none';
        document.getElementById('ctl00_ContentPlaceHolder1_PreWraptextbox').value ='';
        document.getElementById('ctl00_ContentPlaceHolder1_PreWraplabel').style.display ='none';
        document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').style.display ='none';
        document.getElementById('ctl00_ContentPlaceHolder1_PostWrapTextBox').value ='';
        document.getElementById('ctl00_ContentPlaceHolder1_PostWrapLabel').style.display ='none';
        for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
        {
            titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
        }
        for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
        {
        if(document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value == titleArray[arrayCountx])
            {
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].iswrap ='False';
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].prewrap ='';
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].postwrap ='';
            }
        }
    }
}


     
function SetDependent()
{
    var titleArray = new Array();

    if(document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').options.selectedIndex == "0")
    {
        document.getElementById('ctl00_ContentPlaceHolder1_DependentControlLabel').style.display ='inline';
        document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').style.display ='inline';
        document.getElementById('ctl00_ContentPlaceHolder1_PreRefLabel').style.display ='inline';
        document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').style.display ='inline';
        for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
        {
            titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
        }
        for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
        {
            if(document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value == titleArray[arrayCountx])
            {
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].dependency ='True';
            }
        }
    }
    if(document.getElementById('ctl00_ContentPlaceHolder1_IsDependentSelect').options.selectedIndex == "1")
    {
        document.getElementById('ctl00_ContentPlaceHolder1_DependentControlLabel').style.display ='none';
        document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').style.display ='none';
        document.getElementById('ctl00_ContentPlaceHolder1_PreRefLabel').style.display ='none';
        document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').style.display ='none';

        for(var arrayCount =0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
        {
            titleArray[arrayCount] = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].title;
        }
        for(var arrayCountx =0 ; arrayCountx < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCountx++)
        {
            if(document.getElementById('ctl00_ContentPlaceHolder1_titleTextBox').value == titleArray[arrayCountx])
            {
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].dependency ='False';
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].prevref ="";
                document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCountx].dependentid ="";
            }
        }
    }    
}

function FillPrevRefAndDependentLBCtrl(clickElementObj)
{

    document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').length = 0;
    document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').length = 0;

    var noneDepOption = document.createElement("option");
    document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options.add(noneDepOption);
    noneDepOption.innerText = "None";
    noneDepOption.value = "None";
  
    var nonePrevOption = document.createElement("option");
    document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').options.add(nonePrevOption);
    nonePrevOption.innerText = "None";
    nonePrevOption.value = "None";
   
    listBoxArray = listBoxList.split(',');
    listBoxArray.pop(listBoxArray.length - 1)
    
    
    listBoxIDArray = listBoxIDList.split(',');
    listBoxIDArray.pop(listBoxIDArray.length - 1)

    for(var depArrayCount=0 ; depArrayCount < listBoxArray.length; depArrayCount++)
    {
        if(listBoxArray[depArrayCount]!= clickElementObj.title)
        {
           var depOption = document.createElement("option");
           document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options.add(depOption);
           depOption.innerText = listBoxArray[depArrayCount];
           depOption.value = listBoxIDArray[depArrayCount];
        }
    }
      for(var prevArrayCount=0 ; prevArrayCount < listBoxArray.length; prevArrayCount++)
     {
      if(listBoxArray[prevArrayCount]!= clickElementObj.title)
      {
        var prevOption = document.createElement("option");
        document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').options.add(prevOption);
        prevOption.innerText = listBoxArray[prevArrayCount];
        prevOption.value = listBoxIDArray[prevArrayCount];
       } 
    }  
}


function FillPrevRefAndDependentLBCtrlAfterDel()
{

    document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').length = 0;
    document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').length = 0;

    var noneDepOption = document.createElement("option");
    document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options.add(noneDepOption);
    noneDepOption.innerText = "None";
    noneDepOption.value = "None";
  
    var nonePrevOption = document.createElement("option");
    document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').options.add(nonePrevOption);
    nonePrevOption.innerText = "None";
    nonePrevOption.value = "None";
   
   
    listBoxArray = listBoxList.split(',');
    listBoxArray.pop(listBoxArray.length - 1)
    
    
    listBoxIDArray = listBoxIDList.split(',');
    listBoxIDArray.pop(listBoxIDArray.length - 1)

    for(var depArrayCount=0 ; depArrayCount < listBoxArray.length; depArrayCount++)
    {
        
           var depOption = document.createElement("option");
           document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options.add(depOption);
           depOption.innerText = listBoxArray[depArrayCount];
           depOption.value = listBoxIDArray[depArrayCount];
        
    }
      for(var prevArrayCount=0 ; prevArrayCount < listBoxArray.length; prevArrayCount++)
     {
      
        var prevOption = document.createElement("option");
        document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').options.add(prevOption);
        prevOption.innerText = listBoxArray[prevArrayCount];
        prevOption.value = listBoxIDArray[prevArrayCount];
       
    }  
}
   
     
     
function FillPrevRefAndDependentDDCtrl(clickElementObj)
{  
    document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').length = 0;
    document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').length = 0;

    var noneDropDepOption = document.createElement("option");
    document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options.add(noneDropDepOption);
    noneDropDepOption.innerText = "None";
    noneDropDepOption.value = "None";
  
    var noneDropPrevOption = document.createElement("option");
    document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').options.add(noneDropPrevOption);
     noneDropPrevOption.innerText = "None";
    noneDropPrevOption.value = "None";
    
    dropDownArray = dropDownList.split(',');
    dropDownArray.pop(dropDownArray.length - 1);
    
    dropDownIDArray = dropDownIDList.split(',');
    dropDownIDArray.pop(dropDownIDArray.length - 1);
    
    for(var depArrayCount=0 ; depArrayCount < dropDownArray.length; depArrayCount++)
    {   
        if(dropDownArray[depArrayCount]!= clickElementObj.title)
        {
            var depDropOption = document.createElement("option");
           document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options.add(depDropOption);
           depDropOption.innerText = dropDownArray[depArrayCount];
           depDropOption.value = dropDownIDArray[depArrayCount];
       }
        
    }
     for(var prevArrayCount=0 ; prevArrayCount < dropDownArray.length; prevArrayCount++)
    { 
        if(dropDownArray[prevArrayCount]!= clickElementObj.title)
        {
           var prevDropOption = document.createElement("option");
           document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').options.add(prevDropOption);
           prevDropOption.innerText = dropDownArray[prevArrayCount];
           prevDropOption.value = dropDownIDArray[prevArrayCount];
        }
       
    }
}


function FillPrevRefAndDependentDDCtrlAfterDel()
{  
    document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').length = 0;
    document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').length = 0;

    var noneDropDepOption = document.createElement("option");
    document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options.add(noneDropDepOption);
    noneDropDepOption.innerText = "None";
    noneDropDepOption.value = "None";
  
    var noneDropPrevOption = document.createElement("option");
    document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').options.add(noneDropPrevOption);
     noneDropPrevOption.innerText = "None";
    noneDropPrevOption.value = "None";
    
    dropDownArray = dropDownList.split(',');
    dropDownArray.pop(dropDownArray.length - 1);
    
    dropDownIDArray = dropDownIDList.split(',');
    dropDownIDArray.pop(dropDownIDArray.length - 1);
    
    for(var depArrayCount=0 ; depArrayCount < dropDownArray.length; depArrayCount++)
    {   
        
            var depDropOption = document.createElement("option");
           document.getElementById('ctl00_ContentPlaceHolder1_DependentControlSelect').options.add(depDropOption);
           depDropOption.innerText = dropDownArray[depArrayCount];
           depDropOption.value = dropDownIDArray[depArrayCount];
       
        
    }
     for(var prevArrayCount=0 ; prevArrayCount < dropDownArray.length; prevArrayCount++)
    { 
        
           var prevDropOption = document.createElement("option");
           document.getElementById('ctl00_ContentPlaceHolder1_PreRefSelect').options.add(prevDropOption);
           prevDropOption.innerText = dropDownArray[prevArrayCount];
           prevDropOption.value = dropDownIDArray[prevArrayCount];
        
       
    }
}


function CreateXmlString()
{
    var xmlstring = "";
    var CCSSunset = false;
    var DDunset = false;
    
    if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length != 0)
    {
             for(var arrayCount=0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
             {
                if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].type == 'EmpDropDown' || document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].type == 'GlobalMControl' || document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].type == 'GlobalSControl')
                 {
                    var checkSS = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].getAttribute('skillset');
                    
                    var checkSSV = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].getAttribute('skillsetvalues')
                    var checkCCV = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].getAttribute('costcentrevalues')
                    var checkCC = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].getAttribute('costcentre')
                     if(checkSS == "None" || checkSSV== "None" || checkCCV== "None" || checkCC== "None")
                     {
                        document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].style.border = "dashed 4px Red";
                        CCSSunset = true;
                    }
                 }
              }
             for(var arrayCount=0 ; arrayCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayCount++)
             {
                if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].type == 'DropDown')
                {
                    if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].dependency == 'True')
                     {
                        if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].dependentid != "")
                        {
                            if(document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].dependentid + "Table").dependency == 'False')
                            {
                                document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].dependentid + "Table").style.border = "dashed 4px Blue";
                                DDunset = true;
                            }
                        }  
                         if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].prevref != "")
                        {
                            if(document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].prevref + "Table").dependency == 'False')
                            {
                                document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].prevref + "Table").style.border = "dashed 4px Blue";
                                DDunset = true;
                            }
                            if(document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].prevref + "Table").dependentid == '')
                            {
                                document.getElementById(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].prevref + "Table").style.border = "dashed 4px Blue";
                                 DDunset = true;
                            }
                        }        
                     }
                     if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].dependency == 'True')
                     {
                        if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].dependentid == "" && document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].prevref == "")
                        {
                            document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayCount].style.border = "dashed 4px Blue";
                            DDunset = true;
                        }
                     }
                }
             }
             if(DDunset == true)
             {
                alert('Please complete the dependency settings for the dropdowns highlighted in blue.');
                return false;
             }
             if(CCSSunset == false)
             {
                 for(var arrayControlCount=0 ; arrayControlCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes.length; arrayControlCount++)
                {   
                   // alert(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].id.replace('Table',''));
                    if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].type == 'TextBox')
                    {
                        xmlstring += "<TextBox><Label><Text>"+ document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                        xmlstring += "<ControlID>1</ControlID><ControlType>Basic</ControlType>";
                        xmlstring += "<FieldID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].id.replace('Table','').replace(' ','_') + "</FieldID>";
                        xmlstring += "<Title>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                        xmlstring += "<X-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.left.replace('px','') + "</X-Pos>";
                        xmlstring += "<Y-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.top.replace('px','') + "</Y-Pos>";
                        xmlstring += "<Width>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.width.replace('px','') + "</Width>";
                        xmlstring += "<IsRequired>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                        xmlstring += "<IsPostBack>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                        xmlstring += "<IsWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                        xmlstring += "<PreWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                        xmlstring += "<PostWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                        xmlstring += "<TextMode>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].textmode + "</TextMode>";
                        xmlstring += "<IsType>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].istype + "</IsType>";
                        xmlstring += "<MaxLength>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].maxlength + "</MaxLength>";
                        xmlstring += "<Dependency></Dependency>";
                        xmlstring += "<PrevRef></PrevRef>";
                        xmlstring += "<DependentID></DependentID>";
                        xmlstring += "</TextBox>";
                       //document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount]
                   }
                    if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].type == 'DropDown')
                    {  
                        xmlstring += "<DropDownList><Label><Text>"+ document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                        xmlstring += "<ControlID>2</ControlID><ControlType>Basic</ControlType>";
                        xmlstring += "<FieldID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].id.replace('Table','').replace(' ','_') + "</FieldID>";
                        xmlstring += "<Title>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                        if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependency == 'False')
                        {
                            document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependentid = ""
                            document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prevref = "";
                        }
                        if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependentid != "")
                        {
                            xmlstring += "<DependentID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>";
                        }
                        else
                        {
                            xmlstring += "<DependentID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>";
                        }
                        xmlstring += "<X-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.left.replace('px','') + "</X-Pos>";
                        xmlstring += "<Y-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.top.replace('px','') + "</Y-Pos>";
                        xmlstring += "<Width>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.width.replace('px','') + "</Width>";
                        xmlstring += "<IsRequired>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                        xmlstring += "<IsManageable>True</IsManageable>";
                        xmlstring += "<IsPostBack>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                        xmlstring += "<Dependency>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependency + "</Dependency>";
                        xmlstring += "<IsWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                        xmlstring += "<PreWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                        xmlstring += "<PostWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                       
                         if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prevref != "")
                        {
                            xmlstring += "<PrevRef>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prevref + "</PrevRef>";
                        }
                        else
                        {
                            xmlstring += "<PrevRef>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prevref + "</PrevRef>";
                        }
                         xmlstring += "<DataSource>XML</DataSource>";
                        xmlstring += "<LISTITEMS></LISTITEMS></DropDownList>";
                       //document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount]
                   }
                   if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].type == 'ListBox')
                    {  
                        xmlstring += "<ListBox><Label><Text>"+ document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                        xmlstring += "<ControlID>5</ControlID><ControlType>Basic</ControlType>";
                        xmlstring += "<FieldID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].id.replace('Table','').replace(' ','_') + "</FieldID>";
                        xmlstring += "<Title>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                        //xmlstring += "<DependentID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependentid + "ListBox</DependentID>";
                        if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependency == 'False')
                        {
                            document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependentid = ""
                            document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prevref = "";
                        }
                         if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependentid != "")
                        {
                            xmlstring += "<DependentID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>";
                        }
                        else
                        {
                            xmlstring += "<DependentID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>";
                        }
                        xmlstring += "<X-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.left.replace('px','') + "</X-Pos>";
                        xmlstring += "<Y-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.top.replace('px','')+ "</Y-Pos>";
                        xmlstring += "<Width>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.width.replace('px','') + "</Width>";
                        xmlstring += "<IsRequired>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                        xmlstring += "<IsManageable>True</IsManageable>";
                        xmlstring += "<IsPostBack>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                        xmlstring += "<Dependency>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependency + "</Dependency>";
                        xmlstring += "<IsWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                        xmlstring += "<PreWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                        xmlstring += "<PostWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                         if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prevref != "")
                        {
                            xmlstring += "<PrevRef>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prevref + "</PrevRef>";
                        }
                        else
                        {
                            xmlstring += "<PrevRef>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prevref + "</PrevRef>";
                        }
                        //xmlstring += "<PrevRef>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prevref + "ListBox</PrevRef>";
                         xmlstring += "<DataSource>XML</DataSource>";
                        xmlstring += "<LISTITEMS></LISTITEMS></ListBox>";

                   }
                   
                   if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].type == 'CheckBoxList')
                    {  
                        xmlstring += "<CheckBoxList><Label><Text>"+ document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                        xmlstring += "<ControlID>4</ControlID><ControlType>Basic</ControlType>";
                        xmlstring += "<FieldID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].id.replace('Table','').replace(' ','_') + "</FieldID>";
                        xmlstring += "<Title>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                        //xmlstring += "<DependentID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>";
                        xmlstring += "<X-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.left.replace('px','') + "</X-Pos>";
                        xmlstring += "<Y-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.top.replace('px','') + "</Y-Pos>";
                        xmlstring += "<Width>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.width.replace('px','') + "</Width>";
                        xmlstring += "<IsRequired>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                        xmlstring += "<IsManageable>True</IsManageable>";
                        xmlstring += "<IsPostBack>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                        xmlstring += "<RepeatColumns>1</RepeatColumns>";
                        xmlstring += "<RepeatDirection>Horizontal</RepeatDirection>";
                        //xmlstring += "<Dependency>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependency + "</Dependency>";
                        xmlstring += "<IsWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                        xmlstring += "<PreWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                        xmlstring += "<PostWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                        xmlstring += "<Dependency></Dependency>";
                        xmlstring += "<PrevRef></PrevRef>";
                        xmlstring += "<DependentID></DependentID>";
                        xmlstring += "<DataSource>XML</DataSource>";
                        //xmlstring += "<PrevRef>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prevref + "</PrevRef>";
                        xmlstring += "<LISTITEMS>";
                        for(var listCount =1; listCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes.length; listCount++)
                        {  
                            xmlstring += "<LISTITEM Id='" + (parseInt(listCount)-parseInt(1)) + "' value='' DependentOn='0'>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes[listCount].childNodes[1].title + "List Item text here.</LISTITEM>";//+ document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes[listCount].childNodes[1].title + "
                        }
                        xmlstring += "</LISTITEMS></CheckBoxList>";
                        
                       //document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount]
                   }
                   
                   if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].type == 'RadioButtonList')
                    {  
                        xmlstring += "<RadioButtonList><Label><Text>"+ document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                        xmlstring += "<ControlID>3</ControlID><ControlType>Basic</ControlType>";
                        xmlstring += "<FieldID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].id.replace('Table','').replace(' ','_') + "</FieldID>";
                        xmlstring += "<Title>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                        //xmlstring += "<DependentID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>";
                        xmlstring += "<X-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.left.replace('px','') + "</X-Pos>";
                        xmlstring += "<Y-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.top.replace('px','') + "</Y-Pos>";
                        xmlstring += "<Width>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.width.replace('px','') + "</Width>";
                        xmlstring += "<IsRequired>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                        xmlstring += "<IsPostBack>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                        xmlstring += "<IsManageable>True</IsManageable>";// xmlstring += "<IsManageable>True</IsManageable>";
                        //xmlstring += "<Dependency>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependency + "</Dependency>";
                        xmlstring += "<RepeatColumns>1</RepeatColumns>";
                        xmlstring += "<RepeatDirection>Horizontal</RepeatDirection>";
                        xmlstring += "<IsWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                        xmlstring += "<PreWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                        xmlstring += "<PostWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                        xmlstring += "<Dependency></Dependency>";
                        xmlstring += "<PrevRef></PrevRef>";
                        xmlstring += "<DependentID></DependentID>";
                        xmlstring += "<DataSource>XML</DataSource>";
                        //xmlstring += "<PrevRef>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prevref + "</PrevRef>";
                        xmlstring += "<LISTITEMS>";
                        for(var listCount =1; listCount < document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes.length; listCount++)
                        {  
                            xmlstring += "<LISTITEM Id='" + (parseInt(listCount)-parseInt(1)) + "' value='' DependentOn='0'>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes[listCount].childNodes[1].title + "List Item text here.</LISTITEM>";//" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].childNodes[0].childNodes[0].childNodes[listCount].childNodes[1].title + "
                        }
                        xmlstring += "</LISTITEMS></RadioButtonList>";
                        
                       //document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount]
                   }
                   
                    if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].type == 'Label')
                    {  
                        xmlstring += "<Label>";
                        xmlstring += "<ControlID>6</ControlID><ControlType>Basic</ControlType>";
                        xmlstring += "<FieldID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].id.replace('Table','').replace(' ','_') + "</FieldID>";
                        xmlstring += "<Title>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                        xmlstring += "<X-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.left.replace('px','') + "</X-Pos>";
                        xmlstring += "<Y-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.top.replace('px','') + "</Y-Pos>";
                        xmlstring += "<Width>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.width.replace('px','') + "</Width>";
                        xmlstring += "<IsPostBack>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                        xmlstring += "<IsWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                        xmlstring += "<PreWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                        xmlstring += "<PostWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                        xmlstring += "<Dependency></Dependency>";
                        xmlstring += "<PrevRef></PrevRef>";
                        xmlstring += "<DependentID></DependentID>";
                        xmlstring += "</Label>";
                       //document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount]
                   }
                   
                    if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].type == 'Button')
                    {  
                        xmlstring += "<Button>";
                        xmlstring += "<ControlID>7</ControlID><ControlType>Basic</ControlType>";
                        xmlstring += "<FieldID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].id.replace('Table','').replace(' ','_') + "</FieldID>";
                        xmlstring += "<Title>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                        xmlstring += "<X-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.left.replace('px','') + "</X-Pos>";
                        xmlstring += "<Y-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.top.replace('px','') + "</Y-Pos>";
                        xmlstring += "<Width>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.width.replace('px','') + "</Width>";
                        xmlstring += "<IsPostBack>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                        xmlstring += "<IsWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                        xmlstring += "<PreWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                        xmlstring += "<PostWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                        xmlstring += "<Dependency></Dependency>";
                        xmlstring += "<PrevRef></PrevRef>";
                        xmlstring += "<DependentID></DependentID>";
                        xmlstring += "</Button>";
                       //document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount]
                   }
                   
                   if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].type == 'EmpDropDown')
                    {  
                        xmlstring += "<CC1EmployeesDropDown><Label><Text>"+ document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                        xmlstring += "<ControlID>8</ControlID><ControlType>Custom</ControlType>";
                        xmlstring += "<FieldID>"+ document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].id.replace('Table','')+"</FieldID>";
                        xmlstring += "<Title>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                        xmlstring += "<X-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.left.replace('px','') + "</X-Pos>";
                        xmlstring += "<Y-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.top.replace('px','') + "</Y-Pos>";
                        xmlstring += "<Width>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.width.replace('px','') + "</Width>";
                        xmlstring += "<IsRequired>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                        xmlstring += "<IsManageable>False</IsManageable>";
                        xmlstring += "<IsPostBack>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                        xmlstring += "<IsWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                        xmlstring += "<PreWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                        xmlstring += "<PostWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                        xmlstring += "<DataSource>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].datasource + "</DataSource>";
                        xmlstring += "<SkillSets>";
                        
                        var skillSetArray = new Array();
                        skillSetArray = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].getAttribute('skillset').split(',');
                        skillSetArray.pop(skillSetArray.length - 1);
                        
                        var skillSetValuesArray = new Array();
                        skillSetValuesArray = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].getAttribute('skillsetvalues').split(',');
                        skillSetValuesArray.pop(skillSetValuesArray.length - 1);
                        
                        for(var ssCount = 0 ; ssCount < skillSetArray.length; ssCount++)
                        {
                            xmlstring += "<SkillSet Id='"+ skillSetValuesArray[ssCount] +"'>"+ skillSetArray[ssCount] +"</SkillSet>";
                        }
                         xmlstring += "</SkillSets>";
                        
                        xmlstring += "<CostCentres>";
                        var costCentreArray = new Array();
                        costCentreArray = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].getAttribute('costcentre').split(',');
                        costCentreArray.pop(costCentreArray.length - 1);
                        
                        var costCentreValuesArray = new Array();
                        costCentreValuesArray = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].getAttribute('costcentrevalues').split(',');
                        costCentreValuesArray.pop(costCentreValuesArray.length - 1);
                        
                        for(var ccCount = 0 ; ccCount < costCentreArray.length; ccCount++)
                        {
                            xmlstring += "<CostCentre Id='" + costCentreValuesArray[ccCount] + "'>"+ costCentreArray[ccCount] +"</CostCentre>";
                        }
                        xmlstring += "</CostCentres></CC1EmployeesDropDown>";
                   }
                   
                   
                    if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].type == 'GlobalMControl')
                    {  
                        xmlstring += "<GlobalMControl><Label><Text>"+ document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                        xmlstring += "<ControlID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].controlid + "</ControlID><ControlType>Global</ControlType>";
                        xmlstring += "<FieldID>"+ document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].id.replace('DropDownTable','')+"DropDown</FieldID>";
                        xmlstring += "<Title>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                        xmlstring += "<DependentID>"+ document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].dependentid + "</DependentID>";//.replace('DropDownTable','')+"DropDown
                        xmlstring += "<DependentCtrlID>"+ document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].depctrlid + "</DependentCtrlID>";
                        xmlstring += "<X-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.left.replace('px','') + "</X-Pos>";
                        xmlstring += "<Y-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.top.replace('px','') + "</Y-Pos>";
                        xmlstring += "<Width>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.width.replace('px','') + "</Width>";
                        xmlstring += "<IsRequired>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                        xmlstring += "<IsManageable>False</IsManageable>";
                        xmlstring += "<IsPostBack>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                        xmlstring += "<IsWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                        xmlstring += "<PreWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                        xmlstring += "<PostWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                        xmlstring += "<DataSource>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].datasource + "</DataSource>";
                        xmlstring += "<SkillSets>";
                        
                        var skillSetArray = new Array();
                        skillSetArray = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].getAttribute('skillset').split(',');
                        skillSetArray.pop(skillSetArray.length - 1);
                        
                        var skillSetValuesArray = new Array();
                        skillSetValuesArray = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].getAttribute('skillsetvalues').split(',');
                        skillSetValuesArray.pop(skillSetValuesArray.length - 1);
                        
                        for(var ssCount = 0 ; ssCount < skillSetArray.length; ssCount++)
                        {
                            xmlstring += "<SkillSet Id='"+ skillSetValuesArray[ssCount] +"'>"+ skillSetArray[ssCount] +"</SkillSet>";
                        }
                         xmlstring += "</SkillSets>";
                        
                        xmlstring += "<CostCentres>";
                        var costCentreArray = new Array();
                        costCentreArray = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].getAttribute('costcentre').split(',');
                        costCentreArray.pop(costCentreArray.length - 1);
                        
                        var costCentreValuesArray = new Array();
                        costCentreValuesArray = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].getAttribute('costcentrevalues').split(',');
                        costCentreValuesArray.pop(costCentreValuesArray.length - 1);
                        
                        for(var ccCount = 0 ; ccCount < costCentreArray.length; ccCount++)
                        {
                            xmlstring += "<CostCentre Id='" + costCentreValuesArray[ccCount] + "'>"+ costCentreArray[ccCount] +"</CostCentre>";
                        }
                        xmlstring += "</CostCentres></GlobalMControl>";
                      
                   }
                   
                   
                   if(document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].type == 'GlobalSControl')
                    {  
                        xmlstring += "<GlobalSControl><Label><Text>"+ document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Text></Label>";
                        xmlstring += "<ControlID>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].controlid + "</ControlID><ControlType>Global</ControlType>";
                        xmlstring += "<FieldID>"+ document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].id.replace('DropDownTable','')+"DropDown</FieldID>";
                        xmlstring += "<Title>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].title + "</Title>";
                        xmlstring += "<DependentID></DependentID>";//.replace('DropDownTable','')+"DropDown
                        xmlstring += "<X-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.left.replace('px','') + "</X-Pos>";
                        xmlstring += "<Y-Pos>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.top.replace('px','') + "</Y-Pos>";
                        xmlstring += "<Width>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].style.width.replace('px','') + "</Width>";
                        xmlstring += "<IsRequired>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].isrequired + "</IsRequired>";
                        xmlstring += "<IsManageable>False</IsManageable>";
                        xmlstring += "<IsPostBack>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].ispostback + "</IsPostBack>";
                        xmlstring += "<IsWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].iswrap + "</IsWrap>";
                        xmlstring += "<PreWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].prewrap + "</PreWrap>";
                        xmlstring += "<PostWrap>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].postwrap + "</PostWrap>";
                        xmlstring += "<DataSource>" + document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].datasource + "</DataSource>";
                        xmlstring += "<SkillSets>";
                        
                        var skillSetArray = new Array();
                        skillSetArray = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].getAttribute('skillset').split(',');
                        skillSetArray.pop(skillSetArray.length - 1);
                        
                        var skillSetValuesArray = new Array();
                        skillSetValuesArray = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].getAttribute('skillsetvalues').split(',');
                        skillSetValuesArray.pop(skillSetValuesArray.length - 1);
                        
                        for(var ssCount = 0 ; ssCount < skillSetArray.length; ssCount++)
                        {
                            xmlstring += "<SkillSet Id='"+ skillSetValuesArray[ssCount] +"'>"+ skillSetArray[ssCount] +"</SkillSet>";
                        }
                         xmlstring += "</SkillSets>";
                        
                        xmlstring += "<CostCentres>";
                        var costCentreArray = new Array();
                        costCentreArray = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].getAttribute('costcentre').split(',');
                        costCentreArray.pop(costCentreArray.length - 1);
                        
                        var costCentreValuesArray = new Array();
                        costCentreValuesArray = document.getElementById('ctl00_ContentPlaceHolder1_DesignDiv').childNodes[arrayControlCount].getAttribute('costcentrevalues').split(',');
                        costCentreValuesArray.pop(costCentreValuesArray.length - 1);
                        
                        for(var ccCount = 0 ; ccCount < costCentreArray.length; ccCount++)
                        {
                            xmlstring += "<CostCentre Id='" + costCentreValuesArray[ccCount] + "'>"+ costCentreArray[ccCount] +"</CostCentre>";
                        }
                        xmlstring += "</CostCentres></GlobalSControl>";
                      
                   }
                }
                document.getElementById('ctl00_ContentPlaceHolder1_SaveXMLHidden').value = xmlstring;
             }
             else
             {
                alert("Please select the CostCentre and SkillSets for the highlighted controls.")
                return false;
             }
    }
    else
    {
        
        alert("An empty form cannot be submitted.");
        return false;
        
    }
    //***alert(xmlstring); COMMENTED BY AARTI
}



//**=====================================================File Edit Mode Functions to ReCreate Controls==================================**//

function ReCreateControls()
{
    var xmlString= document.getElementById("ctl00_ContentPlaceHolder1_ReadXMLHidden").value
    
    
   var xmlDoc=new ActiveXObject("Microsoft.XMLDOM");
    xmlDoc.async="false";
    xmlDoc.loadXML(xmlString);
    
   // alert(xmlDoc.childNodes[1].childNodes.length);
    
    for(var xmlChildCount=0; xmlChildCount<xmlDoc.childNodes[1].childNodes.length;  xmlChildCount++)
    {
        alert(xmlDoc.childNodes[1].childNodes[xmlChildCount].innerHTML);
    }
    

    
}