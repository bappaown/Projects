﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using EVOLib;
using System.Collections;
using System.Collections.Generic;


public partial class Admin_DataManagement : EvoGeneral
{
    string controlToChange = "";
    XmlDocument doc;
    XDocument xmlDoc = new XDocument();
    string FileName;
    string CallTypeArrayText = "";
    int cnt = 0;
    string controlType = "";

    string BasicArrayText = "";
    string TempHoldDrpNames = "";

    int frmID;
    string frmName;
    string catId;
    string vId;
    string fMode;
    int NoOfDependents = 0;

    ImageButton imgNext;

    public string NtName;

    protected void Page_Load(object sender, EventArgs e)
    {
        
        if (!(Page.IsPostBack))
        {
            Server.ScriptTimeout = 30000;

            ObjUserRights.VersionId = int.Parse(VersionIDHidden.Value);
            ObjUserRights.UserID = RetrieveUserID(userName);
            ObjUserRights.FormId = int.Parse(FormIDHidden.Value);

            IsValidUser();
            IsValidPageEntry();

            if (CategoryIDHidden.Value != "4")
            {
                //Bind the template in DDL
                BindTemplates();
                //lblTemplate.Visible = true;
                //ddlTemplate.Attributes.Add("style", "display:block;");    
            }
            else
            {
                lblTemplate.Visible = false;
                ddlTemplate.Attributes.Add("style", "display:none;");    
            }

            // I WILL ENABLE IT ONCE MY CODING IS DONE
            AddJavascript();

            //***BindControlTypes();

            //  if (!IsStartupScriptRegistered("CallTypeArray"))
            //  {
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "CallTypeArray", JavaScriptTextBox.Text, true);
            //ClientScript.RegisterClientScriptBlock(this.GetType(), "CallTypeArray", "<script language='javascript'>" + JavaScriptTextBox.Text + "</script>");
            //RegisterClientScriptBlock("CallTypeArray", "<script language='javascript'>" + JavaScriptTextBox.Text + "</script>");
            //   }

            CheckDependencyForOptimizingScript("");   // Added Later on 09/06/09

        }
        BuildTemplateControlsList();
    }

    // Checking if user have entered thr' proper channels. :)
    private void IsValidPageEntry()
    {
        if (FormIDHidden.Value == "0")
        {
            Response.Redirect("../AccessDenied.aspx");
        }
    }

    private void AddJavascript()
    {
        txtValue.Attributes.Add("onkeyup", "return CheckFieldJunkCharsDataManagement('" + txtValue.ClientID + "',0)");
		txtWrapNote.Attributes.Add("onkeyup", "return CheckFieldJunkCharsDataManagement('" + txtWrapNote.ClientID + "',0)");
		txtWrapNote.Attributes.Add("onkeypress", "return CheckValidLength(document.getElementById('" + txtWrapNote.ClientID + "'),'500', false)");
		txtWrapNote.Attributes.Add("onpaste", "return CheckValidLength(document.getElementById('" + txtWrapNote.ClientID + "'),'500', true)");

        txtOptionTooltip.Attributes.Add("onkeyup", "return CheckFieldJunkCharsDataManagement('" + txtOptionTooltip.ClientID + "',0)");
        txtOptionTooltip.Attributes.Add("onkeypress", "return CheckValidLength(document.getElementById('" + txtOptionTooltip.ClientID + "'),'500', false)");
        txtOptionTooltip.Attributes.Add("onpaste", "return CheckValidLength(document.getElementById('" + txtOptionTooltip.ClientID + "'),'500', true)");

		btnAdd.Attributes.Add("onclick", "return ValidateDataManagement('btnAdd', '" + txtValue.ClientID + "','" + txtWrapNote.ClientID + "','" + txtOptionTooltip.ClientID  + "');");
        btnUpdate.Attributes.Add("onclick", "return ValidateDataManagement('btnUpdate', '" + txtValue.ClientID + "','" + txtWrapNote.ClientID + "','" + txtOptionTooltip.ClientID + "');");
    }

    private void GetFileName()
    {
        frmID = ManageSession.FormID;
        frmName = ManageSession.FormName;
        string[] fName = frmName.Split('_');
        frmName = fName[0];
        catId = ManageSession.CategoryID.ToString();
        vId = ManageSession.VersionID.ToString();
        fMode = ManageSession.FormMode.ToString();
        FormIDHidden.Value = frmID.ToString(); //ManageSession.FormID.ToString(); //"1"; 
        FormNameHidden.Value = frmName; //"MBB Call Logger";
        CategoryIDHidden.Value = catId; //"1"; 
        VersionIDHidden.Value = vId; //"1";

        FileModeHidden.Value = fMode;

        GetFileNameFromDb();    // To retrieve XML filename from DB.
    }

    protected override void OnInit(EventArgs e)
    {
        if (!(Page.IsPostBack))
        {
            GetFileName();
        }
        GenerateMasterClick();
    }

    private void GenerateMasterClick()
    {
        Label lblModule = (Label)Master.FindControl("lblModule");
        lblModule.Text = "Data Management";

        Label lblForm = (Label)Master.FindControl("lblForm");
        lblForm.Text = FormNameHidden.Value;
        ContentPlaceHolder ctPlaceHolder = (ContentPlaceHolder)Master.FindControl("head");
        ImageButton imgSel = (ImageButton)ctPlaceHolder.FindControl("img3");
        imgSel.ImageUrl = "../images/icon_3_rol.jpg";

        imgNext = (ImageButton)ctPlaceHolder.FindControl("img4");
        imgNext.CssClass = "ImageButtonLinkCursor";
        imgNext.Enabled = true;
        // If IN EDIT MODE, ALLOW SESSION VARIABLES FOR NAVIGATION.
        imgNext.Click += new ImageClickEventHandler(Next_Click);

        ImageButton imgBtnSave = (ImageButton)ctPlaceHolder.FindControl("imgSave");
        imgBtnSave.Click += new ImageClickEventHandler(Save_Click);

        ImageButton imgBtnHome = (ImageButton)ctPlaceHolder.FindControl("imgHome");
        imgBtnHome.Click += new ImageClickEventHandler(Home_Click);
    }

    private void GetFileNameFromDb()
    {
        try
        {
            DataSet ds;
            ObjUserRights.FormId = frmID;
            ObjUserRights.VersionId = int.Parse(vId);

            ds = ObjUserRights.GetXMLFileName();

            if (ds.Tables[0].Rows.Count > 0)
            {
                string FiName = ds.Tables[0].Rows[0]["XMLFileName"].ToString();
                ReadXMLHidden.Value = FiName;
                Session["FileName"] = FiName;
            }
            else
            {
                lblErr.Text = "Could not find the XML file";
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = "Could not find the XML file" + ex.Message;
        }
    }

    EvoAdminUsersRights ObjUserRights = new EvoAdminUsersRights();
    // Checking if the user is valid and have rights to manage the form or no.
    private void IsValidUser()
    {
        try
        {
            Boolean IsValid = false;

            IsValid = ObjUserRights.ValidateAdminManageUser();

            if (!IsValid)
            {
                //Response.Write("Redirecting to access denied");
                Response.Redirect("../AccessDenied.aspx", true);
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = "No data found for this login" + ex.Message;
        }
    }

    private void ReadNLoadFile()
    {
        try
        {
            //if (doc != null)
            //{
            //    //((IDisposable)doc).Dispose();
            //    doc = null;
                
            //}
            FileName = Server.MapPath("..\\XML\\" + ReadXMLHidden.Value);
            doc = new XmlDocument();
            xmlDoc = XDocument.Load(FileName);
            doc.Load(FileName);
        }
        catch (Exception ex)
        { 
        
        }
        
    }

    /// <summary>
    /// Function to pass session variables to the next page.
    /// </summary>
    private void GoToNextForm()
    {
        ManageSession.FormID = int.Parse(FormIDHidden.Value);
        ManageSession.FormName = FormNameHidden.Value;
        ManageSession.XmlFileName = ReadXMLHidden.Value;
        ManageSession.CategoryID = int.Parse(CategoryIDHidden.Value);
        ManageSession.VersionID = int.Parse(VersionIDHidden.Value);
        ManageSession.FormMode = FileModeHidden.Value;
    }

    protected void Save_Click(object sender, EventArgs e)
    {
        GoToNextForm();
        Response.Redirect("../Admin/ControlManagement.aspx", true);
    }

    protected void Next_Click(object sender, EventArgs e)
    {
        if (FileModeHidden.Value.ToUpper() == "EDITMODE")
        {
            GoToNextForm();
            Response.Redirect("../Admin/ControlManagement.aspx", true);
        }
    }

    protected void Home_Click(object sender, EventArgs e)
    {
        GoToNextForm();
        Response.Redirect("../Admin/Default.aspx", true);
    }

    private void ClearMessages()
    {
        lblErr.Text = "";
        lblSuccess.Text = "";
    }

    private void ClearHiddenValues()
    {
        SelectedValue.Value = "0";
        
		txtValue.Text = "";
		txtWrapNote.Text = "";
        txtOptionTooltip.Text = ""; 
        
		SelectedItemOldValue.Value = "";
        SelectedControl.Value = "";
        selectedField.Value = "";
        SelectedDepIdFromXml.Value = "0";
        ddlTemplate.SelectedIndex = -1;
    }

    private void AppendFile()
    {
        ClearMessages();
        ReadNLoadFile();
        XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controlType);
        string SelCtrlType = SelectedControl.Value;
        //** string DepOnId = SelectedValue.Value;  commennted since had problems due to next control's item selection
        string DepOnId = PopulateParentIdHidden.Value;

        if (SelCtrlType != "Parent")
        {
            DepOnId = "0";
        }

        for (int i = 0; i < rootNodeList.Count; i++)
        {
            XmlNode dropDownNode = (XmlNode)rootNodeList[i];

            for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
            {
                if ((dropDownNode.ChildNodes[y].Name == "FieldID") && (dropDownNode.ChildNodes[y].InnerText == drpFrom.SelectedValue))
                {
                    for (int j = 0; j < dropDownNode.ChildNodes.Count; j++)
                    {
                        XmlNode dropDownChildNode = (XmlNode)dropDownNode.ChildNodes[j];

                        string ListItemText = "";
                        string ExistingDepOnId = "";

                        if (dropDownChildNode.Name == "LISTITEMS")
                        {
                            bool isAvail = false;
                            XmlNodeList listItems = dropDownNode.ChildNodes[j].ChildNodes;
                            //XmlNodeList listItems = dropDownChildNode.ChildNodes.Count;
                            for (int l = 0; l < listItems.Count; l++)
                            {
                                ListItemText = listItems.Item(l).InnerText.Trim();
                                if (listItems.Item(l).Name == "LISTITEM")
                                {
                                    ExistingDepOnId = listItems.Item(l).Attributes["DependentOn"].Value;
                                }

                                // Checking if same list item exists for same parent node.
                                if ((ListItemText.ToUpper().Trim() == txtValue.Text.ToUpper().Trim()) && (DepOnId.Trim() == ExistingDepOnId.Trim()))
                                {
                                    isAvail = true;
                                    l = listItems.Count;
                                    j = dropDownNode.ChildNodes.Count;
                                    y = dropDownNode.ChildNodes.Count;
                                    i = rootNodeList.Count;
                                }
                            }

                            if (isAvail)
                            {
                                lblErr.Text = "This option already exists.";
                            }
                            else
                            {
                                int NewId = 0;
                                // int NewId = 0;
                                if (dropDownChildNode.HasChildNodes)
                                {
                                    NewId = int.Parse(dropDownChildNode.LastChild.Attributes["Id"].Value) + 1;
                                }
                                else
                                {
                                    NewId = 1;
                                }

                                XmlNode newChild = doc.CreateElement("LISTITEM");

                                XmlAttribute newAttrId = doc.CreateAttribute("Id");
                                newAttrId.InnerText = NewId.ToString();

                                XmlAttribute newAttrVal = doc.CreateAttribute("value");
                                newAttrVal.InnerText = "";  //** newAttr.InnerText = txtValue.Text;

                                XmlAttribute newAttrDepOn = doc.CreateAttribute("DependentOn");
                                newAttrDepOn.InnerText = DepOnId;

								XmlAttribute newAttrWrapNote = doc.CreateAttribute("WrapNote");
                                newAttrWrapNote.InnerText = txtWrapNote.Text.Trim().Replace("\r\n", "¢");

                                

                                XmlAttribute newAttrOptionTooltip = doc.CreateAttribute("OptionTooltip");
                                newAttrOptionTooltip.InnerText = txtOptionTooltip.Text.Trim();

                                XmlAttribute newAttrTemplate = doc.CreateAttribute("Template");
                                newAttrTemplate.InnerText = ddlTemplate.SelectedValue;

                                // Do some stuff to the child node...
                                newChild.Attributes.Append(newAttrId);
                                newChild.Attributes.Append(newAttrVal);
                                newChild.Attributes.Append(newAttrDepOn);
								newChild.Attributes.Append(newAttrWrapNote);
                                newChild.Attributes.Append(newAttrOptionTooltip);
                                newChild.Attributes.Append(newAttrTemplate); 
                                newChild.InnerText = txtValue.Text.Trim();

                                CallTypeArrayText = JavaScriptTextBox.Text;

                                if (controlType != "ListBox")
                                {

                                    string Arrays = Session["JavaScriptTextBox"].ToString();
                                    Arrays =Arrays+"if (Array" + drpFrom.SelectedValue + "[" + DepOnId + "] ==null) "
                                                     + "Array" + drpFrom.SelectedValue + "[" + DepOnId + "] = new Array();\n";
                                    //CallTypeArrayText += "var Array" + drpFrom.SelectedValue + "= new Array("+ listItems.Count +");  if (Array" + drpFrom.SelectedValue + "[" + DepOnId + "] ==null) "
                                      //               + "Array" + drpFrom.SelectedValue + "[" + DepOnId + "] = new Array();\n";

                                    //CallTypeArrayText += "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "]= new Array('" + ListItemText + "');\n";
                                    Arrays += "Array" + drpFrom.SelectedValue + "[" + DepOnId + "][" + NewId + "] = new Array ('" + txtValue.Text.Trim() + "," + txtWrapNote.Text.Trim().Replace("\r\n", "¢") + "," + txtOptionTooltip.Text.Trim() + "," + ddlTemplate.SelectedValue + "'); \n";

                                    JavaScriptTextBox.Text = Arrays;

                                    // Registering javascript
                                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "CallTypeArray", JavaScriptTextBox.Text, true);
                                }
                                // Add the child node to the root node
                                dropDownChildNode.AppendChild(newChild);

                                doc.Save(FileName);         // Add the listitem and save the file

                                SelectedValue.Value = DepOnId;
                                lblSuccess.Text = "The option added successfully";
                                //l = listItems.Count;
                                j = dropDownNode.ChildNodes.Count;
                                y = dropDownNode.ChildNodes.Count;
                                i = rootNodeList.Count;
                            }
                        }
                    }
                }
            }
        }
    }

    // A function which retrieves the control data and redirects to previous control as well.
    private void GetPrevRefData(string RefObj, string DependentOnId)
    {
        string PrevCtrl = "";
        string FName = "";
        string IsManageable = "";
        bool isSuccess = false;
        string DependentId = "";
        string LabelText = "";
        string Dependency = "";
		string isWrapTrueFalse = "";

        ReadNLoadFile();
       
        NoOfDependents += 1;
        NoOfDependentsHidden.Value = NoOfDependents.ToString();

        Label lblCtrl = new Label();
        DropDownList ddlCtrl = new DropDownList();
        RadioButtonList radCtrl = new RadioButtonList();
        ListBox lstCtrl = new ListBox();
        //**CheckBoxList chkCtrl = new CheckBoxList();

        lblCtrl.Text = "";
		//trWrapNote.Style.Add("display", "none");
        trOptionTooltip.Style.Add("display", "none");
        trTemplate.Style.Add("display", "none");


        if (controlType == "DropDownList")
        {
			trWrapNote.Style.Add("display", "block");
            trOptionTooltip.Style.Add("display", "block");
            trTemplate.Style.Add("display", "block");   

            ddlCtrl.ID = "ddlCtrl" + RefObj; //cnt;
        }
        else if (controlType == "RadioButtonList")
        {
            radCtrl.ID = "radCtrl" + RefObj;
        }
        else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
        {
            lstCtrl.ID = "lstCtrl" + RefObj;
        }

        if (controlType == "ListBox")        
        {
            trWrapNote.Style.Add("display", "block");
            trOptionTooltip.Style.Add("display", "block");
            trTemplate.Style.Add("display", "block");  

            var list = from c in xmlDoc.Descendants("ListBox")                       
                      select new 
                      {
                          IsWrap= c.Element("IsWrap").Value,
                          Name = c.Element("Label").Element("Text").Value 
                      };
            foreach (var e in list)
            {
                if (e.Name.ToString()== drpFrom.SelectedItem.Text)
                {
                    //if (e.IsWrap.ToString() == "True")
                    //{
                    //    trWrapNote.Style.Add("display", "none");
                    //}
                    //else
                    //{
                    //    trWrapNote.Style.Add("display", "block");
                    //}
                }
            }

            if ((DependentOnId.Trim() == "") || (DependentOnId.Trim() == null)) // If previous control's data NOT selected.
            {
                DataSet dsDataItem = new DataSet();
                dsDataItem.Tables.Add();
                dsDataItem.Tables.Add();
           
                var q = from c in xmlDoc.Descendants("ListBox")
                        where c.Element("FieldID").Value == RefObj //controlId
                        select new
                        {
                            LabelText = c.Element("Text"),
                            PreviousRef = c.Element("PrevRef"),
                            DependentID = c.Element("DependentID"),
							isWrapTrueFalse = c.Element("IsWrap"),
                            ListOfItems = c.Element("LISTITEMS").Descendants("LISTITEM")
                        };

                foreach (var obj in q)
                {
                    //PrevRefControl = obj.PreviousRef.Value;
                    PrevCtrl = obj.PreviousRef.Value;
                    DependentId = obj.DependentID.Value;
                    //DependentControl = obj.DependentID.Value;

                    var ListItems = obj.ListOfItems;

                    if (PrevCtrl.Trim() != "")
                    {
                        GetPrevRefData(PrevCtrl.Trim(), "");
                    }
                    else
                    {
                        foreach (var ele in ListItems)
                        {
							string wrapNoteValue;
                            if (ele.Attribute("WrapNote") == null)
							{
								wrapNoteValue = "";
							}
							else
							{
                                wrapNoteValue = ele.Attribute("WrapNote").Value;
							}

                            string optionTooltip;
                            if (ele.Attribute("OptionTooltip") == null)
                            {
                                optionTooltip = "";
                            }
                            else
                            {
                                optionTooltip = ele.Attribute("OptionTooltip").Value;
                            }

                            string template;
                            if (ele.Attribute("Template") == null)
                            {
                                template = "";
                            }
                            else
                            {
                                template = ele.Attribute("Template").Value;
                            }


                            string EleValue = ele.Attribute("Id").Value + "," + ele.Value + "," + ele.Attribute("DependentOn").Value + "," + wrapNoteValue + "," + optionTooltip + "," + template;
                            ListItem lst = new ListItem(ele.Value, EleValue);
                            lstCtrl.Items.Add(lst);
                        }
                    }
                }
            }
            else
            {
                var q = from c in xmlDoc.Descendants("ListBox")
                        where c.Element("FieldID").Value == RefObj
                        select new
                        {
                            ThisRecordId = c.Element("Id"),
                            LabelText = c.Element("Text"),
                            PreviousRef = c.Element("PrevRef"),
                            DependentID = c.Element("DependentID"),
                            WrapNote = c.Element("WrapNote"),
							isWrapTrueFalse = c.Element("IsWrap"),
                            ListOfItems = from items in c.Element("LISTITEMS").Descendants("LISTITEM")
                                          where items.Attribute("DependentOn").Value == DependentOnId
                                          select items
                        };

                if (PrevCtrl.Trim() != "")
                {
                    GetPrevRefData(PrevCtrl.Trim(), "");
                }

                foreach (var obj in q)
                {
                    PrevCtrl = obj.PreviousRef.Value;
                    DependentId = obj.DependentID.Value;
                    var ListItems = obj.ListOfItems;

                    if (PrevCtrl.Trim() != "")
                    {
                        GetPrevRefData(PrevCtrl.Trim(), "");
                    }
                    else
                    {
                        foreach (var ele in ListItems)
                        {
                            //string EleValue = ThisRecordId + "," + ele.Value + "," + DependentId;
							string wrapNoteValue;
                            if (ele.Attribute("WrapNote") == null)
								wrapNoteValue = "";
							else
                                wrapNoteValue = ele.Attribute("WrapNote").Value;

                            string optionTooltip;
                            if (ele.Attribute("OptionTooltip") == null)
                            {
                                optionTooltip = "";
                            }
                            else
                            {
                                optionTooltip = ele.Attribute("OptionTooltip").Value;
                            }

                            string template;
                            if (ele.Attribute("Template") == null)
                            {
                                template = "";
                            }
                            else
                            {
                                template = ele.Attribute("Template").Value;
                            }

							string EleValue = ele.Attribute("Id").Value + "," + ele.Value + "," + ele.Attribute("DependentOn").Value + "," + wrapNoteValue + "," + optionTooltip + "," + template;
                            ListItem lst = new ListItem(ele.Value, EleValue);
                            //ListItem lst = new ListItem(ele.Value, ele.Attribute("Id").Value);
                            lstCtrl.Items.Add(lst);
                        }
                    }
                }
            }

            tdControls.Controls.Add(lstCtrl);
            string SelectedControl = "lstCtrl" + drpFrom.SelectedValue;
            if (lstCtrl.ID.Trim() != SelectedControl.Trim())
            {
                if (DependentId.Trim() != "")
                {
                    lstCtrl.Attributes.Add("onchange", "FillSelectedValues('" + lstCtrl.ID + "', '" + DependentId + "','" + ReadXMLHidden.Value + "','" + NoOfDependents + "')");
                }
            }
            else
            {
                lstCtrl.Attributes.Add("onchange", "EditDeleteItem('" + lstCtrl.ID + "','ListBox')");
            }

			if (isWrapTrueFalse == "True")		// If IsWrap Is true, then dont show add wrap notes for this field here, as the wrap notes are already added in design management section
			{
				//trWrapNote.Style.Add("display", "none");
			}

            DependentId = "";
        }   // If SELECTED CONTROL TYPE IS ANYTHING THAN LISTBOX THEN.
        else
        {
            XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controlType);
            // Reading all the nodes.
            //  while (iterator.MoveNext())
            //        {

            if ((controlType == "ListBox") || (controlType == "DropDownList"))
            {
                trOptionTooltip.Style.Add("display", "block");
                trTemplate.Style.Add("display", "block");  
            }

            for (int i = 0; i < rootNodeList.Count; i++)
            {
                XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                int countElements = 0;

                PrevCtrl = "";
                FName = "";
                IsManageable = "";
                isSuccess = false;
                LabelText = "";

                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if (dropDownNode.ChildNodes[y].Name == "Title")
                    {
                        LabelText = dropDownNode.ChildNodes[y].FirstChild.Value;
                    }
                    else if (dropDownNode.ChildNodes[y].Name == "IsManageable")
                    {
                        IsManageable = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    else if (dropDownNode.ChildNodes[y].Name == "FieldID")
                    {
                        FName = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    else if (dropDownNode.ChildNodes[y].Name == "PrevRef")
                    {
                        PrevCtrl = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    else if (dropDownNode.ChildNodes[y].Name == "DependentID")
                    {
                        DependentId = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    else if (dropDownNode.ChildNodes[y].Name == "Dependency")
                    {
                        Dependency = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
					else if (dropDownNode.ChildNodes[y].Name == "IsWrap")		// If IsWrap Is true, then dont show add wrap notes for this field here, as the wrap notes are already added in design management section
					{
                        if (((controlType == "ListBox") || (controlType == "DropDownList")) )
                        {
                            if (LabelText == drpFrom.SelectedItem.Text)
                            {
                                if (dropDownNode.ChildNodes[y].InnerText.Trim() == "True")
                                {
                                    trWrapNote.Style.Add("display", "block");
                                }
                                else
                                {
                                    trWrapNote.Style.Add("display", "block");
                                }
                            }
                        }
                        else
                        {
 
                        }
					}



                    if ((IsManageable == "True") && (FName == RefObj) && (countElements == 5))  //&& (PrevCtrl != "")
                    {
                        if (PrevCtrl != "")
                        {
                            SelectedControl.Value = "Parent";
                        }

                        lblCtrl.ID = "lbl" + RefObj;
                        lblCtrl.Text =  LabelText + "&nbsp;";
                        lblCtrl.Style.Add("float", "left");

                        if (dropDownNode.ChildNodes[y].Name == "LISTITEMS")
                        {
                            XmlNodeList listItems = dropDownNode.ChildNodes[y].ChildNodes;

                            // Creating an array. This will be used in javascript n registered via code
                            CallTypeArrayText += "var Array" + (FName).ToString() + " = new Array( " + listItems.Count + " );\n";
                            Session["Count"] = listItems.Count.ToString();
                            if ((listItems.Count == 0)) //(PrevCtrl == "") &&
                            {
                                lblErr.Text = "No List Items added in " + LabelText + " <br> Please add Items first.";
                                //if ((FName != RefObj) && (DependentId !=))
                                if (drpFrom.SelectedValue != FName)
                                {
                                    btnAdd.Enabled = false;
                                    btnDelete.Enabled = false;
                                    btnUpdate.Enabled = false;

                                    btnAdd.ImageUrl = "~/Images/but_add_n.jpg";
                                    btnDelete.ImageUrl = "~/Images/but_delete_n.jpg";
                                    btnUpdate.ImageUrl = "~/Images/but_update_n.jpg";
                                }
                            }

                            for (int l = 0; l < listItems.Count; l++)
                            {
                                string dependentOn = "";
                                string ListItemVal = "";
                                string ListItemText = "";
                                string WrapNote = "";
                                string OptionTooltip = "";
                                string Template = "";

                                ListItemText = listItems.Item(l).InnerText;
                                ListItemVal = listItems.Item(l).Attributes["Id"].Value;

                                string wrapNoteValue;
                                if (listItems.Item(l).Attributes["WrapNote"] == null)
									wrapNoteValue = "";
								else
                                    wrapNoteValue = listItems.Item(l).Attributes["WrapNote"].Value;

                                if (listItems.Item(l).Attributes["OptionTooltip"] == null)
                                    OptionTooltip = "";
                                else
                                    OptionTooltip = listItems.Item(l).Attributes["OptionTooltip"].Value;

                                if (listItems.Item(l).Attributes["Template"] == null)
                                    Template = "";
                                else
                                    Template = listItems.Item(l).Attributes["Template"].Value;

								WrapNote = wrapNoteValue; //listItems.Item(l).Attributes["WrapNote"].Value;  
                                if ((listItems.Item(l).Attributes["DependentOn"].Value.Trim() != "") || (listItems.Item(l).Attributes["DependentOn"].Value.Trim() == "0"))
                                {
                                    dependentOn = listItems.Item(l).Attributes["DependentOn"].Value;

                                    if ((dependentOn == "") || (dependentOn == null))
                                    {
                                        dependentOn = "0";
                                    }
                                    CallTypeArrayText += "if (Array" + (FName).ToString() + "[" + dependentOn + "] ==null) "
                                                 + "Array" + (FName).ToString() + "[" + dependentOn + "] = new Array();\n";

                                    CallTypeArrayText += "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "]= new Array('" + ListItemText + "," + WrapNote + "," + OptionTooltip + "," + Template + "');\n";
                                }

                                if ((PrevCtrl == ""))
                                {
                                    ListItem lst = new ListItem();
                                    lst.Text = ListItemText;
                                    lst.Value = ListItemVal + "," + ListItemText + "," + dependentOn;
                                    
                                    if (controlType == "DropDownList")
                                    {
                                        if (listItems.Item(l).Attributes["WrapNote"] == null)
											wrapNoteValue = "";
										else
                                            wrapNoteValue = listItems.Item(l).Attributes["WrapNote"].Value;


                                        if (listItems.Item(l).Attributes["OptionTooltip"] == null)
                                            OptionTooltip = "";
                                        else
                                            OptionTooltip = listItems.Item(l).Attributes["OptionTooltip"].Value;

                                        if (listItems.Item(l).Attributes["Template"] == null)
                                            Template = "";
                                        else
                                            Template = listItems.Item(l).Attributes["Template"].Value;

                                        lst.Value += "," + wrapNoteValue + "," + OptionTooltip + "," + Template; //"," + listItems.Item(l).Attributes["WrapNote"].Value;
										ddlCtrl.Items.Add(lst);

                                        if ((ddlCtrl.ID == selectedField.Value.Trim()) && (ListItemVal == SelectedValue.Value))
                                        {
                                            ddlCtrl.Attributes.Add("onfocusin", "javascript:Populate('" + ddlCtrl.ID + "', 'ddlCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                            ddlCtrl.SelectedIndex = l;
                                            ScriptManager m1 = (ScriptManager)Master.FindControl("ScriptManager1");
                                            m1.SetFocus(ddlCtrl);
                                        }
                                    }
                                    else if (controlType == "RadioButtonList")
                                    {
                                        radCtrl.Items.Add(lst);
                                    }
                                    else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                                    {
                                        lstCtrl.Items.Add(lst);
                                        if ((lstCtrl.ID == selectedField.Value.Trim()) && (ListItemVal == SelectedValue.Value))
                                        {
                                            lstCtrl.Attributes.Add("onfocusin", "javascript:Populate('" + lstCtrl.ID + "', 'lstCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                            lstCtrl.SelectedIndex = l;
                                            ScriptManager m1 = (ScriptManager)Master.FindControl("ScriptManager1");
                                            m1.SetFocus(lstCtrl);
                                        }
                                    }
                                }

                                if (FName != drpFrom.SelectedValue)
                                {
                                    if (controlType == "DropDownList")
                                    {
                                        ddlCtrl.Attributes.Add("onchange", "Populate('" + ddlCtrl.ID + "', 'ddlCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                    }
                                    else if (controlType == "RadioButtonList")
                                    {
                                        radCtrl.Attributes.Add("onclick", "Populate('" + radCtrl.ID + "', 'radCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                    }
                                    else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                                    {
                                        lstCtrl.Attributes.Add("onchange", "Populate('" + lstCtrl.ID + "', 'lstCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                    }
                                }
                                else
                                {
                                    if (controlType == "DropDownList")
                                    {
                                        ddlCtrl.Attributes.Add("onchange", "EditDeleteItem('" + ddlCtrl.ID + "','DropDownList')");
                                    }
                                    else if (controlType == "RadioButtonList")
                                    {
                                        radCtrl.Attributes.Add("onclick", "EditDeleteItem('" + radCtrl.ID + "', 'RadioButtonList')");
                                    }
                                    else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                                    {
                                        lstCtrl.Attributes.Add("onchange", "EditDeleteItem('" + lstCtrl.ID + "','ListBox')");
                                    }
                                }
                            }


                            ////Check the template is assigned to control, if so add in hidden field to restrict multiple control assigned=======
                            //bool isAssiged = false;
                            //for (int indx = 1; indx < ddlCtrl.Items.Count; indx++)
                            //{
                            //    string[] val = ddlCtrl.Items[indx].Value.ToString().Split(',');
                            //    if (val[3] != "")
                            //    {
                            //        isAssiged = true;                                    
                            //        break;
                            //    }
                            //}

                            //ArrayList arr = TemplateControls;
                            //if (isAssiged)
                            //{
                            //    //hfTemplateControls.Value = RefObj;// ddlCtrl.ID;                                
                            //    arr.Add(RefObj);
                            //}
                            //else
                            //{
                            //    arr.Remove(RefObj);
                            //}
                            //TemplateControls = arr;
                            ////=================

                            cnt = cnt + 1;
                            if (PrevCtrl != "")
                            {
                                GetPrevRefData(PrevCtrl,"");
                            }
                            //lblCtrl.Width = 90;
                            tdControls.Controls.Add(lblCtrl);

                            if (controlType == "DropDownList")
                            {
                                ListItem lst = new ListItem(" -- Select " + LabelText + " --", "0,0");
                                ddlCtrl.Items.Insert(0, lst);
                                tdControls.Controls.Add(ddlCtrl);
                            }
                            else if (controlType == "RadioButtonList")
                            {
                                tdControls.Controls.Add(radCtrl);
                            }
                            else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                            {
                                tdControls.Controls.Add(lstCtrl);
                            }
                        }
                        else
                        {
                            isSuccess = false;
                        }
                    }
                    else
                    {
                        if (countElements == 5)
                        {
                            y = dropDownNode.ChildNodes.Count;
                        }
                    }
                    if (isSuccess)
                    {
                        y = dropDownNode.ChildNodes.Count;
                        i = rootNodeList.Count;
                    }
                }
            }
        }        
    }

    private void GetPrevRefControls(string RefObj, string DependentOnId)
    {
        ReadNLoadFile();
        //string PrevRefControl = "";
        string PrevCtrl = "";
        string DependentControl = "";
        string DependentId = "";


        string FName = "";
        string IsManageable = "";
        bool isSuccess = false;
        string LabelText = "";
        string Dependency = "";

        ReadNLoadFile();

        NoOfDependents += 1;
        NoOfDependentsHidden.Value = NoOfDependents.ToString();

        XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controlType);
        Label lblCtrl = new Label();
        DropDownList ddlCtrl = new DropDownList();
        RadioButtonList radCtrl = new RadioButtonList();
        ListBox lstCtrl = new ListBox();

        lblCtrl.Text = "";
        if (controlType == "DropDownList")
        {
            ddlCtrl.ID = "ddlCtrl" + RefObj; //cnt;
        }
        else if (controlType == "RadioButtonList")
        {
            radCtrl.ID = "radCtrl" + RefObj;
        }
        else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
        {
            lstCtrl.ID = "lstCtrl" + RefObj;
        }


        if (controlType == "ListBox")
        {

            if ((DependentOnId.Trim() == "") || (DependentOnId.Trim() == null)) // If previous control's data NOT selected.
            {
                DataSet dsDataItem = new DataSet();
                dsDataItem.Tables.Add();
                dsDataItem.Tables.Add();

                DataTable dtListItems = new DataTable();
                DataTable dtMainData = new DataTable();

                var q = from c in xmlDoc.Descendants("ListBox")
                        where c.Element("FieldID").Value == RefObj //controlId
                        select new
                        {
                            LabelText = c.Element("Text"),
                            PreviousRef = c.Element("PrevRef"),
                            DependentID = c.Element("DependentID"),
                            ListOfItems = c.Element("LISTITEMS").Descendants("LISTITEM")
                        };

                foreach (var obj in q)
                {
                    PrevCtrl = obj.PreviousRef.Value;
                    DependentId = obj.DependentID.Value;

                    var ListItems = obj.ListOfItems;

                    if (PrevCtrl.Trim() != "")
                    {
                        GetPrevRefControls(PrevCtrl.Trim(), "");
                    }
                    else
                    {
                        foreach (var ele in ListItems)
                        {
							string wrapNoteValue;
                            if (ele.Attribute("WrapNote") == null)
								wrapNoteValue = "";
							else
                                wrapNoteValue = ele.Attribute("WrapNote").Value;


                            string optionTooltip;
                            if (ele.Attribute("OptionTooltip") == null)
                                optionTooltip = "";
                            else
                                optionTooltip = ele.Attribute("OptionTooltip").Value;

                            string template;
                            if (ele.Attribute("Template") == null)
                            {
                                template = "";
                            }
                            else
                            {
                                template = ele.Attribute("Template").Value;
                            }

							string EleValue = ele.Attribute("Id").Value + "," + ele.Value + "," + ele.Attribute("DependentOn").Value + "," + wrapNoteValue + "," + optionTooltip + "," + template;
                            ListItem lst = new ListItem(ele.Value, EleValue);
                            //ListItem lst = new ListItem(EleValue, ele.Attribute("Id").Value);
                            lstCtrl.Items.Add(lst);
                        }
                    }
                }
            }
            else
            {
                var q = from c in xmlDoc.Descendants("ListBox")
                        where c.Element("FieldID").Value == RefObj
                        select new
                        {
                            ThisRecordId = c.Element("Id"),
                            LabelText = c.Element("Text"),
                            PreviousRef = c.Element("PrevRef"),
                            DependentID = c.Element("DependentID"),
                            ListOfItems = from items in c.Element("LISTITEMS").Descendants("LISTITEM")
                                          where items.Attribute("DependentOn").Value == DependentOnId
                                          select items
                        };

                if (PrevCtrl.Trim() != "")
                {
                    GetPrevRefControls(PrevCtrl.Trim(), "");
                }

                foreach (var obj in q)
                {
                    PrevCtrl = obj.PreviousRef.Value;
                    DependentId = obj.DependentID.Value;
                    var ListItems = obj.ListOfItems;

                    if (PrevCtrl.Trim() != "")
                    {
                        GetPrevRefControls(PrevCtrl.Trim(), "");
                    }
                    else
                    {
                        foreach (var ele in ListItems)
                        {
                            //string EleValue = ThisRecordId + "," + ele.Value + "," + DependentId;
							string wrapNoteValue;
                            if (ele.Attribute("WrapNote") == null)
								wrapNoteValue = "";
							else
                                wrapNoteValue = ele.Attribute("WrapNote").Value;

                            string optionTooltip;
                            if (ele.Attribute("OptionTooltip") == null)
                                optionTooltip = "";
                            else
                                optionTooltip = ele.Attribute("OptionTooltip").Value;

                            string template;
                            if (ele.Attribute("Template") == null)
                            {
                                template = "";
                            }
                            else
                            {
                                template = ele.Attribute("Template").Value;
                            }

							string EleValue = ele.Attribute("Id").Value + "," + ele.Value + "," + ele.Attribute("DependentOn").Value + "," + wrapNoteValue + "," + optionTooltip + "," + template;
                            ListItem lst = new ListItem(ele.Value, EleValue);
                            //ListItem lst = new ListItem(ele.Value, ele.Attribute("Id").Value);
                            lstCtrl.Items.Add(lst);
                        }
                    }
                }
            }

            tdControls.Controls.Add(lstCtrl);
            string SelectedControl = "lstCtrl" + drpFrom.SelectedValue;
            if (lstCtrl.ID.Trim() != SelectedControl.Trim())
            {
                if (DependentControl.Trim() != "")
                {
                    //lstCtrl.Attributes.Add("onclick", "FillSelectedValues('" + lstCtrl.ID + "', '" + DependentControl + "')");
                    lstCtrl.Attributes.Add("onchange", "FillSelectedValues('" + lstCtrl.ID + "', '" + DependentId + "','" + ReadXMLHidden.Value + "','" + NoOfDependents + "')");
                }
            }
            else
            {
                lstCtrl.Attributes.Add("onchange", "EditDeleteItem('" + lstCtrl.ID + "','ListBox')");
            }
        }
        else
        {
            for (int i = 0; i < rootNodeList.Count; i++)
            {
                XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                int countElements = 0;

                PrevCtrl = "";
                FName = "";
                IsManageable = "";
                isSuccess = false;
                LabelText = "";

                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if (dropDownNode.ChildNodes[y].Name == "Title")
                    {
                        LabelText = dropDownNode.ChildNodes[y].FirstChild.Value;
                    }
                    if (dropDownNode.ChildNodes[y].Name == "IsManageable")
                    {
                        IsManageable = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    if (dropDownNode.ChildNodes[y].Name == "FieldID")
                    {
                        FName = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    if (dropDownNode.ChildNodes[y].Name == "PrevRef")
                    {
                        PrevCtrl = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    if (dropDownNode.ChildNodes[y].Name == "DependentID")
                    {
                        DependentId = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    if (dropDownNode.ChildNodes[y].Name == "Dependency")
                    {
                        Dependency = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }

                    if ((IsManageable == "True") && (FName == RefObj) && (countElements == 5))  //&& (PrevCtrl != "")
                    {
                        if (PrevCtrl != "")
                        {
                            SelectedControl.Value = "Parent";
                        }

                        lblCtrl.ID = "lbl" + RefObj;
                        lblCtrl.Text = "  " + LabelText + "  ";

                        if (dropDownNode.ChildNodes[y].Name == "LISTITEMS")
                        {
                            XmlNodeList listItems = dropDownNode.ChildNodes[y].ChildNodes;

                            // Creating an array. This will be used in javascript n registered via code
                            //***CallTypeArrayText += "var Array" + (FName).ToString() + " = new Array( " + listItems.Count + " );\n";

                            if ((listItems.Count == 0)) //(PrevCtrl == "") &&
                            {
                                lblErr.Text = "No List Items added in " + LabelText + " <br> Please add Items first.";
                                //if ((FName != RefObj) && (DependentId !=))
                                if (drpFrom.SelectedValue != FName)
                                {
                                    btnAdd.Enabled = false;
                                    btnDelete.Enabled = false;
                                    btnUpdate.Enabled = false;

                                    btnAdd.ImageUrl = "~/Images/but_add_n.jpg";
                                    btnDelete.ImageUrl = "~/Images/but_delete_n.jpg";
                                    btnUpdate.ImageUrl = "~/Images/but_update_n.jpg";
                                }
                            }

                            for (int l = 0; l < listItems.Count; l++)
                            {
                                string dependentOn = "";
                                string ListItemVal = "";
                                string ListItemText = "";

                                ListItemText = listItems.Item(l).InnerText;
                                ListItemVal = listItems.Item(l).Attributes["Id"].Value;

                                if ((listItems.Item(l).Attributes["DependentOn"].Value.Trim() != "") || (listItems.Item(l).Attributes["DependentOn"].Value.Trim() == "0"))
                                {
                                    dependentOn = listItems.Item(l).Attributes["DependentOn"].Value;

                                    if ((dependentOn == "") || (dependentOn == null))
                                    {
                                        dependentOn = "0";
                                    }
                                }

                                if ((PrevCtrl == ""))
                                {
                                    ListItem lst = new ListItem();
                                    lst.Text = ListItemText;
									lst.Value = ListItemVal + "," + ListItemText + "," + dependentOn ;

                                    if (controlType == "DropDownList")
                                    {
										string wrapNoteValue;

                                        if (listItems.Item(l).Attributes["WrapNote"] == null)
											wrapNoteValue = "";
										else
                                            wrapNoteValue = listItems.Item(l).Attributes["WrapNote"].Value;

                                        string optionTooltip; 
                                        if (listItems.Item(l).Attributes["OptionTooltip"] == null)
                                            optionTooltip = "";
                                        else
                                            optionTooltip = listItems.Item(l).Attributes["OptionTooltip"].Value;

                                        string template;
                                        if (listItems.Item(l).Attributes["Template"] == null)
                                            template = "";
                                        else
                                            template = listItems.Item(l).Attributes["Template"].Value;

										lst.Value += "," + wrapNoteValue + "," + optionTooltip + "," + template; //listItems.Item(l).Attributes["WrapNote"].Value;
                                        
                                        //Add item to in the control
                                        ddlCtrl.Items.Add(lst);

                                        if ((ddlCtrl.ID == selectedField.Value.Trim()) && (ListItemVal == SelectedValue.Value))
                                        {
                                            ddlCtrl.Attributes.Add("onfocusin", "javascript:Populate('" + ddlCtrl.ID + "', 'ddlCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                            ddlCtrl.SelectedIndex = l;
                                            ScriptManager m1 = (ScriptManager)Master.FindControl("ScriptManager1");
                                            m1.SetFocus(ddlCtrl);
                                        }
                                    }
                                    else if (controlType == "RadioButtonList")
                                    {
                                        radCtrl.Items.Add(lst);
                                    }
                                    else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                                    {
										if (controlType == "ListBox")
										{
                                            lst.Value += "," + listItems.Item(l).Attributes["WrapNote"].Value + "," + listItems.Item(l).Attributes["OptionTooltip"].Value;	
										}

                                        lstCtrl.Items.Add(lst);
                                        if ((lstCtrl.ID == selectedField.Value.Trim()) && (ListItemVal == SelectedValue.Value))
                                        {
                                            lstCtrl.Attributes.Add("onfocusin", "javascript:Populate('" + lstCtrl.ID + "', 'lstCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                            lstCtrl.SelectedIndex = l;
                                            ScriptManager m1 = (ScriptManager)Master.FindControl("ScriptManager1");
                                            m1.SetFocus(lstCtrl);
                                        }
                                    }
                                }

                                if (FName != drpFrom.SelectedValue)
                                {
                                    if (controlType == "DropDownList")
                                    {
                                        ddlCtrl.Attributes.Add("onchange", "Populate('" + ddlCtrl.ID + "', 'ddlCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                    }
                                    else if (controlType == "RadioButtonList")
                                    {
                                        radCtrl.Attributes.Add("onclick", "Populate('" + radCtrl.ID + "', 'radCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                    }
                                    else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                                    {
                                        lstCtrl.Attributes.Add("onchange", "Populate('" + lstCtrl.ID + "', 'lstCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                    }
                                }
                                else
                                {
                                    if (controlType == "DropDownList")
                                    {
                                        ddlCtrl.Attributes.Add("onchange", "EditDeleteItem('" + ddlCtrl.ID + "','DropDownList')");
                                    }
                                    else if (controlType == "RadioButtonList")
                                    {
                                        radCtrl.Attributes.Add("onclick", "EditDeleteItem('" + radCtrl.ID + "', 'RadioButtonList')");
                                    }
                                    else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                                    {
                                        lstCtrl.Attributes.Add("onchange", "EditDeleteItem('" + lstCtrl.ID + "','ListBox')");
                                    }
                                }
                            }


                            ////Check the template is assigned to control, if so add in hidden field to restrict multiple control assigned=======
                            //bool isAssiged = false;
                            //for (int indx = 1; indx < ddlCtrl.Items.Count; indx++)
                            //{
                            //    string[] val = ddlCtrl.Items[indx].Value.ToString().Split(',');
                            //    if (val[3] != "")
                            //    {
                            //        isAssiged = true;                                    
                            //        break;
                            //    }
                            //}

                            //ArrayList arr = TemplateControls;
                            //if (isAssiged)
                            //{
                            //    //hfTemplateControls.Value = RefObj;// ddlCtrl.ID;                                
                            //    arr.Add(RefObj);
                            //}
                            //else
                            //{
                            //    arr.Remove(RefObj);
                            //}

                            //TemplateControls = arr;
                            ////=================


                            cnt = cnt + 1;
                            if (PrevCtrl != "")
                            {
                                GetPrevRefControls(PrevCtrl, "");
                            }

                            tdControls.Controls.Add(lblCtrl);


                            if (controlType == "DropDownList")
                            {
                                ListItem lst = new ListItem(" -- Select " + LabelText + " --", "0,0");
                                ddlCtrl.Items.Insert(0, lst);
                                tdControls.Controls.Add(ddlCtrl);
                            }
                            else if (controlType == "RadioButtonList")
                            {
                                tdControls.Controls.Add(radCtrl);
                            }
                            else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                            {
                                tdControls.Controls.Add(lstCtrl);
                            }
                        }
                        else
                        {
                            isSuccess = false;
                        }
                    }
                    else
                    {
                        if (countElements == 5)
                        {
                            y = dropDownNode.ChildNodes.Count;
                        }
                    }
                    if (isSuccess)
                    {
                        y = dropDownNode.ChildNodes.Count;
                        i = rootNodeList.Count;
                    }
                }
            }
        }
    }

    private void GetPrevRefControlsOld(string RefObj)
    {
        string PrevCtrl = "";
        string FName = "";
        string IsManageable = "";
        bool isSuccess = false;
        string DependentId = "";
        string LabelText = "";
        string Dependency = "";

        ReadNLoadFile();

        NoOfDependents += 1;
        NoOfDependentsHidden.Value = NoOfDependents.ToString();

        XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controlType);
        Label lblCtrl = new Label();
        DropDownList ddlCtrl = new DropDownList();
        RadioButtonList radCtrl = new RadioButtonList();
        ListBox lstCtrl = new ListBox();

        lblCtrl.Text = "";
        if (controlType == "DropDownList")
        {
            ddlCtrl.ID = "ddlCtrl" + RefObj; //cnt;
        }
        else if (controlType == "RadioButtonList")
        {
            radCtrl.ID = "radCtrl" + RefObj;
        }
        else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
        {
            lstCtrl.ID = "lstCtrl" + RefObj;
        }



        for (int i = 0; i < rootNodeList.Count; i++)
        {
            XmlNode dropDownNode = (XmlNode)rootNodeList[i];

            int countElements = 0;

            PrevCtrl = "";
            FName = "";
            IsManageable = "";
            isSuccess = false;
            LabelText = "";

            for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
            {
                if (dropDownNode.ChildNodes[y].Name == "Title")
                {
                    LabelText = dropDownNode.ChildNodes[y].FirstChild.Value;
                }
                if (dropDownNode.ChildNodes[y].Name == "IsManageable")
                {
                    IsManageable = dropDownNode.ChildNodes[y].InnerText.Trim();
                    countElements = countElements + 1;
                }
                if (dropDownNode.ChildNodes[y].Name == "FieldID")
                {
                    FName = dropDownNode.ChildNodes[y].InnerText.Trim();
                    countElements = countElements + 1;
                }
                if (dropDownNode.ChildNodes[y].Name == "PrevRef")
                {
                    PrevCtrl = dropDownNode.ChildNodes[y].InnerText.Trim();
                    countElements = countElements + 1;
                }
                if (dropDownNode.ChildNodes[y].Name == "DependentID")
                {
                    DependentId = dropDownNode.ChildNodes[y].InnerText.Trim();
                    countElements = countElements + 1;
                }
                if (dropDownNode.ChildNodes[y].Name == "Dependency")
                {
                    Dependency = dropDownNode.ChildNodes[y].InnerText.Trim();
                    countElements = countElements + 1;
                }

                if ((IsManageable == "True") && (FName == RefObj) && (countElements == 5))  //&& (PrevCtrl != "")
                {
                    if (PrevCtrl != "")
                    {
                        SelectedControl.Value = "Parent";
                    }

                    lblCtrl.ID = "lbl" + RefObj;
                    lblCtrl.Text = "  " + LabelText + "  ";

                    if (dropDownNode.ChildNodes[y].Name == "LISTITEMS")
                    {
                        XmlNodeList listItems = dropDownNode.ChildNodes[y].ChildNodes;

                        // Creating an array. This will be used in javascript n registered via code
                        //***CallTypeArrayText += "var Array" + (FName).ToString() + " = new Array( " + listItems.Count + " );\n";

                        if ((listItems.Count == 0)) //(PrevCtrl == "") &&
                        {
                            lblErr.Text = "No List Items added in " + LabelText + " <br> Please add Items first.";
                            //if ((FName != RefObj) && (DependentId !=))
                            if (drpFrom.SelectedValue != FName)
                            {
                                btnAdd.Enabled = false;
                                btnDelete.Enabled = false;
                                btnUpdate.Enabled = false;

                                btnAdd.ImageUrl = "~/Images/but_add_n.jpg";
                                btnDelete.ImageUrl = "~/Images/but_delete_n.jpg";
                                btnUpdate.ImageUrl = "~/Images/but_update_n.jpg";
                            }
                        }

                        for (int l = 0; l < listItems.Count; l++)
                        {
                            string dependentOn = "";
                            string ListItemVal = "";
                            string ListItemText = "";

                            ListItemText = listItems.Item(l).InnerText;
                            ListItemVal = listItems.Item(l).Attributes["Id"].Value;

                            if ((listItems.Item(l).Attributes["DependentOn"].Value.Trim() != "") || (listItems.Item(l).Attributes["DependentOn"].Value.Trim() == "0"))
                            {
                                dependentOn = listItems.Item(l).Attributes["DependentOn"].Value;

                                if ((dependentOn == "") || (dependentOn == null))
                                {
                                    dependentOn = "0";
                                }
                            }

                            if ((PrevCtrl == ""))
                            {
                                ListItem lst = new ListItem();
                                lst.Text = ListItemText;
                                lst.Value = ListItemVal + "," + ListItemText + "," + dependentOn;

                                if (controlType == "DropDownList")
                                {
                                    ddlCtrl.Items.Add(lst);
                                    if ((ddlCtrl.ID == selectedField.Value.Trim()) && (ListItemVal == SelectedValue.Value))
                                    {
                                        ddlCtrl.Attributes.Add("onfocusin", "javascript:Populate('" + ddlCtrl.ID + "', 'ddlCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                        ddlCtrl.SelectedIndex = l;
                                        ScriptManager m1 = (ScriptManager)Master.FindControl("ScriptManager1");
                                        m1.SetFocus(ddlCtrl);
                                    }
                                }
                                else if (controlType == "RadioButtonList")
                                {
                                    radCtrl.Items.Add(lst);
                                }
                                else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                                {
                                    lstCtrl.Items.Add(lst);
                                    if ((lstCtrl.ID == selectedField.Value.Trim()) && (ListItemVal == SelectedValue.Value))
                                    {
                                        lstCtrl.Attributes.Add("onfocusin", "javascript:Populate('" + lstCtrl.ID + "', 'lstCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                        lstCtrl.SelectedIndex = l;
                                        ScriptManager m1 = (ScriptManager)Master.FindControl("ScriptManager1");
                                        m1.SetFocus(lstCtrl);
                                    }
                                }
                            }

                            if (FName != drpFrom.SelectedValue)
                            {
                                if (controlType == "DropDownList")
                                {
                                    ddlCtrl.Attributes.Add("onchange", "Populate('" + ddlCtrl.ID + "', 'ddlCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                }
                                else if (controlType == "RadioButtonList")
                                {
                                    radCtrl.Attributes.Add("onclick", "Populate('" + radCtrl.ID + "', 'radCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                }
                                else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                                {
                                    lstCtrl.Attributes.Add("onchange", "Populate('" + lstCtrl.ID + "', 'lstCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                }
                            }
                            else
                            {
                                if (controlType == "DropDownList")
                                {
                                    ddlCtrl.Attributes.Add("onchange", "EditDeleteItem('" + ddlCtrl.ID + "','DropDownList')");
                                }
                                else if (controlType == "RadioButtonList")
                                {
                                    radCtrl.Attributes.Add("onclick", "EditDeleteItem('" + radCtrl.ID + "', 'RadioButtonList')");
                                }
                                else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                                {
                                    lstCtrl.Attributes.Add("onchange", "EditDeleteItem('" + lstCtrl.ID + "','ListBox')");
                                }
                            }
                        }

                        cnt = cnt + 1;
                        if (PrevCtrl != "")
                        {
                            GetPrevRefControls(PrevCtrl,  "");
                        }

                        tdControls.Controls.Add(lblCtrl);

                        if (controlType == "DropDownList")
                        {
                            ListItem lst = new ListItem(" -- Select " + LabelText + " --", "0,0");
                            ddlCtrl.Items.Insert(0, lst);
                            tdControls.Controls.Add(ddlCtrl);
                        }
                        else if (controlType == "RadioButtonList")
                        {
                            tdControls.Controls.Add(radCtrl);
                        }
                        else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                        {
                            tdControls.Controls.Add(lstCtrl);
                        }
                    }
                    else
                    {
                        isSuccess = false;
                    }
                }
                else
                {
                    if (countElements == 5)
                    {
                        y = dropDownNode.ChildNodes.Count;
                    }
                }
                if (isSuccess)
                {
                    y = dropDownNode.ChildNodes.Count;
                    i = rootNodeList.Count;
                }
            }
        }
        //}
    }

    protected void drpSelectControl_SelectedIndexChanged(object sender, EventArgs e)
    {
        //ClearMessages();
        //controlType = drpSelectControl.SelectedValue;
        //BindDropdowns(controlType);
        //EnableActionButtons();
    }

    protected void lnkBtnDropDown_Click(object sender, CommandEventArgs e)
    {
        ClearMessages();
        
		txtValue.Text = "";
		txtWrapNote.Text = "";
        txtOptionTooltip.Text = "";
         
		trWrapNote.Style.Add("display", "none");
        trOptionTooltip.Style.Add("display", "none");
        trTemplate.Style.Add("display", "none");

        controlType = e.CommandArgument.ToString();
        hidSelectedControl.Value = controlType;
        BindDropdowns(controlType);
        EnableActionButtons();
        GetSelectedControlTd();

        NoOfDependentsHidden.Value = "";
        NoOfSelectedParentsHidden.Value = "";
    }

    private void GetSelectedControlTd()
    {
        DeselectControlTd();
        if (controlType == "DropDownList")
        {
            lnkBtnDropDown.BackColor = System.Drawing.Color.SkyBlue;
            txtValue.MaxLength = 200;
            btnOptimize.Visible = true;
            lblOptimize.Visible = true;
        }
        if (controlType == "ListBox")
        {
            lnkBtnListBox.BackColor = System.Drawing.Color.SkyBlue;
            txtValue.MaxLength = 200;
            btnOptimize.Visible = true;
            lblOptimize.Visible = true;
        }
        if (controlType == "CheckBoxList")
        {
            lnkBtnCheckBox.BackColor = System.Drawing.Color.SkyBlue;
            txtValue.MaxLength = 200;
            btnOptimize.Visible = false;
            lblOptimize.Visible = false;
        }
        if (controlType == "RadioButtonList")
        {
            lnkBtnRadioButton.BackColor = System.Drawing.Color.SkyBlue;
            txtValue.MaxLength = 200;
            btnOptimize.Visible = false;
            lblOptimize.Visible = false;
        }
    }

    private void DeselectControlTd()
    {
        lnkBtnListBox.BackColor = System.Drawing.Color.Transparent;
        lnkBtnDropDown.BackColor = System.Drawing.Color.Transparent;
        lnkBtnRadioButton.BackColor = System.Drawing.Color.Transparent;
        lnkBtnCheckBox.BackColor = System.Drawing.Color.Transparent;
    }
    
    // This function is used to check if there are any dependencies set on any controls.
    // If dependency is set, the Optimise Script Button will be enabled.
    private void CheckDependencyForOptimizingScript(string FromWhere)
    {
        ReadNLoadFile();

      //Dependent controls loop to generate array.
        string[] DependentCtrlArray = new string[2];
        DependentCtrlArray[0] = "DropDownList";
        DependentCtrlArray[1] = "ListBox";

        bool IsDepAvail = false;
        bool IsOptimized = false;

        foreach (string ctrl in DependentCtrlArray)
        {
            XmlNodeList rootDropDownNodeList = doc.SelectNodes("FORMS/" + ctrl);

            for (int iNodeDropDownCount = 0; iNodeDropDownCount < rootDropDownNodeList.Count; iNodeDropDownCount++)
            {
                XmlNode CtrlNode = (XmlNode)rootDropDownNodeList[iNodeDropDownCount];

                for (int iChildDropDownNode = 0; iChildDropDownNode < CtrlNode.ChildNodes.Count; iChildDropDownNode++)
                {
                    string Dependency = CtrlNode.ChildNodes[iChildDropDownNode].LocalName;
                    if (Dependency == "Dependency")
                    {
                        string IsDep = CtrlNode.ChildNodes[iChildDropDownNode].InnerText;

                        if (IsDep == "True")
                        {
                            IsDepAvail = true;      // Dependency Available
                            iChildDropDownNode = CtrlNode.ChildNodes.Count;
                            iNodeDropDownCount = rootDropDownNodeList.Count;
                        }
                    }
                }
            }
            if (IsDepAvail == true)
            {
                break;
            }
        }

        XmlNodeList rootNodeListScript = doc.SelectNodes("FORMS/DataScript");
        if (rootNodeListScript.Count > 0)
        {
            XmlNode DataScriptUpdateNode = (XmlNode)rootNodeListScript[0];
            XmlNode IsUpdatedChildNode = (XmlNode)DataScriptUpdateNode.ChildNodes[0];// node <IsUpdated>
            if (IsUpdatedChildNode.InnerText == "True")
            {
                IsOptimized = true;  // Script Optimized already
            }
            else
            {
                IsOptimized = false;    // Script needs to be optimized.
            }
        }

        if((IsDepAvail) && (IsOptimized))
        {
            td1.Visible = true;
            td2.Visible = true;
            btnOptimize.ImageUrl = "../images/but_opt_n.jpg";  // blue Image
            btnOptimize.Enabled = false;
            lblOptimize.Text = "Optimized Script";
            lblInstruction.Text = "This Form has been optimized for usage.";
        }
        else if ((IsDepAvail) && (IsOptimized == false))
        {
            td1.Visible = true;
            td2.Visible = true;
            btnOptimize.ImageUrl = "../images/but_opt_new.jpg";  // Red Image
            btnOptimize.Enabled = true;
            lblOptimize.Text = "Optimize Script";
            //lblInstruction.Text = "Click on this button after you complete data updates(Add/Delete/Update) for all values. This may take a while to process.";
            if (FromWhere == "")
            {
                lblInstruction.Text = "To Optimize Script, click on this button. This will take a while to process. Please wait for a success message.";                
            }
            else
            {
                lblInstruction.Text = "Click on this button after you complete data updates(add/delete/modify) for all values. This may take a while to process.";
            }
        }
    }

    private void EnableActionButtons()
    {
        btnAdd.Enabled = true;
        btnDelete.Enabled = true;
        btnUpdate.Enabled = true;

        btnAdd.ImageUrl = "~/Images/but_Add.jpg";
        btnDelete.ImageUrl = "~/Images/but_Delete.jpg";
        btnUpdate.ImageUrl = "~/Images/but_update.jpg";

    }

    private void BindDropdowns(string ctrlType)
    {
        // Reading and loading XML file
        ReadNLoadFile();

        // Empty control
        drpFrom.Items.Clear();

        // Checking the XML File and retrieving all the Dropdown contrls available in the file.
        XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + ctrlType + "/FieldID");

        for (int i = 0; i < rootNodeList.Count; i++)
        {
            XmlNode dropDownNode = (XmlNode)rootNodeList[i];
            ListItem lst = new ListItem(dropDownNode.NextSibling.InnerText, dropDownNode.FirstChild.InnerText);

            drpFrom.Items.Add(lst);
        }
        drpFrom.Items.Insert(0, "-- Select --");
    }

    public bool TemplateAlreadyNotAssigned()
    {
        //if (ddlTemplate.SelectedIndex == 0 || (ddlTemplate.SelectedIndex > 0 && (drpFrom.SelectedValue == hfTemplateControls.Value || hfTemplateControls.Value == "")))
        if (ddlTemplate.SelectedIndex == 0 || (ddlTemplate.SelectedIndex > 0 && TemplateControls.Count <= 1 && TemplateControls.Contains(drpFrom.SelectedValue)) || TemplateControls.Count==0)
        {
            hfTemplateControls.Value=drpFrom.SelectedItem.Text;
            return true;
        }
        else
        {
            BindControlsValues();
            lblErr.Text = "Template is already assigned on control <b>" + hfTemplateControls.Value + "</b>" ;
            return false;
        }
    }

    // Adding item to control
    protected void btnAdd_Click(object sender, ImageClickEventArgs e)
    {
        if (TemplateAlreadyNotAssigned())
        {
            controlToChange = drpFrom.SelectedValue;
            GetControlType();
            AppendFile();
            //**GetData();  // this was commented. lemme chk if it works without this.
            GetDataAfterAction();
            ClearHiddenValues();
            UpdateXmlOnceDataChanged(); // Added later, to Update XML
            CheckDependencyForOptimizingScript("FromAction");   // Added Later on 09/06/09
        }
        
    }

    // Updating item 
    protected void btnUpdate_Click(object sender, ImageClickEventArgs e)
    {
        
        ClearMessages();
        if (TemplateAlreadyNotAssigned())
        {
            GetControlType();
            ReadNLoadFile();
            XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controlType);
            string DepOnId = SelectedValue.Value;
            string DepIdFromXml = SelectedDepIdFromXml.Value;

            if ((SelectedControl.Value == "Parent") && ((controlType == "DropDownList") || (controlType == "ListBox")) && ((DepIdFromXml == "0") || (DepIdFromXml.ToLower() == "undefined")))
            {
                lblErr.Text = "Please select control list item to update";
                //** GetData();  COMMENTED BY AARTI.. SINCE NEW FUNCTION IS WRITTEN.
                GetDataAfterAction();
            }
            else if (((controlType == "DropDownList") || (controlType == "ListBox")) && ((DepOnId == "") || (DepOnId == "0")))
            {
                lblErr.Text = "Please select control list item to update";
                //**GetData();
                GetDataAfterAction();
            }
            else if (((controlType == "CheckBoxList") || (controlType == "RadioButtonList")) && ((DepOnId == "") || (SelectedItemOldValue.Value == "")))  //|| (DepOnId == "0") -- commented.
            {
                lblSuccess.Text = "Please select control list item to update";
                //** GetData();
                GetDataAfterAction();
            }
            else
            {
                for (int i = 0; i < rootNodeList.Count; i++)
                {
                    XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                    for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                    {
                        if ((dropDownNode.ChildNodes[y].Name == "FieldID") && (dropDownNode.ChildNodes[y].InnerText == drpFrom.SelectedValue))
                        {
                            string FNameUpdate = dropDownNode.ChildNodes[y].InnerText.Trim();
                            for (int j = 0; j < dropDownNode.ChildNodes.Count; j++)
                            {
                                XmlNode dropDownChildNode = (XmlNode)dropDownNode.ChildNodes[j];

                                string ListItemText = "";
                                string ExistingDepOnId = "";
                                string ThisId = "";
                                string ExistingWrapNote = "";
                                string ExistingOptionTooltip = "";
                                string ExistingTemplate = "";

                                if (dropDownChildNode.Name == "LISTITEMS")
                                {
                                    XmlNodeList listItems = dropDownNode.ChildNodes[j].ChildNodes;
                                    bool isAvail = false;

                                    for (int l = 0; l < listItems.Count; l++)
                                    {
                                        ListItemText = listItems.Item(l).InnerText;

                                        if (listItems.Item(l).Name == "LISTITEM")
                                        {
                                            ThisId = listItems.Item(l).Attributes["Id"].Value;
                                            ExistingDepOnId = listItems.Item(l).Attributes["DependentOn"].Value;
                                        }

                                        if ((controlType == "DropDownList") || (controlType == "ListBox"))
                                        {
                                            if (listItems.Item(l).Attributes["WrapNote"] != null)
                                            {
                                                ExistingWrapNote = listItems.Item(l).Attributes["WrapNote"].Value;	// Checking for Existing Wrap Note
                                            }

                                            if (listItems.Item(l).Attributes["OptionTooltip"] != null)
                                            {
                                                ExistingOptionTooltip = listItems.Item(l).Attributes["OptionTooltip"].Value;	// Checking for Existing Option Tooltip
                                            }

                                            if (listItems.Item(l).Attributes["Template"] != null)
                                            {
                                                ExistingTemplate = listItems.Item(l).Attributes["Template"].Value;	// Checking for Existing Option Tooltip
                                            }

                                            if ((ListItemText.ToUpper().Trim() == txtValue.Text.ToUpper().Trim()) && (DepIdFromXml.Trim() == ExistingDepOnId.Trim()) && (ExistingWrapNote.Replace("¢", "\r\n") == txtWrapNote.Text.Trim().Replace("¢", "\r\n")) && (ExistingTemplate == ddlTemplate.SelectedValue))
                                            {
                                                //isAvail = true;
                                            }
                                        }
                                        else
                                        {
                                            // Checking if same list item exists for same parent node.
                                            if ((ListItemText.ToUpper().Trim() == txtValue.Text.ToUpper().Trim()) && (DepIdFromXml.Trim() == ExistingDepOnId.Trim()))
                                            {
                                                //isAvail = true;
                                            }
                                        }
                                    }

                                    if (isAvail == true)
                                    {

                                        //date :29 mar 2011 
                                        // In Update Case no need to check  for already exists 

                                        //lblSuccess.Text = "This option already exists 222";
                                        //SelectedValue.Value = PopulateParentIdHidden.Value;
                                        ////**GetData();
                                        //GetDataAfterAction();
                                    }
                                    else
                                    {
                                        for (int l = 0; l < listItems.Count; l++)
                                        {
                                            ListItemText = listItems.Item(l).InnerText;

                                            if (listItems.Item(l).Name == "LISTITEM")
                                            {
                                                ThisId = listItems.Item(l).Attributes["Id"].Value;
                                                ExistingDepOnId = listItems.Item(l).Attributes["DependentOn"].Value;
                                            }

                                            if ((ListItemText == SelectedItemOldValue.Value) && (DepOnId == ThisId))
                                            {
                                                listItems.Item(l).InnerText = txtValue.Text.Trim();

                                                if ((controlType == "DropDownList") || (controlType == "ListBox"))
                                                {
                                                    if (listItems.Item(l).Attributes["WrapNote"] == null)
                                                    {
                                                        XmlAttribute attr = doc.CreateAttribute("WrapNote");
                                                        listItems.Item(l).Attributes.Append(attr);
                                                    }

                                                    if (listItems.Item(l).Attributes["OptionTooltip"] == null)
                                                    {
                                                        XmlAttribute attr = doc.CreateAttribute("OptionTooltip");
                                                        listItems.Item(l).Attributes.Append(attr);
                                                    }

                                                    if (listItems.Item(l).Attributes["Template"] == null)
                                                    {
                                                        XmlAttribute attr = doc.CreateAttribute("Template");
                                                        listItems.Item(l).Attributes.Append(attr);
                                                    }

                                                    listItems.Item(l).Attributes["WrapNote"].Value = txtWrapNote.Text.Trim().Replace("\r\n", "¢");
                                                    listItems.Item(l).Attributes["OptionTooltip"].Value = txtOptionTooltip.Text.Trim();
                                                    listItems.Item(l).Attributes["Template"].Value = ddlTemplate.SelectedValue;
                                                }

                                                doc.Save(FileName);         // Removes the listitem and save the file
                                                lblSuccess.Text = "Option updated successfully";
                                                SelectedValue.Value = PopulateParentIdHidden.Value;

                                                if (controlType != "ListBox")
                                                {
                                                    string Arrays = Session["JavaScriptTextBox"].ToString();
                                                    string SetDiffrentValues = Arrays + "Array" + (FNameUpdate).ToString() + "[" + ExistingDepOnId + "][" + ThisId + "]= new Array('" + txtValue.Text.Trim() + "," + txtWrapNote.Text.Trim().Replace("\r\n", "¢") + "," + txtOptionTooltip.Text.Trim() + "," + ddlTemplate.SelectedValue + "');\n";
                                                    Session["JavaScriptTextBox"] = SetDiffrentValues;
                                                    ///  JavaScriptTextBox.Text = CallTypeArrayText;
                                                    // Registering javascript
                                                    // ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "CallTypeArray", JavaScriptTextBox.Text, true);
                                                    JavaScriptTextBox.Text = SetDiffrentValues;  //add later on 24-mar-2011

                                                    // Registering javascript
                                                    //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "CallTypeArray", JavaScriptTextBox.Text, true);


                                                }
                                                //**GetData();
                                                GetDataAfterAction();
                                                txtValue.Text = "";
                                                ClearHiddenValues();

                                                l = listItems.Count;
                                                j = dropDownNode.ChildNodes.Count;
                                                y = dropDownNode.ChildNodes.Count;
                                                i = rootNodeList.Count;
                                            }
                                        }
                                        UpdateXmlOnceDataChanged(); // Added later, to Update XML
                                    }
                                }
                            }
                        }
                    }
                }
            }
            CheckDependencyForOptimizingScript("FromAction");
            // Response.Redirect("DataManagement.aspx");

            // Added Later on 09/06/09
            //if (Session["JavaScriptTextBox"] != null)
            //{
            //    JavaScriptTextBox.Text = Session["JavaScriptTextBox"].ToString();  //add later on 24-mar-2011
            //    // Registering javascript
            //    ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "CallTypeArray", JavaScriptTextBox.Text, true);
            //}
        }
    }

    // deleting item
    protected void btnDelete_Click(object sender, ImageClickEventArgs e)
    {

        ClearMessages();
        GetControlType();


        //string deptID = "";
        //string itemname = "";
        //string deletecontrolname = "";
        //int remaingitemcount = 0;
       
        //deptID = "";
        //itemname = "";
        //deptID = SelectedValue.Value;
        //itemname = SelectedValue.Value;
        //deletecontrolname = SelectedValue.Value;
        //remaingitemcount = DeleteNodes(deptID, itemname, deletecontrolname, controlType);




        
        
        ReadNLoadFile();
        XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controlType);
        string DepOnId = SelectedValue.Value;
        string DependentControl = "";
        string IdToDeleteRelNodes = "";
        bool isOver = false;
        string CurrentField = "";
        int counter = 0;

        try
        {
            for (int i = 0; i < rootNodeList.Count; i++)
            {
                XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if (dropDownNode.ChildNodes[y].Name == "DependentID")
                    {
                        DependentControl = dropDownNode.ChildNodes[y].InnerText;    // Assigning Dependent Control here
                        counter += 1;
                    }

                    if (dropDownNode.ChildNodes[y].Name == "FieldID")
                    {
                        CurrentField = dropDownNode.ChildNodes[y].InnerText;
                        counter += 1;
                    }

                    if ((counter == 2) && (CurrentField == drpFrom.SelectedValue))
                    {
                        for (int j = 0; j < dropDownNode.ChildNodes.Count; j++)
                        {
                            XmlNode dropDownChildNode = (XmlNode)dropDownNode.ChildNodes[j];

                            string ListItemText = "";
                            string ExistingDepOnId = "";

                            if (dropDownChildNode.Name == "LISTITEMS")
                            {
                                XmlNodeList listItems = dropDownNode.ChildNodes[j].ChildNodes;

                                for (int l = 0; l < listItems.Count; l++)
                                {
                                    ListItemText = listItems.Item(l).InnerText;
                                    string ThisId = "";
                                    if (listItems.Item(l).Name == "LISTITEM")
                                    {
                                        ExistingDepOnId = listItems.Item(l).Attributes["DependentOn"].Value;
                                        ThisId = listItems.Item(l).Attributes["Id"].Value;
                                    }

                                    // Checking if same list item exists for same parent node.
                                    if ((ListItemText.Trim() == txtValue.Text.Trim()) && (DepOnId == ThisId))
                                    {
                                        IdToDeleteRelNodes = listItems.Item(l).Attributes["Id"].Value;
                                        //DeleteRelatedNodes(DependentControl, IdToDeleteRelNodes);
                                        //Added delete logic same as from bulk upload by koshal on 20-feb -2014
                                        string deptidon = listItems.Item(l).Attributes["DependentOn"].Value;
                                        DeleteNodes(deptidon, txtValue.Text.Trim(), drpFrom.SelectedItem.Text, controlType);
                                        doc.Save(FileName);
                                        
                                        //Response.Write("<br> deleting node..." + listItems.Item(l).Value);
                                        //dropDownNode.ChildNodes[j].RemoveChild(listItems.Item(l));
                                        //Response.Write("<br> deleted...");
                                        //doc.Save(FileName);         // Removes the listitem and save the file
                                        if (controlType != "ListBox")
                                        {
                                            // Added later after call logger was working very slow
                                            CallTypeArrayText += "Array" + (CurrentField).ToString() + "[" + ExistingDepOnId + "].splice(" + IdToDeleteRelNodes + ", 1);\n";

                                            JavaScriptTextBox.Text = CallTypeArrayText;

                                            // Registering javascript
                                            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "CallTypeArray", JavaScriptTextBox.Text, true);
                                        }
                                        break;
                                    }
                                }
                            }
                        }
                        isOver = true;  // This flag will exit the loops
                    }
                    if (isOver)
                    {
                        y = dropDownNode.ChildNodes.Count;
                        i = rootNodeList.Count;
                    }
                }
                counter = 0;
            }


            doc.Save(FileName);         // Removes the listitem and save the file
            lblSuccess.Text = "The selected option and its sub options are deleted successfully";
            SelectedValue.Value = PopulateParentIdHidden.Value;
            txtValue.Text = "";
            //**GetData();
            GetDataAfterAction();
            UpdateXmlOnceDataChanged(); // Added later, to Update XML
            CheckDependencyForOptimizingScript("");   // Added Later on 09/06/09
        }
        catch (Exception)
        {
            lblErr.Text = "Could not delete the selected option";
        }
        ClearHiddenValues();
    }



    private int DeleteNodes(string deptidon, string cvalue, string deletecontrolname, string controltype)
    {
        int remainingitemcount = 0;
        try
        {

            ReadNLoadFile();
            XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controltype);
            string SelCtrlType = SelectedControl.Value;
            //** string DepOnId = SelectedValue.Value;  commennted since had problems due to next control's item selection

            string Listid = "";
            string ExistingDepOnId = "";
            for (int i = 0; i < rootNodeList.Count; i++)
            {
                XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if ((dropDownNode.ChildNodes[y].Name == "Title") && (dropDownNode.ChildNodes[y].InnerText == deletecontrolname))
                    {
                        for (int j = 0; j < dropDownNode.ChildNodes.Count; j++)
                        {
                            XmlNode dropDownChildNode = (XmlNode)dropDownNode.ChildNodes[j];




                            if (dropDownChildNode.Name == "DependentID")
                            {
                                ExistingDepOnId = dropDownChildNode.InnerText;

                            }


                            if (dropDownChildNode.Name == "LISTITEMS")
                            {
                                XmlNode lst;
                                if (deptidon.Replace("&nbsp;", "") != "")
                                {
                                    lst = dropDownChildNode.SelectSingleNode("LISTITEM[@DependentOn=" + deptidon + " and text()='" + cvalue.Replace("&amp;", "&").Replace("&lt;", "<").Replace("&gt;", ">") + "']");
                                }
                                else
                                {
                                    lst = dropDownChildNode.SelectSingleNode("LISTITEM[text()='" + cvalue.Replace("&amp;", "&").Replace("&lt;", "<").Replace("&gt;", ">") + "']");
                                }
                                Listid = lst.Attributes["Id"].Value;
                                lst.ParentNode.RemoveChild(lst);

                                if (ExistingDepOnId != "")
                                {
                                    deletechildnode(ExistingDepOnId, Listid, controltype);
                                }
                                doc.Save(FileName);
                                if (deptidon.Replace("&nbsp;", "") != "")
                                {
                                    if (dropDownChildNode.SelectSingleNode("LISTITEM[@DependentOn=" + deptidon + "]") != null)
                                    {
                                        if (dropDownChildNode.SelectSingleNode("LISTITEM[@DependentOn=" + deptidon + "]").ChildNodes.Count != null)
                                        {
                                            remainingitemcount = dropDownChildNode.SelectSingleNode("LISTITEM[@DependentOn=" + deptidon + "]").ChildNodes.Count;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }
        return remainingitemcount;
    }

    private void deletechildnode(string deletecontrolname, string deptid,string controltype)
    {
        try
        {
            string dependcontrol = "";

            XmlNode ControlNode = doc.SelectNodes("//" + controltype + "[FieldID='" + deletecontrolname + "']")[0];

            XmlNode lstitem = ControlNode.SelectSingleNode("LISTITEMS");
            XmlNodeList lst;
            if (deptid.Replace("&nbsp;", "") != "")
            {
                lst = ControlNode.SelectNodes("LISTITEMS/LISTITEM[@DependentOn=" + deptid + "]");
                for (int i = 0; i <= lst.Count - 1; i++)
                {
                    if (ControlNode.SelectSingleNode("DependentID") != null)
                    {
                        dependcontrol = ControlNode.SelectSingleNode("DependentID").InnerText;
                        if (dependcontrol != "" && dependcontrol != null)
                        {
                            deletechildnode(dependcontrol, lst[i].Attributes["Id"].Value,controltype);
                        }
                    }
                    lstitem.RemoveChild(lst[i]);
                }
            }
            // doc.Save(FileName);
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }
    }

    protected void btnOptimize_Click(object sender, ImageClickEventArgs e)
    {
        GenerateControlInAnArray();
    }

    /// <summary>
    /// Function to get all dependent controls and call handler for generating their array.
    /// </summary>
    private void GenerateControlInAnArray()
    {
        try
        {
            ReadNLoadFile();    // Reading XML file.

            //Dependent controls loop to generate array.
            string[] DependentCtrlArray = new string[2];
            DependentCtrlArray[0] = "DropDownList";
            DependentCtrlArray[1] = "ListBox";

            foreach (string ctrl in DependentCtrlArray)
            {
                XmlNodeList rootDropDownNodeList = doc.SelectNodes("FORMS/" + ctrl);

                for (int iNodeDropDownCount = 0; iNodeDropDownCount < rootDropDownNodeList.Count; iNodeDropDownCount++)
                {
                    XmlNode CtrlNode = (XmlNode)rootDropDownNodeList[iNodeDropDownCount];

                    for (int iChildDropDownNode = 0; iChildDropDownNode < CtrlNode.ChildNodes.Count; iChildDropDownNode++)
                    {
                        string ControlType = CtrlNode.ChildNodes[iChildDropDownNode].LocalName;
                        if (ControlType == "FieldID")
                        {
                            string ControlName = CtrlNode.ChildNodes[iChildDropDownNode].InnerText;
                            GenerateData(ControlName, ctrl);
                        }
                    }
                }

                XmlNodeList rootNodeListScript = doc.SelectNodes("FORMS/DataScript");
                if (rootNodeListScript.Count == 0)
                {
                    XmlNode node = doc.CreateNode(XmlNodeType.Element, "DataScript", "");
                    XmlNode IsUpdatedNode = doc.CreateNode(XmlNodeType.Element, "IsUpdated", "");
                    XmlNode ArrayNode = doc.CreateNode(XmlNodeType.Element, "Array", "");

                    ArrayNode.InnerText = BasicArrayText;
                    IsUpdatedNode.InnerText = "True";

                    node.AppendChild(IsUpdatedNode);
                    node.AppendChild(ArrayNode);                    
                   
                    doc.DocumentElement.AppendChild(node);

                    doc.Save(FileName);         // Add the listitem and save the file
                    lblInstruction.Text= "The Data is optimized successfully";
                    btnOptimize.ImageUrl = "../Images/but_opt_n.jpg";
                    btnOptimize.Enabled = false;
                }
                else
                {
                    XmlNode DataScriptUpdateNode = (XmlNode)rootNodeListScript[0];

                    if (DataScriptUpdateNode.LastChild.Name == "Array")
                    {
                        DataScriptUpdateNode.LastChild.InnerText = BasicArrayText;

                        if (BasicArrayText != "")
                        {
                            DataScriptUpdateNode.FirstChild.InnerText = "True";
                        }
                        doc.Save(FileName);         // Add the Script and save the file
                    }

                    //***XmlNode IsUpdatedChildNode = (XmlNode)DataScriptUpdateNode.ChildNodes[0];// node <IsUpdated>
                    //***IsUpdatedChildNode.InnerText = "True123";
                    //if (DataScriptUpdateNode.LastChild.Name == "IsUpdated")
                    //{
                    //    DataScriptUpdateNode.LastChild.InnerText = "True123";
                    //    doc.Save(FileName);         // Add the Script and save the file
                    //}
                    //XmlNode ScriptChildNode = (XmlNode)DataScriptUpdateNode.ChildNodes[1];  // Node <Array>
                    //ScriptChildNode.InnerText = BasicArrayText;
                    //***doc.Save(FileName);         // Add the Script and save the file
                    btnOptimize.ImageUrl = "../Images/but_opt_n.jpg";
                    lblInstruction.Text = "The Data is optimized successfully";
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    // Function to update Xml Once Data is Changed
    private void UpdateXmlOnceDataChanged()
    {
        XmlNodeList rootNodeListScript = doc.SelectNodes("FORMS/DataScript");
        if (rootNodeListScript.Count == 0)
        {
            XmlNode node = doc.CreateNode(XmlNodeType.Element, "DataScript", "");
            XmlNode IsUpdatedNode = doc.CreateNode(XmlNodeType.Element, "IsUpdated", "");
            XmlNode ArrayNode = doc.CreateNode(XmlNodeType.Element, "Array", "");

            IsUpdatedNode.InnerText = "False";

            node.AppendChild(IsUpdatedNode);
            node.AppendChild(ArrayNode);
            doc.DocumentElement.AppendChild(node);

            doc.Save(FileName);         // Add the listitem and save the file
        }
        else
        {
            XmlNode DataScriptUpdateNode = (XmlNode)rootNodeListScript[0];
            XmlNode IsUpdatedChildNode = (XmlNode)DataScriptUpdateNode.ChildNodes[0];// node <IsUpdated>
            IsUpdatedChildNode.InnerText = "False";
            
            doc.Save(FileName);         // Add the Script and save the file
        }
    }

    /// <summary>
    /// Generate Array for dependent controls.
    /// </summary>
    /// <param name="RefObj"></param>
    /// <param name="ctrlType"></param>
    private void GenerateData(string RefObj, string ctrlType)
    {
        string PrevCtrl = "";
        string FName = "";
        string IsManageable = "";
        bool isSuccess = false;
        string DependentId = "";
        string LabelText = "";

        //** if (!TempHoldDrpNames.ToUpper().Contains(RefObj.ToUpper()))
        //**{
        TempHoldDrpNames += RefObj + ",";

        try
        {
            //**LoadXMLFile();
            //Commented by Koshal to avoid reloading of XML file
           // ReadNLoadFile();
            XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + ctrlType);
            DropDownList ddlCtrl = new DropDownList();
            ListBox lbCtrl = new ListBox();

            for (int i = 0; i < rootNodeList.Count; i++)
            {
                XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                int countElements = 0;
                PrevCtrl = "";
                FName = "";
                IsManageable = "";
                isSuccess = false;
                LabelText = "";

                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if (dropDownNode.ChildNodes[y].Name == "label")
                    {
                        LabelText = dropDownNode.ChildNodes[y].FirstChild.Value;
                    }
                    if (dropDownNode.ChildNodes[y].Name == "IsManageable")
                    {
                        IsManageable = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    if (dropDownNode.ChildNodes[y].Name == "FieldID")
                    {
                        FName = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    if (dropDownNode.ChildNodes[y].Name == "PrevRef")
                    {
                        PrevCtrl = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    if (dropDownNode.ChildNodes[y].Name == "DependentID")
                    {
                        DependentId = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }

                    if ((IsManageable == "True") && (FName == RefObj))  //&& (PrevCtrl != "")
                    {
                        if (dropDownNode.ChildNodes[y].Name == "LISTITEMS")
                        {
                            ContentPlaceHolder ControlHldr = (ContentPlaceHolder)this.Page.Master.FindControl("ContentPlaceHolder1");
                            Control ctrl;
                            ctrl = ControlHldr.FindControl(RefObj);

                            XmlNodeList listItems = dropDownNode.ChildNodes[y].ChildNodes;

                            // Creating an array. This will be used in javascript n registered via code
                            BasicArrayText += "var Array" + (FName).ToString() + " = new Array( " + listItems.Count + " );\n";

                            for (int l = 0; l < listItems.Count; l++)
                            {
                                string dependentOn = "";
                                string ListItemVal = "";
                                string ListItemText = "";
                                string TemplateID = "0";

                                ListItemText = listItems.Item(l).InnerText;
                                ListItemVal = listItems.Item(l).Attributes["Id"].Value;

                                if (listItems.Item(l).Attributes["Template"] != null && listItems.Item(l).Attributes["Template"].Value != "")
                                    TemplateID = listItems.Item(l).Attributes["Template"].Value;

                                // if ((listItems.Item(l).Attributes.Item(1).InnerText == "") || (listItems.Item(l).Attributes.Item(1).InnerText == "0"))
                                if ((listItems.Item(l).Attributes["DependentOn"].Value != "") || (listItems.Item(l).Attributes["DependentOn"].Value == "0"))
                                {
                                    dependentOn = listItems.Item(l).Attributes["DependentOn"].Value;

                                    if ((dependentOn == "") || (dependentOn == null))
                                    {
                                        dependentOn = "";
                                    }
                                    BasicArrayText += "if (Array" + (FName).ToString() + "[" + dependentOn + "] ==null) "
                                                 + "Array" + (FName).ToString() + "[" + dependentOn + "] = new Array();\n";

                                    BasicArrayText += "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "]= new Array('" + ListItemText + "');\n";


									// *** ADDED BY AARTI.. AS WRAP NOTE IS ADDED. AND DATA OPTIMIZATION SCRIPT USES THIS ARRAY - 8-Apr-2011
									string wrapNote = "";
                                    string optionTooltip = "";
                                    
									if ((listItems.Item(l).Attributes["WrapNote"] != null))
									{
										if ((listItems.Item(l).Attributes["WrapNote"].Value.Trim() != ""))
										{
                                            wrapNote = listItems.Item(l).Attributes["WrapNote"].Value.Trim().Replace("\r\n", "¢");
										}
									}

                                    if ((listItems.Item(l).Attributes["OptionTooltip"] != null))
                                    {
                                        if ((listItems.Item(l).Attributes["OptionTooltip"].Value.Trim() != ""))
                                        {
                                            optionTooltip = listItems.Item(l).Attributes["OptionTooltip"].Value.Trim();
                                        }
                                    }

                                    

									BasicArrayText += "if (Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].WN ==null) "
											 + "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].WN = '" + wrapNote + "';\n";

                                    BasicArrayText += "if (Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].OT ==null) "
                                             + "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].OT = '" + optionTooltip + "';\n";

                                    // Added T for dependent template id (Added by Koshal 13-feb-2013)
                                    BasicArrayText += "if (Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].T ==null) "
                                                     + "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].T = '" + TemplateID + "';\n";

                                    
                                }
                            }
                            cnt = cnt + 1;
                        }
                        else
                        {
                            isSuccess = false;
                        }
                    }
                    else
                    {
                        if (countElements == 4)
                        {
                            y = dropDownNode.ChildNodes.Count;
                        }
                    }
                    if (isSuccess)
                    {
                        y = dropDownNode.ChildNodes.Count;
                        i = rootNodeList.Count;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }
    }

    private void DeleteRelatedNodes(string DependentControl, string IdToDeleteRelNodes)
    {
        //   ReadNLoadFile();
        GetControlType();
        XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controlType);
        // string ExistingDepOnId = "";
        bool isOver = false;
        string ThisControl = "";
        string ThisDependentControl = "";
        int counter = 0;
        string newId = "";

        // Checking All the Sub Items of deleted Item. And Delete if exists any
        for (int i = 0; i < rootNodeList.Count; i++)
        {
            XmlNode dropDownNode = (XmlNode)rootNodeList[i];
            //To delete relevant sub options
            for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
            {
                if (dropDownNode.ChildNodes[y].Name == "FieldID")
                {
                    ThisControl = dropDownNode.ChildNodes[y].InnerText;
                    counter += 1;
                }

                if (dropDownNode.ChildNodes[y].Name == "DependentID")
                {
                    ThisDependentControl = dropDownNode.ChildNodes[y].InnerText;    // Assigning Dependent Control here
                    counter += 1;
                }

                if ((counter == 2) && (ThisControl == DependentControl))
                {
                    for (int j = 0; j < dropDownNode.ChildNodes.Count; j++)
                    {
                        XmlNode dropDownChildNode = (XmlNode)dropDownNode.ChildNodes[j];

                        string ListItemText = "";

                        if (dropDownChildNode.Name == "LISTITEMS")
                        {
                            XmlNodeList listItems = dropDownNode.ChildNodes[j].ChildNodes;

                            for (int l = 0; l < listItems.Count; l++)
                            {
                                ListItemText = listItems.Item(l).InnerText;
                                if ((listItems.Item(l).Name == "LISTITEM") && (listItems.Item(l).Attributes["DependentOn"].Value == IdToDeleteRelNodes))
                                {
                                    //ExistingDepOnId = listItems.Item(l).Attributes["DependentOn"].Value;
                                    newId = listItems.Item(l).Attributes["Id"].Value;
                                    if (ThisDependentControl != "")
                                    {
                                        DeleteRelatedNodes(ThisDependentControl, newId);
                                    }
                                    //Response.Write("<br> deleting node..." + listItems.Item(l).Value);
                                    dropDownNode.ChildNodes[j].RemoveChild(listItems.Item(l));
                                    //Response.Write("<br> deleted...");
                                    //doc.Save(FileName);         // Removes the listitem and save the file
                                    l = 0;
                                }
                            }
                        }
                    }
                    xmlDoc.Save(FileName);         // Removes the listitem and save the file
                    isOver = true;  // This flag will exit the loops
                }

                if (isOver)
                {
                    y = dropDownNode.ChildNodes.Count;
                    i = rootNodeList.Count;
                }
            }
            counter = 0;
        }
    }

    protected void drpFrom_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindControlsValues();
    }

    private void BindControlsValues()
    {
        ClearMessages();
        ClearHiddenValues();
        EnableActionButtons();
        NoOfDependentsHidden.Value = "";
        NoOfSelectedParentsHidden.Value = "";
        //GetControlType();
        GetData();
    }

    private void GetControlType()
    {
        controlType = hidSelectedControl.Value; //drpSelectControl.SelectedValue;
    }

    private void GetData()
    {
        GetControlType();

        if ((controlType == "CheckBoxList") || (controlType == "RadioButtonList"))
        {
            btnAdd.Enabled = false;
            btnDelete.Enabled = false;

            btnAdd.ImageUrl = "~/Images/but_Add_n.jpg";
            btnDelete.ImageUrl = "~/Images/but_delete_n.jpg";

            lblErr.Text = "You can only UPDATE items of RadioButton OR CheckList through this module";
        }
        // Function to check if this element has any reference / Parent control
        GetPrevRefData(drpFrom.SelectedValue,"");

        JavaScriptTextBox.Text = CallTypeArrayText;
        Session["JavaScriptTextBox"] = CallTypeArrayText;
        // Registering javascript
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "CallTypeArray", JavaScriptTextBox.Text, true);
    }

    private void GetDataAfterAction()
    {
        GetControlType();

        if ((controlType == "CheckBoxList") || (controlType == "RadioButtonList"))
        {
            btnAdd.Enabled = false;
            btnDelete.Enabled = false;

            btnAdd.ImageUrl = "~/Images/but_Add_n.jpg";
            btnDelete.ImageUrl = "~/Images/but_delete_n.jpg";

            lblErr.Text = "You can only UPDATE items of RadioButton OR CheckList through this module";
        }
        // Function to check if this element has any reference / Parent control
        GetPrevRefControls(drpFrom.SelectedValue,"");
        if (controlType != "ListBox")
        {
            JavaScriptTextBox.Text = CallTypeArrayText;
            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "CallTypeArray", JavaScriptTextBox.Text, true);
        }
    }

    private void BindTemplates()
    {
        DataSet dsTemplates = GetTemplateForms();
        if (dsTemplates != null)
        {
            ddlTemplate.DataSource = dsTemplates.Tables[0];
            ddlTemplate.DataTextField = "FormName";
            ddlTemplate.DataValueField = "FormID";
            ddlTemplate.DataBind();
            ddlTemplate.Items.Insert(0, new ListItem("--Select--",""));
        }
    }

    public void BuildTemplateControlsList()
    {
        ReadNLoadFile();
        XmlNodeList rootNodeList = doc.SelectNodes("//FORMS/DropDownList|//FORMS/ListBox");
        string DepOnId = SelectedValue.Value;
        string DepIdFromXml = SelectedDepIdFromXml.Value;

        TemplateControls = null;
        ArrayList arr = TemplateControls;

        for (int i = 0; i < rootNodeList.Count; i++)
        {
            XmlNode dropDownNode = (XmlNode)rootNodeList[i];

            XmlNode ndFieldID = dropDownNode.SelectSingleNode("FieldID");
            XmlNode ndListItems = dropDownNode.SelectSingleNode("LISTITEMS");
            XmlNode ndText = dropDownNode.SelectSingleNode("Label").SelectSingleNode("Text");

            string FieldID = "";
            string ListItemText = "";
            string controlLabel = "";

            FieldID = ndFieldID.InnerText;
            controlLabel = ndText.InnerText;

            XmlNodeList listItems = ndListItems.ChildNodes;

            for (int l = 0; l < listItems.Count; l++)
            {
                ListItemText = listItems.Item(l).InnerText;

                if (listItems.Item(l).Name == "LISTITEM")
                {
                    if (listItems.Item(l).Attributes["Template"] != null && listItems.Item(l).Attributes["Template"].Value != "")
                    {
                        arr.Add(FieldID);
                        hfTemplateControls.Value = controlLabel;
                        break;
                    }
                }
            }
            
        }

        TemplateControls = arr;
    }

    public ArrayList TemplateControls
    {
        get
        {
            ArrayList tempcontrollist;
            if (ViewState["templateControls"] == null)
            {
                tempcontrollist = new ArrayList();
            }
            else
            {
                tempcontrollist = (ArrayList)ViewState["templateControls"];
            }
            return tempcontrollist;
        }
        set
        {

            ViewState["templateControls"] = value;
        }
    }




    protected void btnUpload_Click(object sender, EventArgs e)
    {
        if (drpFrom.SelectedIndex != 0)
        {
            GoToNextForm();
            ManageSession.ControlName = drpFrom.SelectedItem.Text;
            ManageSession.ControlType = hidSelectedControl.Value;
            ManageSession.CategoryID = Convert.ToInt16(CategoryIDHidden.Value);
            Response.Redirect("../Admin/BulkUpload.aspx", true);
        }
        else
        {
            lblErr.Text = "Please select control.";
        }
    }
    protected void btnDownLoad_Click(object sender, EventArgs e)
    {
        
    }

    

}