﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using EVOLib;

public partial class Admin_RightsManagement : EvoGeneral
{
    //public string NtName;
    int MaxUsers = 0;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            // NtName = GetNTName();

            AddJavascript();
            IsValidUser();
            IsValidPageEntry(); // I WILL ENABLE IT ONCE MY CODING IS DONE

            FillGridUserRights();
            FillFilterCostCentre();
        }
    }

    private void AddJavascript()
    {
        txtUserName.Attributes.Add("onkeyup", "return CheckFieldJunkChars('" + txtUserName.ClientID + "',0)");
        txtUserName.Attributes.Add("onkeydown", "return CheckFieldJunkChars('" + txtUserName.ClientID + "',0)");
        btnSearch.Attributes.Add("onclick", "return CheckFieldJunkChars('" + txtUserName.ClientID + "',0)");
    }

    private void GetFileName()
    {
        FormIDHidden.Value = ManageSession.FormID.ToString(); //"1"; 
        VersionIDHidden.Value = ManageSession.VersionID.ToString(); //"1";
        FormNameHidden.Value = ManageSession.FormName; //"MBB Call Logger"; 
        CategoryIDHidden.Value = ManageSession.CategoryID.ToString(); //"1"; 
        GetFileNameFromDb();
    }

    private void GetFileNameFromDb()
    {
        try
        {
            DataSet ds;
            ObjUserRights.FormId = Convert.ToInt32(FormIDHidden.Value);
            ObjUserRights.VersionId = int.Parse(VersionIDHidden.Value);

            ds = ObjUserRights.GetXMLFileName();

            if (ds.Tables[0].Rows.Count > 0)
            {
                string FiName = ds.Tables[0].Rows[0]["XMLFileName"].ToString();
                ReadXMLHidden.Value = FiName;
            }
            else
            {
                lblError.Text = "Could not find the XML file";
            }
        }
        catch (Exception ex)
        {
            lblError.Text = "Could not find the XML file" + ex.Message;
        }
    }

    protected override void OnInit(EventArgs e)
    {
        if (!(Page.IsPostBack))
        {
            GetFileName();
        }
        GenerateMasterClick();
    }

    private void GenerateMasterClick()
    {
        Label lblModule = (Label)Master.FindControl("lblModule");
        lblModule.Text = "Rights Management";

        Label lblForm = (Label)Master.FindControl("lblForm");
        lblForm.Text = FormNameHidden.Value;
        ContentPlaceHolder ctPlaceHolder = (ContentPlaceHolder)Master.FindControl("head");
        ImageButton imgSel = (ImageButton)ctPlaceHolder.FindControl("img6");
        imgSel.ImageUrl = "../images/icon_5_rol.jpg";

        ImageButton imgNext = (ImageButton)ctPlaceHolder.FindControl("imgSave");    // will have to check which button to put here for next link
        imgNext.Click += new ImageClickEventHandler(Save_Click);

        ImageButton imgBtnHome = (ImageButton)ctPlaceHolder.FindControl("imgHome");
        imgBtnHome.Click += new ImageClickEventHandler(Home_Click);
    }

    EvoAdminUsersRights ObjUserRights = new EvoAdminUsersRights();

    protected void GoToNextForm()
    {
        ManageSession.FormID = int.Parse(FormIDHidden.Value);
        ManageSession.VersionID = int.Parse(VersionIDHidden.Value);
        ManageSession.FormName = FormNameHidden.Value;
        ManageSession.XmlFileName = ReadXMLHidden.Value;
        ManageSession.CategoryID = int.Parse(CategoryIDHidden.Value);
    }

    protected void Save_Click(object sender, EventArgs e)
    {
        GoToNextForm();
        Response.Redirect("../Admin/ModifyFormDetails.aspx", true);
    }

    protected void Home_Click(object sender, EventArgs e)
    {
        GoToNextForm();
        Response.Redirect("../Admin/Default.aspx", true);
    }


    // Checking if user have entered thr' proper channels. :)
    private void IsValidPageEntry()
    {
        if (FormIDHidden.Value == "0")
        {
            Response.Redirect("../AccessDenied.aspx");
        }
    }

    protected void btnSearch_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            //added to restrict Admin-user to give numeric or empty values in Name field
            if (txtUserName.Text.All(Char.IsDigit))
            {
                lblError.Text = "Numeric values or empty value are not allowed";
            }
            else
            {
                lblError.Text = "";
                lblSuccess.Text = "";

                bool IsFullyValid = true;

                drpSearchedUsers.Items.Clear();
                if ((drpFilterCostCtr.SelectedIndex <= 0) || (drpDept.SelectedIndex <= 0))
                {
                    lblError.Text = "Please select department";
                }
                else
                {
                    string[] iChars = { "_", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "+", "=", "[", "]", "\",", "'", ";", ".", "/", "{", "}", "|", "<", ">", "?", ":", "~", "`", "-", "£", "\\" };

                    for (int count = 0; count < iChars.Length; count++)
                    {
                        if (txtUserName.Text.IndexOf(iChars[count]) != -1)
                        {
                            lblError.Text += @"Special Characters are not allowed. <br>";
                            IsFullyValid = false;
                            break;
                        }
                    }

                    if (IsFullyValid)
                    {
                        ObjUserRights.CostCentreId = int.Parse(drpFilterCostCtr.SelectedValue);
                        ObjUserRights.DepartmentId = int.Parse(drpDept.SelectedValue);
                        DataSet ds = ObjUserRights.GetFilteredUserName(txtUserName.Text.Trim().Replace("'", "''"));
                        if (ds.Tables[0].Rows.Count > 0)
                        {
                            drpSearchedUsers.DataSource = ds.Tables[0];
                            drpSearchedUsers.DataTextField = "UserName";
                            drpSearchedUsers.DataValueField = "EmpUserId";
                            drpSearchedUsers.DataBind();
                        }
                        //ListItem lst = new ListItem("-- Select --", "0");
                        //drpSearchedUsers.Items.Insert(0, lst);
                    }
                }
            }

        }
        catch (Exception ex)
        {
            throw;
        }
    }

    // Checking if the user is valid and have rights to manage the form or no.
    private void IsValidUser()
    {
        try
        {
            Boolean IsValid = false;
            ObjUserRights.VersionId = int.Parse(VersionIDHidden.Value);
            ObjUserRights.UserID = RetrieveUserID(userName);
            ObjUserRights.FormId = int.Parse(FormIDHidden.Value);

            IsValid = ObjUserRights.ValidateAdminManageUser();

            if (!IsValid)
            {
                Response.Write("Redirecting to access denied");
                //Response.Redirect("../AccessDenied.aspx");
            }
        }
        catch (Exception ex)
        {
            lblError.Text = "No data found for this login" + ex.Message;
        }
    }

    // Function to add a 
    protected void btnAdd_Click(Object sender, ImageClickEventArgs e)
    {
        try
        {
            lblSuccess.Text = "";
            lblError.Text = "";

            gvUsersRights.EditIndex = -1;

            if ((chkAllowEditForm.Checked == false) && !(chkReportLimerick.Checked) && !(chkReportWaterford.Checked) && !(chkReportMumbai.Checked))
            {
                lblError.Text = "You cannnot assign blank rights. Please assign rights either to 'Edit Form' or 'Reports'.";
            }
            else
            {
                string userids = "";
                int count = 0;
                for (int i = 0; i <= drpSearchedUsers.Items.Count - 1; i++)
                {
                    if (drpSearchedUsers.Items[i].Selected == true)
                    {
                        if (userids == "")
                        {
                            userids = drpSearchedUsers.Items[i].Value;
                        }
                        else
                        {
                            userids = userids + "," + drpSearchedUsers.Items[i].Value;
                        }
                        count++;
                    }
                }

                if (count <= 5)
                {
                    ObjUserRights.UserLogin = userName;
                    ObjUserRights.CanManage = chkAllowEditForm.Checked;
                    //  ObjUserRights.IsReportsAccess = chkAllowReports.Checked;
                    ObjUserRights.IsLimerickReportsAccess = chkReportLimerick.Checked;
                    ObjUserRights.IsWaterfordReportsAccess = chkReportWaterford.Checked;
                    ObjUserRights.IsMumbaiReportsAccess = chkReportMumbai.Checked;
                    ObjUserRights.UserIDs = userids;
                    ObjUserRights.FormId = Convert.ToInt32(FormIDHidden.Value);
                    ObjUserRights.VersionId = Convert.ToInt32(VersionIDHidden.Value);

                    int retVal = ObjUserRights.InsertUserAccessRights();

                    if (retVal == 2)
                    {
                        lblError.Text = "User(s) Already exists as a Super Admin.";
                    }
                    else if (retVal == 3)
                    {
                        lblError.Text = "User(s) Already exists as a Sub Admin for this form.";
                    }
                    else if (retVal == 1)
                    {
                        lblSuccess.Text = "The User(s) has been Added successfully as a Sub Admin for this form.";
                    }
                    else if (retVal == 4)
                    {
                        lblError.Text = "User(s) Already exists as an Admin.";
                    }
                }
                else
                {
                    lblError.Text = "Admin can delegate administrator rights to a maximum of 5 other User(s).";
                }

                //if (ObjUserRights.InsertUserAccessRights())
                //{
                //    lblSuccess.Text = "The record has been Added successfully.";
                //}
                //else
                //{
                //    lblError.Text = "Record Already exists as a Super Admin or Admin for this form.";
                //}
                FillGridUserRights();
            }
        }
        catch (Exception ex)
        {
            lblError.Text = "Could not Add record." + ex.Message;
        }

        chkAllowReports.Checked = false;
        chkAllowEditForm.Checked = false;
        drpSearchedUsers.ClearSelection();
        chkReportLimerick.Checked = false;
        chkReportMumbai.Checked = false;
        chkReportWaterford.Checked = false;
        //txtUserName.Text = "";
        //drpSearchedUsers.Items.Clear();

    }

    private void FillFilterCostCentre()
    {
        try
        {
            DataSet ds;
            ds = ObjUserRights.GetCostCentres();
            if (ds.Tables[0].Rows.Count > 0)
            {
                drpFilterCostCtr.DataSource = ds.Tables[0];
                drpFilterCostCtr.DataValueField = "CostCentreID";
                drpFilterCostCtr.DataTextField = "CostCentre";
                drpFilterCostCtr.DataBind();
            }
            ListItem lst = new ListItem("-- Select --", "0");
            drpFilterCostCtr.Items.Insert(0, lst);
        }
        catch (Exception ex)
        {
            lblError.Text = "Could not fill cost centres " + ex.Message;
        }
    }

    protected void drpDept_SelectedIndexChanged(object sender, EventArgs e)
    {
        ClearUsersList();
    }

    private void ClearUsersList()
    {
        txtUserName.Text = "";
        drpSearchedUsers.Items.Clear();
    }

    protected void drpFilterCostCtr_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            drpDept.Items.Clear();
            ClearUsersList();

            int selCostCentreId = int.Parse(drpFilterCostCtr.SelectedValue);
            if (selCostCentreId > 0)
            {
                DataSet ds;

                ObjUserRights.CostCentreId = selCostCentreId;
                ds = ObjUserRights.GetCostCentresDepartments();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    drpDept.DataSource = ds.Tables[0];
                    drpDept.DataValueField = "DepartmentID";
                    drpDept.DataTextField = "DepartmentName";
                    drpDept.DataBind();
                }
                ListItem lst = new ListItem("-- Select --", "0");
                drpDept.Items.Insert(0, lst);
            }
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    /// <summary>
    /// Function to retrieve Max Admin Users Per Form
    /// </summary>
    /// <returns></returns>
    private int GetMaxAdminUsers()
    {
        try
        {
            DataSet ds = ObjUserRights.GetMaxUsersPerForm();
            if (ds.Tables[0].Rows.Count > 0)
            {
                MaxUsers = Convert.ToInt32(ds.Tables[0].Rows[0]["value"].ToString());
            }
        }
        catch (Exception)
        {
            throw;
        }
        return MaxUsers;
    }


    //  Fills the gridview with all users having rights for particular form and version
    private void FillGridUserRights()
    {
        try
        {
            gvUsersRights.DataSource = null;
            gvUsersRights.DataBind();

            DataSet ds;
            ObjUserRights.FormId = int.Parse(FormIDHidden.Value);
            ObjUserRights.VersionId = int.Parse(VersionIDHidden.Value);
            ds = ObjUserRights.GetUsersRights();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvUsersRights.DataSource = ds.Tables[0];
                gvUsersRights.DataBind();
            }
            if (ds.Tables[0].Rows.Count >= GetMaxAdminUsers())
            {
                lblError.Text = "You can have max " + GetMaxAdminUsers() + " sub-admin users. To add more, you will have to delete one of the existing sub-admin users";
                btnAdd.Enabled = false;
                btnAdd.ImageUrl = "../images/but_add_n.jpg";
            }
            else if (ds.Tables[0].Rows.Count < GetMaxAdminUsers())
            {
                btnAdd.Enabled = true;
                btnAdd.ImageUrl = "../images/but_add.jpg";
            }
        }
        catch (Exception ex)
        {
            lblError.Text = ex.Message;
        }
    }

    protected void gvUsersRights_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        gvUsersRights.EditIndex = -1;
        FillGridUserRights();
    }

    protected void gvUsersRights_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvUsersRights.EditIndex = e.NewEditIndex;
        FillGridUserRights();
    }

    protected void gvUsersRights_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            lblError.Text = "";
            lblSuccess.Text = "";
            int i = e.RowIndex;
            Label lblId = (Label)gvUsersRights.Rows[i].Cells[0].FindControl("lblAccessRightId");
            int AccessRightId = int.Parse(lblId.Text);

            ObjUserRights.IsActive = false;
            ObjUserRights.AccessRightId = AccessRightId;
            if (ObjUserRights.DeleteUserAccessRights())
            {
                gvUsersRights.EditIndex = -1;
                FillGridUserRights();
                lblSuccess.Text = "The record has been deleted successfully";
            }
            else
            {
                lblError.Text = "Could not delete record";
            }
        }
        catch (Exception ex)
        {
            lblError.Text = "Could not delete record" + ex.Message;
        }
    }

    protected void gvUsersRights_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            lblSuccess.Text = "";
            lblError.Text = "";

            int i = e.RowIndex;
            Label lblId = (Label)gvUsersRights.Rows[i].Cells[0].FindControl("lblAccessRightId");
            int AccessRightId = int.Parse(lblId.Text);
            CheckBox ChkEdit = (CheckBox)gvUsersRights.Rows[i].Cells[1].FindControl("chkEditForm");
            // CheckBox ChkRep = (CheckBox)gvUsersRights.Rows[i].Cells[2].FindControl("chkReports");
            CheckBox ChkRepLimerick = (CheckBox)gvUsersRights.Rows[i].Cells[2].FindControl("chkReportsLimerick");
            CheckBox ChkRepWaterford = (CheckBox)gvUsersRights.Rows[i].Cells[2].FindControl("chkReportsWaterford");
            CheckBox ChkRepMumbai = (CheckBox)gvUsersRights.Rows[i].Cells[2].FindControl("chkReportsMumbai");
            //if ((ChkEdit.Checked == false) && (ChkRep.Checked == false) && !(ChkRepLimerick.Checked) && !(ChkRepWaterford.Checked) && !(ChkRepMumbai.Checked))
            if ((ChkEdit.Checked == false) && !(ChkRepLimerick.Checked) && !(ChkRepWaterford.Checked) && !(ChkRepMumbai.Checked))
            {
                lblError.Text = "You cannnot assign blank rights. Please assign rights either to 'Edit Form' or 'Reports'.";
            }
            else
            {
                ObjUserRights.CanManage = ChkEdit.Checked;
                // ObjUserRights.IsReportsAccess = ChkRep.Checked;
                ObjUserRights.IsLimerickReportsAccess = ChkRepLimerick.Checked;
                ObjUserRights.IsWaterfordReportsAccess = ChkRepWaterford.Checked;
                ObjUserRights.IsMumbaiReportsAccess = ChkRepMumbai.Checked;
                ObjUserRights.AccessRightId = AccessRightId;

                if (ObjUserRights.UpdateUserAccessRights())
                {
                    gvUsersRights.EditIndex = -1;
                    FillGridUserRights();
                    lblSuccess.Text = "The record has been updated successfully";
                }
                else
                {
                    lblError.Text = "Could not Update data ";
                }
            }
        }
        catch (Exception ex)
        {
            lblError.Text = "Could not Update data " + ex.Message;

        }
    }
    protected void chkAllowReports_CheckedChanged(object sender, EventArgs e)
    {
        if (chkAllowReports.Checked)
        {
            chkReportLimerick.Checked = true;
            chkReportWaterford.Checked = true;
            chkReportMumbai.Checked = true;
        }
        else
        {
            chkReportLimerick.Checked = false;
            chkReportWaterford.Checked = false;
            chkReportMumbai.Checked = false;
        }


    }
}