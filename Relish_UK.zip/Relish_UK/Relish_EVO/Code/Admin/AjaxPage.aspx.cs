﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Linq;
using System.Data;
using EVOLib;
public partial class Admin_AjaxPage : System.Web.UI.Page
{
    XmlDocument doc;
    XDocument xmlDoc = new XDocument();
    string FileName;
    string BasicArrayText = "";
    string TempHoldDrpNames = "";
    int frmID;
    string frmName;
    string catId;
    string vId;
    string fMode;
    int NoOfDependents = 0;
    EvoAdminUsersRights ObjUserRights = new EvoAdminUsersRights();
    protected void Page_Load(object sender, EventArgs e)
    {
        ReadNLoadFile();
      var list = from c in xmlDoc.Descendants("LISTITEMS")
                 where c.Element("LISTITEMS").Value  == Request.QueryString["setValue"].ToString() &&
                  c.Element("LISTITEMS").Attribute("Id").Value == Request.QueryString["id"].ToString()  
                 select c;
    }
    private void ReadNLoadFile()
    {
        
        FileName = Server.MapPath("..\\XML\\" + Session["FileName"].ToString());
        doc = new XmlDocument();
        xmlDoc = XDocument.Load(FileName);
        doc.Load(FileName);

    }
    private void GetFileName()
    {
        frmID = ManageSession.FormID;
        frmName = ManageSession.FormName;
        string[] fName = frmName.Split('_');
        frmName = fName[0];
        catId = ManageSession.CategoryID.ToString();
        vId = ManageSession.VersionID.ToString();
        fMode = ManageSession.FormMode.ToString();
        
        GetFileNameFromDb();    // To retrieve XML filename from DB.
    }
    private void GetFileNameFromDb()
    {
        try
        {
            DataSet ds;
            ObjUserRights.FormId = frmID;
            ObjUserRights.VersionId = int.Parse(vId);

            ds = ObjUserRights.GetXMLFileName();

            if (ds.Tables[0].Rows.Count > 0)
            {
                string FiName = ds.Tables[0].Rows[0]["XMLFileName"].ToString();
                FileName = FiName;
            }
            else
            {
               
            }
        }
        catch (Exception ex)
        {
            
        }
    }
}
