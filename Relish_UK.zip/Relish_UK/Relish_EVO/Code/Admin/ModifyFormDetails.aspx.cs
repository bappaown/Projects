﻿using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using EVOLib;
using System.Text.RegularExpressions;

public partial class Admin_ModifyFormDetails : EvoGeneral
{
    Forms objForms = new Forms();
    Reports objReports = new Reports();
    DataSet EmpDataSet = new DataSet();
    EvoGeneral objEvoGeneral = new EvoGeneral();
    EvoMain objEvoMain = new EvoMain();
    #region Page and Button Events

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // IsValidUser();
            // IsValidUser();

            AddAttributes();
            BindMainFormGrid();
            GetFileName();
        }
    }

    private void AddAttributes()
    {
        StDateTextBox.Attributes.Add("onClick", "javascript:ShowCalendar(this,1900,2030,'dd/mmm/yyyy');");
        EdDateTextBox.Attributes.Add("onClick", "javascript:ShowCalendar(this,1900,2030,'dd/mmm/yyyy');");

        string stDate = StDateTextBox.ClientID.ToString();
        string edDate = EdDateTextBox.ClientID.ToString();
        StartDateImage.Attributes.Add("onClick", "javascript:ShowCalendar(" + stDate + ",1900,2030,'dd/mmm/yyyy');");
        EndDateImageButton.Attributes.Add("onClick", "javascript:ShowCalendar(" + edDate + ",1900,2030,'dd/mmm/yyyy');");
    }

    private void GetFileName()
    {
        ContentPlaceHolder ctPlaceHolder = (ContentPlaceHolder)Master.FindControl("head");
        Label lblModule = (Label)Master.FindControl("lblModule");
        lblModule.Text = " ";
        lblModule.CssClass = "heading";

        //to hide submit button : Bappa
        ImageButton imgSave = (ImageButton)ctPlaceHolder.FindControl("imgSave");
        imgSave.Visible = false;
        var divNumbers = ctPlaceHolder.FindControl("divNumbers");
        if (divNumbers != null)
            divNumbers.Visible = false;
        var div1 = ctPlaceHolder.FindControl("div1");
        if (div1 != null)
            div1.Visible = false;

        Label lblForm = (Label)Master.FindControl("lblForm");
        lblForm.Text = "Modify Form";

    }

    // Checking if the user is valid and have rights to manage the form or no.
    //private void IsValidUser()
    //{
    //    try
    //    {
    //        Boolean IsValid = false;
    //        EvoAdminUsersRights ObjUserRights = new EvoAdminUsersRights();
    //        ObjUserRights.VersionId = int.Parse(VersionIDHidden.Value);
    //        ObjUserRights.UserID = RetrieveUserID(userName);
    //        ObjUserRights.FormId = int.Parse(FormIDHidden.Value);

    //        IsValid = ObjUserRights.ValidateAdminManageUser();

    //        if (!IsValid)
    //        {
    //            //Response.Write("Redirecting to access denied");
    //            Response.Redirect("../AccessDenied.aspx", true);
    //        }
    //    }
    //    catch (Exception ex)
    //    {
    //        //lblErr.Text = "No data found for this login" + ex.Message;
    //    }
    //}

    protected void SearchButton_Click(object sender, EventArgs e)
    {
        try
        {
            DataSet objDataSet = new DataSet();
            // objDataSet = (DataSet)ViewState["FormsDataSet"];
            EmpDataSet = RetrieveEmployeeDetails(userName);
            if (EmpDataSet.Tables[0].Rows.Count > 0)
            {
                int EmpUserID = Convert.ToInt32(EmpDataSet.Tables[0].Rows[0]["EmpUserID"]);
                objReports.UserID = EmpUserID;
                objReports.FormID = 0;
                objReports.Module = "ModifyForm";
                objReports.EmpName = txtemp.Text;
                if (StDateTextBox.Value != "")
                {
                    objReports.StDate = Convert.ToDateTime(StDateTextBox.Value).ToString("dd-MMM-yyyy 00:00:00");
                    objReports.EndDate = Convert.ToDateTime(EdDateTextBox.Value).ToString("dd-MMM-yyyy 23:59:59");
                }
                objDataSet = objReports.GetFormsForReports(objDataSet, "0");
            }

            if (TitleTextBox.Text != "")
            {
                string FormName = TitleTextBox.Text;

                Regex.Replace(FormName, "'", "");

                objDataSet.Tables[0].DefaultView.RowFilter = "FormName Like '%" + FormName + "%'";
                if (objDataSet.Tables[0].DefaultView.Count > 0)
                {
                    MainFormGridView.DataSource = objDataSet.Tables[0].DefaultView;
                    MainFormGridView.DataBind();
                    MainFormGridView.Style.Add("display", "block");
                    FormNameLabel.Text = "";
                    FormVersionsGridView.Style.Add("display", "none");
                    ErrorLabel.Text = "";
                }
                else
                {
                    ErrorLabel.Text = "No Records Found.";
                    MainFormGridView.Style.Add("display", "none");
                    FormNameLabel.Text = "";
                    FormVersionsGridView.Style.Add("display", "none");
                }
            }
            else
            {
                if (objDataSet.Tables[0].Rows.Count > 0)
                {
                    MainFormGridView.DataSource = objDataSet;
                    MainFormGridView.DataBind();
                    MainFormGridView.Style.Add("display", "block");
                    FormNameLabel.Text = "";
                    FormVersionsGridView.Style.Add("display", "none");
                    ErrorLabel.Text = "";
                }
                else
                {
                    ErrorLabel.Text = "No Records Found.";
                    MainFormGridView.Style.Add("display", "none");
                    FormNameLabel.Text = "";
                    FormVersionsGridView.Style.Add("display", "none");
                }
            }
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message.ToString();
        }
    }
    #endregion



    #region Main Form GridView Event Handlers and Functions
    public void BindMainFormGrid()
    {
        try
        {
            EmpDataSet = RetrieveEmployeeDetails(userName);
            if (EmpDataSet.Tables[0].Rows.Count > 0)
            {
                DataSet objDataSet = new DataSet();
                int EmpUserID = Convert.ToInt32(EmpDataSet.Tables[0].Rows[0]["EmpUserID"]);
                objReports.UserID = EmpUserID;
                objReports.FormID = 0;
                objReports.Module = "ModifyForm";
                objReports.EmpName = txtemp.Text;
                if (StDateTextBox.Value != "")
                {
                    objReports.StDate = Convert.ToDateTime(StDateTextBox.Value).ToString("dd-MMM-yyyy 00:00:00");
                    objReports.EndDate = Convert.ToDateTime(EdDateTextBox.Value).ToString("dd-MMM-yyyy 23:59:59");
                }
                objDataSet = objReports.GetFormsForReports(objDataSet, "0");
                ViewState["FormsDataSet"] = objDataSet;
                MainFormGridView.DataSource = objDataSet;
                MainFormGridView.DataBind();
            }
            else
            {
                Response.Redirect("../AccessDenied.aspx", true);
            }
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message.ToString();
        }
    }


    protected void MainFormGridView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "CmdEdit")
        {
            int formID = Convert.ToInt32(e.CommandArgument);
            if (formID >= 0)
            {
                FormIDHidden.Value = formID.ToString();
                BindFormVersionGrid(formID);
                FormVersionsGridView.Style.Add("display", "block");
            }

        }
        if (e.CommandName == "CmdDeActive")
        {
            int formID = Convert.ToInt32(e.CommandArgument);
            if (formID >= 0)
            {
                FormIDHidden.Value = formID.ToString();
                Reports objrpt = new Reports();
                objrpt.UpdateFormStatus(Convert.ToInt16(FormIDHidden.Value), userName);
                BindMainFormGrid();
            }
        }
    }

    protected void BindFormVersionGrid(int formID)
    {

        EmpDataSet = RetrieveEmployeeDetails(userName);
        if (EmpDataSet.Tables[0].Rows.Count > 0)
        {
            DataSet objDataSet = new DataSet();
            objDataSet = (DataSet)ViewState["FormsDataSet"];
            int EmpUserID = Convert.ToInt32(EmpDataSet.Tables[0].Rows[0]["EmpUserID"]);
            objReports.UserID = EmpUserID;
            objReports.FormID = formID;
            objReports.Module = "ModifyFormVersions";
            objDataSet = objReports.GetFormsForReports(objDataSet, "0");
            ViewState["FormsDataSet"] = objDataSet;
            FormNameLabel.Text = objDataSet.Tables[0].Rows[0]["FormName"].ToString();
            FormIDHidden.Value = objDataSet.Tables[0].Rows[0]["FormID"].ToString();
            FormVersionsGridView.DataSource = objDataSet;
            FormVersionsGridView.DataBind();
        }
        else
        {
            Response.Redirect("../AccessDenied.aspx", true);
        }


    }
    #endregion



    #region Form Versions GridView Event Handlers


    protected void FormVersionsGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[15].Visible = false;
        }
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            string chkchecked = e.Row.Cells[15].Text;
            CheckBox chkbox = (CheckBox)e.Row.Cells[12].FindControl("chkscrabblepad");
            if (chkchecked == "True")
            {
                chkbox.Checked = true;
            }
            else
            {
                chkbox.Checked = false;
            }
            e.Row.Cells[15].Visible = false;

            //Index have been changed from Cells[11] to Cells[12] because Preview is incorporated. Imran
            if (e.Row.Cells[4].Text.ToString() == "True")
            {
                e.Row.Cells[4].Text = "Active";
                LinkButton actButton = (LinkButton)e.Row.Cells[13].FindControl("ActivateButton");
                actButton.OnClientClick = "javascript:alert('This form is already active.');return false;";
                actButton.Text = "Activated";
                actButton.Style.Add("text-decoration", "none");
                actButton.Style.Add("forecolor", "black");
            }
            if (e.Row.Cells[4].Text.ToString() == "False")
            {
                e.Row.Cells[4].Text = "InActive";
                LinkButton actButton = (LinkButton)e.Row.Cells[13].FindControl("ActivateButton");
                actButton.OnClientClick = "javascript:return confirm('Are you sure you want to ACTIVATE this version?');";
                actButton.Text = "Activate";
            }
            if (e.Row.Cells[0].Text.ToString() == "No Version")
            {
                e.Row.Cells[4].Text = "InActive";
                LinkButton actButton = (LinkButton)e.Row.Cells[13].FindControl("ActivateButton");
                actButton.OnClientClick = "javascript:alert('This form cannot be activated. Please create a version.');return false;";
                actButton.Text = "Activate";
                actButton.Style.Add("text-decoration", "none");
                actButton.Style.Add("forecolor", "black");

                ImageButton dataButton = (ImageButton)e.Row.Cells[9].FindControl("DataButton");
                dataButton.Enabled = false;
                dataButton.ToolTip = "No version found.Please create a version.";

                //Np preview if versiom is not created. Imran
                ImageButton previewButton = (ImageButton)e.Row.Cells[11].FindControl("PreviewButton");
                previewButton.OnClientClick = "javascript:alert('Preview not available. Please create a version.');return false;";
            }
        }
    }

    protected void FormVersionsGridView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        EvoMain objGeneral = new EvoMain();

        int formID = Convert.ToInt32(FormIDHidden.Value.ToString());
        string formDesc = "";
        int categoryID = 0;
        string formName = "";
        int activeFormVersionID = 0;
        int versionID = Convert.ToInt32(e.CommandArgument.ToString());
        string xmlFileName = "";

        DataSet objDataSet = new DataSet();
        objDataSet = (DataSet)ViewState["FormsDataSet"];

        for (int rowCount = 0; rowCount < objDataSet.Tables[0].Rows.Count; rowCount++)
        {
            if (Convert.ToInt32(objDataSet.Tables[0].Rows[rowCount]["VersionID"].ToString()) == versionID)
            {
                formDesc = objDataSet.Tables[0].Rows[rowCount]["FormDesc"].ToString();
                categoryID = Convert.ToInt32(objDataSet.Tables[0].Rows[rowCount]["CategoryID"].ToString());
                formName = objDataSet.Tables[0].Rows[rowCount]["FormName"].ToString();

                //xml file name to be carried forward to preview. Imran
                xmlFileName = objDataSet.Tables[0].Rows[rowCount]["XMLFileName"].ToString();
            }
        }

        if (formID != null)
        {
            if (e.CommandName == "CmdDetails")
            {
                ManageSession.FormID = formID;
                ManageSession.VersionID = versionID;
                ManageSession.FormName = formName;
                ManageSession.FormMode = "EDITMODE";
                ManageSession.CategoryID = categoryID;
                //TBC To be collected from altered SP;
                Response.Redirect("../Admin/AdminFormDetails.aspx", true);
            }
            if (e.CommandName == "CmdDesign")
            {

                ManageSession.FormID = formID;
                ManageSession.VersionID = versionID;
                ManageSession.FormName = formName;
                ManageSession.FormMode = "EDITMODE";
                ManageSession.CategoryID = categoryID;

                Response.Redirect("../Admin/DesignManagement.aspx", true);
            }
            if (e.CommandName == "CmdData")
            {
                ManageSession.FormID = formID;
                ManageSession.VersionID = versionID;
                ManageSession.FormName = formName;
                ManageSession.FormMode = "EDITMODE";
                ManageSession.CategoryID = categoryID;

                Response.Redirect("../Admin/DataManagement.aspx", true);
            }
            if (e.CommandName == "CmdControl")
            {
                ManageSession.FormID = formID;
                ManageSession.VersionID = versionID;
                ManageSession.FormName = formName;
                ManageSession.FormMode = "EDITMODE";
                ManageSession.CategoryID = categoryID;

                Response.Redirect("../Admin/ControlManagement.aspx", true);
            }
            if (e.CommandName == "CmdRights")
            {
                ManageSession.FormID = formID;
                ManageSession.VersionID = versionID;
                ManageSession.FormName = formName;
                ManageSession.FormMode = "EDITMODE";
                ManageSession.CategoryID = categoryID;

                Response.Redirect("../Admin/RightsManagement.aspx", true);
            }
            if (e.CommandName == "CmdDuplicate")
            {
                ManageSession.FormID = formID;
                ManageSession.VersionID = versionID;
                ManageSession.FormName = formName;
                ManageSession.FormMode = "EDITMODE";
                ManageSession.CategoryID = categoryID;
            }

            //Details to be carried forward to Preview. Imran
            if (e.CommandName == "CmdPreview")
            {
                ManageSession.FormID = formID;
                ManageSession.VersionID = versionID;
                ManageSession.FormName = formName;
                ManageSession.XmlFileName = xmlFileName;

                ScriptManager.RegisterStartupScript(this, this.GetType(), "Preview", "<script language='javascript'>PreviewPage();</script>", false);
            }
            if (e.CommandName == "CmdScrabblePad")
            {
                string test = versionID.ToString();
            }

            if (e.CommandName == "CmdActivate")
            {
                objGeneral.ActivateFormVersion(versionID, userName);
                for (int rowCount = 0; rowCount < objDataSet.Tables[0].Rows.Count; rowCount++)
                {
                    if (objDataSet.Tables[0].Rows[rowCount]["Status"].ToString() == "True" && Convert.ToInt32(objDataSet.Tables[0].Rows[rowCount]["VersionID"].ToString()) != versionID)
                    {
                        activeFormVersionID = Convert.ToInt32(objDataSet.Tables[0].Rows[rowCount]["VersionID"].ToString());

                        objGeneral.DeActivateFormVersion(activeFormVersionID, userName);

                    }
                }
                BindFormVersionGrid(formID);
            }
        }
    }



    #endregion


    protected void MainFormGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        MainFormGridView.PageIndex = e.NewPageIndex;
        BindMainFormGrid();
    }

    protected void FormVersionsGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        FormVersionsGridView.PageIndex = e.NewPageIndex;
        BindFormVersionGrid(Convert.ToInt32(FormIDHidden.Value));
    }
    protected void chkmyform_CheckedChanged(object sender, EventArgs e)
    {
        if (chkmyform.Checked == true)
        {
            txtemp.Text = userName;
            txtemp.Enabled = false;
        }
        else
        {
            txtemp.Text = "";
            txtemp.Enabled = true;
        }
    }

    protected void btnreset_Click(object sender, EventArgs e)
    {
        clearfrom();
    }

    public void clearfrom()
    {
        txtemp.Text = "";
        txtemp.Enabled = true;
        TitleTextBox.Text = "";
        StDateTextBox.Value = "";
        EdDateTextBox.Value = "";
        chkmyform.Checked = false;
        BindMainFormGrid();
        FormNameLabel.Text = "";
        FormVersionsGridView.DataSource = null;
        FormVersionsGridView.DataBind();
        MainFormGridView.Style.Add("display", "block");
        FormNameLabel.Text = "";
        FormVersionsGridView.Style.Add("display", "none");
        ErrorLabel.Text = "";
    }

    protected void MainFormGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            //Index have been changed from Cells[11] to Cells[12] because Preview is incorporated. Imran
            Label lblIsActive = (Label)e.Row.Cells[7].FindControl("lblIsActive");
            if (lblIsActive.Text.ToLower() == "false")
            {
                LinkButton actButton = (LinkButton)e.Row.Cells[8].FindControl("DeActiveButton");
                actButton.Text = "Active";
                LinkButton editButton = (LinkButton)e.Row.Cells[8].FindControl("EditButton");
                editButton.Enabled = false;
            }
            else if (e.Row.Cells[7].Text.ToLower() == "true")
            {
                LinkButton actButton = (LinkButton)e.Row.Cells[8].FindControl("DeActiveButton");
                actButton.Text = "DeActive";
                LinkButton editButton = (LinkButton)e.Row.Cells[8].FindControl("EditButton");
                editButton.Enabled = true;
            }
            FormNameLabel.Text = "";
            FormVersionsGridView.DataSource = null;
            FormVersionsGridView.DataBind();
        }
    }

    protected void chkscrabblepad_CheckedChanged(object sender, EventArgs e)
    {
        int formID = Convert.ToInt32(FormIDHidden.Value.ToString());
        CheckBox checkbox = (CheckBox)sender;
        GridViewRow row = (GridViewRow)checkbox.NamingContainer;
        int versionID = (int)FormVersionsGridView.DataKeys[row.DataItemIndex].Value;
        string IsScrabblePad = "";
        if (checkbox.Checked == true)
        {
            IsScrabblePad = "True";
        }
        else
        {
            IsScrabblePad = "False";
        }
        EvoMain objGeneral = new EvoMain();
        objGeneral.UpdateIsSrabblePad(versionID, userName, IsScrabblePad);
        BindFormVersionGrid(formID);
    }
}
