﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

public partial class Admin_LinqGetData : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!(Page.IsPostBack))
        {
            string DependentOnId = Request["SelectedId"];
            string controlId = Request["NextControl"];
            string FileName = Request["FileName"];

            string fileName = Server.MapPath("..\\XML\\" + FileName);
            XDocument xmlDoc = XDocument.Load(fileName);

            string PrevRefControl = "";
            string DependentControl = "";

            DataSet dsDataItem = new DataSet();
            
            dsDataItem.Tables.Add();
            dsDataItem.Tables.Add();

            DataTable dtMainData = new DataTable();

            var q = from c in xmlDoc.Descendants("ListBox")
                    where c.Element("FieldID").Value == controlId
                    select new
                    {
                        PreviousRef = c.Element("PrevRef"),
                        DependentID = c.Element("DependentID"),
                        ListOfItems = from items in c.Element("LISTITEMS").Descendants("LISTITEM")
                                      where items.Attribute("DependentOn").Value == DependentOnId
                                      select items
                    };
           
                foreach (var obj in q)
                {
                    PrevRefControl = obj.PreviousRef.Value;
                    DependentControl = obj.DependentID.Value;

                    var ListItems = obj.ListOfItems;

                    dsDataItem.Tables[0].Columns.Add("ListItemId");
                    dsDataItem.Tables[0].Columns.Add("ListItemValue");

                    foreach (var ele in ListItems)
                    {
                        DataRow drNew = dsDataItem.Tables[0].NewRow();
						string wrapNoteValue;
						if (ele.Attribute("WrapNote") == null)
									wrapNoteValue = "";
								else
									wrapNoteValue = ele.Attribute("WrapNote").Value;

                        string optionTooltip;
                        if (ele.Attribute("OptionTooltip") == null)
                            optionTooltip = "";
                        else
                            optionTooltip = ele.Attribute("OptionTooltip").Value;

                        string template;
                        if (ele.Attribute("Template") == null)
                            template = "";
                        else
                            template = ele.Attribute("Template").Value;


                        drNew["ListItemId"] = ele.Attribute("Id").Value + "," + ele.Value + "," + ele.Attribute("DependentOn").Value + "," + wrapNoteValue + "," + optionTooltip + "," + template;
                        drNew["ListItemValue"] = ele.Value;
                        dsDataItem.Tables[0].Rows.Add(drNew);
                    }
                }

            Response.Clear();
            Response.ContentType = "text/xml";
            Response.Write(dsDataItem.GetXml());
            dsDataItem.Clear();
            dsDataItem.Dispose();
            xmlDoc = null;
            Response.End();
        }
    }
}
