using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using EVOLib;

public partial class Admin_Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        //Windows Authentication : Bappa 
        if (!IsPostBack)
        {
            if (HttpContext.Current.Request.Cookies["EVO"] == null)
            {
                DataSet dsAuthTypes = UserAuthDataStore.GetAuthenticationTypes();
                if (dsAuthTypes != null && dsAuthTypes.Tables.Count > 0)
                {
                    if (Convert.ToInt32(dsAuthTypes.Tables[0].Rows[0]["Id"]) == 2) // CEAG
                    {
                        H3GS.Web.Security.PassportAuthentication.SignIn();
                        HttpCookie userCredentials = new HttpCookie("EVO");
                        userCredentials["AuthenticationType"] = dsAuthTypes.Tables[0].Rows[0]["Id"].ToString();
                        userCredentials["CurrentUserName"] = H3GS.Web.Security.PassportIdentity.Current.Employee.LoginId;
                        userCredentials["userName"] = H3GS.Web.Security.PassportIdentity.Current.Employee.LoginId;
                        userCredentials["userType"] = "";
                        userCredentials["userEmailID"] = H3GS.Web.Security.PassportIdentity.Current.Employee.EmailAddress;
                        userCredentials["userFullName"] = H3GS.Web.Security.PassportIdentity.Current.Employee.FullName;
                        userCredentials["userDesignation"] = H3GS.Web.Security.PassportIdentity.Current.Employee.Designation;
                        userCredentials["userEmployeeId"] = H3GS.Web.Security.PassportIdentity.Current.Employee.EmployeeId.ToString();
                        //for departement name and id
                        userCredentials["userDeptID"] = H3GS.Web.Security.PassportIdentity.Current.Employee.DepartmentId.ToString();
                        userCredentials["userDeptName"] = H3GS.Web.Security.PassportIdentity.Current.Employee.Department;
                        //for CID - departement name and id
                        userCredentials["userCIDDeptID"] = H3GS.Web.Security.PassportIdentity.Current.Employee.DepartmentId.ToString();
                        userCredentials["userCIDDeptName"] = H3GS.Web.Security.PassportIdentity.Current.Employee.Department;
                        //Location
                        userCredentials["userLocation"] = "";
                        //Rep man
                        userCredentials["userBoss1ID"] = H3GS.Web.Security.PassportIdentity.Current.Employee.BossId.ToString();
                        userCredentials["userBoss1Name"] = "";
                        //Rev Man
                        userCredentials["userBoss2Id"] = "";
                        userCredentials["userBoss2Name"] = "";

                        Response.AppendCookie(userCredentials);

                        //LogoutButton.Visible = false;
                    }
                }
            }
        }
        //End
    }

    protected override void OnInit(EventArgs e)
    {
        ActivateDeActivateControls();
    }
    private void ActivateDeActivateControls()
    {
        HtmlTable imgBtnSave = (HtmlTable)Master.FindControl("tblTopBar");
        imgBtnSave.Visible = false;
        Label lblModule = (Label)Master.FindControl("lblModule");
        lblModule.Text = "EVO Portal";
    }

    private void DestroySession()
    {
        ManageSession.FormID = 0;
        ManageSession.FormName = null;
        ManageSession.XmlFileName = null;
        ManageSession.CategoryID = 0;
        ManageSession.VersionID = 0;
        ManageSession.FormMode = null;
    }

    protected void CreateFormImageButton_Click(object sender, ImageClickEventArgs e)
    {
        DestroySession();
        Response.Redirect("AdminFormDetails.aspx", true);
    }
    protected void ModifyFormImageButton_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("ModifyFormDetails.aspx", true);
    }
    protected void ReportsImageButton_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("../Reports/ManageReports.aspx", true);
    }
    protected void ModifyConfigImageButton_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("../SuperAdmin/ManageCostCentre.aspx", true);
    }
    protected void UserImageButton_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("../User/UserForms.aspx", true);
    }

    //Logout Functionalily : Bappa
    protected void LogoutButton_Click(object sender, ImageClickEventArgs e)
    {
        int AuthType = Convert.ToInt32(HttpContext.Current.Request.Cookies["EVO"]["AuthenticationType"]);
        Response.Cookies["EVO"].Expires = DateTime.Now.AddDays(-1);
        Session.Abandon();
        Response.Redirect("../LogOut.aspx");
    }
    //End
}
