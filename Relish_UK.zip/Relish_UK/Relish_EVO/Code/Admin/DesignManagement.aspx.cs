using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Text;
using System.IO;
using System.Xml.Xsl;
using System.Xml.XPath;
using EVOLib;
using System.Linq;

public partial class Code_Development_Evo_DesignManagement : EvoGeneral
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            FormIDHidden.Value = ManageSession.FormID.ToString();
            FormNameHidden.Value = ManageSession.FormName;
            FormEndNameHidden.Value = FormNameHidden.Value;
            VersionIDHidden.Value = ManageSession.VersionID.ToString();
            CategoryIDHidden.Value = ManageSession.CategoryID.ToString();
            //FileModeHidden.Value = ManageSession.FormMode;

            //ClientScript.RegisterStartupScript(this.GetType(), "script", "<script>javascript:GetControl();</script>");


            IsValidUser();

            BindCustomCostCentre();
            BindGlobalCostCentre();
            BindGlobalSkillSet();
            //BindCustomSkillSet();

            DeleteButton.Style.Add("display", "none");

            DataSet basicControlDataSet = new DataSet();
            basicControlDataSet = DesignManagement.GetBasicControls();

            for (int controlCount = 0; controlCount < basicControlDataSet.Tables[0].Rows.Count; controlCount++)
            {
                TableRow controlRow = new TableRow();
                TableCell controlCell = new TableCell();
                controlCell.Attributes.Add("runat", "server");
                controlCell.Attributes.Add("onclick", "Create" + basicControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "();");
                controlCell.Text = "" + basicControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "";
                controlCell.Style.Add("cursor", "hand");
                controlCell.ToolTip = "Add " + controlCell.Text;
                controlRow.Controls.Add(controlCell);
                BasicToolsListView.Rows.Add(controlRow);

            }

            DataSet customControlDataSet = new DataSet();
            customControlDataSet = DesignManagement.GetCustomControls();

            for (int controlCount = 0; controlCount < customControlDataSet.Tables[0].Rows.Count; controlCount++)
            {
                TableRow customRow = new TableRow();
                TableCell customCell = new TableCell();
                customCell.Attributes.Add("runat", "server");
                customCell.Attributes.Add("onclick", "Create" + customControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "();");
                customCell.Text = "" + customControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "";
                if (customCell.Text == "CC2Employees")
                {
                    customCell.Style.Add("display", "none");
                    //customCell.Text = "Auto Fill Employee DropDown";
                }
                if (customCell.Text == "CC1Employees")
                {
                    customCell.Text = "Employee DropDown";
                }
                if (customCell.Text == "CC3Employees")
                {
                    customCell.Text = "Employee's Manager DropDown";
                }
                customCell.Style.Add("cursor", "hand");
                customCell.Attributes.Add("runat", "server");
                customCell.ToolTip = "Add " + customCell.Text;
                customRow.Controls.Add(customCell);
                CustomToolsListView.Rows.Add(customRow);
            }


            string dependentIDS = "";
            DataSet globalChildControlDataSet = new DataSet();
            globalChildControlDataSet = DesignManagement.GetGlobalChildControls();

            for (int count = 0; count < globalChildControlDataSet.Tables[0].Rows.Count; count++)
            {
                dependentIDS += globalChildControlDataSet.Tables[0].Rows[count]["DependentControlID"].ToString() + ",";
            }

            if (dependentIDS != "")
            {
                DataSet globalMControlDataSet = new DataSet();
                globalMControlDataSet = DesignManagement.GetGlobalMControls(dependentIDS);


                for (int controlCount = 0; controlCount < globalMControlDataSet.Tables[0].Rows.Count; controlCount++)
                {
                    TableRow globalRow = new TableRow();
                    TableCell globalCell = new TableCell();
                    globalCell.Attributes.Add("runat", "server");
                    globalCell.Attributes.Add("onclick", "CreateMultipleGlobal(this);");
                    for (int globCount = 0; globCount < globalChildControlDataSet.Tables[0].Rows.Count; globCount++)
                    {
                        if (globalChildControlDataSet.Tables[0].Rows[globCount]["DependentControlID"].ToString() == globalMControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString())
                        {
                            globalCell.Text = "" + globalMControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "/" + globalChildControlDataSet.Tables[0].Rows[globCount]["ChildControlName"].ToString() + "";
                            globalCell.Attributes.Add("depctrlid", globalChildControlDataSet.Tables[0].Rows[globCount]["ControlID"].ToString());
                        }
                    }
                    globalCell.Style.Add("cursor", "hand");
                    globalCell.Attributes.Add("ctrlid", globalMControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString());
                    globalCell.Attributes.Add("runat", "server");
                    globalCell.ToolTip = "Add " + globalCell.Text;
                    globalRow.Controls.Add(globalCell);
                    GlobalToolsListView.Rows.Add(globalRow);
                }
            }

            DataSet globalSControlDataSet = new DataSet();
            globalSControlDataSet = DesignManagement.GetGlobalSControls();

            if (globalSControlDataSet.Tables.Count > 0)
            {
                for (int controlCount = 0; controlCount < globalSControlDataSet.Tables[0].Rows.Count; controlCount++)
                {
                    TableRow globalRow = new TableRow();
                    TableCell globalCell = new TableCell();
                    globalCell.Attributes.Add("runat", "server");
                    globalCell.Attributes.Add("onclick", "CreateSingleGlobal(this);");
                    globalCell.Text = "" + globalSControlDataSet.Tables[0].Rows[controlCount]["ControlName"].ToString() + "";
                    globalCell.Style.Add("cursor", "hand");
                    globalCell.Attributes.Add("ctrlid", globalSControlDataSet.Tables[0].Rows[controlCount]["ControlID"].ToString());
                    globalCell.Attributes.Add("runat", "server");
                    globalCell.ToolTip = "Add " + globalCell.Text;
                    globalRow.Controls.Add(globalCell);
                    GlobalToolsListView.Rows.Add(globalRow);
                }
            }


            ////Code to select the form id from query string --> and get the XML file path and VersionName for that form.
            XmlDocument xExistingXMLDoc = new XmlDocument();
            DataSet getFormXMLDataset = new DataSet();
            if (FileModeHidden.Value == "EDITMODE")
            {
                getFormXMLDataset = DesignManagement.GetFormXMLPathForModify(int.Parse(FormIDHidden.Value), int.Parse(VersionIDHidden.Value));

            }
            else
            {
                getFormXMLDataset = DesignManagement.GetFormXMLPath(int.Parse(FormIDHidden.Value));
            }

            try
            {
                if (getFormXMLDataset.Tables[0].Rows[0]["VersionName"].ToString() != "No Version")
                {
                    string title = "";
                    string controlId = "";
                    string controlType = "";
                    string fieldId = "";
                    string xpos = "";
                    string ypos = "";
                    string width = "";
                    string isRequired = "";
                    string dependency = "";
                    string dependentId = "";
                    string dependentCtrlId = "";
                    string isWrap = "";
                    string preWrap = "";
                    string postWrap = "";
                    string prevRef = "";
                    string queryPattern = "Contains";
                    string textMode = "";
                    string isType = "";
                    int maxLength = 0;
                    string height = "";
                    int dropDownCount = 0;
                    int listBoxCount = 0;
                    int checkBoxCount = 0;
                    int radioButtonCount = 0;
                    int textBoxCount = 0;
                    int labelCount = 0;
                    int customCount = 0;
                    int globalCount = 0;
                    string globalCountString = "";
                    string IsHide = "";
                    string skillSet = "";
                    string skillSetValues = "";

                    string costCentre = "";
                    string costCentreValues = "";

                    FileModeHidden.Value = "EDITMODE";
                    xExistingXMLDoc.Load(Server.MapPath("../XML/" + getFormXMLDataset.Tables[0].Rows[0]["XMLFile"]));
                    FormNameHidden.Value = getFormXMLDataset.Tables[0].Rows[0]["XMLFile"].ToString();
                    ReadXMLHidden.Value = xExistingXMLDoc.InnerXml;
                    for (int xmlCount = 0; xmlCount < xExistingXMLDoc.ChildNodes[1].ChildNodes.Count; xmlCount++)
                    {
                        XmlNode xmlNode = (XmlNode)xExistingXMLDoc.ChildNodes[1].ChildNodes[xmlCount];
                        if (xmlNode.Name == "TextBox")
                        {
                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;


                            if (fieldId.Contains("cctxt_"))
                            {
                                textBoxCount = Convert.ToInt32(fieldId.Replace("cctxt_", "").Replace("TextBox", "").ToString());
                            }
                            else
                            {

                                if (fieldId.Replace("txt_", "").Replace("TextBox", "").ToString() != "")
                                {
                                    textBoxCount = Convert.ToInt32(fieldId.Replace("txt_", "").Replace("TextBox", "").ToString());
                                }
                                else
                                {
                                    textBoxCount = 0;
                                }
                            }
                            textBoxCountHidden.Value = textBoxCount.ToString();

                            xpos = xmlNode.ChildNodes[5].InnerText;
                            ypos = xmlNode.ChildNodes[6].InnerText;
                            width = xmlNode.ChildNodes[7].InnerText;
                            isRequired = xmlNode.ChildNodes[8].InnerText;
                            isWrap = xmlNode.ChildNodes[10].InnerText;
                            preWrap = xmlNode.ChildNodes[11].InnerText;
                            postWrap = xmlNode.ChildNodes[12].InnerText;
                            textMode = xmlNode.ChildNodes[13].InnerText;
                            isType = xmlNode.ChildNodes[14].InnerText;
                            maxLength = Convert.ToInt32(xmlNode.ChildNodes[15].InnerText);
                            if (xmlNode.ChildNodes[20] != null)
                            {
                                height = xmlNode.ChildNodes[20].InnerText;
                            }
                            else
                            {
                                height = "50";
                            }
                            if (xmlNode.ChildNodes[21] != null)
                            {
                                IsHide = xmlNode.ChildNodes[21].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }
                            DesignDiv.InnerHtml += "<table id='txt_" + textBoxCount + "TextBoxTable' title='" + title + "' type='TextBox' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:" + height + "px; background-color:White; width:" + width + "px;top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)' controlid='1' controltype='basic' dependency='False' isrequired='" + isRequired + "' ismanageable='False' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False'  maxlength='" + maxLength + "' textmode='" + textMode + "' istype='" + isType + "' IsHide='" + IsHide + "'>";
                            DesignDiv.InnerHtml += "<tr ><td style='cursor:none;white-space:nowrap;' align='center'>" + title + "</td>";
                            DesignDiv.InnerHtml += "<td align='center'><input id='txt_" + textBoxCount + "TextBox' title='" + title + "' style='z-index:-1;width:150px;cursor:none' type='text'/></td></tr></table>";
                        }
                        if (xmlNode.Name == "TextBox1")
                        {
                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;


                            if (fieldId.Contains("cctxt_"))
                            {
                                textBoxCount = Convert.ToInt32(fieldId.Replace("cctxt_", "").Replace("TextBox", "").ToString());
                            }
                            else
                            {

                                if (fieldId.Replace("txt_", "").Replace("TextBox", "").ToString() != "")
                                {
                                    textBoxCount = Convert.ToInt32(fieldId.Replace("txt_", "").Replace("TextBox", "").ToString());
                                }
                                else
                                {
                                    textBoxCount = 0;
                                }
                            }
                            textBoxCountHidden.Value = textBoxCount.ToString();

                            xpos = xmlNode.ChildNodes[5].InnerText;
                            ypos = xmlNode.ChildNodes[6].InnerText;
                            width = xmlNode.ChildNodes[7].InnerText;
                            isRequired = xmlNode.ChildNodes[8].InnerText;
                            isWrap = xmlNode.ChildNodes[10].InnerText;
                            preWrap = xmlNode.ChildNodes[11].InnerText;
                            postWrap = xmlNode.ChildNodes[12].InnerText;
                            textMode = xmlNode.ChildNodes[13].InnerText;
                            isType = xmlNode.ChildNodes[14].InnerText;
                            maxLength = Convert.ToInt32(xmlNode.ChildNodes[15].InnerText);
                            if (xmlNode.ChildNodes[20] != null)
                            {
                                height = xmlNode.ChildNodes[20].InnerText;
                            }
                            else
                            {
                                height = "50";
                            }
                            if (xmlNode.ChildNodes[21] != null)
                            {
                                IsHide = xmlNode.ChildNodes[21].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }
                            DesignDiv.InnerHtml += "<table id='txt_" + textBoxCount + "TextBoxTable' title='" + title + "' type='TextBox' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:" + height + "px; background-color:White; width:" + width + "px;top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)' controlid='1' controltype='basic' dependency='False' isrequired='" + isRequired + "' ismanageable='False' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False'  maxlength='" + maxLength + "' textmode='" + textMode + "' istype='" + isType + "' IsHide='" + IsHide + "'>";
                            DesignDiv.InnerHtml += "<tr ><td style='cursor:none;white-space:nowrap;' align='center'>" + title + "</td>";
                            DesignDiv.InnerHtml += "<td align='center'><input id='txt_" + textBoxCount + "TextBox' title='" + title + "' style='z-index:-1;width:150px;cursor:none' type='text'/></td></tr></table>";
                        }
                        if (xmlNode.Name == "DropDownList")
                        {
                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;

                            if (fieldId.Replace("ddl_", "").Replace("DropDown", "").ToString() != "")
                            {
                                dropDownCount = Convert.ToInt32(fieldId.Replace("ddl_", "").Replace("DropDown", "").ToString());
                            }
                            else
                            {
                                dropDownCount = 0;
                            }


                            dropDownCountHidden.Value = dropDownCount.ToString();

                            dependentId = xmlNode.ChildNodes[5].InnerText;
                            xpos = xmlNode.ChildNodes[6].InnerText;
                            ypos = xmlNode.ChildNodes[7].InnerText;
                            width = xmlNode.ChildNodes[8].InnerText;
                            isRequired = xmlNode.ChildNodes[9].InnerText;
                            dependency = xmlNode.ChildNodes[12].InnerText;
                            isWrap = xmlNode.ChildNodes[13].InnerText;
                            preWrap = xmlNode.ChildNodes[14].InnerText;
                            postWrap = xmlNode.ChildNodes[15].InnerText;
                            prevRef = xmlNode.ChildNodes[16].InnerText;
                            if (xmlNode.ChildNodes[21] != null)
                            {
                                IsHide = xmlNode.ChildNodes[21].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }
                            //if (xmlNode.ChildNodes[17].Name == "IsQueryPattern" && xmlNode.ChildNodes[17].InnerText!="undefined")
                            //{
                            //    queryPattern = xmlNode.ChildNodes[17].InnerText;
                            //}

                            DropDownArray.Value += title + ",";
                            DropDownIDArray.Value += fieldId + ",";

                            DesignDiv.InnerHtml += "<table id='ddl_" + dropDownCount + "DropDownTable' title='" + title + "' type='DropDown' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; width:200px; top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)' controlid='2' controltype='basic' dependency='" + dependency + "' dependentid='" + dependentId + "' prevref='" + prevRef + "' isrequired='" + isRequired + "' ismanageable='False' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False' IsQueryPattern='" + queryPattern + "' IsHide='" + IsHide + "'>";
                            DesignDiv.InnerHtml += "<tr><td style='cursor:none;' align='center'>" + title + "</td>";
                            DesignDiv.InnerHtml += "<td align='center'><img id='ddl_" + dropDownCount + "DropDown' title='" + title + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/></td></tr></table>";


                        }
                        if (xmlNode.Name == "ListBox")
                        {
                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;


                            if (fieldId.Replace("lb_", "").Replace("ListBox", "").ToString() != "")
                            {
                                listBoxCount = Convert.ToInt32(fieldId.Replace("lb_", "").Replace("ListBox", "").ToString());
                            }
                            else
                            {
                                listBoxCount = 0;
                            }

                            dependentId = xmlNode.ChildNodes[5].InnerText;
                            xpos = xmlNode.ChildNodes[6].InnerText;
                            ypos = xmlNode.ChildNodes[7].InnerText;
                            width = xmlNode.ChildNodes[8].InnerText;
                            isRequired = xmlNode.ChildNodes[9].InnerText;
                            dependency = xmlNode.ChildNodes[12].InnerText;
                            isWrap = xmlNode.ChildNodes[13].InnerText;
                            preWrap = xmlNode.ChildNodes[14].InnerText;
                            postWrap = xmlNode.ChildNodes[15].InnerText;
                            prevRef = xmlNode.ChildNodes[16].InnerText;
                            if (xmlNode.ChildNodes[20] != null)
                            {
                                IsHide = xmlNode.ChildNodes[20].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }
                            listBoxCountHidden.Value = listBoxCount.ToString();

                            ListBoxArray.Value += title + ",";
                            ListBoxIDArray.Value += fieldId + ",";

                            DesignDiv.InnerHtml += "<table id='lb_" + listBoxCount + "ListBoxTable' title='" + title + "' type='ListBox' class='drag' style='position:absolute;border:dashed 4px #afafaf;background-color:White; width:100px;top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)'  iswrap='" + isWrap + "' controlid='5' controltype='basic' dependency='" + dependency + "' dependentid='" + dependentId + "' prevref='" + prevRef + "' isrequired='" + isRequired + "' ismanageable='False' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False' IsHide='" + IsHide + "'>";
                            DesignDiv.InnerHtml += "<tr ><td style='cursor:none' align='center'>" + title + "</td></tr><tr>";
                            DesignDiv.InnerHtml += "<td align='center'><img id='lb_" + listBoxCount + "ListBox' title='" + title + "' style='z-index:-1;width:200px;;height:120px;' src='../Images/ListBoxDes.jpg'/></td></tr></table>";

                        }
                        if (xmlNode.Name == "CheckBoxList")
                        {
                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;


                            if (fieldId.Replace("cbl_", "").Replace("CheckBox", "").ToString() != "")
                            {
                                checkBoxCount = Convert.ToInt32(fieldId.Replace("cbl_", "").Replace("CheckBox", "").ToString());

                            }
                            else
                            {
                                checkBoxCount = 0;
                            }

                            xpos = xmlNode.ChildNodes[5].InnerText;
                            ypos = xmlNode.ChildNodes[6].InnerText;
                            width = xmlNode.ChildNodes[7].InnerText;
                            isRequired = xmlNode.ChildNodes[8].InnerText;
                            isWrap = xmlNode.ChildNodes[13].InnerText;
                            preWrap = xmlNode.ChildNodes[14].InnerText;
                            postWrap = xmlNode.ChildNodes[15].InnerText;
                            if (xmlNode.ChildNodes[22] != null)
                            {
                                IsHide = xmlNode.ChildNodes[22].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }
                            checkBoxCountHidden.Value = checkBoxCount.ToString();

                            int resultheight = 0;
                            int resultmod = 0;
                            resultheight = xmlNode.ChildNodes[20].ChildNodes.Count / 5;
                            resultmod = xmlNode.ChildNodes[20].ChildNodes.Count % 5;
                            if (resultheight < 1)
                            {
                                resultheight = 1;
                            }
                            if (resultmod > 0)
                            {
                                resultheight = resultheight + 1;
                            }
                            int resultcount = 0;

                            DesignDiv.InnerHtml += "<table id='cbl_" + checkBoxCount + "CheckBox' title='" + title + "' type='CheckBoxList' class='drag' style='position:absolute;border:dashed 4px #afafaf;background-color:White; width:200px; top:" + ypos + "px; left:" + xpos + "px; z-index:-1;' align='right' onclick ='FillProperties(this)'  iswrap='" + isWrap + "' controlid='4' controltype='basic' dependency='False' isrequired='" + isRequired + "' ismanageable='False' prewrap='" + preWrap + "' postwrap='" + postWrap + "' ispostback='False' IsHide='" + IsHide + "'><tr style='width:50px'><td style='white-space:nowrap;'>" + title + "</td>";
                            for (int listItemCount = 0; listItemCount < xmlNode.ChildNodes[20].ChildNodes.Count; listItemCount++)
                            {
                                listItemCount = Convert.ToInt32(xmlNode.ChildNodes[20].ChildNodes[listItemCount].Attributes["Id"].Value);//+ title 
                                DesignDiv.InnerHtml += "<td style='width:150px; cursor:hand;white-space:nowrap; vertical-align:top' align='right'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + listItemCount.ToString() + "<input id='cbl_" + checkBoxCount + "CheckBox'  title='" + listItemCount.ToString() + "' type='checkbox'  name='" + title + "' repeatdirection='horizontal' repeatcolumns='1' /></td>";
                                if (listItemCount == 4 * (resultcount + 1) && resultcount != resultheight)
                                {
                                    DesignDiv.InnerHtml += "</tr><tr style='width:50px'> <td style='white-space: nowrap;'></td>";
                                    resultcount = resultcount + 1;
                                }
                            }
                            DesignDiv.InnerHtml += "</tr></table>";
                        }
                        if (xmlNode.Name == "RadioButtonList")
                        {
                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;


                            if (fieldId.Replace("rbl_", "").Replace("RadioButton", "").ToString() != "")
                            {
                                radioButtonCount = Convert.ToInt32(fieldId.Replace("rbl_", "").Replace("RadioButton", "").ToString());
                            }
                            else
                            {
                                radioButtonCount = 0;
                            }


                            xpos = xmlNode.ChildNodes[5].InnerText;
                            ypos = xmlNode.ChildNodes[6].InnerText;
                            width = xmlNode.ChildNodes[7].InnerText;
                            isRequired = xmlNode.ChildNodes[8].InnerText;
                            isWrap = xmlNode.ChildNodes[13].InnerText;
                            preWrap = xmlNode.ChildNodes[14].InnerText;
                            postWrap = xmlNode.ChildNodes[15].InnerText;
                            if (xmlNode.ChildNodes[22] != null)
                            {
                                IsHide = xmlNode.ChildNodes[22].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }
                            radioButtonCountHidden.Value = radioButtonCount.ToString();
                            int resultheight = 0;
                            int resultmod = 0;
                            resultheight = xmlNode.ChildNodes[20].ChildNodes.Count / 5;
                            resultmod = xmlNode.ChildNodes[20].ChildNodes.Count % 5;
                            if (resultheight < 1)
                            {
                                resultheight = 1;
                            }
                            if (resultmod > 0)
                            {
                                resultheight = resultheight + 1;
                            }
                            int resultcount = 0;
                            DesignDiv.InnerHtml += "<table id='rbl_" + radioButtonCount + "RadioButton' title='" + title + "' type='RadioButtonList' class='drag' style='position:absolute;border:dashed 4px #afafaf;background-color:White; width:200px; top:" + ypos + "px; left:" + xpos + "px; z-index:-1;' align='right' onclick ='FillProperties(this)'  iswrap='" + isWrap + "' controlid='4' controltype='basic' dependency='False' isrequired='" + isRequired + "' ismanageable='False' prewrap='" + preWrap + "' postwrap='" + postWrap + "' ispostback='False' IsHide='" + IsHide + "'><tr style='width:50px'><td style='white-space:nowrap;'>" + title + "</td>";

                            for (int listItemCount = 0; listItemCount < xmlNode.ChildNodes[20].ChildNodes.Count; listItemCount++)
                            {
                                listItemCount = Convert.ToInt32(xmlNode.ChildNodes[20].ChildNodes[listItemCount].Attributes["Id"].Value);//title +
                                DesignDiv.InnerHtml += "<td style='width:150px; cursor:hand;white-space:nowrap; vertical-align:top' align='right'>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" + listItemCount.ToString() + "<input id='rbl_" + radioButtonCount + "RadioButton'  title='" + listItemCount.ToString() + "' type='radio'  name='" + title + "' repeatdirection='horizontal' repeatcolumns='1' /></td>";
                                if (listItemCount == 4 * (resultcount + 1) && resultcount != resultheight)
                                {
                                    DesignDiv.InnerHtml += "</tr><tr style='width:50px'> <td style='white-space: nowrap;'></td>";
                                    resultcount = resultcount + 1;
                                }
                            }

                            DesignDiv.InnerHtml += "</tr></table>";
                        }
                        if (xmlNode.Name == "Label")
                        {
                            title = xmlNode.ChildNodes[3].InnerText;
                            controlId = xmlNode.ChildNodes[0].InnerText;
                            controlType = xmlNode.ChildNodes[1].InnerText;
                            fieldId = xmlNode.ChildNodes[2].InnerText;
                            xpos = xmlNode.ChildNodes[4].InnerText;
                            ypos = xmlNode.ChildNodes[5].InnerText;
                            width = xmlNode.ChildNodes[6].InnerText;
                            isWrap = xmlNode.ChildNodes[8].InnerText;
                            preWrap = xmlNode.ChildNodes[9].InnerText;
                            postWrap = xmlNode.ChildNodes[10].InnerText;

                            if (fieldId.Replace("lbl_", "").Replace("Label", "").ToString() != "")
                            {
                                labelCount = Convert.ToInt32(fieldId.Replace("lbl_", "").Replace("Label", "").ToString());
                            }
                            else
                            {
                                labelCount = 0;
                            }

                            if (xmlNode.ChildNodes[15] != null)
                            {
                                IsHide = xmlNode.ChildNodes[15].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }
                            labelCountHidden.Value = labelCount.ToString();
                            DesignDiv.InnerHtml += "<table id='lbl_" + labelCount + "LabelTable' title='" + title + "' type='Label' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; width:" + width + "px; top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)'    controlid='1' controltype='basic' dependency='False' isrequired='False' ismanageable='False' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False' IsHide='" + IsHide + "'>";
                            DesignDiv.InnerHtml += "<tr ><td style='cursor:none;' align='center'>" + title + "</td>";
                            DesignDiv.InnerHtml += "<td align='center'><label id='lbl_" + labelCount + "Label' title='" + title + "' style='z-index:-1;width:150px;cursor:none'></label></td></tr></table>";


                        }
                        if (xmlNode.Name == "Button")
                        {

                        }
                        if (xmlNode.Name == "CC1EmployeesDropDown")
                        {
                            skillSet = "";
                            skillSetValues = "";

                            costCentre = "";
                            costCentreValues = "";

                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;


                            if (fieldId.Replace("cc_", "").Replace("DropDown", "").ToString() != "")
                            {
                                customCount = Convert.ToInt32(fieldId.Replace("cc_", "").Replace("DropDown", "").ToString());
                            }
                            else
                            {
                                customCount = 0;
                            }
                            if (xmlNode.ChildNodes[19] != null)
                            {
                                IsHide = xmlNode.ChildNodes[19].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }

                            xpos = xmlNode.ChildNodes[5].InnerText;
                            ypos = xmlNode.ChildNodes[6].InnerText;
                            width = xmlNode.ChildNodes[7].InnerText;
                            isRequired = xmlNode.ChildNodes[8].InnerText;
                            isWrap = xmlNode.ChildNodes[11].InnerText;
                            preWrap = xmlNode.ChildNodes[12].InnerText;
                            postWrap = xmlNode.ChildNodes[13].InnerText;

                            customCountHidden.Value = customCount.ToString();

                            for (int skillCount = 0; skillCount < xmlNode.ChildNodes[15].ChildNodes.Count; skillCount++)
                            {
                                skillSet += xmlNode.ChildNodes[15].ChildNodes[skillCount].InnerText + ",";
                                skillSetValues += xmlNode.ChildNodes[15].ChildNodes[skillCount].Attributes["Id"].Value + ",";
                            }

                            for (int costCentreCount = 0; costCentreCount < xmlNode.ChildNodes[16].ChildNodes.Count; costCentreCount++)
                            {
                                costCentre += xmlNode.ChildNodes[16].ChildNodes[costCentreCount].InnerText + ",";
                                costCentreValues += xmlNode.ChildNodes[16].ChildNodes[costCentreCount].Attributes["Id"].Value + ",";
                            }

                            DesignDiv.InnerHtml += "<table id='cc_" + customCount + "DropDownTable' title='" + title + "' type='EmpDropDown' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)'  controlid='4' controltype='custom' isrequired='" + isRequired + "' datasource='DB' skillset='" + skillSet + "' skillsetvalues='" + skillSetValues + "' costcentre='" + costCentre + "' costcentrevalues='" + costCentreValues + "' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False' IsHide='" + IsHide + "'>";
                            DesignDiv.InnerHtml += "<tr ><td style='cursor:none' align='left'>" + title + "</td>";
                            DesignDiv.InnerHtml += "<td align='right'><img id='cc_" + customCount + "DropDown' title='" + title + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/></td>";
                            DesignDiv.InnerHtml += "<td><img id='ShowCustPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
                            DesignDiv.InnerHtml += "cursor: hand; padding-left: 5px;' onclick='ShowCustProps(event, this);' align='left' /></td></tr></table>";

                        }
                        if (xmlNode.Name == "CC3EmployeesDropDown")
                        {
                            skillSet = "";
                            skillSetValues = "";

                            costCentre = "";
                            costCentreValues = "";

                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;


                            if (fieldId.Replace("cc_", "").Replace("DropDown", "").ToString() != "")
                            {
                                customCount = Convert.ToInt32(fieldId.Replace("cc_", "").Replace("DropDown", "").ToString());

                            }
                            else
                            {
                                customCount = 0;
                            }
                            if (xmlNode.ChildNodes[19] != null)
                            {
                                IsHide = xmlNode.ChildNodes[19].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }

                            xpos = xmlNode.ChildNodes[5].InnerText;
                            ypos = xmlNode.ChildNodes[6].InnerText;
                            width = xmlNode.ChildNodes[7].InnerText;
                            isRequired = xmlNode.ChildNodes[8].InnerText;
                            isWrap = xmlNode.ChildNodes[11].InnerText;
                            preWrap = xmlNode.ChildNodes[12].InnerText;
                            postWrap = xmlNode.ChildNodes[13].InnerText;

                            customCountHidden.Value = customCount.ToString();

                            for (int skillCount = 0; skillCount < xmlNode.ChildNodes[16].ChildNodes.Count; skillCount++)
                            {
                                skillSet += xmlNode.ChildNodes[16].ChildNodes[skillCount].InnerText + ",";
                                skillSetValues += xmlNode.ChildNodes[16].ChildNodes[skillCount].Attributes["Id"].Value + ",";
                            }

                            for (int costCentreCount = 0; costCentreCount < xmlNode.ChildNodes[17].ChildNodes.Count; costCentreCount++)
                            {
                                costCentre += xmlNode.ChildNodes[17].ChildNodes[costCentreCount].InnerText + ",";
                                costCentreValues += xmlNode.ChildNodes[17].ChildNodes[costCentreCount].Attributes["Id"].Value + ",";
                            }

                            DesignDiv.InnerHtml += "<table id='cc_" + customCount + "DropDownTable' title='" + title + "' type='EmpManagerDropDown' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)'  controlid='4' controltype='custom' isrequired='" + isRequired + "' datasource='DB' skillset='" + skillSet + "' skillsetvalues='" + skillSetValues + "' costcentre='" + costCentre + "' costcentrevalues='" + costCentreValues + "' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False' IsHide='" + IsHide + "'>";
                            DesignDiv.InnerHtml += "<tr ><td style='cursor:none' align='left'>" + title + "</td>";
                            DesignDiv.InnerHtml += "<td align='right'><img id='cc_" + customCount + "DropDown' title='" + title + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/></td>";
                            DesignDiv.InnerHtml += "<td><img id='ShowCustPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
                            DesignDiv.InnerHtml += "cursor: hand; padding-left: 5px;' onclick='ShowCustProps(event, this);' align='left' /></td>";
                            //DesignDiv.InnerHtml += "<td><input id='cctxt_" + customCount + "TextBox' title='Textbox' style='z-index:-1;width:150px;cursor:none' type='text' readonly/></td></tr></table>";
                            DesignDiv.InnerHtml += "</tr></table>";

                        }
                        if (xmlNode.Name == "GlobalMControl")
                        {
                            skillSet = "";
                            skillSetValues = "";

                            costCentre = "";
                            costCentreValues = "";

                            globalCount++;

                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;
                            dependentId = xmlNode.ChildNodes[5].InnerText;
                            dependentCtrlId = xmlNode.ChildNodes[6].InnerText;

                            globalCountString = fieldId.Replace("gc_", "").Replace("DropDown", "").ToString();

                            globalCountHidden.Value = globalCount.ToString();

                            xpos = xmlNode.ChildNodes[7].InnerText;
                            ypos = xmlNode.ChildNodes[8].InnerText;
                            width = xmlNode.ChildNodes[9].InnerText;
                            isRequired = xmlNode.ChildNodes[10].InnerText;
                            isWrap = xmlNode.ChildNodes[13].InnerText;
                            preWrap = xmlNode.ChildNodes[14].InnerText;
                            postWrap = xmlNode.ChildNodes[15].InnerText;
                            if (xmlNode.ChildNodes[19] != null)
                            {
                                IsHide = xmlNode.ChildNodes[19].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }

                            for (int skillCount = 0; skillCount < xmlNode.ChildNodes[17].ChildNodes.Count; skillCount++)
                            {
                                skillSet += xmlNode.ChildNodes[17].ChildNodes[skillCount].InnerText + ",";
                                skillSetValues += xmlNode.ChildNodes[17].ChildNodes[skillCount].Attributes["Id"].Value + ",";
                            }

                            for (int costCentreCount = 0; costCentreCount < xmlNode.ChildNodes[18].ChildNodes.Count; costCentreCount++)
                            {
                                costCentre += xmlNode.ChildNodes[18].ChildNodes[costCentreCount].InnerText + ",";
                                costCentreValues += xmlNode.ChildNodes[18].ChildNodes[costCentreCount].Attributes["Id"].Value + ",";
                            }

                            DesignDiv.InnerHtml += "<table id='gc_" + globalCountString + "DropDownTable' title='" + title + "' type='GlobalMControl' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:" + ypos + "px; left:" + xpos + "px;' align='right' onclick ='FillProperties(this)'  iswrap='" + isWrap + "'  controltype='global' isrequired='" + isRequired + "' datasource='DB' skillset='" + skillSet + "' skillsetvalues='" + skillSetValues + "' costcentre='" + costCentre + "' costcentrevalues='" + costCentreValues + "' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False' dependentid='" + dependentId + "' controlid='" + controlId + "' depctrlid='" + dependentCtrlId + "' IsHide='" + IsHide + "'>";//
                            DesignDiv.InnerHtml += "<tr ><td style='cursor:none' align='left'>" + title + "</td>";
                            DesignDiv.InnerHtml += "<td align='right'><img id='gc_" + globalCountString + "DropDown' title='" + title + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/>&nbsp;&nbsp;";
                            DesignDiv.InnerHtml += "<td><img id='" + dependentId + "' title='" + title + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/></td>";
                            DesignDiv.InnerHtml += "</td>";
                            DesignDiv.InnerHtml += "<td><img id='ShowGlobalPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
                            DesignDiv.InnerHtml += "cursor: hand; padding-left: 5px;' onclick='ShowGlobalProps(event, this, " + controlId + ", CCArray);' align='left'/></td></tr></table>";
                        }
                        if (xmlNode.Name == "GlobalSControl")
                        {
                            skillSet = "";
                            skillSetValues = "";

                            costCentre = "";
                            costCentreValues = "";

                            globalCount++;

                            title = xmlNode.ChildNodes[0].ChildNodes[0].InnerText;
                            controlId = xmlNode.ChildNodes[1].InnerText;
                            controlType = xmlNode.ChildNodes[2].InnerText;
                            fieldId = xmlNode.ChildNodes[3].InnerText;
                            dependentId = xmlNode.ChildNodes[5].InnerText;
                            //dependentCtrlId = xmlNode.ChildNodes[5].InnerText;

                            globalCountString = fieldId.Replace("gc_", "").Replace("DropDown", "").ToString();

                            globalCountHidden.Value = globalCount.ToString();

                            xpos = xmlNode.ChildNodes[6].InnerText;
                            ypos = xmlNode.ChildNodes[7].InnerText;
                            width = xmlNode.ChildNodes[8].InnerText;
                            isRequired = xmlNode.ChildNodes[9].InnerText;
                            isWrap = xmlNode.ChildNodes[12].InnerText;
                            preWrap = xmlNode.ChildNodes[13].InnerText;
                            postWrap = xmlNode.ChildNodes[14].InnerText;

                            for (int skillCount = 0; skillCount < xmlNode.ChildNodes[16].ChildNodes.Count; skillCount++)
                            {
                                skillSet += xmlNode.ChildNodes[16].ChildNodes[skillCount].InnerText + ",";
                                skillSetValues += xmlNode.ChildNodes[16].ChildNodes[skillCount].Attributes["Id"].Value + ",";
                            }

                            for (int costCentreCount = 0; costCentreCount < xmlNode.ChildNodes[17].ChildNodes.Count; costCentreCount++)
                            {
                                costCentre += xmlNode.ChildNodes[17].ChildNodes[costCentreCount].InnerText + ",";
                                costCentreValues += xmlNode.ChildNodes[17].ChildNodes[costCentreCount].Attributes["Id"].Value + ",";
                            }
                            if (xmlNode.ChildNodes[18] != null)
                            {
                                IsHide = xmlNode.ChildNodes[18].InnerText;
                            }
                            else
                            {
                                IsHide = "False";
                            }

                            DesignDiv.InnerHtml += "<table id='gc_" + globalCountString + "DropDownTable' title='" + title + "' type='GlobalSControl' class='drag' style='position:absolute;border:dashed 4px #afafaf; height:50px; background-color:White; top:" + ypos + "px;left:" + xpos + "px;' align='right' onclick ='FillProperties(this)'  controltype='global' isrequired='" + isRequired + "' datasource='DB' skillset='" + skillSet + "' skillsetvalues='" + skillSetValues + "' costcentre='" + costCentre + "' costcentrevalues='" + costCentreValues + "' iswrap='" + isWrap + "' prewrap='" + preWrap + "' postwrap='" + postWrap + "' style='z-index:-1;' ispostback='False' controlid='" + controlId + "' IsHide='" + IsHide + "'>";//
                            DesignDiv.InnerHtml += "<tr ><td style='cursor:none' align='left'>" + title + "</td>";
                            DesignDiv.InnerHtml += "<td align='right'><img id='gc_" + globalCountString + "DropDown' title='" + title + "' style='z-index:-1;width:150px;cursor:none' src='../Images/DropDownDes.jpg'/>&nbsp;&nbsp;";
                            DesignDiv.InnerHtml += "<td><img id='ShowGlobalPropImg' alt='Hide' src='../Images/arrow_blue.gif' style='width: 10px;";
                            DesignDiv.InnerHtml += "cursor: hand; padding-left: 5px;' onclick='ShowGlobalProps(event, this, " + controlId + ", CCArray);' align='left' /></td></tr></table>";
                        }
                    }

                    //ClientScript.RegisterStartupScript(this.GetType(), "ReCreate", "ReCreateControls();", true);
                }
                else
                {
                    FileModeHidden.Value = "CREATEMODE";
                    dropDownCountHidden.Value = "0";
                    listBoxCountHidden.Value = "0";
                    radioButtonCountHidden.Value = "0";
                    checkBoxCountHidden.Value = "0";
                    labelCountHidden.Value = "0";
                    textBoxCountHidden.Value = "0";
                    customCountHidden.Value = "0";
                    globalCountHidden.Value = "0";
                }
                ClientScript.RegisterStartupScript(this.GetType(), "script", "<script>javascript:GetControl();</script>");
            }
            catch(Exception ex)
            {

            }

            //catch (IndexOutOfRangeException ex)
            //{

            //}

        }
    }

    #region Master Page Button Implementation
    protected override void OnInit(EventArgs e)
    {
        GenerateMasterClick();
    }

    private void GenerateMasterClick()
    {
        Label lblModule = (Label)Master.FindControl("lblModule");
        lblModule.Text = "Design Management";

        ContentPlaceHolder ctPlaceHolder = (ContentPlaceHolder)Master.FindControl("head");
        ImageButton imgBtnSave = (ImageButton)ctPlaceHolder.FindControl("imgSave");

        imgBtnSave.Attributes.Add("onclick", "return CreateXmlString();");
        //imgBtnSave.Attributes.Add("onclientclick", "javascript:settabindex();");
        imgBtnSave.Click += new ImageClickEventHandler(XMLButton_Click);

        ImageButton imgBtnHome = (ImageButton)ctPlaceHolder.FindControl("imgHome");
        imgBtnHome.Click += new ImageClickEventHandler(HomeButton_Click);

        ImageButton img1 = (ImageButton)ctPlaceHolder.FindControl("img1");
        ImageButton img2 = (ImageButton)ctPlaceHolder.FindControl("img2");
        ImageButton img3 = (ImageButton)ctPlaceHolder.FindControl("img3");
        ImageButton img4 = (ImageButton)ctPlaceHolder.FindControl("img4");

        FileModeHidden.Value = ManageSession.FormMode;

        if (FileModeHidden.Value == "EDITMODE")
        {
            img1.Enabled = false;
            img2.Enabled = false;
            img2.ImageUrl = "../images/icon_2_rol.jpg";
            img3.Enabled = false;
            img4.Enabled = false;
        }
        if (FileModeHidden.Value == "CREATEMODE")
        {
            img2.ImageUrl = "../images/icon_2_rol.jpg";
            img1.Enabled = false;
            img2.Enabled = false;
            img3.Enabled = false;
            img4.Enabled = false;
        }

    }

    protected void SetSession()
    {
        ManageSession.FormID = Convert.ToInt32(FormIDHidden.Value);
        ManageSession.FormName = FormNameHidden.Value;
        ManageSession.VersionID = Convert.ToInt32(VersionIDHidden.Value);
        ManageSession.CategoryID = Convert.ToInt32(CategoryIDHidden.Value);
        ManageSession.FormMode = FileModeHidden.Value;
    }

    protected void DataManage_Click(object sender, ImageClickEventArgs e)
    {
        SetSession();
        Response.Redirect("../Admin/DataManagement.aspx", true);
    }

    protected void Rights_Click(object sender, ImageClickEventArgs e)
    {
        SetSession();
        Response.Redirect("../Admin/RightsManagement.aspx", true);
    }

    protected void Admin_Click(object sender, ImageClickEventArgs e)
    {
        SetSession();
        Response.Redirect("../Admin/AdminFormDetails.aspx", true);
    }

    #endregion

    // Checking if the user is valid and have rights to manage the form or no.
    private void IsValidUser()
    {
        try
        {
            Boolean IsValid = false;
            EvoAdminUsersRights ObjUserRights = new EvoAdminUsersRights();
            ObjUserRights.VersionId = int.Parse(VersionIDHidden.Value);
            ObjUserRights.UserID = RetrieveUserID(userName);
            ObjUserRights.FormId = int.Parse(FormIDHidden.Value);

            IsValid = ObjUserRights.ValidateAdminManageUser();

            if (!IsValid)
            {
                //Response.Write("Redirecting to access denied");
                Response.Redirect("../AccessDenied.aspx", true);
            }
        }
        catch (Exception ex)
        {
            //lblErr.Text = "No data found for this login" + ex.Message;
        }
    }


    /// <summary>
    /// This region provides the functionality to prefill the costcentres and then fill the skillsets depending on the costcentre selection.
    /// </summary>
    #region Custom Control Implementation
    private void BindCustomCostCentre()
    {
        try
        {
            DataSet ds;
            DesignManagement desObj = new DesignManagement();
            ds = desObj.GetCustomCostCentre();
            if (ds.Tables[0].Rows.Count > 0)
            {
                CostCentreSelect.DataSource = ds.Tables[0];
                CostCentreSelect.DataValueField = "CostCentreID";
                CostCentreSelect.DataTextField = "CostCentre";
                CostCentreSelect.DataBind();
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void CostCentreSelect_SelectedIndexChanged(object sender, EventArgs e)
    {
        BindCustomSkillSet();
        ChangeCCLabel.Style.Add("display", "none");
        ChangeSSLabel.Style.Add("display", "none");
    }

    private void BindCustomSkillSet()
    {
        try
        {
            DataSet ds;
            string costCentreList = "";
            for (int i = 0; i < CostCentreSelect.Items.Count; i++)
            {
                if (CostCentreSelect.Items[i].Selected)
                {
                    costCentreList += CostCentreSelect.Items[i].Value + ",";
                }
            }

            DesignManagement desObj = new DesignManagement();
            ds = desObj.GetCustomSkillSet(costCentreList);
            if (ds.Tables[0].Rows.Count > 0)
            {
                SkillSetSelect.DataSource = ds.Tables[0];
                SkillSetSelect.DataValueField = "DepartmentID";
                SkillSetSelect.DataTextField = "DepartmentName";
                SkillSetSelect.DataBind();
            }

        }
        catch (Exception ex)
        {

        }
    }

    #endregion



    /// <summary>
    /// This region provides the functionality to prefill the costcentres and then fill the skillsets depending on the costcentre selection.
    /// </summary>
    #region Global Control Implementation
    private void BindGlobalCostCentre()
    {
        string costCentreArray = "";

        try
        {
            DataSet ds = new DataSet();
            DesignManagement globalObj = new DesignManagement();
            ds = globalObj.GetGlobalCostCentre();
            if (ds.Tables[0].Rows.Count > 0)
            {
                costCentreArray += "\n var CCArray = new Array(" + ds.Tables[0].Rows.Count + ");\n";
                for (int costCentreCount = 0; costCentreCount < ds.Tables[0].Rows.Count; costCentreCount++)
                {
                    costCentreArray += "CCArray[" + costCentreCount + "] = new Array('" + ds.Tables[0].Rows[costCentreCount]["CostCentreID"].ToString() + "', '" + ds.Tables[0].Rows[costCentreCount]["CostCentre"].ToString() + "', '" + ds.Tables[0].Rows[costCentreCount]["ControlID"].ToString() + "');\n";
                }

                RegisterClientScriptBlock("CostCentreArray", "\n<script language='javascript'>" + costCentreArray + "</script>\n");
                costCentreArray = "";
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void CostCentreGlobalSelect_SelectedIndexChanged(object sender, EventArgs e)
    {
        //BindGlobalSkillSet();
        ChangeCCGlobalLabel.Style.Add("display", "none");
        ChangeSSGlobalLabel.Style.Add("display", "none");
    }


    private void BindGlobalSkillSet()
    {
        try
        {
            DataSet skillDataSet = new DataSet();
            string skillSetArray = "";

            DesignManagement desObj = new DesignManagement();
            skillDataSet = desObj.GetGlobalSkillSet();
            if (skillDataSet.Tables[0].Rows.Count > 0)
            {

                skillSetArray += "\n var SSArray = new Array(" + skillDataSet.Tables[0].Rows.Count + ");\n";
                for (int skillSetCount = 0; skillSetCount < skillDataSet.Tables[0].Rows.Count; skillSetCount++)
                {
                    skillSetArray += "SSArray[" + skillSetCount + "] = new Array('" + skillDataSet.Tables[0].Rows[skillSetCount]["DepName"].ToString() + "', '" + skillDataSet.Tables[0].Rows[skillSetCount]["DepID"].ToString() + "', '" + skillDataSet.Tables[0].Rows[skillSetCount]["ControlID"].ToString() + "', '" + skillDataSet.Tables[0].Rows[skillSetCount]["CostCentreID"].ToString() + "');\n";
                }

                RegisterClientScriptBlock("SkillSetArray", "\n<script language='javascript'>" + skillSetArray + "</script>\n");
                skillSetArray = "";
            }

        }
        catch (Exception ex)
        {

        }
    }

    #endregion


    protected void HomeButton_Click(object sender, EventArgs e)
    {
        Response.Redirect("../Admin/Default.aspx", true);
    }

    /// <summary>
    /// This function is called on clicking on the SAVE button in the page header.
    /// This function checks the mode of entry 1.)EDITMODE  or  2.)CREATEMODE.
    /// If the page is in the CREATEMODE the function saves the XML file with file version set as 1.0 by default.(saved in EVO_FormVersions)
    /// The file and control details are saved(EVO_FormFields).
    /// If the page is in the EDITMODE the function checks.... 
    /// IF the existing xml file does not match with older xml file version set as 1 + older major version number by default (saved in EVO_FormVersions)
    /// The file and control details are saved(EVO_FormFields).
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void XMLButton_Click(object sender, EventArgs e)
    {
        FileVersionSave();
    }

    protected void FileVersionSave()
    {
        XmlDocument xCreatedXMLDoc = new XmlDocument();
        XmlDocument xExistingXMLDoc = new XmlDocument();
        XmlNode rootExistingNode = null;
        XmlNode rootCreatedNode = null;
        string fieldName = "";
        string fieldAlias = "";
        string fieldDisplayType = "";
        int controlID = 0;
        int positionID = 0;
        bool insertCtrlResult = false;
        bool fileCreated = false;
        string versionName = "1.0";
        int versionId = Convert.ToInt32(VersionIDHidden.Value);

        if (FileModeHidden.Value == "EDITMODE")
        {
            xExistingXMLDoc.InnerXml = ReadXMLHidden.Value;
            rootExistingNode = xExistingXMLDoc.SelectSingleNode("/FORMS");

            //versionName = xExistingXMLDoc.SelectSingleNode("/FORMS/@VersionName").Value.ToString();
            DesignManagement desObj = new DesignManagement();
            DataSet versionNameDataSet = new DataSet();
            versionNameDataSet = desObj.GetFormLastVersionName(Convert.ToInt32(FormIDHidden.Value));
            versionName = versionNameDataSet.Tables[0].Rows[0]["VersionName"].ToString();

            xCreatedXMLDoc.InnerXml = "<?xml version='1.0' encoding='utf-8'?><FORMS xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' FormID='" + FormIDHidden.Value + "' VersionName='" + versionName + "'>" + SaveXMLHidden.Value.Replace("&", "and") + "</FORMS>";
            rootCreatedNode = xCreatedXMLDoc.SelectSingleNode("/FORMS");

            //This code is to copy the existing data into the new for version without losing on existing data.
            for (int existCount = 0; existCount < rootExistingNode.ChildNodes.Count; existCount++)
            {
                if (rootExistingNode.ChildNodes[existCount].Name != "DataScript")
                {
                    for (int createdCount = 0; createdCount < rootCreatedNode.ChildNodes.Count; createdCount++)
                    {
                        //if (rootCreatedNode.ChildNodes[createdCount].ChildNodes[3].InnerText == rootExistingNode.ChildNodes[existCount].ChildNodes[3].InnerText)
                        //{
                        if (rootCreatedNode.ChildNodes[createdCount].Name != "DataScript")
                        {
                            if (rootExistingNode.ChildNodes[existCount].SelectSingleNode("Title") != null)
                            {
                                if (rootCreatedNode.ChildNodes[createdCount].SelectSingleNode("Title").InnerText == rootExistingNode.ChildNodes[existCount].SelectSingleNode("Title").InnerText)
                                {
                                    if (rootCreatedNode.ChildNodes[createdCount].Name == "DropDownList" || rootCreatedNode.ChildNodes[createdCount].Name == "ListBox" || rootCreatedNode.ChildNodes[createdCount].Name == "RadioButtonList" || rootCreatedNode.ChildNodes[createdCount].Name == "CheckBoxList")
                                    {
                                        if (rootExistingNode.ChildNodes[existCount].SelectSingleNode("LISTITEMS") != null)
                                        {
                                            rootCreatedNode.ChildNodes[createdCount].SelectSingleNode("LISTITEMS").InnerXml = rootExistingNode.ChildNodes[existCount].SelectSingleNode("LISTITEMS").InnerXml;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else
                {//Script to handle the DataScript issue and paste datascript values if they exist.
                    for (int createdCount = 0; createdCount < rootCreatedNode.ChildNodes.Count; createdCount++)
                    {
                        //if (rootCreatedNode.ChildNodes[createdCount].ChildNodes[3].InnerText == rootExistingNode.ChildNodes[existCount].ChildNodes[3].InnerText)
                        //{
                        if (rootCreatedNode.ChildNodes[createdCount].Name == "DataScript")
                        {
                            rootCreatedNode.ChildNodes[createdCount].SelectSingleNode("Array").InnerXml = rootExistingNode.ChildNodes[existCount].SelectSingleNode("Array").InnerXml;
                            rootCreatedNode.ChildNodes[createdCount].SelectSingleNode("IsUpdated").InnerXml = rootExistingNode.ChildNodes[existCount].SelectSingleNode("IsUpdated").InnerXml;
                        }
                    }
                }
            }


            if (rootCreatedNode.InnerXml != rootExistingNode.InnerXml)//check if there was any change in the form design.
            {
                string[] versionArray = new string[2];
                versionArray = versionName.Split('.');
                int minor = int.Parse(versionArray[1].ToString());
                int major = int.Parse(versionArray[0].ToString());

                if (minor >= 0 && minor <= 9)
                {
                    minor = minor + 1;
                }
                if (minor == 10)
                {
                    minor = 0;
                    major = major + 1;
                }
                versionName = major + "." + minor;


                //The below code is used to insert the formid, versionname, xmlfilename, xmlconfidid in the database.
                //formid is got from the querystring from form details page, versionname is from the file as above, xmlfilename is from above, config is constant(depends on EVO version).


                xCreatedXMLDoc.InnerXml = "<?xml version='1.0' encoding='utf-8'?><FORMS xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' FormID='" + FormIDHidden.Value + "' VersionName='" + versionName + "'>" + rootCreatedNode.InnerXml + "</FORMS>";

                string[] formNameArray = new string[2];
                formNameArray = FormNameHidden.Value.Replace(".xml", "").Split('_');
                //Validatefordependencyandprevref(xCreatedXMLDoc, "ListBox");
                //return;
                xCreatedXMLDoc.Save(Server.MapPath("../XML/" + formNameArray[0].ToString() + "_" + versionName + ".xml"));

                FormNameHidden.Value = formNameArray[0].ToString() + "_" + versionName + ".xml";

                fileCreated = true;

                if (fileCreated)
                {
                    versionId = DesignManagement.InsertFormVersion(int.Parse(FormIDHidden.Value), versionName, FormNameHidden.Value, userName);

                    if (versionId != null)
                    {
                        XmlNodeList controls = xCreatedXMLDoc.SelectNodes("FORMS");

                        for (int elementCnt = 0; elementCnt < controls.Count; elementCnt++)
                        {
                            XmlNode propertyNode = (XmlNode)controls[elementCnt];

                            for (int propCount = 0; propCount < propertyNode.ChildNodes.Count; propCount++)
                            {
                                XmlNode property = (XmlNode)propertyNode.ChildNodes[propCount];
                                if (property.Name != "DataScript")//OptScript Change
                                {
                                    fieldName = property["FieldID"].InnerText.Replace(' ', '_').ToString();
                                    fieldName = fieldName.Replace(property.Name.Replace("List", ""), "").ToString();
                                    fieldAlias = property["Title"].InnerText;
                                    if (property.Name != "ListBox")
                                    {
                                        fieldDisplayType = property.Name.Replace("List", "");
                                        if (property.Name == "CC1EmployeesDropDown")
                                        {
                                            fieldDisplayType = "DropDown";
                                            fieldName = fieldName.Replace("DropDown", "");
                                        }
                                        if (property.Name == "CC3EmployeesDropDown")
                                        {
                                            fieldDisplayType = "DropDown";
                                            fieldName = fieldName.Replace("DropDown", "");
                                        }
                                        if (property.Name == "TextBox1")
                                        {
                                            fieldDisplayType = "TextBox";
                                            fieldName = fieldName.Replace("TextBox1", "");
                                            fieldName = fieldName.Replace("TextBox", "");
                                        }

                                        if (property.Name == "GlobalMControl" || property.Name == "GlobalSControl")
                                        {
                                            fieldDisplayType = "DropDown";
                                            fieldName = fieldName.Replace("DropDown", "");
                                            if (property.Name == "GlobalMControl")
                                            {
                                                string dependentCtrlName = property["DependentID"].InnerText.Replace("DropDown", "");
                                                int dependentID = int.Parse(property["DependentCtrlID"].InnerText);
                                                positionID = propCount + 1;
                                                string depAlias = dependentCtrlName.Replace("gc_", "");
                                                int charPos = depAlias.IndexOf('_');
                                                depAlias = depAlias.Substring(charPos, depAlias.Length - 1);
                                                insertCtrlResult = DesignManagement.InsertFormControls(int.Parse(FormIDHidden.Value), dependentCtrlName, property["Title"].InnerText + depAlias, fieldDisplayType, versionId, dependentID, positionID, userName);
                                            }
                                        }
                                    }

                                    else
                                    {
                                        fieldName = fieldName.Replace("List", "");
                                        fieldDisplayType = property.Name;
                                    }
                                    controlID = int.Parse(property["ControlID"].InnerText.ToString());
                                    positionID = propCount + 1;
                                    insertCtrlResult = DesignManagement.InsertFormControls(int.Parse(FormIDHidden.Value), fieldName, fieldAlias, fieldDisplayType, versionId, controlID, positionID, userName);

                                }
                            }
                        }
                        DesignManagement.SetControlManagement(FormIDHidden.Value, versionId.ToString());
                    }
                    if (insertCtrlResult)
                    {
                        DesignManagement.SetDTMSControls(FormIDHidden.Value, versionId.ToString(), userName);
                        ManageSession.FormID = int.Parse(FormIDHidden.Value);
                        ManageSession.FormName = FormEndNameHidden.Value;
                        ManageSession.XmlFileName = FormNameHidden.Value + versionName + ".xml";
                        ManageSession.CategoryID = int.Parse(CategoryIDHidden.Value);
                        ManageSession.VersionID = versionId;
                        Response.Redirect("../Admin/DataManagement.aspx", true);

                    }
                }
            }
            else
            {
                ManageSession.FormID = int.Parse(FormIDHidden.Value);
                ManageSession.FormName = FormEndNameHidden.Value;
                ManageSession.XmlFileName = FormNameHidden.Value.Replace(".xml", "") + versionName + ".xml";
                ManageSession.CategoryID = int.Parse(CategoryIDHidden.Value);
                ManageSession.VersionID = versionId;
                Response.Redirect("../Admin/DataManagement.aspx", true);
            }
        }

        if (FileModeHidden.Value == "CREATEMODE")
        {
            xCreatedXMLDoc.InnerXml = "<?xml version='1.0' encoding='utf-8'?><FORMS xmlns:xsi='http://www.w3.org/2001/XMLSchema-instance' FormID='" + FormIDHidden.Value + "' VersionName='" + versionName + "'>" + SaveXMLHidden.Value.Replace("&", "and") + "</FORMS>";

            xCreatedXMLDoc.Save(Server.MapPath("../XML/" + FormNameHidden.Value.Replace(".xml", "") + "_" + versionName + ".xml"));
            fileCreated = true;

            if (fileCreated)
            {
                bool result = DesignManagement.UpdateFormVersion(int.Parse(FormIDHidden.Value), versionName, FormNameHidden.Value.Replace(".xml", "") + "_" + versionName + ".xml", userName, Convert.ToInt32(VersionIDHidden.Value));

                if (Convert.ToInt32(VersionIDHidden.Value) != 0 && result != false)
                {
                    XmlNodeList controls = xCreatedXMLDoc.SelectNodes("FORMS");

                    for (int elementCnt = 0; elementCnt < controls.Count; elementCnt++)
                    {
                        XmlNode propertyNode = (XmlNode)controls[elementCnt];

                        for (int propCount = 0; propCount < propertyNode.ChildNodes.Count; propCount++)
                        {
                            XmlNode property = (XmlNode)propertyNode.ChildNodes[propCount];

                            if (property.Name != "DataScript")//OptScript Change
                            {
                                fieldName = property["FieldID"].InnerText.Replace(' ', '_').ToString();
                                fieldName = fieldName.Replace(property.Name.Replace("List", ""), "").ToString();
                                fieldAlias = property["Title"].InnerText;
                                if (property.Name != "ListBox")
                                {
                                    fieldDisplayType = property.Name.Replace("List", "");
                                    if (property.Name == "CC1EmployeesDropDown")
                                    {
                                        fieldDisplayType = "DropDown";
                                        fieldName = fieldName.Replace("DropDown", "");
                                    }
                                    if (property.Name == "CC3EmployeesDropDown")
                                    {
                                        fieldDisplayType = "DropDown";
                                        fieldName = fieldName.Replace("DropDown", "");
                                    }
                                    if (property.Name == "TextBox1")
                                    {
                                        fieldDisplayType = "TextBox";
                                        fieldName = fieldName.Replace("TextBox1", "");
                                        fieldName = fieldName.Replace("TextBox", "");
                                    }
                                    if (property.Name == "GlobalMControl" || property.Name == "GlobalSControl")
                                    {
                                        fieldDisplayType = "DropDown";
                                        fieldName = fieldName.Replace("DropDown", "");
                                        if (property.Name == "GlobalMControl")
                                        {

                                            string dependentCtrlName = property["DependentID"].InnerText.Replace("DropDown", "");
                                            int dependentID = int.Parse(property["DependentCtrlID"].InnerText);
                                            positionID = propCount + 1;
                                            string depAlias = dependentCtrlName.Replace("gc_", "");
                                            int charPos = depAlias.IndexOf('_');
                                            depAlias = depAlias.Substring(charPos, depAlias.Length - 1);
                                            insertCtrlResult = DesignManagement.InsertFormControls(int.Parse(FormIDHidden.Value), dependentCtrlName, property["Title"].InnerText + depAlias, fieldDisplayType, versionId, dependentID, positionID, userName);


                                            //string dependentCtrlName = property["DependentID"].InnerText.Replace("DropDown", "");
                                            //int dependentID = int.Parse(property["DependentCtrlID"].InnerText);
                                            //positionID = propCount + 1;
                                            //insertCtrlResult = DesignManagement.InsertFormControls(int.Parse(FormIDHidden.Value), dependentCtrlName, positionID.ToString() + dependentCtrlName, fieldDisplayType, Convert.ToInt32(VersionIDHidden.Value), dependentID, positionID, userName);
                                        }
                                    }
                                }

                                else
                                {
                                    fieldName = fieldName.Replace("List", "");
                                    fieldDisplayType = property.Name;
                                }
                                controlID = int.Parse(property["ControlID"].InnerText.ToString());
                                positionID = propCount + 1;
                                insertCtrlResult = DesignManagement.InsertFormControls(int.Parse(FormIDHidden.Value), fieldName, fieldAlias, fieldDisplayType, Convert.ToInt32(VersionIDHidden.Value), controlID, positionID, userName);
                            }
                        }
                    }
                }
                DesignManagement.SetControlManagement(FormIDHidden.Value, versionId.ToString());
                if (insertCtrlResult)
                {
                    DesignManagement.SetDTMSControls(FormIDHidden.Value, versionId.ToString(), userName);

                    ManageSession.FormID = int.Parse(FormIDHidden.Value);
                    ManageSession.FormName = FormEndNameHidden.Value;
                    ManageSession.XmlFileName = FormNameHidden.Value.Replace(".xml", "") + versionName + ".xml";
                    ManageSession.CategoryID = int.Parse(CategoryIDHidden.Value);
                    ManageSession.VersionID = Convert.ToInt32(VersionIDHidden.Value);
                    Response.Redirect("../Admin/DataManagement.aspx", true);
                }
            }
        }
    }

    public bool Validatefordependencyandprevref(XmlDocument doc, string controltype)
    {
        bool result = false;
        //XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controltype);

        //DataTable deptdt = new DataTable();
        //deptdt.Columns.Add("ControlName", typeof(string));
        //deptdt.Columns.Add("Dependent", typeof(string));
        //deptdt.Columns.Add("PrevRef", typeof(string));
        //string controlsname = "";
        //for (int i = 0; i < rootNodeList.Count; i++)
        //{
        //    XmlNode dropDownNode = (XmlNode)rootNodeList[i];

        //    DataRow dr = deptdt.NewRow();
        //    for (int j = 0; j < dropDownNode.ChildNodes.Count; j++)
        //    {
        //        XmlNode dropDownChildNode = (XmlNode)dropDownNode.ChildNodes[j];

        //        if (dropDownChildNode.Name == "FieldID")
        //        {

        //            dr["ControlName"] = dropDownChildNode.InnerText;


        //        }


        //        if (dropDownChildNode.Name == "DependentID")
        //        {
        //            dr["Dependent"] = dropDownChildNode.InnerText;

        //        }

        //        if (dropDownChildNode.Name == "PrevRef")
        //        {
        //            dr["PrevRef"] = dropDownChildNode.InnerText;

        //        }

        //    }
        //    if (dr["Dependent"] != "" || dr["PrevRef"] != "")
        //    {
        //        deptdt.Rows.Add(dr);
        //        deptdt.AcceptChanges();
        //    }
        //}

        ////var dValue = (from row in deptdt.AsEnumerable()
        ////              select new
        //// {
        ////     Dependent =  row.Field<string>("Dependent")
        //// }).ToList();

        ////DataRow[] results = dValue.Select("Count(Dependent)");




        //////DataRow[] results = deptdt.Columns["Dependent"].Table.Select("Count(Dependent)");
        ////if (results.Count() - 1 < deptdt.Rows.Count)
        ////{ 

        ////}

        //DataView Dv = new DataView(deptdt);

        //DataTable Dt = Dv.ToTable(false, "Dependent");
        ////DataRow[] results = Dt.Select("Count(Dependent)");


        ////deptdt
        return result;
    }

    [System.Web.Services.WebMethod]
    public static string GetDTMSControl(string FormId)
    {
        string result = "";
        Forms objForms = new Forms();
        DataSet dscontrol = new DataSet();
        dscontrol = DesignManagement.GetDTMSControls(FormId, dscontrol);
        if (dscontrol.Tables.Count > 0)
        {
            if (dscontrol.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i <= dscontrol.Tables[0].Rows.Count - 1; i++)
                {
                    if (result == "")
                    {
                        result = dscontrol.Tables[0].Rows[i]["ControlName"].ToString();
                    }
                    else
                    {
                        result = result + "," + dscontrol.Tables[0].Rows[i]["ControlName"].ToString();
                    }
                }
            }
        }
        return result;

    }
}
