﻿using System;
using System.Data;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;
using System.Xml;
using System.Xml.Linq;
using EVOLib;
using System.Collections;
using System.Web.Security;
using H3GS.Web.Security;

public partial class Admin_DataManagement : EvoGeneral
{
    string controlToChange = "";
    XmlDocument doc;
    XDocument xmlDoc = new XDocument();
    string FileName;
    string CallTypeArrayText = "";
    int cnt = 0;
    string controlType = "";

    string BasicArrayText = "";
    string TempHoldDrpNames = "";

    int frmID;
    string frmName;
    string catId;
    string vId;
    string fMode;
    int NoOfDependents = 0;
    int Flag;

    ImageButton imgNext;

    public string NtName;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!(Page.IsPostBack))
        {
            Server.ScriptTimeout = 30000;

            ObjUserRights.VersionId = int.Parse(VersionIDHidden.Value);
            ObjUserRights.UserID = RetrieveUserID(userName);
            ObjUserRights.FormId = int.Parse(FormIDHidden.Value);

            IsValidUser();
            IsValidPageEntry();

            if (CategoryIDHidden.Value != "4")
            {


                GetHiddenControl();
                GetAssignHiddenControl(0);

            }


            AddJavascript();


            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "CallTypeArray", JavaScriptTextBox.Text, true);


        }

    }

    // Checking if user have entered thr' proper channels. :)
    private void IsValidPageEntry()
    {
        if (FormIDHidden.Value == "0")
        {
            Response.Redirect("../AccessDenied.aspx");
        }
    }

    private void AddJavascript()
    {
        //txtValue.Attributes.Add("onkeyup", "return CheckFieldJunkCharsDataManagement('" + txtValue.ClientID + "',0)");
        //txtWrapNote.Attributes.Add("onkeyup", "return CheckFieldJunkCharsDataManagement('" + txtWrapNote.ClientID + "',0)");
        //txtWrapNote.Attributes.Add("onkeypress", "return CheckValidLength(document.getElementById('" + txtWrapNote.ClientID + "'),'500', false)");
        //txtWrapNote.Attributes.Add("onpaste", "return CheckValidLength(document.getElementById('" + txtWrapNote.ClientID + "'),'500', true)");

        //txtOptionTooltip.Attributes.Add("onkeyup", "return CheckFieldJunkCharsDataManagement('" + txtOptionTooltip.ClientID + "',0)");
        //txtOptionTooltip.Attributes.Add("onkeypress", "return CheckValidLength(document.getElementById('" + txtOptionTooltip.ClientID + "'),'500', false)");
        //txtOptionTooltip.Attributes.Add("onpaste", "return CheckValidLength(document.getElementById('" + txtOptionTooltip.ClientID + "'),'500', true)");

        //btnAdd.Attributes.Add("onclick", "return ValidateDataManagement('btnAdd', '" + txtValue.ClientID + "','" + txtWrapNote.ClientID + "','" + txtOptionTooltip.ClientID  + "');");
        //btnUpdate.Attributes.Add("onclick", "return ValidateDataManagement('btnUpdate', '" + txtValue.ClientID + "','" + txtWrapNote.ClientID + "','" + txtOptionTooltip.ClientID + "');");
    }

    private void GetFileName()
    {
        frmID = ManageSession.FormID;
        frmName = ManageSession.FormName;
        string[] fName = frmName.Split('_');
        frmName = fName[0];
        catId = ManageSession.CategoryID.ToString();
        vId = ManageSession.VersionID.ToString();
        fMode = ManageSession.FormMode.ToString();
        FormIDHidden.Value = frmID.ToString(); //ManageSession.FormID.ToString(); //"1"; 
        FormNameHidden.Value = frmName; //"MBB Call Logger";
        CategoryIDHidden.Value = catId; //"1"; 
        VersionIDHidden.Value = vId; //"1";

        FileModeHidden.Value = fMode;

        GetFileNameFromDb();    // To retrieve XML filename from DB.
    }

    protected override void OnInit(EventArgs e)
    {
        if (!(Page.IsPostBack))
        {
            GetFileName();
        }
        GenerateMasterClick();
    }

    private void GenerateMasterClick()
    {
        Label lblModule = (Label)Master.FindControl("lblModule");
        lblModule.Text = "Control Management";

        Label lblForm = (Label)Master.FindControl("lblForm");
        lblForm.Text = FormNameHidden.Value;
        ContentPlaceHolder ctPlaceHolder = (ContentPlaceHolder)Master.FindControl("head");
        ImageButton imgSel = (ImageButton)ctPlaceHolder.FindControl("img4");
        imgSel.ImageUrl = "../images/icon_4_rol.jpg";

        imgNext = (ImageButton)ctPlaceHolder.FindControl("img6");
        imgNext.CssClass = "ImageButtonLinkCursor";
        imgNext.Enabled = true;
        // If IN EDIT MODE, ALLOW SESSION VARIABLES FOR NAVIGATION.
        imgNext.Click += new ImageClickEventHandler(Next_Click);

        ImageButton imgBtnSave = (ImageButton)ctPlaceHolder.FindControl("imgSave");
        imgBtnSave.Click += new ImageClickEventHandler(Save_Click);

        ImageButton imgBtnHome = (ImageButton)ctPlaceHolder.FindControl("imgHome");
        imgBtnHome.Click += new ImageClickEventHandler(Home_Click);
    }

    private void GetFileNameFromDb()
    {
        try
        {
            DataSet ds;
            ObjUserRights.FormId = frmID;
            ObjUserRights.VersionId = int.Parse(vId);

            ds = ObjUserRights.GetXMLFileName();

            if (ds.Tables[0].Rows.Count > 0)
            {
                string FiName = ds.Tables[0].Rows[0]["XMLFileName"].ToString();
                ReadXMLHidden.Value = FiName;
                Session["FileName"] = FiName;
            }
            else
            {
                lblErr.Text = "Could not find the XML file";
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = "Could not find the XML file" + ex.Message;
        }
    }

    EvoAdminUsersRights ObjUserRights = new EvoAdminUsersRights();
    // Checking if the user is valid and have rights to manage the form or no.
    private void IsValidUser()
    {
        try
        {
            Boolean IsValid = false;

            IsValid = ObjUserRights.ValidateAdminManageUser();

            if (!IsValid)
            {
                //Response.Write("Redirecting to access denied");
                Response.Redirect("../AccessDenied.aspx", true);
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = "No data found for this login" + ex.Message;
        }
    }

    private void ReadNLoadFile()
    {
        try
        {
            //if (doc != null)
            //{
            //    //((IDisposable)doc).Dispose();
            //    doc = null;

            //}
            FileName = Server.MapPath("..\\XML\\" + ReadXMLHidden.Value);
            doc = new XmlDocument();
            xmlDoc = XDocument.Load(FileName);
            doc.Load(FileName);
        }
        catch (Exception ex)
        {

        }

    }

    /// <summary>
    /// Function to pass session variables to the next page.
    /// </summary>
    private void GoToNextForm()
    {
        ManageSession.FormID = int.Parse(FormIDHidden.Value);
        ManageSession.FormName = FormNameHidden.Value;
        ManageSession.XmlFileName = ReadXMLHidden.Value;
        ManageSession.CategoryID = int.Parse(CategoryIDHidden.Value);
        ManageSession.VersionID = int.Parse(VersionIDHidden.Value);
        ManageSession.FormMode = FileModeHidden.Value;
    }

    protected void Save_Click(object sender, EventArgs e)
    {
        GoToNextForm();
        Response.Redirect("../Admin/RightsManagement.aspx", true);
    }

    protected void Next_Click(object sender, EventArgs e)
    {
        if (FileModeHidden.Value.ToUpper() == "EDITMODE")
        {
            GoToNextForm();
            Response.Redirect("../Admin/RightsManagement.aspx", true);
        }
    }

    protected void Home_Click(object sender, EventArgs e)
    {
        GoToNextForm();
        Response.Redirect("../Admin/Default.aspx", true);
    }

    private void ClearMessages()
    {
        lblErr.Text = "";
        lblSuccess.Text = "";
    }

    private void ClearHiddenValues()
    {
        SelectedValue.Value = "0";

        //txtValue.Text = "";
        //txtWrapNote.Text = "";
        //txtOptionTooltip.Text = ""; 

        SelectedItemOldValue.Value = "";
        SelectedControl.Value = "";
        selectedField.Value = "";
        SelectedDepIdFromXml.Value = "0";
        //ddlTemplate.SelectedIndex = -1;
    }


    // A function which retrieves the control data and redirects to previous control as well.
    private void GetPrevRefData(string RefObj, string DependentOnId, int datafor)
    {
        string PrevCtrl = "";
        string FName = "";
        string IsManageable = "";
        bool isSuccess = false;
        string DependentId = "";
        string LabelText = "";
        string Dependency = "";
        string isWrapTrueFalse = "";
        string DependentID = "";

        ReadNLoadFile();

        NoOfDependents += 1;
        NoOfDependentsHidden.Value = NoOfDependents.ToString();

        Label lblCtrl = new Label();
        ListBox ddlCtrl = new ListBox();
        ListBox radCtrl = new ListBox();
        ListBox lstCtrl = new ListBox();
        ListBox chkCtrl = new ListBox();
        tdControls.Visible = true;
        tdhtohcontrols.Visible = true;
        lblCtrl.Text = "";



        if (controlType == "DropDownList")
        {


            ddlCtrl.ID = "ddlCtrl" + RefObj; //cnt;
        }
        else if (controlType == "RadioButtonList")
        {
            radCtrl.ID = "radCtrl" + RefObj;
        }
        else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
        {
            lstCtrl.ID = "lstCtrl" + RefObj;
        }

        if (controlType == "ListBox")
        {


            var list = from c in xmlDoc.Descendants("ListBox")
                       select new
                       {
                           IsWrap = c.Element("IsWrap").Value,
                           Name = c.Element("Label").Element("Text").Value
                       };
            foreach (var e in list)
            {
                if (e.Name.ToString() == drpFrom.SelectedItem.Text)
                {

                }
            }

            if ((DependentOnId.Trim() == "") || (DependentOnId.Trim() == null)) // If previous control's data NOT selected.
            {
                DataSet dsDataItem = new DataSet();
                dsDataItem.Tables.Add();
                dsDataItem.Tables.Add();

                var q = from c in xmlDoc.Descendants("ListBox")
                        where c.Element("FieldID").Value == RefObj //controlId
                        select new
                        {
                            LabelText = c.Element("Text"),
                            PreviousRef = c.Element("PrevRef"),
                            DependentID = c.Element("DependentID"),
                            isWrapTrueFalse = c.Element("IsWrap"),
                            ListOfItems = c.Element("LISTITEMS").Descendants("LISTITEM")

                        };

                foreach (var obj in q)
                {
                    //PrevRefControl = obj.PreviousRef.Value;
                    PrevCtrl = obj.PreviousRef.Value;
                    DependentId = obj.DependentID.Value;
                    //DependentControl = obj.DependentID.Value;

                    var ListItems = obj.ListOfItems;

                    if (PrevCtrl.Trim() != "")
                    {
                        GetPrevRefData(PrevCtrl.Trim(), "", datafor);
                    }
                    else
                    {
                        foreach (var ele in ListItems)
                        {
                            string wrapNoteValue;
                            if (ele.Attribute("WrapNote") == null)
                            {
                                wrapNoteValue = "";
                            }
                            else
                            {
                                wrapNoteValue = ele.Attribute("WrapNote").Value;
                            }

                            string optionTooltip;
                            if (ele.Attribute("OptionTooltip") == null)
                            {
                                optionTooltip = "";
                            }
                            else
                            {
                                optionTooltip = ele.Attribute("OptionTooltip").Value;
                            }

                            string template;
                            if (ele.Attribute("Template") == null)
                            {
                                template = "";
                            }
                            else
                            {
                                template = ele.Attribute("Template").Value;
                            }


                            string EleValue = ele.Attribute("Id").Value + "," + ele.Value + "," + ele.Attribute("DependentOn").Value + "," + wrapNoteValue + "," + optionTooltip + "," + template;
                            ListItem lst = new ListItem(ele.Value, EleValue);
                            lstCtrl.Items.Add(lst);
                        }
                    }
                }
            }
            else
            {
                var q = from c in xmlDoc.Descendants("ListBox")
                        where c.Element("FieldID").Value == RefObj
                        select new
                        {
                            ThisRecordId = c.Element("Id"),
                            LabelText = c.Element("Text"),
                            PreviousRef = c.Element("PrevRef"),
                            DependentID = c.Element("DependentID"),
                            WrapNote = c.Element("WrapNote"),
                            isWrapTrueFalse = c.Element("IsWrap"),
                            ListOfItems = from items in c.Element("LISTITEMS").Descendants("LISTITEM")
                                          where items.Attribute("DependentOn").Value == DependentOnId
                                          select items
                        };

                if (PrevCtrl.Trim() != "")
                {
                    GetPrevRefData(PrevCtrl.Trim(), "", datafor);
                }

                foreach (var obj in q)
                {
                    PrevCtrl = obj.PreviousRef.Value;
                    DependentId = obj.DependentID.Value;
                    var ListItems = obj.ListOfItems;

                    if (PrevCtrl.Trim() != "")
                    {
                        GetPrevRefData(PrevCtrl.Trim(), "", datafor);
                    }
                    else
                    {
                        foreach (var ele in ListItems)
                        {
                            //string EleValue = ThisRecordId + "," + ele.Value + "," + DependentId;
                            string wrapNoteValue;
                            if (ele.Attribute("WrapNote") == null)
                                wrapNoteValue = "";
                            else
                                wrapNoteValue = ele.Attribute("WrapNote").Value;

                            string optionTooltip;
                            if (ele.Attribute("OptionTooltip") == null)
                            {
                                optionTooltip = "";
                            }
                            else
                            {
                                optionTooltip = ele.Attribute("OptionTooltip").Value;
                            }

                            string template;
                            if (ele.Attribute("Template") == null)
                            {
                                template = "";
                            }
                            else
                            {
                                template = ele.Attribute("Template").Value;
                            }

                            string EleValue = ele.Attribute("Id").Value + "," + ele.Value + "," + ele.Attribute("DependentOn").Value + "," + wrapNoteValue + "," + optionTooltip + "," + template;
                            ListItem lst = new ListItem(ele.Value, EleValue);
                            //ListItem lst = new ListItem(ele.Value, ele.Attribute("Id").Value);
                            lstCtrl.Items.Add(lst);
                        }
                    }
                }
            }
            if (datafor == 1)
            {
                tdhtohcontrols.Controls.Add(lstCtrl);
            }
            else
            {
                tdControls.Controls.Add(lstCtrl);
            }


            string SelectedControl = "lstCtrl" + drpFrom.SelectedValue;
            if (lstCtrl.ID.Trim() != SelectedControl.Trim())
            {
                if (DependentId.Trim() != "")
                {
                    lstCtrl.Attributes.Add("onchange", "FillSelectedValues('" + lstCtrl.ID + "', '" + DependentId + "','" + ReadXMLHidden.Value + "','" + NoOfDependents + "')");
                }
                else
                {
                    lstCtrl.SelectionMode = ListSelectionMode.Multiple;
                }
            }
            else
            {
                //lstCtrl.Attributes.Add("onchange", "EditDeleteItem('" + lstCtrl.ID + "','ListBox')");

            }


            DependentId = "";
        }   // If SELECTED CONTROL TYPE IS ANYTHING THAN LISTBOX THEN.
        else
        {
            XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controlType);
            // Reading all the nodes.
            //  while (iterator.MoveNext())
            //        {



            for (int i = 0; i < rootNodeList.Count; i++)
            {
                XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                int countElements = 0;

                PrevCtrl = "";
                FName = "";
                IsManageable = "";
                isSuccess = false;
                LabelText = "";

                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if (dropDownNode.ChildNodes[y].Name == "Title")
                    {
                        LabelText = dropDownNode.ChildNodes[y].FirstChild.Value;
                    }
                    else if (dropDownNode.ChildNodes[y].Name == "IsManageable")
                    {
                        IsManageable = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    else if (dropDownNode.ChildNodes[y].Name == "FieldID")
                    {
                        FName = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    else if (dropDownNode.ChildNodes[y].Name == "PrevRef")
                    {
                        PrevCtrl = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    else if (dropDownNode.ChildNodes[y].Name == "DependentID")
                    {
                        DependentId = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    else if (dropDownNode.ChildNodes[y].Name == "Dependency")
                    {
                        Dependency = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    else if (dropDownNode.ChildNodes[y].Name == "IsWrap")		// If IsWrap Is true, then dont show add wrap notes for this field here, as the wrap notes are already added in design management section
                    {
                        if (((controlType == "ListBox") || (controlType == "DropDownList")))
                        {
                            if (LabelText == drpFrom.SelectedItem.Text)
                            {

                            }
                        }
                        else
                        {

                        }
                    }



                    if ((IsManageable == "True") && (FName == RefObj) && (countElements == 5))  //&& (PrevCtrl != "")
                    {
                        if (PrevCtrl != "")
                        {
                            SelectedControl.Value = "Parent";
                        }

                        // lblCtrl.ID = "lbl" + RefObj;
                        // lblCtrl.Text = LabelText + "&nbsp;";

                        if (dropDownNode.ChildNodes[y].Name == "LISTITEMS")
                        {
                            XmlNodeList listItems = dropDownNode.ChildNodes[y].ChildNodes;

                            // Creating an array. This will be used in javascript n registered via code
                            CallTypeArrayText += "var Array" + (FName).ToString() + " = new Array( " + listItems.Count + " );\n";
                            Session["Count"] = listItems.Count.ToString();


                            for (int l = 0; l < listItems.Count; l++)
                            {
                                string dependentOn = "";
                                string ListItemVal = "";
                                string ListItemText = "";
                                string WrapNote = "";
                                string OptionTooltip = "";
                                string Template = "";


                                ListItemText = listItems.Item(l).InnerText;
                                ListItemVal = listItems.Item(l).Attributes["Id"].Value;

                                string wrapNoteValue;
                                if (listItems.Item(l).Attributes["WrapNote"] == null)
                                    wrapNoteValue = "";
                                else
                                    wrapNoteValue = listItems.Item(l).Attributes["WrapNote"].Value;

                                if (listItems.Item(l).Attributes["OptionTooltip"] == null)
                                    OptionTooltip = "";
                                else
                                    OptionTooltip = listItems.Item(l).Attributes["OptionTooltip"].Value;

                                if (listItems.Item(l).Attributes["Template"] == null)
                                    Template = "";
                                else
                                    Template = listItems.Item(l).Attributes["Template"].Value;

                                WrapNote = wrapNoteValue; //listItems.Item(l).Attributes["WrapNote"].Value;  
                                if ((listItems.Item(l).Attributes["DependentOn"].Value.Trim() != "") || (listItems.Item(l).Attributes["DependentOn"].Value.Trim() == "0"))
                                {
                                    dependentOn = listItems.Item(l).Attributes["DependentOn"].Value;

                                    if ((dependentOn == "") || (dependentOn == null))
                                    {
                                        dependentOn = "0";
                                    }
                                    CallTypeArrayText += "if (Array" + (FName).ToString() + "[" + dependentOn + "] ==null) "
                                                 + "Array" + (FName).ToString() + "[" + dependentOn + "] = new Array();\n";

                                    CallTypeArrayText += "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "]= new Array('" + ListItemText + "," + WrapNote + "," + OptionTooltip + "," + Template + "');\n";
                                }

                                if ((PrevCtrl == ""))
                                {
                                    ListItem lst = new ListItem();
                                    lst.Text = ListItemText;
                                    lst.Value = ListItemVal + "," + ListItemText + "," + dependentOn;

                                    if (controlType == "DropDownList")
                                    {
                                        if (listItems.Item(l).Attributes["WrapNote"] == null)
                                            wrapNoteValue = "";
                                        else
                                            wrapNoteValue = listItems.Item(l).Attributes["WrapNote"].Value;


                                        if (listItems.Item(l).Attributes["OptionTooltip"] == null)
                                            OptionTooltip = "";
                                        else
                                            OptionTooltip = listItems.Item(l).Attributes["OptionTooltip"].Value;

                                        if (listItems.Item(l).Attributes["Template"] == null)
                                            Template = "";
                                        else
                                            Template = listItems.Item(l).Attributes["Template"].Value;

                                        lst.Value += "," + wrapNoteValue + "," + OptionTooltip + "," + Template; //"," + listItems.Item(l).Attributes["WrapNote"].Value;
                                        ddlCtrl.Items.Add(lst);

                                        if ((ddlCtrl.ID == selectedField.Value.Trim()) && (ListItemVal == SelectedValue.Value))
                                        {

                                            ddlCtrl.Attributes.Add("onfocusin", "javascript:PopulateNew('" + ddlCtrl.ID + "', 'ddlCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                            ddlCtrl.SelectedIndex = l;
                                            ScriptManager m1 = (ScriptManager)Master.FindControl("ScriptManager1");
                                            m1.SetFocus(ddlCtrl);
                                        }
                                    }
                                    else if (controlType == "RadioButtonList")
                                    {
                                        radCtrl.Items.Add(lst);
                                    }
                                    else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                                    {
                                        lstCtrl.Items.Add(lst);
                                        if ((lstCtrl.ID == selectedField.Value.Trim()) && (ListItemVal == SelectedValue.Value))
                                        {
                                            lstCtrl.Attributes.Add("onfocusin", "javascript:PopulateNew('" + lstCtrl.ID + "', 'lstCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                            lstCtrl.SelectedIndex = l;
                                            ScriptManager m1 = (ScriptManager)Master.FindControl("ScriptManager1");
                                            m1.SetFocus(lstCtrl);
                                        }
                                    }
                                }
                                // if ((DependentId == ""))
                                // {
                                string[] selectedFName = null;

                                if (datafor == 1)
                                {
                                    selectedFName = ddlhiddentohiddencontrolvalues.SelectedItem.Value.Split(',');
                                }
                                else
                                {
                                    selectedFName = drpFrom.SelectedItem.Value.Split(',');
                                }
                                string Fnamenew = "";
                                if (selectedFName.Length > 0)
                                {
                                    Fnamenew = selectedFName[1];
                                }

                                if (FName != Fnamenew)
                                {
                                    if (controlType == "DropDownList")
                                    {
                                        ddlCtrl.Attributes.Add("onchange", "PopulateNew('" + ddlCtrl.ID + "', 'ddlCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                    }
                                    else if (controlType == "RadioButtonList")
                                    {
                                        radCtrl.Attributes.Add("onclick", "PopulateNew('" + radCtrl.ID + "', 'radCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                    }
                                    else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                                    {
                                        lstCtrl.Attributes.Add("onchange", "PopulateNew('" + lstCtrl.ID + "', 'lstCtrl" + DependentId + "', Array" + DependentId + ",'', '" + NoOfDependents + "')");
                                    }
                                }
                                else
                                {
                                    if (controlType == "DropDownList")
                                    {
                                        ddlCtrl.SelectionMode = ListSelectionMode.Multiple;
                                    }
                                    else if (controlType == "RadioButtonList")
                                    {

                                        radCtrl.SelectionMode = ListSelectionMode.Multiple;
                                    }
                                    else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                                    {

                                        lstCtrl.SelectionMode = ListSelectionMode.Multiple;
                                    }
                                }

                                //}
                            }




                            cnt = cnt + 1;
                            if (PrevCtrl != "")
                            {
                                GetPrevRefData(PrevCtrl, "", datafor);
                            }
                            //lblCtrl.Width = 90;
                            //tdControls.Controls.Add(lblCtrl);

                            if (controlType == "DropDownList")
                            {

                                if (datafor == 1)
                                {
                                    tdhtohcontrols.Controls.Add(ddlCtrl);
                                }
                                else
                                {
                                    tdControls.Controls.Add(ddlCtrl);
                                }
                                ddlCtrl.Attributes.Add("runat", "server");

                            }
                            else if (controlType == "RadioButtonList")
                            {
                                if (datafor == 1)
                                {
                                    tdhtohcontrols.Controls.Add(radCtrl);
                                }
                                else
                                {
                                    tdControls.Controls.Add(radCtrl);
                                }

                                radCtrl.Attributes.Add("runat", "server");
                            }
                            else if ((controlType == "ListBox") || (controlType == "CheckBoxList"))
                            {
                                //tdControls.Controls.Add(lstCtrl);
                                if (datafor == 1)
                                {
                                    tdhtohcontrols.Controls.Add(lstCtrl);
                                }
                                else
                                {
                                    tdControls.Controls.Add(lstCtrl);
                                }
                                lstCtrl.Attributes.Add("runat", "server");
                            }
                        }
                        else
                        {
                            isSuccess = false;
                        }
                    }
                    else
                    {
                        if (countElements == 5)
                        {
                            y = dropDownNode.ChildNodes.Count;
                        }
                    }
                    if (isSuccess)
                    {
                        y = dropDownNode.ChildNodes.Count;
                        i = rootNodeList.Count;
                    }
                }
            }
        }
    }





    protected void drpSelectControl_SelectedIndexChanged(object sender, EventArgs e)
    {
        //ClearMessages();
        //controlType = drpSelectControl.SelectedValue;
        //BindDropdowns(controlType);
        //EnableActionButtons();
    }





    // This function is used to check if there are any dependencies set on any controls.
    // If dependency is set, the Optimise Script Button will be enabled.


    private void EnableActionButtons()
    {
        //btnAdd.Enabled = true;
        //btnDelete.Enabled = true;
        //btnUpdate.Enabled = true;

        //btnAdd.ImageUrl = "~/Images/but_Add.jpg";
        //btnDelete.ImageUrl = "~/Images/but_Delete.jpg";
        //btnUpdate.ImageUrl = "~/Images/but_update.jpg";

    }

    private void BindDropdowns(string ctrlType)
    {
        // Reading and loading XML file
        ReadNLoadFile();

        // Empty control
        drpFrom.Items.Clear();

        // Checking the XML File and retrieving all the Dropdown contrls available in the file.
        XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + ctrlType);

        for (int i = 0; i < rootNodeList.Count; i++)
        {
            XmlNode dropDownNode = (XmlNode)rootNodeList[i];
            XmlNode ndIsHide = dropDownNode.SelectSingleNode("IsHide");
            XmlNode ndFieldID = dropDownNode.SelectSingleNode("FieldID");
            XmlNode ndtxt = dropDownNode.SelectSingleNode("Label").SelectSingleNode("Text");
            if (ndIsHide.InnerText == "False")
            {
                ListItem lst = new ListItem(ndtxt.InnerText, ndFieldID.InnerText);

                drpFrom.Items.Add(lst);
            }
        }
        drpFrom.Items.Insert(0, "-- Select --");
    }

    public bool TemplateAlreadyNotAssigned()
    {
        return true;
    }

    // Adding item to control
    protected void btnAdd_Click(object sender, ImageClickEventArgs e)
    {
        // lblstep.Text = SelectedValue.Value;
        string test = tdControls.ToString();

    }







    /// <summary>
    /// Generate Array for dependent controls.
    /// </summary>
    /// <param name="RefObj"></param>
    /// <param name="ctrlType"></param>
    private void GenerateData(string RefObj, string ctrlType)
    {
        string PrevCtrl = "";
        string FName = "";
        string IsManageable = "";
        bool isSuccess = false;
        string DependentId = "";
        string LabelText = "";

        //** if (!TempHoldDrpNames.ToUpper().Contains(RefObj.ToUpper()))
        //**{
        TempHoldDrpNames += RefObj + ",";

        try
        {
            //**LoadXMLFile();
            //Commented by Koshal to avoid reloading of XML file
            // ReadNLoadFile();
            XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + ctrlType);
            DropDownList ddlCtrl = new DropDownList();
            ListBox lbCtrl = new ListBox();

            for (int i = 0; i < rootNodeList.Count; i++)
            {
                XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                int countElements = 0;
                PrevCtrl = "";
                FName = "";
                IsManageable = "";
                isSuccess = false;
                LabelText = "";

                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if (dropDownNode.ChildNodes[y].Name == "label")
                    {
                        LabelText = dropDownNode.ChildNodes[y].FirstChild.Value;
                    }
                    if (dropDownNode.ChildNodes[y].Name == "IsManageable")
                    {
                        IsManageable = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    if (dropDownNode.ChildNodes[y].Name == "FieldID")
                    {
                        FName = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    if (dropDownNode.ChildNodes[y].Name == "PrevRef")
                    {
                        PrevCtrl = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }
                    if (dropDownNode.ChildNodes[y].Name == "DependentID")
                    {
                        DependentId = dropDownNode.ChildNodes[y].InnerText.Trim();
                        countElements = countElements + 1;
                    }

                    if ((IsManageable == "True") && (FName == RefObj))  //&& (PrevCtrl != "")
                    {
                        if (dropDownNode.ChildNodes[y].Name == "LISTITEMS")
                        {
                            ContentPlaceHolder ControlHldr = (ContentPlaceHolder)this.Page.Master.FindControl("ContentPlaceHolder1");
                            Control ctrl;
                            ctrl = ControlHldr.FindControl(RefObj);

                            XmlNodeList listItems = dropDownNode.ChildNodes[y].ChildNodes;

                            // Creating an array. This will be used in javascript n registered via code
                            BasicArrayText += "var Array" + (FName).ToString() + " = new Array( " + listItems.Count + " );\n";

                            for (int l = 0; l < listItems.Count; l++)
                            {
                                string dependentOn = "";
                                string ListItemVal = "";
                                string ListItemText = "";
                                string TemplateID = "0";

                                ListItemText = listItems.Item(l).InnerText;
                                ListItemVal = listItems.Item(l).Attributes["Id"].Value;

                                if (listItems.Item(l).Attributes["Template"] != null && listItems.Item(l).Attributes["Template"].Value != "")
                                    TemplateID = listItems.Item(l).Attributes["Template"].Value;

                                // if ((listItems.Item(l).Attributes.Item(1).InnerText == "") || (listItems.Item(l).Attributes.Item(1).InnerText == "0"))
                                if ((listItems.Item(l).Attributes["DependentOn"].Value != "") || (listItems.Item(l).Attributes["DependentOn"].Value == "0"))
                                {
                                    dependentOn = listItems.Item(l).Attributes["DependentOn"].Value;

                                    if ((dependentOn == "") || (dependentOn == null))
                                    {
                                        dependentOn = "";
                                    }
                                    BasicArrayText += "if (Array" + (FName).ToString() + "[" + dependentOn + "] ==null) "
                                                 + "Array" + (FName).ToString() + "[" + dependentOn + "] = new Array();\n";

                                    BasicArrayText += "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "]= new Array('" + ListItemText + "');\n";


                                    // *** ADDED BY AARTI.. AS WRAP NOTE IS ADDED. AND DATA OPTIMIZATION SCRIPT USES THIS ARRAY - 8-Apr-2011
                                    string wrapNote = "";
                                    string optionTooltip = "";
                                    if ((listItems.Item(l).Attributes["WrapNote"] != null))
                                    {
                                        if ((listItems.Item(l).Attributes["WrapNote"].Value.Trim() != ""))
                                        {
                                            wrapNote = listItems.Item(l).Attributes["WrapNote"].Value.Trim();
                                        }
                                    }

                                    if ((listItems.Item(l).Attributes["OptionTooltip"] != null))
                                    {
                                        if ((listItems.Item(l).Attributes["OptionTooltip"].Value.Trim() != ""))
                                        {
                                            optionTooltip = listItems.Item(l).Attributes["OptionTooltip"].Value.Trim();
                                        }
                                    }


                                    BasicArrayText += "if (Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].WN ==null) "
                                             + "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].WN = '" + wrapNote + "';\n";

                                    BasicArrayText += "if (Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].OT ==null) "
                                             + "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].OT = '" + optionTooltip + "';\n";

                                    // Added T for dependent template id (Added by Koshal 13-feb-2013)
                                    BasicArrayText += "if (Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].T ==null) "
                                                     + "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].T = '" + TemplateID + "';\n";
                                }
                            }
                            cnt = cnt + 1;
                        }
                        else
                        {
                            isSuccess = false;
                        }
                    }
                    else
                    {
                        if (countElements == 4)
                        {
                            y = dropDownNode.ChildNodes.Count;
                        }
                    }
                    if (isSuccess)
                    {
                        y = dropDownNode.ChildNodes.Count;
                        i = rootNodeList.Count;
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }
    }



    protected void drpFrom_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (drpFrom.SelectedItem.Value != "")
        {
            lblSelCtrlValue.Visible = true;
            BindControlsValues(0);
        }
        else
        {
            lblSelCtrlValue.Visible = false;
        }
    }

    private void BindControlsValues(int datafor)
    {
        ClearMessages();
        ClearHiddenValues();
        EnableActionButtons();
        NoOfDependentsHidden.Value = "";
        NoOfSelectedParentsHidden.Value = "";
        //GetControlType();
        GetData(datafor);
    }

    private void GetControlType(int datafor)
    {
        string[] words = null;
        if (datafor == 1)
        {
            words = ddlhiddentohiddencontrolvalues.SelectedItem.Value.Split(',');
        }
        else
        {
            words = drpFrom.SelectedItem.Value.Split(',');
        }
        if (words.Length > 0)
        {
            controlType = words[0];
        }

    }

    private void GetData(int datafor)
    {
        GetControlType(datafor);
        string[] words = null;
        if (datafor == 1)
        {
            words = ddlhiddentohiddencontrolvalues.SelectedItem.Value.Split(',');
        }
        else
        {
            words = drpFrom.SelectedItem.Value.Split(',');
        }
        if (words.Length > 0)
        {
            GetPrevRefData(words[1], "", datafor);
        }

        JavaScriptTextBox.Text = CallTypeArrayText;
        Session["JavaScriptTextBox"] = CallTypeArrayText;
        // Registering javascript
        ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "CallTypeArray", JavaScriptTextBox.Text, true);


    }








    public void GetHiddenControl()
    {
        ReadNLoadFile();
        XmlNodeList rootNodeList = doc.SelectNodes("//FORMS").Item(0).ChildNodes;
        string DepOnId = SelectedValue.Value;
        string DepIdFromXml = SelectedDepIdFromXml.Value;

        DataTable Hidedt = new DataTable();
        Hidedt.Clear();
        Hidedt.Columns.Add("controlname");
        Hidedt.Columns.Add("controltype");

        DataTable NonHidedt = new DataTable();
        NonHidedt.Clear();
        NonHidedt.Columns.Add("controlname");
        NonHidedt.Columns.Add("controltype");

        for (int i = 0; i < rootNodeList.Count; i++)
        {
            // XmlNodeList dropDownNode = rootNodeList[i];

            XmlNode dropDownNode = (XmlNode)rootNodeList[i];
            if ((dropDownNode).Name != "DataScript")
            {
                XmlNode ndFieldID = null;
                if ((dropDownNode).Name != "Label")
                {
                    ndFieldID = dropDownNode.SelectSingleNode("Label").SelectSingleNode("Text");
                }
                else
                {
                    ndFieldID = dropDownNode.SelectSingleNode("Title");
                }
                XmlNode ndIsHide = dropDownNode.SelectSingleNode("IsHide");
                XmlNode ndFieldId = dropDownNode.SelectSingleNode("FieldID");
                XmlNode ndDependentID = dropDownNode.SelectSingleNode("DependentID");
                if (ndDependentID != null)
                {
                    if (ndDependentID.InnerText == "")
                    {
                        if (ndIsHide != null)
                        {
                            if (ndIsHide.InnerText == "True")
                            {
                                DataRow dr = Hidedt.NewRow();
                                dr["controlname"] = ndFieldID.InnerText;
                                dr["controltype"] = (dropDownNode).Name.ToString() + "," + ndFieldId.InnerText;
                                Hidedt.Rows.Add(dr);

                            }
                            else
                            {
                                if (dropDownNode.Name.ToString() == "DropDownList" || dropDownNode.Name.ToString() == "RadioButtonList" || dropDownNode.Name.ToString() == "CheckBoxList" || dropDownNode.Name.ToString() == "ListBox")
                                {
                                    DataRow dr = NonHidedt.NewRow();
                                    dr["controlname"] = ndFieldID.InnerText;
                                    dr["controltype"] = (dropDownNode).Name.ToString() + "," + ndFieldId.InnerText;
                                    NonHidedt.Rows.Add(dr);
                                }
                            }
                        }
                        else
                        {
                            if (dropDownNode.Name.ToString() == "DropDownList" || dropDownNode.Name.ToString() == "RadioButtonList" || dropDownNode.Name.ToString() == "CheckBoxList" || dropDownNode.Name.ToString() == "ListBox")
                            {
                                DataRow dr = NonHidedt.NewRow();
                                dr["controlname"] = ndFieldID.InnerText;
                                dr["controltype"] = (dropDownNode).Name.ToString() + "," + ndFieldId.InnerText;
                                NonHidedt.Rows.Add(dr);
                            }
                        }
                    }
                }
                else
                {
                    if (ndIsHide != null)
                    {
                        if (ndIsHide.InnerText == "True")
                        {
                            DataRow dr = Hidedt.NewRow();
                            dr["controlname"] = ndFieldID.InnerText;
                            dr["controltype"] = (dropDownNode).Name.ToString() + "," + ndFieldId.InnerText;
                            Hidedt.Rows.Add(dr);

                        }
                    }
                }
            }
        }

        if (Hidedt.Rows.Count > 0)
        {


            ddlhiddencontrol.DataSource = Hidedt;
            ddlhiddencontrol.DataTextField = "controlname";
            ddlhiddencontrol.DataValueField = "controltype";
            ddlhiddencontrol.DataBind();

        }
        if (NonHidedt.Rows.Count > 0)
        {
            drpFrom.DataSource = NonHidedt;
            drpFrom.DataTextField = "controlname";
            drpFrom.DataValueField = "controltype";
            drpFrom.DataBind();

            ListItem lst = new ListItem(" -- Select ", "");
            drpFrom.Items.Insert(0, lst);
            //tdControls.Controls.Add(ddlCtrl);

        }
    }
    [System.Web.Services.WebMethod]
    public static int InsertControlMgm(string FieldNameValue, string ToShowControl, string VersionId, string FormId, string ParentId, string AddedBy)
    {
        Forms forms = new Forms();
        int result = 0;
        result = forms.InsertControlMgm(FieldNameValue, ToShowControl, VersionId, FormId, ParentId, AddedBy);
        return result;

    }
    protected void rdlhiddencontrols_SelectedIndexChanged(object sender, EventArgs e)
    {
        ddlhiddentohiddencontrolvalues.Items.Clear();
        lsthiddentohiddencontrols.Items.Clear();
        ListItem lst = new ListItem(" -- Select ", "");
        ddlhiddentohiddencontrolvalues.Items.Insert(0, lst);
        rdAssignHiddenControls.Items.Clear();
        if (rdlhiddencontrols.SelectedItem.Value == "1")
        {
            lblShowMesage.Text = "";
            divShowHiddenControls.Visible = false;
            tblvisiblecontrols.Visible = false;
            divhiddentohiddencontrols.Visible = true;
            GetAssignHiddenControl(1);

            Forms forms = new Forms();
            DataSet ds = new DataSet();
            ds = forms.GetVisibleToHiddenControlValues(Convert.ToInt16(FormIDHidden.Value), Convert.ToInt16(VersionIDHidden.Value), 0);
            if (ds != null)
            {
                rdAssignHiddenControls.DataSource = ds;
                rdAssignHiddenControls.DataTextField = "AssignedControlValue";
                rdAssignHiddenControls.DataValueField = "CMID";
                rdAssignHiddenControls.DataBind();
                drpFrom.SelectedIndex = -1;


                //ddlhiddentohiddencontrolvalues.SelectedIndex = -1;
            }
            else
            {
                rdAssignHiddenControls.DataSource = null;
                rdAssignHiddenControls.DataBind();
                drpFrom.SelectedIndex = -1;

            }

        }
        else if (rdlhiddencontrols.SelectedItem.Value == "2")
        {

            EncryptControls();
            lblShowMesage.Text = "";


        }
        else
        {
            lblShowMesage.Text = "";
            divShowHiddenControls.Visible = false;
            divhiddentohiddencontrols.Visible = false;
            tblvisiblecontrols.Visible = true;
            GetAssignHiddenControl(0);
        }
    }

    public void EncryptControls()
    {
        divhiddentohiddencontrols.Visible = false;
        tblvisiblecontrols.Visible = false;
        divShowHiddenControls.Visible = true;
        Forms forms = new Forms();
        DataSet ds = new DataSet();
        try
        {
            ds = forms.GetControlsforEncrypt(Convert.ToInt16(FormIDHidden.Value), Convert.ToInt16(VersionIDHidden.Value));
            if (ds.Tables[0].Rows.Count > 0)
            {
                ControlListBox.DataTextField = "FieldName";
                ControlListBox.DataValueField = "FieldID";
                ControlListBox.DataSource = ds.Tables[0];
                ControlListBox.DataBind();
            }
            if (ds.Tables[1].Rows.Count > 0)
            {
                lstselectedControl.DataTextField = "FieldName";
                lstselectedControl.DataValueField = "FieldID";
                lstselectedControl.DataSource = ds.Tables[1];
                lstselectedControl.DataBind();
            }
        }
        catch (Exception ex)
        {

        }
        finally
        {
            forms = null;
        }
    }
    protected void rdAssignHiddenControls_SelectedIndexChanged(object sender, EventArgs e)
    {
        string[] radiovalue = rdAssignHiddenControls.SelectedItem.Text.Split(':');
        if (radiovalue.Length > 0)
        {
            GetHiddenToHiddenControl(radiovalue[1]);
        }
    }


    public void GetHiddenToHiddenControl(string hiddencontrolnames)
    {
        ReadNLoadFile();
        XmlNodeList rootNodeList = doc.SelectNodes("//FORMS").Item(0).ChildNodes;
        string DepOnId = SelectedValue.Value;
        string DepIdFromXml = SelectedDepIdFromXml.Value;

        lsthiddentohiddencontrols.Items.Clear();
        ddlhiddentohiddencontrolvalues.Items.Clear();

        DataTable Hidedt = new DataTable();
        Hidedt.Clear();
        Hidedt.Columns.Add("controlname");
        Hidedt.Columns.Add("controltype");

        DataTable NonHidedt = new DataTable();
        NonHidedt.Clear();
        NonHidedt.Columns.Add("controlname");
        NonHidedt.Columns.Add("controltype");

        for (int i = 0; i < rootNodeList.Count; i++)
        {
            // XmlNodeList dropDownNode = rootNodeList[i];

            XmlNode dropDownNode = (XmlNode)rootNodeList[i];
            if ((dropDownNode).Name != "DataScript")
            {
                //XmlNode ndFieldID = dropDownNode.SelectSingleNode("Label").SelectSingleNode("Text");
                XmlNode ndFieldID = null;
                if ((dropDownNode).Name != "Label")
                {
                    ndFieldID = dropDownNode.SelectSingleNode("Label").SelectSingleNode("Text");
                }
                else
                {
                    ndFieldID = dropDownNode.SelectSingleNode("Title");
                }
                XmlNode ndIsHide = dropDownNode.SelectSingleNode("IsHide");
                XmlNode ndFieldId = dropDownNode.SelectSingleNode("FieldID");
                XmlNode ndDependentID = dropDownNode.SelectSingleNode("DependentID");
                if (ndDependentID != null)
                {
                    if (ndDependentID.InnerText == "")
                    {
                        if (ndIsHide != null)
                        {
                            if (ndIsHide.InnerText == "True")
                            {
                                string[] FieldIds = hiddencontrolnames.Split(',');
                                int haselement = 0;
                                for (int k = 0; k <= FieldIds.Length - 1; k++)
                                {
                                    if (ndFieldID.InnerText == FieldIds[k])
                                    {
                                        haselement = 1;
                                        break;
                                    }
                                }

                                //if (hiddencontrolnames.Contains(ndFieldID.InnerText))
                                if (haselement == 1)
                                {
                                    if (dropDownNode.Name.ToString() == "DropDownList" || dropDownNode.Name.ToString() == "RadioButtonList" || dropDownNode.Name.ToString() == "CheckBoxList" || dropDownNode.Name.ToString() == "ListBox")
                                    {
                                        DataRow dr = Hidedt.NewRow();
                                        dr["controlname"] = ndFieldID.InnerText;
                                        dr["controltype"] = (dropDownNode).Name.ToString() + "," + ndFieldId.InnerText;
                                        Hidedt.Rows.Add(dr);
                                    }
                                }
                                else
                                {
                                    DataRow dr = NonHidedt.NewRow();
                                    dr["controlname"] = ndFieldID.InnerText;
                                    dr["controltype"] = (dropDownNode).Name.ToString() + "," + ndFieldId.InnerText;
                                    NonHidedt.Rows.Add(dr);
                                }
                            }

                        }

                    }
                }
                else
                {
                    if (ndIsHide != null)
                    {
                        if (ndIsHide.InnerText == "True")
                        {
                            DataRow dr = Hidedt.NewRow();
                            dr["controlname"] = ndFieldID.InnerText;
                            dr["controltype"] = (dropDownNode).Name.ToString() + "," + ndFieldId.InnerText;
                            Hidedt.Rows.Add(dr);

                        }
                    }
                }
            }
        }

        if (Hidedt.Rows.Count > 0)
        {


            ddlhiddentohiddencontrolvalues.DataSource = Hidedt;
            ddlhiddentohiddencontrolvalues.DataTextField = "controlname";
            ddlhiddentohiddencontrolvalues.DataValueField = "controltype";
            ddlhiddentohiddencontrolvalues.DataBind();

        }
        else
        {

            ddlhiddentohiddencontrolvalues.DataSource = null;
            ddlhiddentohiddencontrolvalues.DataBind();
        }
        ListItem lst = new ListItem(" -- Select ", "");
        ddlhiddentohiddencontrolvalues.Items.Insert(0, lst);

        if (NonHidedt.Rows.Count > 0)
        {
            lsthiddentohiddencontrols.DataSource = NonHidedt;
            lsthiddentohiddencontrols.DataTextField = "controlname";
            lsthiddentohiddencontrols.DataValueField = "controltype";
            lsthiddentohiddencontrols.DataBind();


            //tdControls.Controls.Add(ddlCtrl);

        }
        else
        {

            lsthiddentohiddencontrols.DataSource = null;
            lsthiddentohiddencontrols.DataBind();
        }
    }
    protected void ddlhiddentohiddencontrolvalues_SelectedIndexChanged(object sender, EventArgs e)
    {
        if (ddlhiddentohiddencontrolvalues.SelectedItem.Value != "")
        {
            tdhtohcontrols.Visible = true;
            BindControlsValues(1);

        }
        else
        {
            tdhtohcontrols.Visible = false;

        }
    }

    public void GetAssignHiddenControl(int forparent)
    {
        Forms forms = new Forms();
        DataSet ds = new DataSet();
        ds = forms.GetVisibleToHiddenControlValues(Convert.ToInt16(FormIDHidden.Value), Convert.ToInt16(VersionIDHidden.Value), forparent);
        if (ds != null)
        {
            if (forparent == 0)
            {
                grvhiddencontrol.DataSource = ds;
                grvhiddencontrol.DataBind();
            }
            else
            {

                grdhiddeoncontrols.DataSource = ds;
                grdhiddeoncontrols.DataBind();
            }

        }
        else
        {
            if (forparent == 0)
            {
                grvhiddencontrol.DataSource = null;
                grvhiddencontrol.DataBind();
            }
            else
            {

                grdhiddeoncontrols.DataSource = null;
                grdhiddeoncontrols.DataBind();
            }


        }
    }
    protected void btnsubmit_Click(object sender, EventArgs e)
    {
        GetAssignHiddenControl(0);
        drpFrom.SelectedIndex = -1;
        tdControls.Visible = false;
        ddlhiddencontrol.SelectedIndex = -1;

    }
    protected void btnhlevel1_Click(object sender, EventArgs e)
    {
        rdAssignHiddenControls.SelectedIndex = -1;
        tdhtohcontrols.Visible = false;
        ddlhiddentohiddencontrolvalues.Items.Clear();
        ListItem lst = new ListItem(" -- Select-- ", "");
        ddlhiddentohiddencontrolvalues.Items.Insert(0, lst);
        lsthiddentohiddencontrols.Items.Clear();
        GetAssignHiddenControl(1);

    }
    protected void grvhiddencontrol_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "CmdDelete")
        {
            int CMID = Convert.ToInt32(e.CommandArgument);
            if (CMID >= 0)
            {
                Forms forms = new Forms();
                forms.DeleteControlMgm(CMID);
                GetAssignHiddenControl(0);
            }
        }
    }
    protected void grdhiddeoncontrols_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "CmdDelete")
        {
            int CMID = Convert.ToInt32(e.CommandArgument);
            if (CMID >= 0)
            {
                Forms forms = new Forms();
                forms.DeleteControlMgm(CMID);
                GetAssignHiddenControl(1);
            }
        }
    }

    //smishra0065617 : Add control for encryption and maintain log.
    protected void btnEncrypt_Click(object sender, EventArgs e)
    {
        ////Windows Authentication : Bapp
        //string AddedBy = H3GS.Web.Security.PassportIdentity.Current.Employee.LoginId;
        string AddedBy = HttpContext.Current.Request.Cookies["EVO"] != null ? HttpContext.Current.Request.Cookies["EVO"]["userName"] : string.Empty;
        //Bappa
        Forms forms = new Forms();


        //forms.DeleteEncryptControlDetails(Convert.ToInt32(FormIDHidden.Value), Convert.ToInt32(VersionIDHidden.Value));

        for (int iLoop = 0; iLoop <= lstselectedControl.Items.Count - 1; iLoop++)
        {

            if (ViewState["items"] != null)
            {
                ViewState["items"] = ViewState["items"] + lstselectedControl.Items[iLoop].Value + ",";
            }
            else
            {
                ViewState["items"] = lstselectedControl.Items[iLoop].Value + ",";
            }

        }

        if (ViewState["items"] != null)
        {
            bool isStatus = forms.AddEncryptControlDetails(Convert.ToInt32(FormIDHidden.Value), Convert.ToInt32(VersionIDHidden.Value), ViewState["items"].ToString(), AddedBy);
            if (ViewState["Flag"] != null)
            {
                if (ViewState["Flag"].ToString() == "1" || ViewState["Flag"].ToString() == "2")
                {
                    lblShowMesage.Text = "Updated Successfully";
                }
            }


        }
        else
        {
            bool isStatus = forms.AddEncryptControlDetails(Convert.ToInt32(FormIDHidden.Value), Convert.ToInt32(VersionIDHidden.Value), "", AddedBy);
            if (isStatus == true)
            {
                lblShowMesage.Text = "Updated Successfully";
            }
            if (isStatus == false)
            {
                lblShowMesage.Text = "Move control in Right panel to Encrypt.";
            }


        }
        ViewState["items"] = null;

    }

    //smishra0065617 : move control from left list to right list for encryption.
    protected void ControlRightImageButton_Click(object sender, ImageClickEventArgs e)
    {
        Flag = 1;
        ViewState["Flag"] = "1";
        bool iSExist = false;
        lblShowMesage.Text = "";
        try
        {
            if (ControlListBox.SelectedIndex > -1)
            {
                for (int iRowCount = 0; iRowCount < ControlListBox.Items.Count; iRowCount++)
                {
                    if (ControlListBox.Items[iRowCount].Selected == true)
                    {
                        if (lstselectedControl.Items.Count > 0)
                        {
                            for (int iCount = 0; iCount < lstselectedControl.Items.Count; iCount++)
                            {
                                if (lstselectedControl.Items[iCount].Text == ControlListBox.Items[iRowCount].Text)
                                {
                                    iSExist = true;
                                    break;
                                }
                            }
                            if (iSExist == false)
                            {
                                ListItem lst = new ListItem(ControlListBox.Items[iRowCount].Text, ControlListBox.Items[iRowCount].Value);
                                lstselectedControl.Items.Insert(lstselectedControl.Items.Count, lst);
                            }
                            else
                            {
                                iSExist = false;
                            }
                        }
                        else
                        {
                            ListItem lst = new ListItem(ControlListBox.Items[iRowCount].Text, ControlListBox.Items[iRowCount].Value);
                            lstselectedControl.Items.Insert(0, lst);
                        }

                    }
                }
            }
            else
            {
                ErrorMessageLabel.Text = "Please select Control/s to move to right.";
            }
        }
        catch (Exception ex)
        {

        }
    }

    //smishra0065617 : Move control from right to left if user don't want any control to be encrypted.
    protected void ControlLeftImageButton_Click(object sender, ImageClickEventArgs e)
    {

        Flag = 0;
        ViewState["Flag"] = "2";
        lblShowMesage.Text = "";
        try
        {
            if (lstselectedControl.Items.Count > 0)
            {
                for (int iRowCount = 0; iRowCount < lstselectedControl.Items.Count; iRowCount++)
                {
                    if (lstselectedControl.Items[iRowCount].Selected == true)
                    {
                        lstselectedControl.Items.Remove(lstselectedControl.Items[iRowCount]);
                        iRowCount--;
                    }
                }
            }
            else
            {
                ErrorMessageLabel.Text = "Please select item/s to remove.";
            }
        }

        catch (Exception ex)
        {

        }
    }
}