using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using EVOLib;

public partial class Admin_AdminFormDetails : System.Web.UI.Page
{

    protected void Page_Load(object sender, EventArgs e)
    {
        EvoGeneral objEvoGeneral = new EvoGeneral();
        EvoMain objEvoMain = new EvoMain();
        try
        {
            int formId;
            GetFileName();


            if (!IsPostBack)
            {
                //if (formId != 0)
                formId = ManageSession.FormID;
                FormIdHidden.Value = formId.ToString();
                if (FormIdHidden.Value != "0")
                {
                    string NTName = objEvoGeneral.userName;
                    objEvoMain.UserID = objEvoGeneral.RetrieveUserID(NTName);
                    if (FillSkillSetListBoxEditMode(objEvoMain.UserID, formId))
                    {
                        FillCategoryDropDown();
                        DataRead(int.Parse(FormIdHidden.Value));
                    }
                    else
                    {
                        Response.Redirect("~/AccessDenied.aspx", true);
                    }
                }
                else
                {
                    string NTName = objEvoGeneral.userName;
                    objEvoMain.UserID = objEvoGeneral.RetrieveUserID(NTName);
                    bool isValid = objEvoMain.GetAllAdmin(objEvoMain.UserID);
                    if (isValid == false)
                    {
                        Response.Redirect("~/AccessDenied.aspx", true);
                    }
                    FillCategoryDropDown();
                    FillSkillSetListBox(objEvoMain.UserID);
                    treditable.Style.Value = "display:block";
                    trforform.Style.Value = "display:block";
                }

                MessageLabel.Text = "";
                //formId = ManageSession.FormID;
                //FormIdHidden.Value = formId.ToString();
                //int vId = ManageSession.VersionID;
                VersionIdHidden.Value = ManageSession.VersionID.ToString();

            }
            //Page.ClientScript.RegisterStartupScript(this.GetType(), "myscript", "GetSelectedSkillSet();", true);
            setDTMSCheck();
        }
        catch (Exception ex)
        {
            ErrorMessageLabel.Text = "Page_Load" + ex.Message;
        }
        finally
        {
            objEvoGeneral = null;
            objEvoMain = null;
        }
    }
    private bool FillSkillSetListBoxEditMode(long userID, int formId)
    {
        bool isValid = false;
        EvoMain objEvoMain = new EvoMain();
        DataSet dsSkillSet = new DataSet();
        try
        {
            dsSkillSet = objEvoMain.RetrieveDeptDetailsEditMode(userID, formId);
            if (dsSkillSet != null && dsSkillSet.Tables[0].Rows.Count > 0)
            {
                SkillSetListBox.DataTextField = "DepartmentName";
                SkillSetListBox.DataValueField = "DepartmentID";
                SkillSetListBox.DataSource = dsSkillSet;
                SkillSetListBox.DataBind();
                isValid = true;
            }
            else
            {
                isValid = false;
            }

        }
        catch (Exception ex)
        {
            ErrorMessageLabel.Text = "FillSkillSetListBoxEditMode" + ex.Message;
        }
        finally
        {
            objEvoMain = null;
        }
        return isValid;
    }
    protected override void OnInit(EventArgs e)
    {
        GenerateClick();
    }
    private void GenerateClick()
    {
        ContentPlaceHolder ctPlaceHolder = (ContentPlaceHolder)Master.FindControl("head");
        ImageButton imgBtnSave = (ImageButton)ctPlaceHolder.FindControl("imgSave");
        imgBtnSave.ToolTip = "Click for submit form";
        imgBtnSave.Attributes.Add("onclick", "return ValidateOnSave();");
        imgBtnSave.Click += new ImageClickEventHandler(Save_Clicked);
        ImageButton HomeImageButton = (ImageButton)ctPlaceHolder.FindControl("imgHome");
        HomeImageButton.ImageUrl = "~/Images/home.png";
        HomeImageButton.ToolTip = "Go to home";
        HomeImageButton.Click += new ImageClickEventHandler(HomeImageButton_Clicked);
    }
    protected void HomeImageButton_Clicked(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("Default.aspx");
    }

    protected void Save_Clicked(object sender, ImageClickEventArgs e)
    {
        EvoMain objEvoMain = new EvoMain();
        EvoGeneral objEvoGeneral = new EvoGeneral();
        string NTName = objEvoGeneral.userName;
        objEvoMain.UserID = objEvoGeneral.RetrieveUserID(NTName);
        bool isStatus = false;
        int formID = 0;
        try
        {
            if (txtmail.Text != "")
            {
                string[] emails = txtmail.Text.Split(',');
                if (emails.Length > 5)
                {
                    ErrorMessageLabel.Text = "Only 5 emails are allowed.";
                    ScriptManager.RegisterStartupScript(this, GetType(), "showhidechk", "javascript:showhidechk();", true);
                    return;
                }
                if (txtmail.Text.Contains(" "))
                {
                    ScriptManager.RegisterStartupScript(this, GetType(), "alert", "alert('Enter or space is not allowed in email textbox.');", true);
                    return;
                }
            }
            if (FormIdHidden.Value == "0")
            {
                objEvoMain.FormName = NameTextBox.Text.Trim();
                objEvoMain.FormDesc = DescriptionTextBox.Text.Trim();
                objEvoMain.CategoryId = int.Parse(CategoryDropDown.SelectedValue);
                objEvoMain.AddedBy = objEvoGeneral.userName;
                objEvoMain.EmpUserId = objEvoMain.UserID;
                if (chkiseditable.Checked == true)
                {
                    objEvoMain.IsEditable = "true";
                }
                else
                {
                    objEvoMain.IsEditable = "false";
                }
                if (CategoryDropDown.SelectedValue == "4")
                {
                    objEvoMain.IsEditable = "false";
                }
                if (chkformspec.Checked == true)
                {
                    objEvoMain.IsSearchFormSpecific = "true";
                }
                else
                {
                    objEvoMain.IsSearchFormSpecific = "false";
                }
                if (CategoryDropDown.SelectedValue == "4")
                {
                    objEvoMain.IsSearchFormSpecific = "false";
                }

                if (chkdtms.Checked == true)
                {
                    objEvoMain.IsDTMS = "true";
                }
                else
                {
                    objEvoMain.IsDTMS = "false";
                }
                objEvoMain.TemplateEmail = "";
                if (CategoryDropDown.SelectedValue == "4")
                {
                    objEvoMain.IsDTMS = "false";
                    objEvoMain.TemplateEmail = txtmail.Text;

                }
                if (objEvoMain.AddFormDetails())
                {
                    for (int iLoop = 0; iLoop <= lstselectedskillset.Items.Count - 1; iLoop++)
                    {
                        // item selected 
                        // if (lstselectedskillset.Items[iLoop].Selected)
                        // {
                        formID = objEvoMain.FormId;
                        objEvoMain.SkillSetId = int.Parse(lstselectedskillset.Items[iLoop].Value);
                        isStatus = objEvoMain.AddSkillSetDetails();
                        //  }
                    }
                    //Session Build......
                    ManageSession.FormID = objEvoMain.FormId;
                    ManageSession.VersionID = objEvoMain.VersionId;
                    ManageSession.FormName = objEvoMain.FormName;
                    ManageSession.CategoryID = objEvoMain.CategoryId;
                    ManageSession.FormMode = "CREATEMODE"; //for New form. CHANGED BY AARTI
                    FormClear();
                }
            }
            else
            {
                DataSet objds = new DataSet();
                objds = objEvoMain.CheckForIsEditable(Convert.ToInt32(FormIdHidden.Value));

                if (hfCategoryID.Value != CategoryDropDown.SelectedValue && (hfCategoryID.Value == "4" || CategoryDropDown.SelectedValue == "4"))
                {
                    ErrorMessageLabel.Text = "Category cannot be changed from/to template";
                    ScriptManager.RegisterStartupScript(this, GetType(), "showhidechk", "javascript:showhidechk();", true);
                    return;
                }
                else if (chkiseditable.Checked != Convert.ToBoolean(objds.Tables[0].Rows[0]["isEditable"].ToString() == "" ? "false" : objds.Tables[0].Rows[0]["isEditable"].ToString()) && Convert.ToInt32(objds.Tables[0].Rows[0]["TotalCount"].ToString()) > 0)
                {
                    ErrorMessageLabel.Text = "Logger already have data. Cannot update iseditable field.";
                    return;
                }
                else if (chkdtms.Checked != Convert.ToBoolean(objds.Tables[0].Rows[0]["isDTMS"].ToString() == "" ? "false" : objds.Tables[0].Rows[0]["isDTMS"].ToString()))
                {
                    ErrorMessageLabel.Text = "Cannot update IsDtms field. This Logger already assign to EVO OR DTMS Logger";
                    return;
                }


                else
                {
                    objEvoMain.FormId = int.Parse(FormIdHidden.Value);
                    objEvoMain.FormName = NameTextBox.Text.Trim();
                    objEvoMain.FormDesc = DescriptionTextBox.Text.Trim();
                    objEvoMain.CategoryId = int.Parse(CategoryDropDown.SelectedValue);
                    objEvoMain.UpdatedBy = objEvoGeneral.userName;
                    objEvoMain.UpdatedWhen = System.DateTime.Now.ToString();
                    if (chkiseditable.Checked == true)
                    {
                        objEvoMain.IsEditable = "true";
                    }
                    else
                    {
                        objEvoMain.IsEditable = "false";
                    }
                    if (CategoryDropDown.SelectedValue == "4")
                    {
                        objEvoMain.IsEditable = "false";
                    }

                    if (chkformspec.Checked == true)
                    {
                        objEvoMain.IsSearchFormSpecific = "true";
                    }
                    else
                    {
                        objEvoMain.IsSearchFormSpecific = "false";
                    }
                    objEvoMain.TemplateEmail = "";
                    if (CategoryDropDown.SelectedValue == "4")
                    {
                        objEvoMain.IsSearchFormSpecific = "false";
                        objEvoMain.TemplateEmail = txtmail.Text;
                    }

                    if (objEvoMain.UpdateFormDetails())
                    {
                        if (objEvoMain.DeleteSkillSetRelationsls(int.Parse(FormIdHidden.Value)))
                        {
                            for (int iLoop = 0; iLoop <= lstselectedskillset.Items.Count - 1; iLoop++)
                            {
                                // item selected 
                                //if (lstselectedskillset.Items[iLoop].Selected)
                                // {
                                formID = objEvoMain.FormId;
                                objEvoMain.AddedBy = objEvoGeneral.userName;
                                objEvoMain.SkillSetId = int.Parse(lstselectedskillset.Items[iLoop].Value);
                                isStatus = objEvoMain.AddSkillSetDetails();
                                // }
                            }
                        }
                        //Session Build...... for form mode.
                        ManageSession.FormID = objEvoMain.FormId;
                        ManageSession.FormName = objEvoMain.FormName;
                        ManageSession.CategoryID = objEvoMain.CategoryId;
                        ManageSession.VersionID = Convert.ToInt32(VersionIdHidden.Value);
                        ManageSession.FormMode = "EDITMODE";    //CHANGED BY AARTI
                    }
                }
            }
            if (isStatus == false)
            {
                ErrorMessageLabel.Text = "Duplicate record found";
            }
            else
            {
                Response.Redirect("../Admin/DesignManagement.aspx");
            }
        }
        catch (Exception ex)
        {
            ErrorMessageLabel.Text = "SaveImageButton_Click " + ex.Message;
        }
        finally
        {
            objEvoMain = null;
            objEvoGeneral = null;
        }
    }
    private void GetFileName()
    {
        ContentPlaceHolder ctPlaceHolder = (ContentPlaceHolder)Master.FindControl("head");
        Label lblModule = (Label)Master.FindControl("lblModule");
        lblModule.Text = "Form Details";
        lblModule.CssClass = "heading";

        ImageButton imgSel = (ImageButton)ctPlaceHolder.FindControl("img1");
        imgSel.ImageUrl = "../images/icon_1_rol.jpg";

    }

    public void setDTMSCheck()
    {
        if (chkdtms.Checked == true)
        {

            chkiseditable.Checked = false;
            trforform.Style.Value = "display:none";
            treditable.Style.Value = "display:none";
        }
        else
        {
            if (chkiseditable.Checked == true)
            {
                trforform.Style.Value = "display:block";
            }
            else
            {
                trforform.Style.Value = "display:none";
            }
            treditable.Style.Value = "display:block";

        }
    }
    private void DataRead(int formID)
    {
        EvoMain objEvoMain = new EvoMain();
        DataSet dsFormDetail = new DataSet();
        DataSet dsSkillSet = new DataSet();
        try
        {
            dsFormDetail = objEvoMain.RetrieveFormDetails(formID);
            FormIdHidden.Value = dsFormDetail.Tables[0].Rows[0]["FormID"].ToString();
            NameTextBox.Text = dsFormDetail.Tables[0].Rows[0]["FormName"].ToString();
            DescriptionTextBox.Text = dsFormDetail.Tables[0].Rows[0]["FormDesc"].ToString();
            CategoryDropDown.SelectedValue = dsFormDetail.Tables[0].Rows[0]["CategoryID"].ToString();
            hfCategoryID.Value = dsFormDetail.Tables[0].Rows[0]["CategoryID"].ToString();
            txtmail.Text = dsFormDetail.Tables[0].Rows[0]["TemplateEmails"].ToString();
            dsSkillSet = objEvoMain.RetrieveSkillSetDetails(formID);

            if (dsFormDetail.Tables[0].Rows[0]["IsDtms"].ToString() != "")
            {
                if (dsFormDetail.Tables[0].Rows[0]["IsDtms"].ToString().ToLower() == "true")
                {
                    chkdtms.Checked = true;
                    chkiseditable.Checked = false;
                    trforform.Style.Value = "display:none";
                    treditable.Style.Value = "display:none";
                }
                else
                {
                    chkdtms.Checked = false;
                    treditable.Style.Value = "display:block";
                }
            }
            else
            {
                chkdtms.Checked = false;
                treditable.Style.Value = "display:block";
            }

            if (dsFormDetail.Tables[0].Rows[0]["Iseditable"].ToString() != "")
            {
                if (dsFormDetail.Tables[0].Rows[0]["Iseditable"].ToString() == "True")
                {
                    chkiseditable.Checked = true;
                    trforform.Style.Value = "display:block";
                }
                else
                {
                    chkiseditable.Checked = false;
                }
            }
            else
            {
                chkiseditable.Checked = false;
            }

            if (dsFormDetail.Tables[0].Rows[0]["IsSearchFormSpecific"].ToString() != "")
            {
                if (dsFormDetail.Tables[0].Rows[0]["IsSearchFormSpecific"].ToString() == "True")
                {
                    chkformspec.Checked = true;
                }
                else
                {
                    chkformspec.Checked = false;
                }
            }
            else
            {
                chkformspec.Checked = false;
            }
            if (hfCategoryID.Value == "4")
            {
                treditable.Style.Value = "display:none";
                chkiseditable.Checked = false;
                trforform.Style.Value = "display:none";
                chkformspec.Checked = false;
                trtemp.Style.Value = "display:block";
            }
            if (dsSkillSet.Tables.Count > 0)

            {
                lstselectedskillset.DataTextField = "DepartmentName";
                lstselectedskillset.DataValueField = "DepartmentID";
                lstselectedskillset.DataSource = dsSkillSet.Tables[0];
                lstselectedskillset.DataBind();
            }

            ScriptManager.RegisterStartupScript(this, GetType(), "showhidechk", "javascript:showhidechk();", true);
        }
        catch (Exception ex)
        {
            ErrorMessageLabel.Text = "DataRead" + ex.Message;
        }
        finally
        {
            objEvoMain = null;
        }

    }
    /// <summary>
    /// This method is used to fill SkillsetListbox.
    /// </summary>
    private void FillSkillSetListBox(long userID)
    {
        EvoMain objEvoMain = new EvoMain();
        try
        {
            SkillSetListBox.DataTextField = "DepartmentName";
            SkillSetListBox.DataValueField = "DepartmentID";
            SkillSetListBox.DataSource = objEvoMain.RetrieveDeptDetails(userID).Tables[0];
            SkillSetListBox.DataBind();
        }
        catch (Exception ex)
        {
            ErrorMessageLabel.Text = "FillSkillSetListBox" + ex.Message;
        }
        finally
        {
            objEvoMain = null;
        }

    }
    /// <summary>
    /// This method is used to  fill the Category Dropdown.
    /// </summary>
    private void FillCategoryDropDown()
    {
        EvoMain objEvoMain = new EvoMain();
        try
        {
            DataSet Catds = new DataSet();
            Catds = objEvoMain.RetrieveCatDetails();
            CategoryDropDown.DataTextField = "CategoryName";
            CategoryDropDown.DataValueField = "CategoryID";
            //CategoryDropDown.Attributes["title"] = "CategoryDesc";
            CategoryDropDown.DataSource = Catds.Tables[0];
            CategoryDropDown.DataBind();

            for (int i = 0; i <= Catds.Tables[0].Rows.Count - 1; i++)
            {
                CategoryDropDown.Items[i].Attributes["title"] = Catds.Tables[0].Rows[i]["CategoryDesc"].ToString();

            }
            ListItem item = new ListItem("Select", "0");
            CategoryDropDown.Items.Insert(0, item);

        }
        catch (Exception ex)
        {
            ErrorMessageLabel.Text = "FillCategoryDropDown" + ex.Message;
        }
        finally
        {
            objEvoMain = null;
        }

    }
    /// <summary>
    /// This method is used to clear value of all controls.
    /// </summary>
    private void FormClear()
    {
        NameTextBox.Text = "";
        DescriptionTextBox.Text = "";
        CategoryDropDown.SelectedIndex = 0;
        chkiseditable.Checked = false;
        for (int iLoop = 0; iLoop <= SkillSetListBox.Items.Count - 1; iLoop++)
        {
            SkillSetListBox.Items[iLoop].Selected = false;
        }
    }


    //protected void CategoryDropDown_SelectedIndexChanged(object sender, EventArgs e)
    //{
    //    if (CategoryDropDown.SelectedItem.Value == "4")
    //    {
    //        treditable.Visible = false;
    //    }
    //    else
    //    {
    //        treditable.Visible = true;
    //    }
    //}
    protected void TeamRightImageButton_Click(object sender, ImageClickEventArgs e)
    {
        bool iSExist = false;
        try
        {
            if (SkillSetListBox.SelectedIndex > -1)
            {
                for (int iRowCount = 0; iRowCount < SkillSetListBox.Items.Count; iRowCount++)
                {
                    if (SkillSetListBox.Items[iRowCount].Selected == true)
                    {
                        if (lstselectedskillset.Items.Count > 0)
                        {
                            for (int iCount = 0; iCount < lstselectedskillset.Items.Count; iCount++)
                            {
                                if (lstselectedskillset.Items[iCount].Text == SkillSetListBox.Items[iRowCount].Text)
                                {
                                    iSExist = true;

                                    // code added for alert pop-up when user selects skill set to be transferred to right panel,
                                    //which already exists in right panel
                                    Page.ClientScript.RegisterStartupScript(this.GetType(), "a", "alert('Selected value is already exists.');", true);
                                    break;
                                }
                            }
                            if (iSExist == false)
                            {
                                ListItem lst = new ListItem(SkillSetListBox.Items[iRowCount].Text, SkillSetListBox.Items[iRowCount].Value);
                                lstselectedskillset.Items.Insert(lstselectedskillset.Items.Count, lst);
                            }
                            else
                            {
                                iSExist = false;
                            }
                        }
                        else
                        {
                            ListItem lst = new ListItem(SkillSetListBox.Items[iRowCount].Text, SkillSetListBox.Items[iRowCount].Value);
                            lstselectedskillset.Items.Insert(0, lst);
                        }

                    }
                }
            }
            else
            {
                ErrorMessageLabel.Text = "Please select Skillset/s to move to right.";
            }
        }
        catch (Exception ex)
        {

        }
    }
    protected void TeamLeftImageButton_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (lstselectedskillset.Items.Count > 0)
            {
                for (int iRowCount = 0; iRowCount < lstselectedskillset.Items.Count; iRowCount++)
                {
                    if (lstselectedskillset.Items[iRowCount].Selected == true)
                    {
                        lstselectedskillset.Items.Remove(lstselectedskillset.Items[iRowCount]);
                        iRowCount--;
                    }
                }
            }
            else
            {
                ErrorMessageLabel.Text = "Please select item/s to remove.";
            }
        }

        catch (Exception ex)
        {

        }
    }
}
