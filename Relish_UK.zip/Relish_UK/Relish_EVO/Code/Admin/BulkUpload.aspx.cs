﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using EVOLib;
using System.Data;
using System.Xml;
using System.Xml.Linq;
using System.Data.OleDb;
using System.IO;
using System.Collections;



public partial class Admin_BulkUpload : EvoGeneral
{
    XmlDocument doc;
    XDocument xmlDoc = new XDocument();
    string FileName;
    int frmID;
    string frmName;
    string catId;
    string vId;
    string fMode;


    ImageButton imgNext;

    public string NtName;

    DataTable dserr;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!(Page.IsPostBack))
        {
            Server.ScriptTimeout = 30000;

            ObjUserRights.VersionId = int.Parse(VersionIDHidden.Value);
            ObjUserRights.UserID = RetrieveUserID(userName);
            ObjUserRights.FormId = int.Parse(FormIDHidden.Value);

            IsValidUser();
            IsValidPageEntry();
            ParentIDHidden.Value = "";
            GetIdForControl(controlIDHidden.Value);
            //lblErr.Text = ParentIDHidden.Value;
        }

        BuildTemplateControlsList();



    }


    private void IsValidPageEntry()
    {
        if (FormIDHidden.Value == "0")
        {
            Response.Redirect("../AccessDenied.aspx");
        }
    }
    private void GetFileName()
    {
        frmID = ManageSession.FormID;
        frmName = ManageSession.FormName;
        string[] fName = frmName.Split('_');
        frmName = fName[0];
        catId = ManageSession.CategoryID.ToString();
        vId = ManageSession.VersionID.ToString();
        fMode = ManageSession.FormMode.ToString();
        FormIDHidden.Value = frmID.ToString(); //ManageSession.FormID.ToString(); //"1"; 
        FormNameHidden.Value = frmName; //"MBB Call Logger";
        CategoryIDHidden.Value = catId; //"1"; 
        VersionIDHidden.Value = vId; //"1";


        controlIDHidden.Value = ManageSession.ControlName;
        controltypeHidden.Value = ManageSession.ControlType;
        CategoryIDHidden.Value = catId;
        FileModeHidden.Value = fMode;

        GetFileNameFromDb();    // To retrieve XML filename from DB.
    }

    protected override void OnInit(EventArgs e)
    {
        if (!(Page.IsPostBack))
        {
            GetFileName();
        }
        GenerateMasterClick();
    }

    private void GenerateMasterClick()
    {
        Label lblModule = (Label)Master.FindControl("lblModule");
        lblModule.Text = "Bulk Upload";

        Label lblForm = (Label)Master.FindControl("lblForm");
        lblForm.Text = FormNameHidden.Value;//+ controlIDHidden.Value;
        ContentPlaceHolder ctPlaceHolder = (ContentPlaceHolder)Master.FindControl("head");
        ImageButton imgSel = (ImageButton)ctPlaceHolder.FindControl("img3");
        imgSel.ImageUrl = "../images/icon_3_rol.jpg";

        imgNext = (ImageButton)ctPlaceHolder.FindControl("img4");
        imgNext.CssClass = "ImageButtonLinkCursor";
        imgNext.Enabled = true;
        // If IN EDIT MODE, ALLOW SESSION VARIABLES FOR NAVIGATION.
        imgNext.Click += new ImageClickEventHandler(Next_Click);

        ImageButton imgBtnSave = (ImageButton)ctPlaceHolder.FindControl("imgSave");
        imgBtnSave.Click += new ImageClickEventHandler(Save_Click);

        ImageButton imgBtnHome = (ImageButton)ctPlaceHolder.FindControl("imgHome");
        imgBtnHome.Click += new ImageClickEventHandler(Home_Click);
    }
    EvoAdminUsersRights ObjUserRights = new EvoAdminUsersRights();

    private void GetFileNameFromDb()
    {
        try
        {
            DataSet ds;
            ObjUserRights.FormId = frmID;
            ObjUserRights.VersionId = int.Parse(vId);

            ds = ObjUserRights.GetXMLFileName();

            if (ds.Tables[0].Rows.Count > 0)
            {
                string FiName = ds.Tables[0].Rows[0]["XMLFileName"].ToString();
                ReadXMLHidden.Value = FiName;
                Session["FileName"] = FiName;
            }
            else
            {
                lblErr.Text = "Could not find the XML file";
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = "Could not find the XML file" + ex.Message;
        }
    }

    private void IsValidUser()
    {
        try
        {
            Boolean IsValid = false;

            IsValid = ObjUserRights.ValidateAdminManageUser();

            if (!IsValid)
            {
                //Response.Write("Redirecting to access denied");
                Response.Redirect("../AccessDenied.aspx", true);
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = "No data found for this login" + ex.Message;
        }
    }

    protected void Save_Click(object sender, EventArgs e)
    {
        GoToNextForm();
        Response.Redirect("../Admin/RightsManagement.aspx", true);
    }

    protected void Next_Click(object sender, EventArgs e)
    {
        if (FileModeHidden.Value.ToUpper() == "EDITMODE")
        {
            GoToNextForm();
            Response.Redirect("../Admin/RightsManagement.aspx", true);
        }
    }

    protected void Home_Click(object sender, EventArgs e)
    {
        GoToNextForm();
        Response.Redirect("../Admin/Default.aspx", true);
    }

    public DataTable FilterDataTable(DataTable table, bool arrangeonly)
    {
        DataTable dtnew = table.Clone();
        int totalcol = 0;
        totalcol = dtnew.Columns.Count;
        for (int i = 0; i <= totalcol - 1; i++)
        {
            dtnew.Columns[i].DataType = typeof(string);
        }
        try
        {
            // Erase duplicates
            string rownumber = "";
            string[] itemlist = ParentIDHidden.Value.Split(',');




            string sorting = "";
            for (int i = 0; i <= itemlist.Length - 1; i++)
            {
                if (sorting == "")
                {
                    double Num;

                    bool isNum = double.TryParse(itemlist[i].ToString(), out Num);
                    if (isNum == true && arrangeonly == false)
                    {
                        sorting = "[(" + itemlist[i].ToString() + ")]" + " ASC ";
                    }
                    else
                    {
                        sorting = "[" + itemlist[i].ToString() + "]" + " ASC ";
                    }
                }
                else
                {
                    double Num;
                    bool isNum = double.TryParse(itemlist[i].ToString(), out Num);
                    if (isNum == true && arrangeonly == false)
                    {
                        sorting = "[(" + itemlist[i].ToString() + ")]" + " ASC " + "," + sorting;
                    }
                    else
                    {
                        sorting = "[" + itemlist[i].ToString() + "]" + " ASC " + "," + sorting;
                    }
                }
            }

            DataView dv = new DataView(table);
            dv.Sort = sorting;
            //table = dv.ToTable(true, itemlist);


            string previousvalue = "";
            string newvalue = "";
            for (int rows = 0; rows <= dv.Count - 1; rows++)
            {

                newvalue = "";
                for (int i = 0; i <= itemlist.Length - 1; i++)
                {
                    double Num;
                    bool isNum = double.TryParse(itemlist[i].ToString(), out Num);
                    if (isNum == true && arrangeonly == false)
                    {
                        newvalue = newvalue + "," + dv[rows]["(" + itemlist[i].ToString() + ")"].ToString();
                    }
                    else
                    {
                        newvalue = newvalue + "," + dv[rows][itemlist[i].ToString()].ToString();
                    }

                }

                if (previousvalue.ToLower().Replace(",", "").Replace(" ", "") == newvalue.ToLower().Replace(",", "").Replace(" ", ""))
                {
                    if (rownumber == "")
                    {
                        rownumber = rows.ToString();
                    }
                    else
                    {
                        rownumber = rownumber + "," + rows.ToString();
                    }
                    //dv.RemoveAt(rows);


                }

                previousvalue = newvalue;

            }

            foreach (DataRowView dvr in dv)
            {
                dtnew.ImportRow(dvr.Row);
                //dtnew.Tables.Add(dtnew);
            }

            if (arrangeonly == false)
            {
                string[] itemcounts = rownumber.Split(',');
                for (int k = itemcounts.Length - 1; k >= 0; k--)
                {
                    DataRow row = dtnew.Rows[Convert.ToInt16(itemcounts[k])];
                    dtnew.Rows.Remove(row);
                }
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;

        }
        return dtnew;
    }


    public void IsFileValid(FileUpload fileUploadControl, out string errMsg)
    {
        errMsg = "";
        long maxUploadFileSize = long.Parse(System.Configuration.ConfigurationManager.AppSettings["MaxFileSize"]);

        if (fileUploadControl.PostedFile.ContentLength == 0)
        {
            errMsg = "Please select a proper file to to upload.";

        }
        else if (fileUploadControl.FileName.Length > 30)
        {
            errMsg = "Please enter file name having maximum 30 characters only.";

        }
        else if (fileUploadControl.PostedFile.ContentLength > maxUploadFileSize)
        {
            errMsg = "Please select a file not more than " + ((int)(maxUploadFileSize / 1048576)).ToString() + " MB in size.";

        }
        //if (!fileUploadControl.FileName.ToUpper().EndsWith(allowedFileExtension))


    }


    public string CheckColumnsName(DataTable dt)
    {
        string errorMsg = "";
        string[] columnsname = ParentIDHidden.Value.Split(',');

        for (int colcount = 0; colcount <= columnsname.Length - 1; colcount++)
        {

            // if (colcount == 0)
            //{
            if (dt.Columns[(colcount * 4) + 1].ColumnName.ToLower().Contains("template") == false || dt.Columns[(colcount * 4) + 2].ColumnName.ToLower().Contains("wrapnote") == false || dt.Columns[(colcount * 4) + 3].ColumnName.ToLower().Contains("tooltip") == false)
            {
                errorMsg = "Invalid Column name/postion";
            }

            // }
            //else
            //{
            //    if (dt.Columns[(colcount * 4) + 1].ColumnName.ToLower() != "template" + colcount.ToString() || dt.Columns[(colcount * 4) + 2].ColumnName.ToLower() != "wrapnote" + colcount.ToString() || dt.Columns[(colcount * 4) + 3].ColumnName.ToLower() != "tooltip" + colcount.ToString())
            //    {
            //        errorMsg = "Invalid Column name/postion";
            //    }

            //}
        }
        return errorMsg;
    }

    public ArrayList TemplateControls
    {
        get
        {
            ArrayList tempcontrollist;
            if (ViewState["templateControls"] == null)
            {
                tempcontrollist = new ArrayList();
            }
            else
            {
                tempcontrollist = (ArrayList)ViewState["templateControls"];
            }
            return tempcontrollist;
        }
        set
        {

            ViewState["templateControls"] = value;
        }

    }
    public void BuildTemplateControlsList()
    {
        ReadNLoadFile();
        XmlNodeList rootNodeList = doc.SelectNodes("//FORMS/DropDownList|//FORMS/ListBox");
        string DepOnId = SelectedValue.Value;
        string DepIdFromXml = SelectedDepIdFromXml.Value;

        TemplateControls = null;
        ArrayList arr = TemplateControls;

        for (int i = 0; i < rootNodeList.Count; i++)
        {
            XmlNode dropDownNode = (XmlNode)rootNodeList[i];

            XmlNode ndFieldID = dropDownNode.SelectSingleNode("FieldID");
            XmlNode ndListItems = dropDownNode.SelectSingleNode("LISTITEMS");
            XmlNode ndText = dropDownNode.SelectSingleNode("Label").SelectSingleNode("Text");

            string FieldID = "";
            string ListItemText = "";
            string controlLabel = "";

            FieldID = ndFieldID.InnerText;
            controlLabel = ndText.InnerText;

            XmlNodeList listItems = ndListItems.ChildNodes;

            for (int l = 0; l < listItems.Count; l++)
            {
                ListItemText = listItems.Item(l).InnerText;

                if (listItems.Item(l).Name == "LISTITEM")
                {
                    if (listItems.Item(l).Attributes["Template"] != null && listItems.Item(l).Attributes["Template"].Value != "")
                    {
                        arr.Add(FieldID);
                        hfTemplateControls.Value = controlLabel;
                        break;
                    }
                }
            }

        }

        TemplateControls = arr;
    }


    public DataTable ValidateData(DataTable dt)
    {
        dt.Columns.Add("Error", typeof(string));
        dt.AcceptChanges();
        dserr = new DataTable();
        dserr = dt.Clone();

        try
        {
            int totalColumCount = 0;
            int ColumCount = 0;
            totalColumCount = dt.Columns.Count;



            for (int j = 0; j < totalColumCount; j++)
            {


                for (int rowcount = 0; rowcount <= dt.Rows.Count - 1; rowcount++)
                {
                    if (dt.Columns[j].ColumnName.ToLower().Contains("wrapnote") == true || dt.Columns[j].ColumnName.ToLower().Contains("tooltip") == true || dt.Columns[j].ColumnName.ToLower().Contains("template") != true || dt.Columns[j].ColumnName.ToLower() != "error")
                    {

                        if (dt.Columns[j].ColumnName.ToLower().Contains("wrapnote") == true || dt.Columns[j].ColumnName.ToLower().Contains("tooltip") == true || dt.Columns[j].ColumnName.ToLower().Contains("template") != true || dt.Columns[j].ColumnName.ToLower() != "error")
                        {
                            if ((dt.Columns[j].ColumnName.ToLower().Contains("wrapnote") == true || dt.Columns[j].ColumnName.ToLower().Contains("tooltip") == true) && dt.Columns[j].ColumnName.ToLower() != "error")
                            {
                                if (dt.Rows[rowcount][j].ToString().Length > 500 || dt.Rows[rowcount][j].ToString().Contains(",") == true || dt.Rows[rowcount][j].ToString().Contains("'") == true || dt.Rows[rowcount][j].ToString().Contains("\"") == true)
                                {
                                    if (dt.Rows[rowcount][j].ToString().Length > 500)
                                    {
                                        //dt.Rows[rowcount]["Error"] = "Column <strong>" + dt.Columns[j].ColumnName.ToString() + "</strong> length cannot be greater then 500 charaters";
                                        dt.Rows[rowcount]["Error"] = "Column \"" + dt.Columns[j].ColumnName.ToString() + "\" length cannot be greater then 500 charaters";
                                    }
                                    else
                                    {
                                        dt.Rows[rowcount]["Error"] = "Special charaters(" + "',\"" + ") not allowed.";
                                    }
                                    dserr = CreateErrorDT(dserr, dt.Rows[rowcount]);

                                }
                            }
                            else if (dt.Columns[j].ColumnName.ToLower() == "error")
                            {

                            }
                            else
                            {
                                if (dt.Rows[rowcount][j].ToString().Length > 200 || dt.Rows[rowcount][j].ToString().Contains(",") == true || dt.Rows[rowcount][j].ToString().Contains("'") == true || dt.Rows[rowcount][j].ToString().Contains("\"") == true)
                                {
                                    if (dt.Rows[rowcount][j].ToString().Length > 200)
                                    {
                                        //dt.Rows[rowcount]["Error"] = "Column <strong>" + dt.Columns[j].ColumnName.ToString() + "</strong> length cannot be greater then 50 charaters";
                                        dt.Rows[rowcount]["Error"] = "Column \"" + dt.Columns[j].ColumnName.ToString() + "\" length cannot be greater then 200 charaters";
                                    }
                                    else
                                    {
                                        dt.Rows[rowcount]["Error"] = "Special charaters(" + "',\"" + ") not allowed.";
                                    }

                                    dserr = CreateErrorDT(dserr, dt.Rows[rowcount]);

                                }
                            }

                        }



                    }

                }

            }
        }
        catch (Exception ex)
        {

        }
        return dserr;
    }


    public string checkfortemplatetype(DataTable dt)
    {
        string ErrorMsg = "";
        string[] columnsname = ParentIDHidden.Value.Split(',');
        int colnum = 0;
        for (int colcount = 0; colcount <= columnsname.Length - 1; colcount++)
        {
            colnum = dt.Columns.IndexOf(columnsname[colcount]);


            if (dt.Columns[(colnum) + 1].ColumnName.ToLower().Contains("template") == true)
            {
                for (int hasvalue = 0; hasvalue <= dt.Rows.Count - 1; hasvalue++)
                {
                    if (dt.Rows[hasvalue][dt.Columns[(colnum) + 1].ColumnName.ToLower()].ToString() != "")
                    {
                        ErrorMsg = "Type Template should not have template value.";
                        break;
                    }
                }
            }



        }

        return ErrorMsg;
    }


    public DataTable ChangeDataType(DataTable dt)
    {
        int totalcol = 0;
        totalcol = dt.Columns.Count;
        for (int i = 0; i <= totalcol - 1; i++)
        {
            dt.Columns[i].DataType = typeof(string);
        }
        return dt;
    }
    protected void btnUpload_Click(object sender, EventArgs e)
    {
        try
        {
            Clear();
            gvdata.DataSource = null;
            gvdata.DataBind();
            DirectoryInfo odiDestination = null;
            DataTable odtExcel = null;// odtValidTable = null, odtErrTable = null, odtUploadErrTable = null;
            string destinationPath = string.Empty;
            destinationPath = Server.MapPath("../Upload");
            string destinationFileName = "";
            //destinationFileName = fleupload.FileName; //fleupload.PostedFile.FileName;
            destinationFileName = Path.GetFileName(fleupload.PostedFile.FileName.ToString());//Get the source file name.

            if (destinationFileName == string.Empty)//Check if file is uploaded.
            {
                lblErr.Text = "Please select a file to be uploaded.";
                return;
            }

            if (destinationFileName.EndsWith(".xls") == false && destinationFileName.EndsWith(".xlsx") == false)
            {
                lblErr.Text = "Invalid file format.";

                return;
            }


            odiDestination = new DirectoryInfo(destinationPath);
            if (!odiDestination.Exists)//If directory doesnot exists then create it.
                odiDestination.Create();
            else
            {
                foreach (FileInfo ofile in odiDestination.GetFiles())
                    ofile.Delete();//Delete any file if present in the Uploads directory.
            }

            destinationFileName = destinationPath + "\\" + destinationFileName;//Create the full file name with it path.

            fleupload.PostedFile.SaveAs(destinationFileName);//Save the uploaded file.

            //Read data from excel sheet and store the same in the datatable object.

            string ErrorMsg = "";
            //odtExcel = ExcelHelper.GetData(destinationFileName, out ErrorMsg);
            odtExcel = ExcelHelper.ReadExcel(destinationFileName, out ErrorMsg);
            if (ErrorMsg != "")
            {
                lblErr.Text = ErrorMsg;

                return;
            }

            IsFileValid(fleupload, out ErrorMsg);
            if (ErrorMsg != "")
            {
                lblErr.Text = ErrorMsg;

                return;
            }

            for (int colpos = 0; colpos <= odtExcel.Columns.Count - 1; colpos++)
            {

                if (odtExcel.Columns[colpos].ColumnName.ToString().ToLower().Contains("smartnote"))
                {
                    odtExcel.Columns[colpos].ColumnName = odtExcel.Columns[colpos].ColumnName.ToLower().Replace("smartnote", "WrapNote");
                }
            }

            int totalrowcount = 0;
            totalrowcount = odtExcel.Rows.Count;
            if (totalrowcount > Convert.ToInt16(System.Configuration.ConfigurationManager.AppSettings["MaxRowNum"]))
            {
                lblErr.Text = "Number of rows cannot be greater then " + System.Configuration.ConfigurationManager.AppSettings["MaxRowNum"];

                return;
            }

            string[] columnsname = ParentIDHidden.Value.Split(',');
            int columncount = 0;
            int totalcolums = odtExcel.Columns.Count;
            if (totalcolums > 0)
            {
                if (totalcolums < (columnsname.Length * 4))
                {
                    lblErr.Text = "File is not in correct format.";

                    return;
                }
            }
            else
            {
                lblErr.Text = "File is not in correct format.";

                return;
            }
            for (int k = 0; k <= columnsname.Length - 1; k++)
            {
                int colcountforname = 0;

                double Num;

                bool isNum = double.TryParse(columnsname[k], out Num);
                if (isNum == true)
                {
                    colcountforname = odtExcel.Columns.IndexOf("(" + columnsname[k] + ")");
                    if (odtExcel.Columns[colcountforname].ColumnName == "(" + columnsname[k] + ")")
                    {
                        columncount = columncount + 1;
                    }
                    else
                    {
                        columncount = 0;
                        break;
                    }
                }
                else
                {
                    colcountforname = odtExcel.Columns.IndexOf(columnsname[k]);
                    if (colcountforname >= 0)
                    {
                        if (odtExcel.Columns[colcountforname].ColumnName == columnsname[k])
                        {
                            columncount = columncount + 1;
                        }
                        else
                        {
                            columncount = 0;
                            break;
                        }
                    }
                    else
                    {
                        columncount = 0;
                        break;
                    }
                }

            }


            if (columncount == 0)
            {
                lblErr.Text = "Invalid control name.";

                return;
            }
            ErrorMsg = CheckColumnsName(odtExcel);
            if (ErrorMsg != "")
            {
                lblErr.Text = ErrorMsg;
                return;
            }

            odtExcel = FilterDataTable(odtExcel, false);
            //gvdata.DataSource = odtExcel;
            //gvdata.DataBind();
            //odtExcel = ChangeDataType(odtExcel);

            if (CategoryIDHidden.Value == "4")
            {
                string ErrorMagTemp = checkfortemplatetype(odtExcel);
                if (ErrorMagTemp != "")
                {
                    lblErr.Text = ErrorMagTemp;
                    return;
                }

            }
            dserr = ValidateData(odtExcel);
            if (dserr.Rows.Count > 0)
            {
                lblErr.Text = "Error while uploading data, Please check error list below.";

                gvdata.DataSource = dserr;
                gvdata.DataBind();
                gvdata.RowStyle.Wrap = true;//  = DataGridViewAutoSizeRowsMode.AllCells;
                //gvdata.Rows[1].Cells[4].Wrap = true;
                //gvdata.RowStyle.CssClass = "RowStylenew";
                //gvdata.AlternatingRowStyle.CssClass = "AltRowStylenew";
                if (gvdata.HeaderRow != null)
                {
                    gvdata.HeaderRow.Cells[0].Visible = false;
                    for (int i = 0; i <= gvdata.Rows.Count - 1; i++)
                    {
                        gvdata.Rows[i].Cells[0].Visible = false;
                    }
                }

                return;
            }
            else
            {
                dserr = null;
                odtExcel.Columns.Remove("Error");
            }

            if (odtExcel.Rows.Count > 0)
            {
                int tempcolhasrows = 0;
                string[] tempcolcount = ParentIDHidden.Value.Split(',');
                string tempcontrolname = "";
                int totalcounttemp = 0;
                for (int k = 0; k <= odtExcel.Columns.Count - 1; k++)
                {
                    if (odtExcel.Columns[k].ColumnName.Contains("Template"))
                    {
                        totalcounttemp = totalcounttemp + 1;
                        for (int valuecount = 0; valuecount <= odtExcel.Rows.Count - 1; valuecount++)
                        {

                            if (odtExcel.Rows[valuecount][k].ToString() != "" && odtExcel.Rows[valuecount][k].ToString() != "0")
                            {
                                tempcolhasrows = tempcolhasrows + 1;
                                if (tempcontrolname == "")
                                {
                                    tempcontrolname = odtExcel.Rows[valuecount].Table.Columns[(k - 1)].ColumnName;
                                }
                                else
                                {
                                    tempcontrolname = tempcontrolname + odtExcel.Rows[valuecount].Table.Columns[(k - 1)].ColumnName;
                                }

                                break;
                            }

                        }
                    }
                }


                //for (int colcount = 0; colcount <= tempcolcount.Length - 1; colcount++)
                //{


                //    for (int valuecount = 0; valuecount <= odtExcel.Rows.Count - 1; valuecount++)
                //    {
                //        if (colcount == 0)
                //        {
                //            if (odtExcel.Rows[valuecount]["Template"].ToString() != "" && odtExcel.Rows[valuecount]["Template"].ToString() != "0")
                //            {
                //                tempcolhasrows = tempcolhasrows + 1;
                //                if (tempcontrolname == "")
                //                {
                //                    tempcontrolname = odtExcel.Rows[valuecount].Table.Columns[(colcount * 4)].ColumnName;
                //                }
                //                else
                //                {
                //                    tempcontrolname = tempcontrolname + odtExcel.Rows[valuecount].Table.Columns[(colcount * 4)].ColumnName;
                //                }

                //                break;
                //            }
                //        }
                //        else
                //        {

                //            if (odtExcel.Rows[valuecount]["Template" + colcount.ToString()].ToString() != "" && odtExcel.Rows[valuecount]["Template" + colcount.ToString()].ToString() != "0")
                //            {
                //                tempcolhasrows = tempcolhasrows + 1;
                //                if (tempcontrolname == "")
                //                {
                //                    tempcontrolname = odtExcel.Rows[valuecount].Table.Columns[(colcount * 4)].ColumnName;
                //                }
                //                else
                //                {
                //                    tempcontrolname = tempcontrolname + odtExcel.Rows[valuecount].Table.Columns[(colcount * 4)].ColumnName;
                //                }
                //                break;
                //            }
                //        }
                //    }

                //}

                if (tempcolhasrows > 1)
                {
                    lblErr.Text = "Multiple control should not have template.";
                    return;
                }
                else if (tempcolhasrows == 1)
                {
                    string[] controlnames = tempcontrolname.Split(',');
                    for (int i = 0; i <= controlnames.Length - 1; i++)
                    {
                        if (hfTemplateControls.Value != controlnames[i].ToString() && TemplateControls.Count != 0)
                        {
                            lblErr.Text = "Template is already assigned on control <b>" + hfTemplateControls.Value + "</b>";
                            return;
                        }

                    }


                }
            }



            int totalColumCount = 0;
            int ColumCount = 0;
            totalColumCount = odtExcel.Columns.Count;
            for (int i = 0; i < totalColumCount; i++)
            {
                if (odtExcel.Columns[i].ColumnName.ToString().ToLower().Contains("template"))
                {
                    ColumCount = ColumCount + 1;
                }
            }
            DataManagement objDM = new DataManagement();
            DataSet objds;
            odtExcel.Columns.Add("Error", typeof(string));
            odtExcel.AcceptChanges();
            dserr = new DataTable();
            dserr = odtExcel.Clone();
            for (int j = 0; j < ColumCount; j++)
            {
                if (j == 0)
                {
                    odtExcel.Columns.Add("TemplateId", typeof(string));
                    odtExcel.Columns.Add("Dependid", typeof(string));
                    for (int rowcount = 0; rowcount <= odtExcel.Rows.Count - 1; rowcount++)
                    {

                        if (odtExcel.Rows[rowcount]["Template"].ToString().Trim() != "")
                        {
                            objds = new DataSet();
                            objds = objDM.GetTemplateId(odtExcel.Rows[rowcount]["Template"].ToString(), "");
                            if (objds.Tables.Count > 0)
                            {
                                if (objds.Tables[0].Rows.Count > 0)
                                {
                                    odtExcel.Rows[rowcount]["TemplateId"] = objds.Tables[0].Rows[0]["FORMID"].ToString();
                                }
                                else
                                {
                                    odtExcel.Rows[rowcount]["Error"] = "Invalid template name.Please upload proper template name.";
                                    dserr = CreateErrorDT(dserr, odtExcel.Rows[rowcount]);
                                }
                            }
                            else
                            {
                                odtExcel.Rows[rowcount]["Error"] = "Invalid template name.Please upload proper template name.";
                                dserr = CreateErrorDT(dserr, odtExcel.Rows[rowcount]);
                            }
                        }
                        else
                        {
                            odtExcel.Rows[rowcount]["TemplateId"] = "";
                        }
                        odtExcel.AcceptChanges();
                    }
                }
                else
                {

                    odtExcel.Columns.Add("TemplateId" + j.ToString(), typeof(string));
                    odtExcel.Columns.Add("Dependid" + j.ToString(), typeof(string));
                    for (int rowcount = 0; rowcount <= odtExcel.Rows.Count - 1; rowcount++)
                    {
                        if (odtExcel.Rows[rowcount]["Template" + j.ToString()].ToString().Trim() != "")
                        {

                            objds = new DataSet();
                            objds = objDM.GetTemplateId(odtExcel.Rows[rowcount]["Template" + j.ToString()].ToString(), "");
                            if (objds.Tables.Count > 0)
                            {
                                if (objds.Tables[0].Rows.Count > 0)
                                {
                                    odtExcel.Rows[rowcount]["TemplateId" + j.ToString()] = objds.Tables[0].Rows[0]["FORMID"].ToString();
                                }
                                else
                                {
                                    odtExcel.Rows[rowcount]["Error"] = "Invalid template name.Please upload proper template name.";
                                    dserr = CreateErrorDT(dserr, odtExcel.Rows[rowcount]);
                                }
                            }
                            else
                            {
                                odtExcel.Rows[rowcount]["Error"] = "Invalid template name.Please upload proper template name.";
                                dserr = CreateErrorDT(dserr, odtExcel.Rows[rowcount]);
                            }

                        }
                        else
                        {
                            odtExcel.Rows[rowcount]["TemplateId" + j.ToString()] = "";
                        }
                        odtExcel.AcceptChanges();
                    }
                }
            }


            if (dserr.Rows.Count > 0)
            {
                lblErr.Text = "Error while uploading data, Please check error list below.";

                gvdata.DataSource = dserr;
                gvdata.DataBind();

                if (gvdata.HeaderRow != null)
                {
                    gvdata.HeaderRow.Cells[0].Visible = false;
                    for (int i = 0; i <= gvdata.Rows.Count - 1; i++)
                    {
                        gvdata.Rows[i].Cells[0].Visible = false;
                    }
                }

                return;
            }
            else
            {
                dserr = null;
                odtExcel.Columns.Remove("Error");
            }



            string[] itemlist = ParentIDHidden.Value.Split(',');
            int itemcountnumber = 0;
            int itemtotalcount = 0;
            string parentitem = "";
            int totalitem = 0;
            totalitem = itemlist.Length;
            string prevparent = "";
            for (int k = 0; k <= totalitem - 1; k++)
            {
                for (int i = 0; i <= itemlist.Length - 1; i++)
                {
                    if (itemlist[i] != "")
                    {

                        parentitem = itemlist[totalitem - itemcountnumber - 1].ToString();

                    }
                }
                string[] itemlistid = ParentIdNameHidden.Value.Split(',');
                string parentitemid = "";
                for (int i = 0; i <= itemlistid.Length - 1; i++)
                {
                    if (itemlistid[i] != "")
                    {
                        parentitemid = itemlistid[totalitem - itemcountnumber - 1].ToString();
                    }
                }
                double Num;
                bool isNum = double.TryParse(parentitem, out Num);
                if (isNum == true)
                {

                    itemtotalcount = odtExcel.Columns.IndexOf("(" + parentitem + ")");
                }
                else
                {
                    itemtotalcount = odtExcel.Columns.IndexOf(parentitem);
                }
                if (itemtotalcount != 0)
                {
                    itemtotalcount = itemtotalcount / 4;//- 3;
                }
                if (itemtotalcount == 0)
                {
                    var x = (from r in odtExcel.AsEnumerable()
                             select new
                             {
                                 name = r.Field<string>((isNum == true) ? "(" + parentitem + ")" : parentitem).Replace("\n", "").Trim(),
                                 templateid = r.Field<string>("TemplateId"),
                                 WrapNote = r.Field<string>("WrapNote"),
                                 ToolTip = r.Field<string>("ToolTip")
                             }).Distinct().ToList();

                    foreach (var contrl in x)
                    {
                        //contrl.


                        CreateNodes("0", contrl.WrapNote, contrl.ToolTip, contrl.templateid, parentitemid, contrl.name, odtExcel, itemcountnumber, parentitem);
                    }
                }
                else
                {
                    int actualcount = 0;
                    if (itemcountnumber == 0)
                    {
                        actualcount = itemtotalcount;
                    }
                    else
                    {
                        actualcount = itemcountnumber;
                    }

                    var x = (from r in odtExcel.AsEnumerable()
                             select new
                             {
                                 name = r.Field<string>((isNum == true) ? "(" + parentitem + ")" : parentitem).Replace("\n", "").Trim(),
                                 templateid = r.Field<string>("TemplateId" + actualcount.ToString()),
                                 WrapNote = r.Field<string>("WrapNote" + actualcount.ToString()),
                                 ToolTip = r.Field<string>("ToolTip" + actualcount.ToString()),
                                 deptid = r.Field<string>("Dependid" + ((actualcount == 1) ? "" : (actualcount - 1).ToString()))

                             }).Distinct().ToList();

                    foreach (var contrl in x)
                    {
                        //contrl.


                        CreateNodes(contrl.deptid, contrl.WrapNote, contrl.ToolTip, contrl.templateid, parentitemid, contrl.name, odtExcel, itemcountnumber, parentitem);
                    }
                }
                prevparent = parentitem;
                itemcountnumber = itemcountnumber + 1;
            }


            lblErr.Text = "Data updated Successfully";
            lblErr.Style.Value = "Color:Green";
            UpdateXmlOnceDataChanged();
            //BindGrid();

        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }

    }

    public DataTable CreateErrorDT(DataTable dterr, DataRow drnew)
    {
        try
        {

            DataRow dr = dterr.NewRow();
            dr = drnew;

            dterr.ImportRow(dr);
            //dterr.Rows.Add(dr);
            dterr.AcceptChanges();
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }
        return dterr;
    }

    private void GoToNextForm()
    {
        ManageSession.FormID = int.Parse(FormIDHidden.Value);
        ManageSession.FormName = FormNameHidden.Value;
        ManageSession.XmlFileName = ReadXMLHidden.Value;
        ManageSession.CategoryID = int.Parse(CategoryIDHidden.Value);
        ManageSession.VersionID = int.Parse(VersionIDHidden.Value);
        ManageSession.FormMode = FileModeHidden.Value;
    }



    private void AppendFile(string controlnamenew)
    {

        //ReadNLoadFile();
        try
        {
            XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controltypeHidden.Value);



            for (int i = 0; i < rootNodeList.Count; i++)
            {
                XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if ((dropDownNode.ChildNodes[y].Name == "FieldID") && (dropDownNode.ChildNodes[y].InnerText == controlnamenew))
                    {
                        for (int j = 0; j < dropDownNode.ChildNodes.Count; j++)
                        {
                            XmlNode dropDownChildNode = (XmlNode)dropDownNode.ChildNodes[j];


                            if (dropDownChildNode.Name == "Title")
                            {
                                if (ParentIDHidden.Value == "")
                                {
                                    ParentIDHidden.Value = dropDownChildNode.InnerText;
                                }
                                else
                                {
                                    ParentIDHidden.Value = ParentIDHidden.Value + "," + dropDownChildNode.InnerText;
                                }
                            }

                            if (dropDownChildNode.Name == "FieldID")
                            {
                                if (ParentIdNameHidden.Value == "")
                                {
                                    ParentIdNameHidden.Value = controlnamenew;
                                }
                                else
                                {
                                    ParentIdNameHidden.Value = ParentIdNameHidden.Value + "," + controlnamenew;
                                }
                            }

                            string ExistingDepOnId = "";
                            string PrevRef = "";
                            if (dropDownChildNode.Name == "PrevRef")
                            {
                                PrevRef = dropDownChildNode.InnerText;



                                if (PrevRef.Trim() != "")
                                {
                                    AppendFile(PrevRef);
                                }
                                else
                                {
                                    return;


                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }


    }



    private void GetIdForControl(string controlnamenew)
    {
        try
        {
            ReadNLoadFile();
            string allitemid = "";
            XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controltypeHidden.Value);



            for (int i = 0; i < rootNodeList.Count; i++)
            {
                XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if ((dropDownNode.ChildNodes[y].Name == "Title") && (dropDownNode.ChildNodes[y].InnerText == controlnamenew))
                    {
                        for (int j = 0; j < dropDownNode.ChildNodes.Count; j++)
                        {
                            XmlNode dropDownChildNode = (XmlNode)dropDownNode.ChildNodes[j];


                            string ExistingDepOnId = "";
                            string controlid = "";
                            if (dropDownChildNode.Name == "FieldID")
                            {
                                controlid = dropDownChildNode.InnerText;
                                AppendFile(controlid);


                            }
                        }
                    }
                }
            }
        }

        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }

    }

    private void ReadNLoadFile()
    {
        FileName = Server.MapPath("..\\XML\\" + ReadXMLHidden.Value);
        doc = new XmlDocument();
        xmlDoc = XDocument.Load(FileName);
        doc.Load(FileName);

    }

    private void CreateNodes(string deptidon, string WrapNote, string Tooltip, string templateid, string controlid, string cvalue, DataTable odtExcel, int itemcount, string contrlname)
    {
        try
        {
            ReadNLoadFile();
            XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controltypeHidden.Value);
            string SelCtrlType = SelectedControl.Value;
            //** string DepOnId = SelectedValue.Value;  commennted since had problems due to next control's item selection
            string DepOnId = "";



            for (int i = 0; i < rootNodeList.Count; i++)
            {
                XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if ((dropDownNode.ChildNodes[y].Name == "FieldID") && (dropDownNode.ChildNodes[y].InnerText == controlid))
                    {
                        for (int j = 0; j < dropDownNode.ChildNodes.Count; j++)
                        {
                            XmlNode dropDownChildNode = (XmlNode)dropDownNode.ChildNodes[j];

                            string ListItemText = "";
                            string ExistingDepOnId = "";
                            string ExistingId = "";

                            if (dropDownChildNode.Name == "LISTITEMS")
                            {
                                bool isAvail = false;
                                XmlNodeList listItems = dropDownNode.ChildNodes[j].ChildNodes;
                                //XmlNodeList listItems = dropDownChildNode.ChildNodes.Count;
                                for (int l = 0; l < listItems.Count; l++)
                                {
                                    ListItemText = listItems.Item(l).InnerText.Trim();
                                    if (listItems.Item(l).Name == "LISTITEM")
                                    {
                                        ExistingDepOnId = listItems.Item(l).Attributes["DependentOn"].Value;
                                        ExistingId = listItems.Item(l).Attributes["Id"].Value;
                                    }

                                    // Checking if same list item exists for same parent node.
                                    if ((ListItemText.ToUpper().Trim() == cvalue.ToUpper()) && (DepOnId.Trim() == ExistingDepOnId.Trim()))
                                    {
                                        isAvail = true;
                                        l = listItems.Count;
                                        j = dropDownNode.ChildNodes.Count;
                                        y = dropDownNode.ChildNodes.Count;
                                        i = rootNodeList.Count;

                                        for (int t = 0; t <= odtExcel.Rows.Count - 1; t++)
                                        {
                                            double Num;
                                            bool isNum = double.TryParse(contrlname, out Num);

                                            if (odtExcel.Rows[t][(isNum == true) ? "(" + contrlname + ")" : contrlname].ToString().Trim() == cvalue)
                                            {
                                                if (itemcount == 0)
                                                {
                                                    if (odtExcel.Rows[t]["Dependid"].ToString() != ExistingId.ToString())
                                                    {
                                                        odtExcel.Rows[t]["Dependid"] = ExistingId.ToString();
                                                    }
                                                }
                                                else
                                                {
                                                    if (odtExcel.Rows[t]["Dependid" + (itemcount).ToString()].ToString() != ExistingId.ToString())
                                                    {
                                                        odtExcel.Rows[t]["Dependid" + (itemcount).ToString()] = ExistingId.ToString();
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                if (isAvail)
                                {


                                    //lblErr.Text = "This option already exists.";
                                }
                                else
                                {
                                    int NewId = 0;
                                    // int NewId = 0;
                                    if (dropDownChildNode.HasChildNodes)
                                    {
                                        NewId = int.Parse(dropDownChildNode.LastChild.Attributes["Id"].Value) + 1;
                                    }
                                    else
                                    {
                                        NewId = 1;
                                    }

                                    //if (itemcount  != 0)
                                    // {

                                    if (deptidon == "" || deptidon == null)
                                    {
                                        deptidon = "0";
                                    }

                                    XmlNode newChild = doc.CreateElement("LISTITEM");

                                    XmlAttribute newAttrId = doc.CreateAttribute("Id");
                                    newAttrId.InnerText = NewId.ToString();

                                    XmlAttribute newAttrVal = doc.CreateAttribute("value");
                                    newAttrVal.InnerText = "";  //** newAttr.InnerText = txtValue.Text;

                                    XmlAttribute newAttrDepOn = doc.CreateAttribute("DependentOn");
                                    newAttrDepOn.InnerText = deptidon;

                                    XmlAttribute newAttrWrapNote = doc.CreateAttribute("WrapNote");
                                    newAttrWrapNote.InnerText = (WrapNote != null) ? WrapNote.Replace("\r\n", "¢") : WrapNote;

                                    XmlAttribute newAttrOptionTooltip = doc.CreateAttribute("OptionTooltip");
                                    newAttrOptionTooltip.InnerText = Tooltip;

                                    XmlAttribute newAttrTemplate = doc.CreateAttribute("Template");
                                    newAttrTemplate.InnerText = templateid;

                                    // Do some stuff to the child node...
                                    newChild.Attributes.Append(newAttrId);
                                    newChild.Attributes.Append(newAttrVal);
                                    newChild.Attributes.Append(newAttrDepOn);
                                    newChild.Attributes.Append(newAttrWrapNote);
                                    newChild.Attributes.Append(newAttrOptionTooltip);
                                    newChild.Attributes.Append(newAttrTemplate);
                                    newChild.InnerText = cvalue;



                                    // Add the child node to the root node
                                    string id = "";
                                    bool result = checkexists(controlid, deptidon, cvalue, out id);
                                    if (result == true)
                                    {
                                        dropDownChildNode.AppendChild(newChild);

                                        doc.Save(FileName);         // Add the listitem and save the file


                                    }



                                    for (int t = 0; t <= odtExcel.Rows.Count - 1; t++)
                                    {
                                        double Num;
                                        bool isNum = double.TryParse(contrlname, out Num);


                                        if (odtExcel.Rows[t][(isNum == true) ? "(" + contrlname + ")" : contrlname].ToString().Trim() == cvalue)
                                        {
                                            if (itemcount == 0)
                                            {
                                                if (id == "")
                                                {
                                                    if (odtExcel.Rows[t]["Dependid"].ToString() == "")
                                                    {
                                                        odtExcel.Rows[t]["Dependid"] = NewId.ToString();
                                                    }
                                                }
                                                else
                                                {
                                                    if (odtExcel.Rows[t]["Dependid"].ToString() == "")
                                                    {
                                                        odtExcel.Rows[t]["Dependid"] = id;
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                if (odtExcel.Rows[t]["Dependid" + ((itemcount == 1) ? "" : (itemcount - 1).ToString()).ToString()].ToString() == deptidon)
                                                {
                                                    if (id == "")
                                                    {
                                                        if (odtExcel.Rows[t]["Dependid" + (itemcount).ToString()].ToString() == "")
                                                        {
                                                            odtExcel.Rows[t]["Dependid" + (itemcount).ToString()] = NewId.ToString();
                                                        }
                                                    }
                                                    else
                                                    {
                                                        if (odtExcel.Rows[t]["Dependid" + (itemcount).ToString()].ToString() == "")
                                                        {
                                                            odtExcel.Rows[t]["Dependid" + (itemcount).ToString()] = id;
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }
    }

    protected void imgBack_Click(object sender, ImageClickEventArgs e)
    {
        GoToNextForm();
        Response.Redirect("../Admin/DataManagement.aspx", true);
    }
    protected void btnupdate_Click(object sender, EventArgs e)
    {
        Clear();
        BindGrid();
    }

    public void BindGrid()
    {
        try
        {
            string[] itemlist = ParentIDHidden.Value.Split(',');

            string controltype = controlIDHidden.Value;

            DataTable itemsdt = new DataTable();

            for (int i = 0; i <= itemlist.Length - 1; i++)
            {
                double Num;
                bool isNum = double.TryParse(itemlist[i].ToString(), out Num);
                itemsdt.Columns.Add((isNum == true) ? itemlist[i].ToString() : itemlist[i].ToString(), typeof(string));
                itemsdt.Columns.Add("deptid" + itemlist[i].ToString(), typeof(string));
                if (i == 0)
                {
                    itemsdt.Columns.Add("Template", typeof(string));
                    itemsdt.Columns.Add("WrapNote", typeof(string));
                    itemsdt.Columns.Add("Tooltip", typeof(string));
                }
                else
                {
                    itemsdt.Columns.Add("Template" + i.ToString(), typeof(string));
                    itemsdt.Columns.Add("WrapNote" + i.ToString(), typeof(string));
                    itemsdt.Columns.Add("Tooltip" + i.ToString(), typeof(string));
                }
                GetControl(itemlist[i].ToString(), itemsdt, i);
            }


            itemsdt = FilterDataTable(itemsdt, true);


            gvdata.DataSource = itemsdt;
            gvdata.DataBind();

            if (gvdata.HeaderRow != null)
            {
                for (int itemscol = 0; itemscol <= gvdata.HeaderRow.Cells.Count - 1; itemscol++)
                {
                    if (gvdata.HeaderRow.Cells[itemscol].Text.Contains("deptid") == true)
                    {
                        gvdata.HeaderRow.Cells[itemscol].Visible = false;
                        for (int i = 0; i <= gvdata.Rows.Count - 1; i++)
                        {
                            gvdata.Rows[i].Cells[itemscol].Visible = false;
                        }
                    }
                }
            }

            else
            {
                lblErr.Text = "No record found.";


            }
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }
    }



    public DataTable GetControl(string controlnamenew, DataTable itemsdt, int controlcount)
    {
        try
        {
            ReadNLoadFile();
            XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controltypeHidden.Value);




            for (int i = 0; i < rootNodeList.Count; i++)
            {

                XmlNode dropDownNode = (XmlNode)rootNodeList[i];


                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if ((dropDownNode.ChildNodes[y].Name == "Title") && (dropDownNode.ChildNodes[y].InnerText == controlnamenew))
                    {
                        for (int j = 0; j < dropDownNode.ChildNodes.Count; j++)
                        {

                            XmlNode ndFieldID = dropDownNode.SelectSingleNode("FieldID");
                            XmlNode ndListItems = dropDownNode.SelectSingleNode("LISTITEMS");
                            XmlNode ndText = dropDownNode.SelectSingleNode("DependentID");

                            string FieldID = "";
                            string ListItemText = "";
                            string DependentID = "";

                            FieldID = ndFieldID.InnerText;
                            DependentID = ndText.InnerText;

                            XmlNodeList listItems = ndListItems.ChildNodes;

                            for (int l = 0; l < listItems.Count; l++)
                            {
                                ListItemText = listItems.Item(l).InnerText;

                                if (listItems.Item(l).Name == "LISTITEM")
                                {
                                    string prevrefcontrolname = "";

                                    GetNameForDependent(DependentID, out prevrefcontrolname);

                                    DataRow dr = itemsdt.NewRow();
                                    if (DependentID == "" || (ParentIDHidden.Value.ToString().Contains(prevrefcontrolname) == false))
                                    {
                                        double Num;
                                        bool isNum = double.TryParse(controlnamenew, out Num);
                                        dr[(isNum == true) ? controlnamenew.ToString() : controlnamenew] = ListItemText.ToString();
                                        dr["deptid" + controlnamenew] = listItems.Item(l).Attributes["DependentOn"].Value.ToString();
                                        //dr[prevrefcontrolname] = deptname.ToString();
                                        if (controlcount == 0)
                                        {
                                            if (listItems.Item(l).Attributes["Template"].Value.ToString() != "")
                                            {
                                                DataSet objds = new DataSet();
                                                DataManagement objDM = new DataManagement();

                                                objds = new DataSet();
                                                objds = objDM.GetTemplateId("", listItems.Item(l).Attributes["Template"].Value.ToString());
                                                if (objds.Tables.Count > 0)
                                                {
                                                    if (objds.Tables[0].Rows.Count > 0)
                                                    {
                                                        dr["Template"] = objds.Tables[0].Rows[0]["FormName"].ToString();
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                dr["Template"] = "";
                                            }


                                            dr["WrapNote"] = listItems.Item(l).Attributes["WrapNote"].Value.ToString();
                                            dr["Tooltip"] = listItems.Item(l).Attributes["OptionTooltip"].Value.ToString();
                                        }
                                        else
                                        {
                                            if (listItems.Item(l).Attributes["Template"].Value.ToString() != "")
                                            {
                                                DataSet objds = new DataSet();
                                                DataManagement objDM = new DataManagement();

                                                objds = new DataSet();
                                                objds = objDM.GetTemplateId("", listItems.Item(l).Attributes["Template"].Value.ToString());
                                                if (objds.Tables.Count > 0)
                                                {
                                                    if (objds.Tables[0].Rows.Count > 0)
                                                    {
                                                        dr["Template" + controlcount.ToString()] = objds.Tables[0].Rows[0]["FormName"].ToString();
                                                    }
                                                }
                                            }
                                            else
                                            {
                                                dr["Template" + controlcount.ToString()] = "";
                                            }

                                            dr["WrapNote" + controlcount.ToString()] = listItems.Item(l).Attributes["WrapNote"].Value.ToString();
                                            dr["Tooltip" + controlcount.ToString()] = listItems.Item(l).Attributes["OptionTooltip"].Value.ToString();
                                        }
                                        itemsdt.Rows.Add(dr);
                                    }
                                    else
                                    {
                                        for (int k = 0; k <= itemsdt.Rows.Count - 1; k++)
                                        {
                                            if (itemsdt.Rows[k]["deptid" + prevrefcontrolname].ToString() == listItems.Item(l).Attributes["Id"].Value.ToString())
                                            {
                                                double Num;
                                                bool isNum = double.TryParse(controlnamenew, out Num);

                                                itemsdt.Rows[k][(isNum == true) ? controlnamenew.ToString() : controlnamenew] = ListItemText.ToString();
                                                itemsdt.Rows[k]["deptid" + controlnamenew] = listItems.Item(l).Attributes["DependentOn"].Value.ToString();
                                                if (controlcount == 0)
                                                {
                                                    if (listItems.Item(l).Attributes["Template"].Value.ToString() != "")
                                                    {
                                                        DataSet objds = new DataSet();
                                                        DataManagement objDM = new DataManagement();

                                                        objds = new DataSet();
                                                        objds = objDM.GetTemplateId("", listItems.Item(l).Attributes["Template"].Value.ToString());
                                                        if (objds.Tables.Count > 0)
                                                        {
                                                            if (objds.Tables[0].Rows.Count > 0)
                                                            {
                                                                itemsdt.Rows[k]["Template"] = objds.Tables[0].Rows[0]["FormName"].ToString();
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        dr["Template"] = "";
                                                    }
                                                    itemsdt.Rows[k]["WrapNote"] = listItems.Item(l).Attributes["WrapNote"].Value.ToString();
                                                    itemsdt.Rows[k]["Tooltip"] = listItems.Item(l).Attributes["OptionTooltip"].Value.ToString();
                                                }
                                                else
                                                {
                                                    if (listItems.Item(l).Attributes["Template"].Value.ToString() != "")
                                                    {
                                                        DataSet objds = new DataSet();
                                                        DataManagement objDM = new DataManagement();

                                                        objds = new DataSet();
                                                        objds = objDM.GetTemplateId("", listItems.Item(l).Attributes["Template"].Value.ToString());
                                                        if (objds.Tables.Count > 0)
                                                        {
                                                            if (objds.Tables[0].Rows.Count > 0)
                                                            {
                                                                itemsdt.Rows[k]["Template" + controlcount.ToString()] = objds.Tables[0].Rows[0]["FormName"].ToString();
                                                            }
                                                        }
                                                    }
                                                    else
                                                    {
                                                        itemsdt.Rows[k]["Template" + controlcount.ToString()] = "";
                                                    }
                                                    itemsdt.Rows[k]["WrapNote" + controlcount.ToString()] = listItems.Item(l).Attributes["WrapNote"].Value.ToString();
                                                    itemsdt.Rows[k]["Tooltip" + controlcount.ToString()] = listItems.Item(l).Attributes["OptionTooltip"].Value.ToString();
                                                }
                                                //itemsdt.Rows.Add(dr);
                                            }
                                        }
                                    }





                                    itemsdt.AcceptChanges();


                                }
                            }
                            break;
                        }
                    }
                }

            }
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }

        return itemsdt;

    }


    private void GetNameForDependent(string controlnamenew, out string prevrefcontrolname)
    {
        prevrefcontrolname = "";
        try
        {

            //ReadNLoadFile();

            XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controltypeHidden.Value);

            string ListItemText = "";

            for (int i = 0; i < rootNodeList.Count; i++)
            {
                XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if ((dropDownNode.ChildNodes[y].Name == "FieldID") && (dropDownNode.ChildNodes[y].InnerText == controlnamenew))
                    {
                        for (int j = 0; j < dropDownNode.ChildNodes.Count; j++)
                        {
                            XmlNode dropDownChildNode = (XmlNode)dropDownNode.ChildNodes[j];

                            if (dropDownChildNode.Name == "Title")
                            {
                                prevrefcontrolname = dropDownChildNode.InnerText;

                            }




                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }

    }



    protected void btndelete_Click(object sender, EventArgs e)
    {
        try
        {
            Clear();
            int deleterowcount = 0;
            string deptID = "";
            string itemname = "";
            string deletecontrolname = "";
            int remaingitemcount = 0;
            for (int i = 0; i < gvdata.Rows.Count; i++)
            {

                CheckBox chkDelete = gvdata.Rows[i].FindControl("chkDeleteStatus") as CheckBox;

                if (chkDelete.Checked)
                {
                    deptID = "";
                    itemname = "";
                    deleterowcount = deleterowcount + 1;
                    deptID = gvdata.Rows[i].Cells[2].Text;
                    itemname = gvdata.Rows[i].Cells[1].Text;
                    deletecontrolname = controlIDHidden.Value;
                    remaingitemcount = DeleteNodes(deptID, itemname, deletecontrolname);

                }
            }
            UpdateXmlOnceDataChanged();
            BindGrid();



            if (deleterowcount == 0)
            {


                lblErr.Text = "Please select atleast one record to delete.";

                return;


            }

        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }
    }

    private int DeleteNodes(string deptidon, string cvalue, string deletecontrolname)
    {
        int remainingitemcount = 0;
        try
        {

            ReadNLoadFile();
            XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controltypeHidden.Value);
            string SelCtrlType = SelectedControl.Value;
            //** string DepOnId = SelectedValue.Value;  commennted since had problems due to next control's item selection

            string Listid = "";
            string ExistingDepOnId = "";
            for (int i = 0; i < rootNodeList.Count; i++)
            {
                XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if ((dropDownNode.ChildNodes[y].Name == "Title") && (dropDownNode.ChildNodes[y].InnerText == deletecontrolname))
                    {
                        for (int j = 0; j < dropDownNode.ChildNodes.Count; j++)
                        {
                            XmlNode dropDownChildNode = (XmlNode)dropDownNode.ChildNodes[j];




                            if (dropDownChildNode.Name == "DependentID")
                            {
                                ExistingDepOnId = dropDownChildNode.InnerText;

                            }


                            if (dropDownChildNode.Name == "LISTITEMS")
                            {
                                XmlNode lst;
                                if (deptidon.Replace("&nbsp;", "") != "")
                                {
                                    lst = dropDownChildNode.SelectSingleNode("LISTITEM[@DependentOn=" + deptidon + " and text()='" + cvalue.Replace("&amp;", "&").Replace("&lt;", "<").Replace("&gt;", ">") + "']");
                                }
                                else
                                {
                                    lst = dropDownChildNode.SelectSingleNode("LISTITEM[text()='" + cvalue.Replace("&amp;", "&").Replace("&lt;", "<").Replace("&gt;", ">") + "']");
                                }
                                Listid = lst.Attributes["Id"].Value;
                                lst.ParentNode.RemoveChild(lst);

                                if (ExistingDepOnId != "")
                                {
                                    deletechildnode(ExistingDepOnId, Listid);
                                }
                                doc.Save(FileName);
                                if (deptidon.Replace("&nbsp;", "") != "")
                                {
                                    if (dropDownChildNode.SelectSingleNode("LISTITEM[@DependentOn=" + deptidon + "]") != null)
                                    {
                                        if (dropDownChildNode.SelectSingleNode("LISTITEM[@DependentOn=" + deptidon + "]").ChildNodes.Count != null)
                                        {
                                            remainingitemcount = dropDownChildNode.SelectSingleNode("LISTITEM[@DependentOn=" + deptidon + "]").ChildNodes.Count;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }
        return remainingitemcount;
    }

    private void deletechildnode(string deletecontrolname, string deptid)
    {
        try
        {
            string dependcontrol = "";

            XmlNode ControlNode = doc.SelectNodes("//" + controltypeHidden.Value + "[FieldID='" + deletecontrolname + "']")[0];

            XmlNode lstitem = ControlNode.SelectSingleNode("LISTITEMS");
            XmlNodeList lst;
            if (deptid.Replace("&nbsp;", "") != "")
            {
                lst = ControlNode.SelectNodes("LISTITEMS/LISTITEM[@DependentOn=" + deptid + "]");
                for (int i = 0; i <= lst.Count - 1; i++)
                {
                    if (ControlNode.SelectSingleNode("DependentID") != null)
                    {
                        dependcontrol = ControlNode.SelectSingleNode("DependentID").InnerText;
                        if (dependcontrol != "" && dependcontrol != null)
                        {
                            deletechildnode(dependcontrol, lst[i].Attributes["Id"].Value);
                        }
                    }
                    lstitem.RemoveChild(lst[i]);
                }
            }
            // doc.Save(FileName);
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }
    }


    private bool checkexists(string controlid, string deptid, string cvalue, out string id)
    {
        id = "";
        bool result = true;
        try
        {

            string dependcontrol = "";

            XmlNode ControlNode = doc.SelectNodes("//" + controltypeHidden.Value + "[FieldID='" + controlid + "']")[0];

            XmlNode lstitem = ControlNode.SelectSingleNode("LISTITEMS");
            XmlNodeList lst = ControlNode.SelectNodes("LISTITEMS/LISTITEM[@DependentOn=" + deptid + " and text()='" + cvalue.Replace("&amp;", "&").Replace("&lt;", "<").Replace("&gt;", ">") + "']");
            if (lst.Count != 0)
            {
                id = lst.Item(0).Attributes["Id"].Value;
                result = false;
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }
        return result;
        // doc.Save(FileName);
    }


    public void Clear()
    {
        lblErr.Text = "";
        lblErr.Style.Value = "Color:Red";
        //gvdata.AlternatingRowStyle.CssClass = "AltRowStyle";
        //gvdata.RowStyle.CssClass = "RowStyle";

    }


    private void UpdateXmlOnceDataChanged()
    {
        XmlNodeList rootNodeListScript = doc.SelectNodes("FORMS/DataScript");
        if (rootNodeListScript.Count == 0)
        {
            XmlNode node = doc.CreateNode(XmlNodeType.Element, "DataScript", "");
            XmlNode IsUpdatedNode = doc.CreateNode(XmlNodeType.Element, "IsUpdated", "");
            XmlNode ArrayNode = doc.CreateNode(XmlNodeType.Element, "Array", "");

            IsUpdatedNode.InnerText = "False";

            node.AppendChild(IsUpdatedNode);
            node.AppendChild(ArrayNode);
            doc.DocumentElement.AppendChild(node);

            doc.Save(FileName);         // Add the listitem and save the file
        }
        else
        {
            XmlNode DataScriptUpdateNode = (XmlNode)rootNodeListScript[0];
            XmlNode IsUpdatedChildNode = (XmlNode)DataScriptUpdateNode.ChildNodes[0];// node <IsUpdated>
            IsUpdatedChildNode.InnerText = "False";
            doc.Save(FileName);         // Add the Script and save the file
        }
    }


    //added download option to download values of a logger added by koshal
    protected void btnDownLoad_Click(object sender, EventArgs e)
    {
        //controlIDHidden.Value = ManageSession.ControlName;
        //controltypeHidden.Value = ManageSession.ControlType;

        if (controltypeHidden.Value == "DropDownList" || controltypeHidden.Value == "ListBox")
        {
            DataSet ds = new DataSet();
            GetDataToDownload(controlIDHidden.Value, controltypeHidden.Value, ds);
            int tblcount = 0;
            DataTable jt = new DataTable("Joinedtable");
            if (ds.Tables.Count > 0)
            {
                for (int i = 0; i <= ds.Tables.Count - 1; i++)
                {

                    if (jt.Columns.Count == 0)
                    {
                        jt = ds.Tables[i].Copy();
                        foreach (DataRow row in jt.Rows)
                        {
                            if (row["DependentOn"].ToString() == "")
                                row.Delete();
                        }
                        jt.AcceptChanges();
                    }
                    else
                    {
                        for (int k = 0; k <= ds.Tables[i].Columns.Count - 1; k++)
                        {
                            if (k == 0)
                            {
                                jt.Columns.Add(ds.Tables[i].Columns[k].ColumnName);
                            }
                            else
                            {
                                jt.Columns.Add(ds.Tables[i].Columns[k].ColumnName + tblcount.ToString());
                            }
                        }

                        string dependentOn = "";
                        string newid = "";
                        for (int rowcount = 0; rowcount <= jt.Rows.Count - 1; rowcount++)
                        {
                            for (int newrowcount = 0; newrowcount <= ds.Tables[i].Rows.Count - 1; newrowcount++)
                            {
                                if (tblcount == 1)
                                {
                                    dependentOn = jt.Rows[rowcount]["DependentOn"].ToString();
                                }
                                else
                                {


                                    dependentOn = jt.Rows[rowcount]["DependentOn" + (tblcount - 1).ToString()].ToString();
                                }
                                newid = ds.Tables[i].Rows[newrowcount]["Id"].ToString();
                                if (newid != "" && dependentOn != "")
                                {
                                    if (Convert.ToInt16(dependentOn) == Convert.ToInt16(ds.Tables[i].Rows[newrowcount]["Id"].ToString()))
                                    {
                                        jt.Rows[rowcount][ds.Tables[i].Columns[0].ColumnName.ToString()] = ds.Tables[i].Rows[newrowcount][0];
                                        jt.Rows[rowcount]["Id" + tblcount.ToString()] = ds.Tables[i].Rows[newrowcount]["Id"];
                                        jt.Rows[rowcount]["DependentOn" + tblcount.ToString()] = ds.Tables[i].Rows[newrowcount]["DependentOn"];
                                        jt.Rows[rowcount]["WrapNote" + tblcount.ToString()] = ds.Tables[i].Rows[newrowcount]["WrapNote"];
                                        jt.Rows[rowcount]["Tooltip" + tblcount.ToString()] = ds.Tables[i].Rows[newrowcount]["Tooltip"];
                                        jt.Rows[rowcount]["Template" + tblcount.ToString()] = ds.Tables[i].Rows[newrowcount]["Template"];
                                        break;
                                    }
                                }
                            }
                        }
                    }



                    tblcount = tblcount + 1;

                }

                for (int colcount = jt.Columns.Count - 1; colcount >= 0; colcount--)
                {
                    if (jt.Columns[colcount].ColumnName.Contains("Id") == true || jt.Columns[colcount].ColumnName.Contains("DependentOn") == true)
                    {
                        jt.Columns.Remove(jt.Columns[colcount].ColumnName);
                    }
                }
                jt = RearrangeColumns(jt);
                ExportToExcel(jt);
            }

        }
        else
        {
            lblErr.Text = "Download option only available for dropdown or listbox.";
        }

    }

    public DataSet GetDataToDownload(string controlname, string controltype, DataSet downloadds)
    {
        try
        {
            ReadNLoadFile();
            XmlNodeList rootNodeList = doc.SelectNodes("//FORMS/" + controltype);

            for (int i = 0; i < rootNodeList.Count; i++)
            {
                XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                XmlNode ndFieldID = dropDownNode.SelectSingleNode("FieldID");
                XmlNode ndListItems = dropDownNode.SelectSingleNode("LISTITEMS");
                XmlNode ndText = dropDownNode.SelectSingleNode("Label").SelectSingleNode("Text");
                XmlNode ndPrevRef = dropDownNode.SelectSingleNode("PrevRef");
                string FieldID = "";
                string ListItemText = "";
                string controlLabel = "";
                string prevref = ndPrevRef.InnerText;
                FieldID = ndFieldID.InnerText;
                controlLabel = ndText.InnerText;
                if (controlname == controlLabel || FieldID == controlname)
                {


                    XmlNodeList listItems = ndListItems.ChildNodes;
                    DataTable dt = new DataTable();
                    dt.Clear();
                    dt.Columns.Add(controlLabel);
                    dt.Columns.Add("Id");
                    dt.Columns.Add("DependentOn");
                    dt.Columns.Add("Template");
                    dt.Columns.Add("WrapNote");
                    dt.Columns.Add("Tooltip");


                    for (int l = 0; l < listItems.Count; l++)
                    {
                        ListItemText = listItems.Item(l).InnerText;

                        if (listItems.Item(l).Name == "LISTITEM")
                        {

                            DataRow dr = dt.NewRow();
                            dr[controlLabel] = ListItemText;
                            dr["Id"] = listItems.Item(l).Attributes["Id"].Value;
                            dr["DependentOn"] = listItems.Item(l).Attributes["DependentOn"].Value;

                            if (listItems.Item(l).Attributes["WrapNote"] != null && listItems.Item(l).Attributes["WrapNote"].Value != "")
                            {
                                dr["WrapNote"] = listItems.Item(l).Attributes["WrapNote"].Value;
                            }
                            else
                            {
                                dr["WrapNote"] = "";
                            }
                            if (listItems.Item(l).Attributes["OptionTooltip"] != null && listItems.Item(l).Attributes["OptionTooltip"].Value != "")
                            {
                                dr["Tooltip"] = listItems.Item(l).Attributes["OptionTooltip"].Value;
                            }
                            else
                            {
                                dr["Tooltip"] = "";
                            }
                            if (listItems.Item(l).Attributes["Template"] != null && listItems.Item(l).Attributes["Template"].Value != "")
                            {
                                //dr["Template"] = listItems.Item(l).Attributes["Template"].Value;
                                DataSet objds = new DataSet();
                                DataManagement objDM = new DataManagement();

                                objds = new DataSet();
                                objds = objDM.GetTemplateId("", listItems.Item(l).Attributes["Template"].Value.ToString());
                                if (objds.Tables.Count > 0)
                                {
                                    if (objds.Tables[0].Rows.Count > 0)
                                    {
                                        dr["Template"] = objds.Tables[0].Rows[0]["FormName"].ToString();
                                    }
                                }
                            }
                            else
                                dr["Template"] = "";

                            dt.Rows.Add(dr);


                        }
                    }

                    downloadds.Tables.Add(dt);
                    if (prevref != "")
                    {
                        GetDataToDownload(prevref, controltype, downloadds);
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }

        return downloadds;
    }



    public void ExportToExcel(DataTable dt)
    {


        try
        {
            if (dt.Rows.Count > 0)
            {
                string filename = FormNameHidden.Value + ".xls";
                dt.TableName = "Sheet1";
                EVOLib.ExcelHelper.ToExcel(dt, filename, Response);

                //System.IO.StringWriter tw = new System.IO.StringWriter();
                //System.Web.UI.HtmlTextWriter hw = new System.Web.UI.HtmlTextWriter(tw);
                //DataGrid dgGrid = new DataGrid();
                //dt.TableName = "[Sheet1]";
                //dgGrid.DataSource = dt;
                //dgGrid.DataBind();

                ////Get the HTML for the control.
                //dgGrid.RenderControl(hw);

                ////Write the HTML back to the browser.
                ////Response.ContentType = application/vnd.ms-excel;
                //Response.ContentType = "application/vnd.ms-excel";
                //Response.AppendHeader("Content-Disposition", "attachment; filename=" + filename + "");
                ////this.EnableViewState = false;

                //Response.Write(tw.ToString());
                //Response.End();
            }
        }
        catch (Exception ex)
        {

        }
    }

    public DataTable RearrangeColumns(DataTable dt)
    {
        DataTable rearrangedt = new DataTable();
        string columnnames = "";
        for (int i = dt.Columns.Count - 1; i >= 0; i--)
        {
            if (dt.Columns[i].ColumnName.Contains("WrapNote") == false && dt.Columns[i].ColumnName.Contains("Tooltip") == false && dt.Columns[i].ColumnName.Contains("Template") == false)
            {
                if (columnnames == "")
                {
                    columnnames = dt.Columns[i].ColumnName + "," + dt.Columns[i + 1].ColumnName + "," + dt.Columns[i + 2].ColumnName + "," + dt.Columns[i + 3].ColumnName;
                }
                else
                {
                    columnnames = columnnames + "," + dt.Columns[i].ColumnName + "," + dt.Columns[i + 1].ColumnName + "," + dt.Columns[i + 2].ColumnName + "," + dt.Columns[i + 3].ColumnName;
                }
            }
        }

        string[] columns = columnnames.Split(',');
        for (int colpos = 0; colpos <= columns.Length - 1; colpos++)
        {

            dt.Columns[columns[colpos]].SetOrdinal(colpos);
            if (dt.Columns[colpos].ColumnName.ToString().ToLower().Contains("wrapnote"))
            {
                dt.Columns[colpos].ColumnName = dt.Columns[colpos].ColumnName.Replace("WrapNote", "SmartNote");
            }
            //dt.Columns[colpos].ColumnName = dt.Columns[colpos].ColumnName + "0";
        }

        dt.DefaultView.Sort = "[" + columns[0] + "]" + " ASC";
        dt = dt.DefaultView.ToTable();

        int totalrowcount = (dt.Columns.Count / 4);
        //totalrowcount = totalrowcount + 1;

        for (int totalrows = dt.Rows.Count - 1; totalrows >= 0; totalrows--)
        {
            bool isemptyrow = false;
            for (int i = 0; i <= totalrowcount - 1; i++)
            {
                if (dt.Rows[totalrows][(i * 4)].ToString() == "")
                {
                    isemptyrow = true;
                    break;
                }
            }
            if (isemptyrow == true)
            {
                DataRow row = dt.Rows[totalrows];
                dt.Rows.Remove(row);
            }
        }
        dt = RearrangecolumnNames(dt, totalrowcount);
        return dt;
    }

    public DataTable RearrangecolumnNames(DataTable dt, int totalrowcount)
    {
        for (int i = 0; i <= totalrowcount - 1; i++)
        {
            if (i != totalrowcount - 1)
            {
                if (i == 0)
                {
                    dt.Columns[(i * 4) + 1].ColumnName = dt.Columns[(i * 4) + 1].ColumnName.Remove(dt.Columns[(i * 4) + 1].ColumnName.Length - 1) + "0";
                    dt.Columns[(i * 4) + 2].ColumnName = dt.Columns[(i * 4) + 2].ColumnName.Remove(dt.Columns[(i * 4) + 2].ColumnName.Length - 1) + "0";
                    dt.Columns[(i * 4) + 3].ColumnName = dt.Columns[(i * 4) + 3].ColumnName.Remove(dt.Columns[(i * 4) + 3].ColumnName.Length - 1) + "0";
                }
                else
                {
                    dt.Columns[(i * 4) + 1].ColumnName = dt.Columns[(i * 4) + 1].ColumnName.Remove(dt.Columns[(i * 4) + 1].ColumnName.Length - 1) + i.ToString() + "0";
                    dt.Columns[(i * 4) + 2].ColumnName = dt.Columns[(i * 4) + 2].ColumnName.Remove(dt.Columns[(i * 4) + 2].ColumnName.Length - 1) + i.ToString() + "0";
                    dt.Columns[(i * 4) + 3].ColumnName = dt.Columns[(i * 4) + 3].ColumnName.Remove(dt.Columns[(i * 4) + 3].ColumnName.Length - 1) + i.ToString() + "0";
                }
            }
            else
            {
                dt.Columns[(i * 4) + 1].ColumnName = dt.Columns[(i * 4) + 1].ColumnName + i.ToString() + "0";
                dt.Columns[(i * 4) + 2].ColumnName = dt.Columns[(i * 4) + 2].ColumnName + i.ToString() + "0";
                dt.Columns[(i * 4) + 3].ColumnName = dt.Columns[(i * 4) + 3].ColumnName + i.ToString() + "0";
            }

        }

        for (int rowcount = 0; rowcount <= dt.Columns.Count - 1; rowcount++)
        {
            dt.Columns[rowcount].ColumnName = dt.Columns[rowcount].ColumnName.Replace("0", "");
        }
        return dt;
    }
}