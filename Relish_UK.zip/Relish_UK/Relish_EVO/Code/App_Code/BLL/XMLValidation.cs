using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml;
using System.Xml.Schema;
using System.IO;
using System.Collections;

/// <summary>
/// Summary description for XMLValidation
/// </summary>
namespace EVOLib
{
    public class XMLValidation
    {
        public XMLValidation()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        
        private XmlTextReader Reader;
        private ArrayList Results = new ArrayList();      

        public void ValidatingProcess(string XSDPath, string XMLPath)
        {
            try
            {
                // 1- Read XML file content
                this.Reader = new XmlTextReader(XMLPath);

                // 2- Read Schema file content
                StreamReader SR = new StreamReader(XSDPath);

                // 3- Create a new instance of XmlSchema object
                XmlSchema Schema = new XmlSchema();
                // 4- Set Schema object by calling XmlSchema.Read() method
                Schema = XmlSchema.Read(SR,
                    new ValidationEventHandler(ReaderSettings_ValidationEventHandler));

                // 5- Create a new instance of XmlReaderSettings object
                XmlReaderSettings ReaderSettings = new XmlReaderSettings();
                // 6- Set ValidationType for XmlReaderSettings object
                ReaderSettings.ValidationType = ValidationType.Schema;
                // 7- Add Schema to XmlReaderSettings Schemas collection
                ReaderSettings.Schemas.Add(Schema);

                // 8- Add your ValidationEventHandler address to
                // XmlReaderSettings ValidationEventHandler
                ReaderSettings.ValidationEventHandler +=
                    new ValidationEventHandler(ReaderSettings_ValidationEventHandler);

                // 9- Create a new instance of XmlReader object
                XmlReader objXmlReader = XmlReader.Create(Reader, ReaderSettings);


                // 10- Read XML content in a loop
                while (objXmlReader.Read())
                { /*Empty loop*/}

            }//try
            // Handle exceptions if you want
            catch (UnauthorizedAccessException AccessEx)
            {
                throw AccessEx;
            }//catch
            catch (Exception Ex)
            {
                throw Ex;
            }//catch
        }

        private void ReaderSettings_ValidationEventHandler(object sender, ValidationEventArgs args)
        {
            // 11- Implement your logic for each validation iteration
            string strTemp;
            strTemp = "Line: " + this.Reader.LineNumber + " - Position: "
                + this.Reader.LinePosition + " - " + args.Message;

            this.Results.Add(strTemp);
        }
    }
}