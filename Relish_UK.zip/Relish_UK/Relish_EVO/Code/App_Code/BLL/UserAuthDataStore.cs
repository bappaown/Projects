﻿using DAL;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
/// <summary>
/// Summary description for UserAuthDataStore
/// </summary>
public static class UserAuthDataStore
{
    public static DataSet AuthenticateUser(string NTLogin)
    {
        DataSet ds = new DataSet();
        string commandText = "Proc_AuthenticateUser";
        try
        {
            SqlParameter[] param = new SqlParameter[1];
            param[0] = new SqlParameter("@NTLogin", NTLogin);
            ds = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, commandText, param);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds;
    }


    public static DataSet GetAuthenticationTypes()
    {
        DataSet ds = new DataSet();
        string commandText = "Proc_GetAuthenticationTypes";
        try
        {
            ds = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, commandText);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ds;
    }
}