﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using DAL;

/// <summary>
/// Summary description for EvoSuperAdminGlobalControls
/// </summary>
namespace EVOLib
{
    public class EvoSuperAdminGlobalControls
    {
        private string controlName;
        private string controlType;
        private int dependentControlId;
        private string userLogin;
        private int controlId;
        private int costCentreId;
        private string skillSetId;
        private int dataStoreId;

        public EvoSuperAdminGlobalControls()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #region Properties

        /// <summary>
        ///   This property is used to Get Or Set the UserLogin of the form  
        /// </summary>
        public string UserLogin
        {
            get
            {
                return userLogin;
            }
            set
            {
                userLogin = value;
            }
        }


        /// <summary>
        ///   This property is used to Get Or Set the dependent control Id of the form  
        /// </summary>
        public int DependentControlId
        {
            get
            {
                return dependentControlId;
            }
            set
            {
                dependentControlId = value;
            }
        }


        /// <summary>
        ///   This property is used to Get Or Set the dependent control Id of the form
        /// </summary>
        public int DataStoreId
        {
            get
            {
                return dataStoreId;
            }
            set
            {
                dataStoreId = value;
            }
        }

        /// <summary>
        ///   This property is used to Get Or Set the control Id of the form  
        /// </summary>
        public int ControlId
        {
            get
            {
                return controlId;
            }
            set
            {
                controlId = value;
            }
        }


        /// <summary>
        ///   This property is used to Get Or Set the ControlName of the form
        /// </summary>
        public string ControlName
        {
            get
            {
                return controlName;
            }
            set
            {
                controlName = value;
            }
        }


        /// <summary>
        ///   This property is used to Get Or Set the controlType of the form
        /// </summary>
        public string ControlType
        {
            get
            {
                return controlType;
            }
            set
            {
                controlType = value;
            }
        }

        /// <summary>
        ///   This property is used to Get Or Set the costCentreId of the form
        /// </summary>
        public int CostCentreId
        {
            get
            {
                return costCentreId;
            }
            set
            {
                costCentreId = value;
            }
        }

        /// <summary>
        ///   This property is used to Get Or Set the costCentreId of the form
        /// </summary>
        public string SkillSetId
        {
            get
            {
                return skillSetId;
            }
            set
            {
                skillSetId = value;
            }
        }

        #endregion


        #region Methods

        public DataSet GetParentGlobalControls()
        {
            //DataSet ds;
            //string query = "select * from Evo_ControlMain where controlType = 'global' and DependentControlId = 0 and ControlDisplayType='" + ControlType + "' " +
            //               " and controlId not in (select DependentControlId from Evo_ControlMain where IsActive = 1) and IsActive = 1";
            //ds = DAL.SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, query);
            //return ds;

            DataSet dsParentGlobalControls = new DataSet();
            try
            {
                string spName = "EVO_GetParentGlobalControls";
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@ControlType", ControlType);
                dsParentGlobalControls = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsParentGlobalControls != null && dsParentGlobalControls.Tables.Count > 0)
                {
                    return dsParentGlobalControls;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetParentGlobalControls" + ex.Message);
            }
        }

        public bool InsertGlobalControl()
        {
            bool result = false;
            int rowsEffected = 0;

            string spName = "EVO_Insert_GlobalControl";
            SqlParameter[] parameters = new SqlParameter[4];
            parameters[0] = new SqlParameter("@ControlName", ControlName);
            parameters[1] = new SqlParameter("@ControlType", ControlType);
            parameters[2] = new SqlParameter("@DepControlId", DependentControlId);
            parameters[3] = new SqlParameter("@AddedBy", UserLogin);

            rowsEffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
            if (rowsEffected > 0)
            {
                result = true;
            }

            return result;
        }

        public DataSet GetGlobalControls()
        {
            //DataSet ds;
            //string query = "select a.ControlId, a.ControlName as Parent,a.ControlDisplayType as DisplayType, b.ControlName as Child from Evo_controlMain a " +
            //               " left outer join Evo_controlMain b on b.DependentControlId = a.controlId and b.IsActive = a.isActive " +
            //               " where  a.Controltype='Global' and (a.DependentControlId = 0 or a.DependentControlId <> 0) and a.IsActive = 1";
            //ds = DAL.SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, query);
            //return ds;

            DataSet dsGlobalControls = new DataSet();
            try
            {
                string spName = "EVO_GetGlobalControls";

                dsGlobalControls = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

                if (dsGlobalControls != null && dsGlobalControls.Tables.Count > 0)
                {
                    return dsGlobalControls;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetGlobalControls" + ex.Message);
            }


        }

        /// <summary>
        /// Function to update the record from the table Evo_AccessRights
        /// </summary>
        /// <returns></returns>
        public bool UpdateGlobalControl()
        {
            bool result = false;
            int rowsEffected = 0;

            string spName = "EVO_Update_GlobalControl";
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@ControlId", ControlId);
            parameters[1] = new SqlParameter("@ControlName", ControlName);
            rowsEffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
            if (rowsEffected > 0)
            {
                result = true;
            }

            return result;
        }

        /// <summary>
        /// Function to virtually delete the record from the table Evo_AccessRights
        /// </summary>
        /// <returns></returns>
        public bool DeleteGlobalControl()
        {
            bool result = false;
            int rowsEffected = 0;

            string spName = "EVO_Delete_GlobalControl";
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@ControlId", ControlId);
            rowsEffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
            if (rowsEffected > 0)
            {
                result = true;
            }

            return result;
        }

        /// <summary>
        /// Function to retrieve all the Global controls of particular Control Type
        /// </summary>
        /// <returns></returns>
        public DataSet GetAllGlobalControls()
        {
            //DataSet ds;
            //string query = "select * from Evo_ControlMain where controlType = 'Global' and ControlDisplayType='" + ControlType + "' and IsActive = 1 order by ControlName";

            //ds = DAL.SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, query);
            //return ds;

            DataSet dsGlobal = null;
            SqlParameter[] param;
            try
            {
                string spName = "EVO_GetAllGlobalControls";
                param = new SqlParameter[1];
                param[0] = new SqlParameter("@ControlType", ControlType);

                dsGlobal = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, param);

                if (dsGlobal != null && dsGlobal.Tables.Count > 0)
                {
                    return dsGlobal;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetAllGlobalControls" + ex.Message);
            }
        }

        /// <summary>
        /// Function To call all the cost centres from Central_CostCentre_Main
        /// </summary>
        /// <returns></returns>
        public DataSet GetCostCentres()
        {
            //DataSet ds;
            //string query = "select * from Central_CostCentre_Main order by CostCentre";
            //ds = DAL.SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, query);
            //return ds;

            DataSet dsCC;
            try
            {
                string spName = "EVO_GetCostCentres";
                dsCC = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

                if (dsCC != null && dsCC.Tables.Count > 0)
                {
                    return dsCC;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetCostCentres" + ex.Message);
            }
        }

        /// <summary>
        /// Function To call all the cost centres from Central_CostCentre_Main
        /// </summary>
        /// <returns></returns>
        public DataSet GetCostCentresSkillsets()
        {
            //DataSet ds;
            ////string query = "select * from Central_Department_Main where CostCentreId =" + CostCentreId + " order by DepartmentName";
            //string query = "select * from Central_Department_Main where CostCentreId =" + CostCentreId + " AND status = 1 AND DepartmentName not like '%tesco%' order by DepartmentName";
            //ds = DAL.SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, query);
            //return ds;

            DataSet dsDept;
            try
            {
                string spName = "EVO_GetCostCentresDepartments";
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@CostCentreId", CostCentreId);
                dsDept = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsDept != null && dsDept.Tables.Count > 0)
                {
                    return dsDept;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetCostCentresSkillsets" + ex.Message);
            }
        }

        public DataSet GetControlDetails()
        {
            //DataSet ds;
            //string query = "select * from Evo_ControlMain where ControlId =" + ControlId + " and IsActive = 1";
            //ds = DAL.SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, query);
            //return ds;

            DataSet dsControls;
            try
            {
                string spName = "EVO_GetControlDetails";
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@ControlId", ControlId);
                dsControls = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsControls != null && dsControls.Tables.Count > 0)
                {
                    return dsControls;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetControlDetails" + ex.Message);
            }

        }

        public DataSet GetSelectedControlData()
        {
            //DataSet ds;
            ////string query = "select * from Evo_GlobalControlDataStore where ControlId =" + ControlId + " and CostCentreId =" + CostCentreId + " and SkillSetId in (" + SkillSetId + ") and IsActive = 1";
            //string query = "select distinct * from Evo_GlobalControlDataStore where ControlId =" + ControlId + " and DataStoreID in " +
            //               "(select datastoreId from Evo_GlobalControlDataSkillSetRelation where SkillSetId in (" + SkillSetId + ") and IsActive = 1)";
            ////CostCentreId =" + CostCentreId + " and **** commented By Aarti.
            //ds = DAL.SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, query);
            //return ds;

            DataSet dsControls;
            try
            {
                string spName = "EVO_GetSelectedControlData";
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@ControlId", ControlId);
                parameters[1] = new SqlParameter("@SkillSetId", SkillSetId);
                dsControls = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsControls != null && dsControls.Tables.Count > 0)
                {
                    return dsControls;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetSelectedControlData" + ex.Message);
            }



        }


        public DataSet GetChildGlobalControlData()
        {
            //DataSet ds;
            ////**string query = "select * from Evo_GlobalControlDataStore where DependentId =" + DependentControlId + " and IsActive =1";
            //string query = "select * from Evo_GlobalControlDataStore where DependentId =" + DependentControlId + " and CostCentreID = " + CostCentreId + " and DataStoreID in (select datastoreId from " +
            //               "Evo_GlobalControlDataSkillSetRelation where SkillSetId in (" + SkillSetId + ")  and IsActive = 1)";
            //ds = DAL.SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.Text, query);
            //return ds;

            DataSet dsControls;
            try
            {
                string spName = "EVO_GetChildGlobalControlData";
                SqlParameter[] parameters = new SqlParameter[3];
                parameters[0] = new SqlParameter("@CostCentreId", CostCentreId);
                parameters[1] = new SqlParameter("@SkillSetId", SkillSetId);
                parameters[2] = new SqlParameter("@DependentControlId", DependentControlId);
                dsControls = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsControls != null && dsControls.Tables.Count > 0)
                {
                    return dsControls;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetChildGlobalControlData" + ex.Message);
            }


        }

        public bool InsertGlobalControlData()
        {
            bool result = false;
            int rowsEffected = 0;

            string spName = "EVO_Insert_GlobalControlData";
            SqlParameter[] parameters = new SqlParameter[6];
            parameters[0] = new SqlParameter("@ControlId", ControlId);
            parameters[1] = new SqlParameter("@ControlName", ControlName);
            parameters[2] = new SqlParameter("@CostCentreId", CostCentreId);
            parameters[3] = new SqlParameter("@SkillSetId", SkillSetId);
            parameters[4] = new SqlParameter("@DependentId", DependentControlId);
            parameters[5] = new SqlParameter("@AddedBy", UserLogin);

            rowsEffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
            if (rowsEffected > 0)
            {
                result = true;
            }
            return result;
        }

        public bool UpdateGlobalControlData()
        {
            bool result = false;
            int rowsEffected = 0;

            string spName = "EVO_Update_GlobalControlData";
            SqlParameter[] parameters = new SqlParameter[4];
            parameters[0] = new SqlParameter("@ControlId", ControlId);
            parameters[1] = new SqlParameter("@ControlName", ControlName);
            parameters[2] = new SqlParameter("@DataStoreId", DataStoreId);
            parameters[3] = new SqlParameter("@CostCentreId", CostCentreId);

            rowsEffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
            if (rowsEffected > 0)
            {
                result = true;
            }
            return result;
        }

        public bool DeleteGlobalControlData()
        {
            bool result = false;
            int rowsEffected = 0;

            string spName = "EVO_Delete_GlobalControlData";
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@ControlId", ControlId);
            //parameters[1] = new SqlParameter("@CostCentreId", CostCentreId);
            parameters[1] = new SqlParameter("@SkillSetId", SkillSetId);

            rowsEffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
            if (rowsEffected > 0)
            {
                result = true;
            }

            return result;
        }
        #endregion
    }
}