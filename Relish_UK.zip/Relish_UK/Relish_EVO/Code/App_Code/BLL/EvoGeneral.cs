using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using DAL;
using H3GS.Web.Security;
using System.Data.SqlClient;

/// <summary>
/// Summary description for EvoGeneral
/// </summary>
namespace EVOLib
{
    public class EvoGeneral : System.Web.UI.Page
    {
        public string userName = "";
        public EvoGeneral()
        {
            userName = GetNTName();
        }

        /// <summary>
        /// To Get the nt login name of user
        /// </summary>
        /// <remarks></remarks>
        /// <returns>NT Name of logged in user</returns>
        public string GetNTName()
        {
            ////Windows Authentication : Bappa
            //string ntUserName = PassportIdentity.Current.Employee.LoginId; //User.Identity.Name.ToString();
            string ntUserName = HttpContext.Current.Request.Cookies["EVO"] != null ? HttpContext.Current.Request.Cookies["EVO"]["userName"] : string.Empty;
            ////End

            //***	 COMMENTED BY AARTI ON 21/4/2011 AS WE HAVE INTEGRATED CEAG NOW.
            ////try
            ////{
            ////    ntUserName = ntUserName.Substring(ntUserName.IndexOf(@"\"), ntUserName.Length - ntUserName.IndexOf(@"\")).Replace(@"\", " ").TrimStart();
            ////}
            ////catch (Exception ex)
            ////{
            ////    throw ex;
            ////}
            //***	 COMMENTED TILL HERE.

            return ntUserName;
        }

        /// <summary>
        /// Get active employee list of all employees from Employees table.
        /// </summary>
        /// <returns></returns>
        public DataSet GetEmployeeList()
        {
            //string commandText = "SELECT EmployeeId, FirstName + ' ' + LastName AS EmployeeName, FirstName + ' ' + LastName + ' - ' + CONVERT(VarChar, EmployeeId) AS EmployeeNameWithID  FROM Employees WHERE Status = 1 ORDER BY FirstName + ' ' + LastName";
            //DataSet adminRightsDataSet = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //return adminRightsDataSet;

            DataSet dsEmployees;
            try
            {
                string spName = "EVO_GetEmployeeList";
                dsEmployees = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

                if (dsEmployees != null && dsEmployees.Tables.Count > 0)
                {
                    return dsEmployees;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetEmployeeList" + ex.Message);
            }

        }

        /// <summary>
        /// Get active employee list of all employees from Central_Employee_Main table.
        /// </summary>
        /// <returns></returns>
        public DataSet RetrieveEmployeeList()
        {
            //string commandText = "SELECT EmpUserID, EmployeeID, FirstName + ' ' + LastName AS EmployeeName, FirstName + ' ' + LastName + ' - ' + CONVERT(VarChar, EmployeeId) AS EmployeeNameWithID, DesignationID, CostCentreID, DepartmentID, BossUserID, BossID, Login, Email, Location, Status FROM Central_Employee_Main WHERE Status = 1 ORDER BY FirstName + ' ' + LastName";
            //DataSet adminRightsDataSet = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //return adminRightsDataSet;

            DataSet dsEmployeeList;
            try
            {
                string spName = "EVO_RetrieveEmployeeList";
                dsEmployeeList = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

                if (dsEmployeeList != null && dsEmployeeList.Tables.Count > 0)
                {
                    return dsEmployeeList;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("RetrieveEmployeeList" + ex.Message);
            }

        }

        /// <summary>
        /// Get employee name from employeeid.
        /// </summary>
        /// <returns></returns>
        public string GetEmployeeName(int employeeId)
        {
            //string commandText = "SELECT FirstName + ' ' + LastName + ' ' + CONVERT(VarChar, EmployeeId) FROM Employees WHERE EmployeeId = " + employeeId + "AND Status = 1 ";
            //return Convert.ToString(DAL.SqlHelper.ExecuteScalar(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText));

            DataSet dsEmpName;
            try
            {
                string spName = "EVO_GetEmployeeName";
                SqlParameter[] parameters = new SqlParameter[1];

                parameters[0] = new SqlParameter("@EmployeeId", employeeId);
                dsEmpName = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsEmpName != null && dsEmpName.Tables.Count > 0)
                {
                    return dsEmpName.Tables[0].Rows[0]["EmpName"].ToString();
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetEmployeeName" + ex.Message);
            }

        }

        /// <summary>
        /// Get employee name from EmpUserID(Table - Central_Employee_Main).
        /// </summary>
        /// <returns></returns>
        public string RetrieveEmployeeName(int employeeId)
        {
            //string commandText = "SELECT FirstName + ' ' + LastName + ' ' + CONVERT(VarChar, EmployeeId) FROM Central_Employee_Main WHERE EmpUserID = " + employeeId + "AND Status = 1 ";
            //return Convert.ToString(DAL.SqlHelper.ExecuteScalar(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText));

            DataSet dsEmpName;
            try
            {
                string spName = "EVO_RetrieveEmployeeName";
                SqlParameter[] parameters = new SqlParameter[1];

                parameters[0] = new SqlParameter("@EmployeeId", employeeId);
                dsEmpName = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsEmpName != null && dsEmpName.Tables.Count > 0)
                {
                    return dsEmpName.Tables[0].Rows[0]["EmpName"].ToString();
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("RetrieveEmployeeName" + ex.Message);
            }

        }

        /// <summary>
        /// Get only employee name from employeeid.
        /// </summary>
        /// <returns></returns>
        public string GetEmployeeFullName(int employeeId)
        {
            //  string commandText = "SELECT FirstName + ' ' + LastName AS EmpName FROM Employees WHERE EmployeeId = " + employeeId + " AND Status = 1 ";
            //return Convert.ToString(DAL.SqlHelper.ExecuteScalar(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText));

            DataSet dsEmpName;
            try
            {
                string spName = "EVO_GetEmployeeFullName";
                SqlParameter[] parameters = new SqlParameter[1];

                parameters[0] = new SqlParameter("@EmployeeId", employeeId);
                dsEmpName = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsEmpName != null && dsEmpName.Tables.Count > 0)
                {
                    return dsEmpName.Tables[0].Rows[0]["EmpName"].ToString();
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetEmployeeFullName" + ex.Message);
            }

        }

        /// <summary>
        /// Get only employee name from EmpUserID(Table - Central_Employee_Main).
        /// </summary>
        /// <returns></returns>
        public string RetrieveEmployeeFullName(int employeeId)
        {
            //string commandText = "SELECT FirstName + ' ' + LastName AS EmpName FROM Central_Employee_Main WHERE EmpUserID = " + employeeId + " AND Status = 1 ";
            //return Convert.ToString(DAL.SqlHelper.ExecuteScalar(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText));


            DataSet dsEmpName;
            try
            {
                string spName = "EVO_RetrieveEmployeeFullName";
                SqlParameter[] parameters = new SqlParameter[1];

                parameters[0] = new SqlParameter("@EmployeeId", employeeId);
                dsEmpName = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsEmpName != null && dsEmpName.Tables.Count > 0)
                {
                    return dsEmpName.Tables[0].Rows[0]["EmpName"].ToString();
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("RetrieveEmployeeFullName" + ex.Message);
            }


        }

        /// <summary>
        /// Get Employee Details for passed EmployeeId
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        public DataSet GetEmployeeDetails(int employeeId)
        {
            //string commandText = " SELECT	    EmployeeId, FirstName + ' ' + LastName AS EmployeeName, Dept.Name AS Department, Desg.Name AS Designation, Emp.Status, CostCentre, Email " +
            //                     " FROM		    Employees       Emp " +
            //                     " LEFT JOIN	Departments		Dept ON Dept.id = Emp.departmentid " +
            //                     " LEFT JOIN	Designations	Desg ON Desg.id = Emp.designationid " +
            //                     " WHERE        EmployeeId = " + employeeId + " AND Emp.Status = 1 ";
            //DataSet employeeDetailsDataSet = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //return employeeDetailsDataSet;

            DataSet dsEmpDetail;
            try
            {
                string spName = "EVO_GetEmployeeDetail";
                SqlParameter[] parameters = new SqlParameter[1];

                parameters[0] = new SqlParameter("@EmployeeId", employeeId);
                dsEmpDetail = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsEmpDetail != null && dsEmpDetail.Tables.Count > 0)
                {
                    return dsEmpDetail;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetEmployeeDetails" + ex.Message);
            }
        }

        /// <summary>
        /// Get Employee Details for passed EmployeeId(Table - Central_Employee_Main).
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        public DataSet RetrieveEmployeeDetails(int employeeId)
        {
            //string commandText = " SELECT EmpUserID, EmployeeID, FirstName + ' ' + LastName AS EmployeeName, FirstName + ' ' + LastName + ' - ' + CONVERT(VarChar, EmployeeId) AS EmployeeNameWithID, DesignationID, CostCentreID, DepartmentID, BossUserID, BossID, Login, Email, Location, Status " +
            //                     " FROM Central_Employee_Main " +
            //                     " WHERE EmpUserID = " + employeeId + " AND Status = 1 ORDER BY FirstName + ' ' + LastName";
            //DataSet employeeDetailsDataSet = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //return employeeDetailsDataSet;

            DataSet dsEmpDetail;
            try
            {
                string spName = "EVO_RetrieveEmployeeDetails";
                SqlParameter[] parameters = new SqlParameter[1];

                parameters[0] = new SqlParameter("@EmployeeId", employeeId);
                dsEmpDetail = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsEmpDetail != null && dsEmpDetail.Tables.Count > 0)
                {
                    return dsEmpDetail;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("RetrieveEmployeeDetails" + ex.Message);
            }

        }

        /// <summary>
        /// Get Employee Details for passed employeeLogin
        /// </summary>
        /// <param name="employeeLogin"></param>
        /// <returns></returns>
        public DataSet GetEmployeeDetails(string employeeLogin)
        {
            //string commandText = " SELECT	    EmployeeId, FirstName + ' ' + LastName AS EmployeeName, Dept.ID AS DeptID, Dept.Name AS Department, Desg.Name AS Designation, Emp.Status, CostCentre, Email " +
            //                     " FROM		    Employees       Emp " +
            //                     " LEFT JOIN	Departments		Dept ON Dept.id = Emp.departmentid " +
            //                     " LEFT JOIN	Designations	Desg ON Desg.id = Emp.designationid " +
            //                     " WHERE        Login = '" + employeeLogin + "' AND Emp.Status = 1 ";
            //DataSet employeeDetailsDataSet = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //return employeeDetailsDataSet;

            DataSet dsEmpDetail;
            try
            {
                string spName = "EVO_GetEmployeeDetailsByLogin";
                SqlParameter[] parameters = new SqlParameter[1];

                parameters[0] = new SqlParameter("@EmployeeLogin", employeeLogin);
                dsEmpDetail = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsEmpDetail != null && dsEmpDetail.Tables.Count > 0)
                {
                    return dsEmpDetail;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetEmployeeDetails" + ex.Message);
            }

        }

        /// <summary>
        /// Get Employee Details for passed employeeLogin(Table - Central_Employee_Main).
        /// </summary>
        /// <param name="employeeId"></param>
        /// <returns></returns>
        public DataSet RetrieveEmployeeDetails(string employeeLogin)
        {
            //string commandText = " SELECT EmpUserID, EmployeeID, FirstName + ' ' + LastName AS EmployeeName, FirstName + ' ' + LastName + ' - ' + CONVERT(VarChar, EmployeeId) AS EmployeeNameWithID, DesignationID, CostCentreID, DepartmentID, BossUserID, BossID, Login, Email, Location, Status " +
            //                     " FROM Central_Employee_Main " +
            //                     " WHERE Login = '" + employeeLogin + "' AND Status = 1 ORDER BY FirstName + ' ' + LastName";
            //DataSet employeeDetailsDataSet = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //return employeeDetailsDataSet;

            DataSet dsEmpDetail;
            try
            {
                string spName = "EVO_RetrieveEmployeeDetailsByLogin";
                SqlParameter[] parameters = new SqlParameter[1];

                parameters[0] = new SqlParameter("@EmployeeLogin", employeeLogin);
                dsEmpDetail = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsEmpDetail != null && dsEmpDetail.Tables.Count > 0)
                {
                    return dsEmpDetail;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("RetrieveEmployeeDetails" + ex.Message);
            }


        }

        /// <summary>
        /// Returns EmpUserID from Central_Employee_Main Table.
        /// </summary>
        /// <param name="employeeLogin"></param>
        /// <returns></returns>
        public Int64 RetrieveUserID(string employeeLogin)
        {
            //string commandText = "SELECT EmpUserID FROM Central_Employee_Main WHERE Login = '" + employeeLogin + "' AND Status = 1 ";
            //return Convert.ToInt64(DAL.SqlHelper.ExecuteScalar(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText));


            DataSet dsEmpDetail;
            try
            {
                string spName = "EVO_RetrieveUserIdByLogin";
                SqlParameter[] parameters = new SqlParameter[1];

                parameters[0] = new SqlParameter("@EmployeeLogin", employeeLogin);
                dsEmpDetail = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsEmpDetail != null && dsEmpDetail.Tables.Count > 0)
                {
                    return Convert.ToInt64(dsEmpDetail.Tables[0].Rows[0]["EmpUserID"].ToString());
                }
                else
                    return 0;
            }
            catch (Exception ex)
            {
                throw new Exception("RetrieveUserID" + ex.Message);
            }

        }

        /// <summary>
        /// This function is used to Get Employee Information.
        /// </summary>
        /// <param name="login"></param>
        public DataSet GetEmployeeInfo(string login, string fID)
        {
            //DataSet employeeDataset = new DataSet();

            //string commandText = " SELECT CEM.EmpUserID, CEM.FirstName + ' ' + CEM.LastName AS EmpName, CEM.BossUserID,CEM2.FirstName + ' ' + CEM2.LastName AS Boss1Name " +
            //                    " FROM Central_Employee_Main CEM " +
            //                        " INNER JOIN Central_Employee_Main CEM2 ON CEM.BossUserID = CEM2.EmpUserID " +
            //                    " WHERE CEM.EmpUserID IN (SELECT EmpUserID FROM Central_Employee_Main " +
            //                        " WHERE login = '" + login + "' AND Status = 1) " +

            //                     " SELECT COUNT(*) TransID FROM dbo.Evo_Transaction WHERE FormId = '" + fID + "' AND AddedBy = '" + login + "' AND DATEDIFF(DAY, AddedWhen, getdate()) = 0";
            //try
            //{
            //    employeeDataset = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);

            //    employeeDataset.Tables[0].TableName = "EmpDetails";
            //    employeeDataset.Tables[1].TableName = "SalesCount";
            //}
            //catch (Exception ex)
            //{
            //    throw ex;
            //}
            //return employeeDataset;

            DataSet employeeDataset;
            try
            {
                string spName = "EVO_GetEmployeeInfo";
                SqlParameter[] parameters = new SqlParameter[2];

                parameters[0] = new SqlParameter("@EmployeeLogin", login);
                parameters[1] = new SqlParameter("@FormId", fID);
                employeeDataset = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (employeeDataset != null && employeeDataset.Tables.Count > 0)
                {
                    employeeDataset.Tables[0].TableName = "EmpDetails";
                    employeeDataset.Tables[1].TableName = "SalesCount";
                    return employeeDataset;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetEmployeeInfo" + ex.Message);
            }

        }

        /// <summary>
        /// Returns the Template form list
        /// </summary>
        /// <returns></returns>
        public DataSet GetTemplateForms()
        {
            DataSet dsTemplates = null;

            dsTemplates = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, "proc_GetTemplates");

            if (dsTemplates != null && dsTemplates.Tables[0].Rows.Count > 0)
            {
                return dsTemplates;
            }
            else
            {
                return null;
            }
        }

        /// <summary>
        /// Returns the Template Details
        /// </summary>
        /// <param name="TemplateID">Form ID of the template</param>
        /// <returns></returns>
        public DataTable GetTemplateDetails(int TemplateID)
        {
            DataSet dsTemplates = null;

            SqlParameter[] oParams = new SqlParameter[1];
            oParams[0] = new SqlParameter("@FormId", TemplateID);

            dsTemplates = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, "proc_GetTemplateDetails", oParams);

            if (dsTemplates != null && dsTemplates.Tables[0].Rows.Count > 0)
            {
                return dsTemplates.Tables[0];
            }
            else
            {
                return null;
            }
        }





    }
}