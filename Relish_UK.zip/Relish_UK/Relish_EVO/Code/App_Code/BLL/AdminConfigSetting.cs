using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DAL;
/// <summary>
/// Summary description for EvoAdminConfig
/// </summary>
/// 
namespace EVOLib
{

    public class AdminConfigSetting
    {
        private int configId;
        private string configName;
        private int configValue;
        private int userAllowed;
        private string addedBy;
        private bool isActive;
        private double totalRows;
        public AdminConfigSetting()
        {
            configName = "";
            configValue = 0;
            userAllowed = 0;
            addedBy = "";
            configId = 0;
            totalRows = 0;
        }


        #region Properties.
        /// <summary>
        /// This properties is used for  set and get the ConfigId Value.
        /// </summary>
        public int ConfigId
        {
            get
            {
                return configId;
            }
            set
            {
                configId = value;
            }
        }
        /// <summary>
        /// This properties is used to set and get the ConfigName Value.
        /// Created by Santosh
        /// </summary>
        public string ConfigName
        {
            get
            {
                return configName;
            }
            set
            {
                configName = value;
            }
        }
        /// <summary>
        /// This properties is used to set and get the ConfigValue Value.
        /// Created by Santosh
        /// </summary>
        public int ConfigValue
        {
            get
            {
                return configValue;
            }
            set
            {
                configValue = value;
            }
        }
        /// <summary>
        /// This properties is used to set and get the UserAllowed Value.
        /// Created by Santosh
        /// </summary>
        public int UserAllowed
        {
            get
            {
                return userAllowed;
            }
            set
            {
                userAllowed = value;
            }
        }
        /// <summary>
        /// This properties is used to set and get the AddedBy Value.
        /// Created by Santosh
        /// </summary>
        public string AddedBy
        {
            get
            {
                return addedBy;
            }
            set
            {
                addedBy = value;
            }
        }
        /// <summary>
        /// This properties is used to set and get the IsActive Value.
        /// Created by Santosh
        /// </summary>
        public bool IsActive
        {
            get
            {
                return isActive;
            }
            set
            {
                isActive = value;
            }
        }
        /// <summary>
        /// This property is used to set and get the TotalRows value.
        /// </summary>
        public double TotalRows
        {
            get
            {
                return totalRows;
            }
            set
            {
                totalRows = value;
            }
        }
        #endregion
                       
        /// <summary>
        /// This method is used for insert record in to Admin Config Table.
        /// </summary>
        /// <returns></returns>
        public bool AddConfig()
        {
            bool result = false;
            int rowsaffected = 0;         
            try
            {
                string spName = "EVO_Insert_AdminConfig";
                SqlParameter[] parameters = new SqlParameter[5];
                parameters[0] = new SqlParameter("@UserAllowed",UserAllowed);
                parameters[1] = new SqlParameter("@ConfigName",ConfigName);
                parameters[2] = new SqlParameter("@Value",ConfigValue);
                parameters[3] = new SqlParameter("@AddedBy",AddedBy);              
                parameters[4] = new SqlParameter("@NewConfigID", ConfigId);
                parameters[4].Direction = ParameterDirection.Output;             
                rowsaffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                ConfigId = int.Parse(parameters[4].Value.ToString());
                if (ConfigId > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("AddConfig" + ex.Message);
            }
            return result;
        }
        /// <summary>
        /// This method is used for update record from Config setting.
        /// </summary>
        /// <returns></returns>
        public bool UpdateConfig()
        {
            bool result = false;
            int rowsaffected = 0;
            try
            {
                string spName = "EVO_Update_AdminConfig";
                SqlParameter[] parameters = new SqlParameter[4];
                parameters[0] = new SqlParameter("@UserAllowed", UserAllowed);
                parameters[1] = new SqlParameter("@ConfigName", ConfigName);
                parameters[2] = new SqlParameter("@Value", ConfigValue);
                parameters[3] = new SqlParameter("@ConfigId", ConfigId);               
                rowsaffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                if (rowsaffected > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("UpdateConfig" + ex.Message);
            }
            return result;
        }
        /// <summary>
        /// This method is used for Delete the config setting.
        /// </summary>
        /// <returns></returns>
        public bool DeleteConfig()
        {
            bool result = false;
            int rowsaffected = 0;
            try
            {
                string spName = "EVO_Delete_AdminConfig";
                SqlParameter[] parameters = new SqlParameter[1];              
                parameters[0] = new SqlParameter("@ConfigId", ConfigId);
                rowsaffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                if (rowsaffected > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("DeleteConfig" + ex.Message);
            }
            return result;
        }     
       
        /// <summary>
        /// This method is used for get admin config reord.
        /// </summary>
        /// <param name="currentPage"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetAdminConfigDetail(int currentPage,int pageSize)
        {
            DataSet dsAdmin = null;

            SqlParameter[] oParams;

            try 
            {
                string spName = "EVO_Select_AdminConfig";
                oParams = new SqlParameter[3];
                oParams[0] = new SqlParameter("@startRowIndex", currentPage);
                oParams[1] = new SqlParameter("@maximumRows", pageSize);
                oParams[2] = new SqlParameter("@totalRows", TotalRows);
                oParams[2].Direction = ParameterDirection.Output;
                dsAdmin = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, oParams);
                TotalRows = int.Parse(oParams[2].Value.ToString());
                if (dsAdmin != null && dsAdmin.Tables.Count > 0)
                {
                    return dsAdmin;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetAdminConfigDetail" + ex.Message);
            }
          
        }

    }
}
