﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using DAL;
using System.Data.SqlClient;

/// <summary>
/// Summary description for DataManagement
/// </summary>
public class DataManagement
{
	public DataManagement()
	{
		//
		// TODO: Add constructor logic here
		//
	}

    public DataSet GetTemplateId(string FormName,string FormId)
    {
        string procName = "EVO_GetTemplateId";
        DataSet objDataSet = new DataSet();
        try
        {
            SqlParameter[] parameters = new SqlParameter[2];
            parameters[0] = new SqlParameter("@FormName", SqlDbType.VarChar,200);
            parameters[0].Value = FormName ;
            parameters[1] = new SqlParameter("@FormId", SqlDbType.VarChar, 50);
            parameters[1].Value = FormId;
            

            objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters);

            return objDataSet;
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }



    public static string GetEmployeeManager(int employeeId)
    {
        string employeeManager;
        string procName = "EVO_GetEmployeeManager";
        DataSet objDataSet = new DataSet();
        try
        {
            SqlParameter[] parameters = new SqlParameter[1];
            parameters[0] = new SqlParameter("@EmployeeID", SqlDbType.Int);
            parameters[0].Value = employeeId;



            objDataSet = SqlHelper.ExecuteDataset(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, procName, parameters);
            employeeManager = objDataSet.Tables[0].Rows[0][0].ToString();


        }
        catch
        {
            employeeManager = "";
        }
        return employeeManager;
    }
}