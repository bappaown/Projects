using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DAL;
/// <summary>
/// Summary description for EvoAdminUsersRights
/// </summary>
/// 
namespace EVOLib
{

    public class SuperAssignAdmin
    {
        private int userId;
        private int roleId;
        private string addedBy;
        private double totalRows;
        private int adminId;
        private string adminUserLogin;
        public SuperAssignAdmin()
        {
            addedBy = "";
            userId = 0;
            roleId = 0;
            totalRows = 0;
            adminId = 0;
            adminUserLogin = "";
        }
        #region Properties
        /// <summary>
        /// This property is used to set and get the AdminUserLogin value.
        /// Created by Santosh
        /// </summary>
        public string AdminUserLogin
        {
            get
            {
                return adminUserLogin;
            }
            set
            {
                adminUserLogin = value;
            }
        }
        /// <summary>
        /// This property is used to set and get the AdminId value.
        /// Created by Santosh
        /// </summary>
        public int AdminId
        {
            get
            {
                return adminId;
            }
            set
            {
                adminId = value;
            }
        }
        /// <summary>
        /// This property is used to set and get the UserId value.
        /// Created by Santosh
        /// </summary>
        public int UserId
        {
            get
            {
                return userId;
            }
            set
            {
                userId = value;
            }
        }
        /// <summary>
        /// This property is used to set and get the TotalRows value.
        /// Created by Santosh
        /// </summary>
        public double TotalRows
        {
            get
            {
                return totalRows;
            }
            set
            {
                totalRows = value;
            }
        }
        /// <summary>
        /// This property is used to set and get the AddedBy value.
        /// Created by Santosh
        /// </summary>
        public string AddedBy
        {
            get
            {
                return addedBy;
            }
            set
            {
                addedBy = value;
            }
        }
        /// <summary>
        /// This property is used to set and get the RoleId value.
        /// Created by Santosh
        /// </summary>
        public int RoleId
        {
            get
            {
                return roleId;
            }
            set
            {
                roleId = value;
            }
        }
        #endregion

        /// <summary>
        /// This method return AdminUserLogin as per empUserID.
        /// Created by santosh
        /// </summary>
        /// <param name="empUserId"></param>
        /// <returns></returns>

        public string RetrieveAdminUserLogin(int empUserId)
        {
            //DataSet dsAdminLogin = new DataSet();
            //string userLogin = "";
            //try
            //{

            //    string commandText = "SELECT Login FROM Central_Employee_Main WHERE EmpUserID =" + empUserId + "";
            //    dsAdminLogin = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //    userLogin = dsAdminLogin.Tables[0].Rows[0]["Login"].ToString();              
            //}
            //catch (Exception ex)
            //{

            //    throw ex;
            //}
            //finally
            //{
            //    dsAdminLogin = null;  
            //}
            //return userLogin;          

            string userLogin = "";
            DataSet dsEmpName;
            try
            {
                string spName = "EVO_RetrieveAdminUserLogin";
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@empUserId", empUserId);
                dsEmpName = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (dsEmpName != null && dsEmpName.Tables.Count > 0)
                {
                    if (dsEmpName.Tables[0].Rows.Count > 0)
                    {
                        userLogin = dsEmpName.Tables[0].Rows[0]["Login"].ToString();
                    }
                }
                else
                    userLogin = null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetCostCentresDepartments" + ex.Message);
            }
            return userLogin;

        }

        /// <summary>
        /// This method is used for add record in to Evo_AdminUserRights.
        /// Created by Santosh
        /// </summary>
        /// <returns></returns>
        public bool AddAdmin(SqlTransaction objSqlTransaction)
        {
            bool result = false;
            int rowsaffected = 0;
            try
            {
                string spName = "EVO_Insert_AdminUserRights";
                SqlParameter[] parameters = new SqlParameter[5];
                parameters[0] = new SqlParameter("@UserID", UserId);
                parameters[1] = new SqlParameter("@AdminUserLogin", AdminUserLogin);
                parameters[2] = new SqlParameter("@RoleID", RoleId);
                parameters[3] = new SqlParameter("@AddedBy", AddedBy);
                parameters[4] = new SqlParameter("@SubAdmin", SqlDbType.Int);
                parameters[4].Direction = ParameterDirection.Output;
                rowsaffected = SqlHelper.ExecuteNonQuery(objSqlTransaction, CommandType.StoredProcedure, spName, parameters);
                AdminId = Convert.ToInt32(parameters[4].Value);
                if (rowsaffected > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("AddAdmin" + ex.Message);
            }
            return result;
        }
        /// <summary>
        /// This method is used for Delete record from Evo_AdminUserRightsTable.
        /// </summary>
        /// <returns></returns>
        public bool DeleteAssignAdmin()
        {
            bool result = false;
            int rowsaffected = 0;
            try
            {
                string spName = "EVO_Delete_AdminUserRights";
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@AdmUsrRightID", AdminId);
                rowsaffected = SqlHelper.ExecuteNonQuery(SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);
                if (rowsaffected > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("DeleteAssignAdmin" + ex.Message);
            }
            return result;
        }

        /// <summary>
        /// This method is used for get admin config reord.
        /// </summary>
        /// <param name="currentPage"></param>
        /// <param name="pageSize"></param>
        /// <returns></returns>
        public DataSet GetAdminUserRights(int currentPage, int pageSize)
        {
            DataSet dsAdmin = null;
            SqlParameter[] oParams;
            try
            {
                string spName = "EVO_Select_AdminUserRights";
                oParams = new SqlParameter[3];
                oParams[0] = new SqlParameter("@startRowIndex", currentPage);
                oParams[1] = new SqlParameter("@maximumRows", pageSize);
                oParams[2] = new SqlParameter("@totalRows", TotalRows);
                oParams[2].Direction = ParameterDirection.Output;
                dsAdmin = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, oParams);
                TotalRows = int.Parse(oParams[2].Value.ToString());
                if (dsAdmin != null && dsAdmin.Tables.Count > 0)
                {
                    return dsAdmin;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetAdminUserRights" + ex.Message);
            }

        }

    }
}
