using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using DAL;
/// <summary>
/// Summary description for EvoAdminCCRelation
/// </summary>
/// 
namespace EVOLib
{

    public class AssignCostCentre
    {
        private int userId;
        private int cCId;
        private string addedBy;
        private double totalRows;
        public AssignCostCentre()
        {
            userId = 0;
            cCId = 0;
            addedBy = "";
            totalRows = 0;

        }

        #region Properties
        /// <summary>
        /// This property is used to set and get the UserId value.
        /// Created by Santosh
        /// </summary>
        public int UserId
        {
            get
            {
                return userId;
            }
            set
            {
                userId = value;
            }
        }
        /// <summary>
        /// This property is used to set and get the TotalRows value.
        /// Created by Santosh
        /// </summary>
        public double TotalRows
        {
            get
            {
                return totalRows;
            }
            set
            {
                totalRows = value;
            }
        }
        /// <summary>
        /// This property is used to set and get the AddedBy value.
        /// Created by Santosh
        /// </summary>
        public string AddedBy
        {
            get
            {
                return addedBy;
            }
            set
            {
                addedBy = value;
            }
        }
        /// <summary>
        /// This property is used to set and get the CCId value.
        /// Created by Santosh
        /// </summary>
        public int CCId
        {
            get
            {
                return cCId;
            }
            set
            {
                cCId = value;
            }
        }
        #endregion
        /// <summary>
        /// This method used get costcentre for filter the employees as per cost centre.
        /// created by santosh
        /// </summary>
        /// <returns></returns>
        public DataSet GetFilterCostCentre()
        {
            //string commandText = "SELECT CostCentreID,CostCentre FROM Central_CostCentre_Main";
            //                     //***+ " WHERE  CostCentre ='UK-INDIA' OR CostCentre='ROI-India' OR CostCentre='AUS-India' OR CostCentre ='JOINT'"; -- COMMENTED BY AARTI on 11/05/2011.. AS AUS HOST WAS REQUIRED TO BE DISPLAYED.
            //DataSet centralCostCentreDs = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //return centralCostCentreDs;

            DataSet centralCostCentreDs;
            try
            {
                string spName = "EVO_GetFilterCostCentre";
                centralCostCentreDs = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

                if (centralCostCentreDs != null && centralCostCentreDs.Tables.Count > 0)
                {
                    return centralCostCentreDs;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetFilterCostCentre" + ex.Message);
            }




        }
        /// <summary>
        /// This method is used for get cost centre for user assign.
        /// created by santosh
        /// </summary>
        /// <returns></returns>
        public DataSet GetCentralCostCentre()
        {
            //string commandText = "SELECT CostCentreID,CostCentre FROM Central_CostCentre_Main";

            /////+ " WHERE  CostCentre ='UK-INDIA' OR CostCentre='ROI-India' OR CostCentre='AUS-India'"; -- COMMENTED BY AARTI on 11/05/2011.. AS AUS HOST WAS REQUIRED TO BE DISPLAYED.
            //DataSet centralCostCentreDs = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //return centralCostCentreDs;

            DataSet centralCostCentreDs;
            try
            {
                string spName = "GetFilterCostCentre";
                centralCostCentreDs = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

                if (centralCostCentreDs != null && centralCostCentreDs.Tables.Count > 0)
                {
                    return centralCostCentreDs;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetFilterCostCentre" + ex.Message);
            }
        }
        #region GetEmployees.
        /// <summary>
        /// This method is used for get admin user name from employee data base as per filter.
        /// </summary>
        /// <param name="costCentre"></param>
        /// <param name="adminName"></param>
        /// <returns></returns>
        public DataSet GetEmployeeDetails(int costCentre, string adminName)
        {


            //try
            //{
            //    string whereClause = "";
            //    //build whereclause	
               
            //    if (status > 0)
            //    {
            //        if (whereClause.Length == 0)
            //            whereClause += "status =" + status + " ";
            //    }
            //    if (costCentre > 0)
            //    {
            //        if (whereClause.Length == 0)
            //            whereClause += " CostCentreID =" + costCentre + "";
            //        else
            //            whereClause += " AND CostCentreID =" + costCentre + "";

            //    }
            //    if (adminName.Length > 0)
            //    {
            //        if (whereClause.Length == 0)
            //            whereClause += " EmployeeName Like '" + adminName + "%'";
            //        else
            //            whereClause += " AND EmployeeName Like '" + adminName + "%'";
            //    }
            //    employeeDetailsDataSet = GetDataSet(whereClause);

            //}
            //catch (Exception ex)
            //{
            //    throw new Exception("GetEmployeeDetails.\n" + ex.Message);
            //}
            //return employeeDetailsDataSet;
            int status = 1;
            DataSet employeeDetailsDataSet = new DataSet();
            try
            {
                string spName = "EVO_GetEmployeeDetails";


                SqlParameter[] parameters = new SqlParameter[3];

                parameters[0] = new SqlParameter("@CostCentre", costCentre);
                parameters[1] = new SqlParameter("@AdminName", adminName);
                parameters[2] = new SqlParameter("@Status", status);
                
                employeeDetailsDataSet = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, parameters);

                if (employeeDetailsDataSet != null && employeeDetailsDataSet.Tables.Count > 0)
                {
                    return employeeDetailsDataSet;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetEmployeeDetails" + ex.Message);
            }
        }
        /// <summary>
        /// This method is used for get admin user name from employee data base as per filter.
        /// </summary>
        /// <param name="whereClause"></param>
        /// <returns></returns>
        //public DataSet GetDataSet(string whereClause)
        //{
        //    DataSet employeeDetailsDataSet = new DataSet();
        //    try
        //    {
        //        string sql;
        //        sql = "SELECT  EmpUserID,EmployeeName,status"
        //              + " FROM(SELECT  EmpUserID,FirstName + ' ' + LastName AS EmployeeName ,status,CostCentreID FROM Central_Employee_Main) Central_Employee_Main";
        //        if (whereClause.Length > 0)
        //            sql += " WHERE " + whereClause;
        //        sql = sql + " ORDER BY  EmployeeName";
        //        employeeDetailsDataSet = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, sql);
        //    }
        //    catch (Exception ex)
        //    {
        //        throw new Exception("GetDataSet.\n" + ex.Message);
        //    }
        //    return employeeDetailsDataSet;
        //}
        #endregion


        public DataSet GetAdminCCR()
        {
            //string commandText = "SELECT * FROM Evo_Admin_CCRelation ORDER BY UserID";
            //DataSet adminCCR = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.Text, commandText);
            //return adminCCR;

            DataSet adminCCR = new DataSet();
            try
            {
                string spName = "EVO_GetAdminCCR";
                adminCCR = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, null);

                if (adminCCR != null && adminCCR.Tables.Count > 0)
                {
                    return adminCCR;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetAdminCCR" + ex.Message);
            }


        }
        /// <summary>
        /// This method is used for add record in to Evo_Admin_CCRelation table.
        /// </summary>
        /// <returns></returns>
        public bool AddAdminCCR(SqlTransaction objSqlTransaction)
        {
            bool result = false;
            int rowsaffected = 0;
            try
            {
                string spName = "EVO_Insert_AdminCCRelation";
                SqlParameter[] parameters = new SqlParameter[3];

                parameters[0] = new SqlParameter("@UserID", UserId);
                parameters[1] = new SqlParameter("@CCID", CCId);
                parameters[2] = new SqlParameter("@AddedBy", AddedBy);
                rowsaffected = SqlHelper.ExecuteNonQuery(objSqlTransaction, spName, parameters);
                if (rowsaffected > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("AddAdminCCR" + ex.Message);
            }
            return result;
        }
        /// <summary>
        /// This method is used for delete the record from Evo_Admin_CCRelation table.
        /// </summary>
        /// <returns></returns>
        public bool DeleteAdminCCR(SqlTransaction objSqlTransaction)
        {
            bool result = false;
            int rowsaffected = 0;
            try
            {
                string spName = "EVO_Delete_AdminCCRelation";
                SqlParameter[] parameters = new SqlParameter[1];
                parameters[0] = new SqlParameter("@UserID", UserId);
                rowsaffected = SqlHelper.ExecuteNonQuery(objSqlTransaction, spName, parameters);
                if (rowsaffected > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw new Exception("DeleteAdminCCR" + ex.Message);
            }
            return result;
        }
        public DataSet GetAdminCCRelation(int currentPage, int pageSize)
        {
            DataSet dsAdmin = null;
            SqlParameter[] oParams;
            try
            {
                string spName = "EVO_Select_AdminCCRelation";
                oParams = new SqlParameter[3];
                oParams[0] = new SqlParameter("@startRowIndex", currentPage);
                oParams[1] = new SqlParameter("@maximumRows", pageSize);
                oParams[2] = new SqlParameter("@totalRows", TotalRows);
                oParams[2].Direction = ParameterDirection.Output;
                dsAdmin = DAL.SqlHelper.ExecuteDataset(DAL.SqlHelper.GetConnectionString(), CommandType.StoredProcedure, spName, oParams);
                TotalRows = int.Parse(oParams[2].Value.ToString());
                if (dsAdmin != null && dsAdmin.Tables.Count > 0)
                {
                    return dsAdmin;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw new Exception("GetAdminCCRelation" + ex.Message);
            }

        }
    }
}
