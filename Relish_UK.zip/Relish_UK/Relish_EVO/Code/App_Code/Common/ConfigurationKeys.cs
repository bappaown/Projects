﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;

/// <summary>
/// Summary description for ConfigurationKeys
/// </summary>
public class ConfigurationKeys
{
    

    public static string ApplicationTitle
    {
        get
        {
            return ConfigurationManager.AppSettings["AppName"].ToString();
        }
    }

    public static String ErrorRedirectionPage
    {
        get
        {
            return ConfigurationManager.AppSettings["ErrorRedirectionPage"].ToString();
            //return "ErrorHandler.aspx";
        }
    }

    /// <summary>
    /// Whether notifications for application are to be sent or not, supercedes all types of notifications
    /// </summary>
    public static string Notifications
    {
        get
        {
            return ConfigurationManager.AppSettings["Notifications"];
        }
    }

    /// <summary>
    /// whether errors are to be notified or not
    /// </summary>
    public static string ErrorNotifications
    {
        get
        {
            return ConfigurationManager.AppSettings["ErrorNotifications"];
        }
    }

    /// <summary>
    /// Email address for sending all mails
    /// </summary>
    public static string SenderEMail
    {
        get
        {
            return ConfigurationManager.AppSettings["SenderEMail"];
        }
    }

    /// <summary>
    /// The email address for receiving error or system-exception mails
    /// </summary>
    public static string ErrorReceiverEMail
    {
        get
        {
            return ConfigurationManager.AppSettings["ErrorReceiverEMail"];
        }
    }

    /// <summary>
    /// A default receiver of all emails of system-exceptions
    /// </summary>
    public static string ErrorDefaultReciever
    {
        get
        {
            return ConfigurationManager.AppSettings["ErrorDefaultReciever"];
        }
    }

    /// <summary>
    /// The address of the mail sending server
    /// </summary>
    public static string SMTPServer
    {
        get
        {
            return ConfigurationManager.AppSettings["SMTPServer"];
        }
    }

    /// <summary>
    /// The folder path for mail templates
    /// </summary>
    public static string MailTemplateFolderPath
    {
        get
        {
            return ConfigurationManager.AppSettings["MailTemplateFolderPath"];
        }
    }

    /// <summary>
    /// A short-name for the application
    /// </summary>
    public static string ApplicationCode
    {
        get
        {
            return ConfigurationManager.AppSettings["AppCode"];
        }
    }

    public static string ApplicationVersion
    {
        get
        {
            return ConfigurationManager.AppSettings["AppVersion"];
        }
    }

    /// <summary>
    /// The environment or instance of the application
    /// </summary>
    public static string ApplicationMode
    {
        get
        {
            return ConfigurationManager.AppSettings["AppMode"];
        }
    }

    /// <summary>
    /// Gets the web-link or URL of the application
    /// </summary>
    public static string ApplicationURL
    {
        get
        {
            return ConfigurationManager.AppSettings["AppURL"];
            //return HttpContext.Current.Request.Url.AbsoluteUri;
        }
    }

    public static string ApplicationName
    {
        get
        {
            return ConfigurationManager.AppSettings["AppName"];
        }
    }

}
