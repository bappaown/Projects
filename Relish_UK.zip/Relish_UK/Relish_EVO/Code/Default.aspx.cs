using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        ////Windows Authentication : Bappa
        DataSet dsAuthTypes = UserAuthDataStore.GetAuthenticationTypes();
        if (dsAuthTypes != null)
        {
            if (dsAuthTypes.Tables.Count > 0)
            {
                if (dsAuthTypes.Tables[0].Rows.Count > 0)
                {
                    int AuthenticationType = Convert.ToInt32(dsAuthTypes.Tables[0].Rows[0]["Id"]);
                    if (AuthenticationType == 1)
                    {
                        Response.Redirect("UserAuthentication.aspx");
                    }
                    else if (AuthenticationType == 2)
                    {
                        string CeagLink = ConfigurationSettings.AppSettings["CEAGLink"].ToString();
                        Response.Redirect(CeagLink);
                    }

                }
            }
        }
        //Response.Redirect("Admin/Default.aspx");
        ////End
    }
}
