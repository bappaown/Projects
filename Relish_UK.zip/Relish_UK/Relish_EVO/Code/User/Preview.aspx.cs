﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Xsl;
using System.Xml.XPath;
using System.IO;
using EVOLib;

public partial class _Default : EvoGeneral
{
    /// <summary>
    /// Declare private variables below.
    /// </summary>
    XmlDocument xmldoc;
    string xmlFileName;
    string BasicArrayText = "";
    string TempHoldDrpNames = "";
    int cnt = 0;

    Forms objForms = new Forms();

    /// <summary>
    /// capture values from session object.
    /// </summary>
    /// <param name="e"></param>
    protected override void OnInit(EventArgs e)
    {
        if (!IsPostBack)
        {
            //Check if session has value if yes assign it to hidden fields.
            int frmID = ManageSession.FormID;// 291;
            int vrsnID = ManageSession.VersionID; //371;
            string xmlFile = ManageSession.XmlFileName; //"Fainted By test_1.5.xml"; //
            string frmNme = ManageSession.FormName; //"Fainted By test"; //

            if (frmID != 0)
            {
                FormIdHiddenField.Value = frmID.ToString();
            }
            else
            {
                Response.Redirect("../AccessDenied.aspx", true);
            }
            if (vrsnID != 0)
            {
                VersionIDHiddenField.Value = vrsnID.ToString();
            }
            else
            {
                Response.Redirect("../AccessDenied.aspx", true);
            }
            if (xmlFile != null)
            {
                xmlFileNameHiddenField.Value = xmlFile;
            }
            else
            {
                Response.Redirect("../AccessDenied.aspx", true);
            }
            if (frmNme != null)
            {
                frmNmeHiddenField.Value = frmNme;
            }
            else
            {
                Response.Redirect("../AccessDenied.aspx", true);
            }
        }
        base.OnInit(e);
    }

    private void ActiveDeActiveControls(bool IsActive)
    {

    }

    /// <summary>
    /// Calls handlers for generating XSLT, Binding Custom Controls, Array for Controls, Array for dependent controls.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            frmNmeLabel.Text = frmNmeHiddenField.Value;
            objForms.FormID = Convert.ToInt32(FormIdHiddenField.Value);
            objForms.VersionID = Convert.ToInt32(VersionIDHiddenField.Value);

            CreateForm(xmlFileNameHiddenField.Value);

            if (!IsPostBack)
            {
                FormStructure.Visible = true;
                //SetValidations();
                GetDropDownNodes();
                BindCustomControl();
                BindGlobalControl();
            }
            ClientScript.RegisterStartupScript(this.GetType(), "script", "<script>javascript:setheight();</script>");
        }
        catch (Exception ex)
        {
            Errorlabel.Text = ex.Message;
            if (Errorlabel.Text == "Length cannot be less than zero.\r\nParameter name: length")
            {
                Errorlabel.Text = "Please select Cost Centre and SkillSets for Custom/Global Controls.";
            }
        }
    }

    /// <summary>
    /// Function to get all dependent controls and call handler for generating their array.
    /// </summary>
    private void GetDropDownNodes()
    {
        try
        {
            LoadXMLFile();

            //Dependent controls loop to generate array.
            string[] DependentCtrlArray = new string[2];
            DependentCtrlArray[0] = "DropDownList";
            DependentCtrlArray[1] = "ListBox";

            foreach (string ctrl in DependentCtrlArray)
            {
                XmlNodeList rootDropDownNodeList = xmldoc.SelectNodes("FORMS/" + ctrl);

                for (int iNodeDropDownCount = 0; iNodeDropDownCount < rootDropDownNodeList.Count; iNodeDropDownCount++)
                {
                    XmlNode CtrlNode = (XmlNode)rootDropDownNodeList[iNodeDropDownCount];

                    for (int iChildDropDownNode = 0; iChildDropDownNode < CtrlNode.ChildNodes.Count; iChildDropDownNode++)
                    {
                        string ControlType = CtrlNode.ChildNodes[iChildDropDownNode].LocalName;
                        if (ControlType == "FieldID")
                        {
                            string ControlName = CtrlNode.ChildNodes[iChildDropDownNode].InnerText;

                            GetPrevRefData(ControlName, ctrl);
                        }
                    }
                }

                //if (!IsStartupScriptRegistered("CallTypeArray"))
                //{
                RegisterClientScriptBlock("CallTypeArray" + ctrl, "<script language='javascript'>" + BasicArrayText + "</script>");
                BasicArrayText = "";
                //}
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// Generate WHERE clause for cutom control and bind it from Employees table.
    /// </summary>
    private string GenerateWhereClause(string ctrlName)
    {
        //LoadXMLFile();
        string whereClause = " WHERE ";
        try
        {
            string CCId = "";
            string SSId = "";

            //CCId = GetCCIds(ctrlName, out SSId);
            //GetCCIds(ctrlName);
            if (CCId != "Control not found.")
            {
                if (CCId != "" && SSId != "")
                {
                    whereClause += " CostCentreID IN ( " + CCId + ") AND DepartmentID IN ( " + SSId + ")";
                }
                else if (CCId != "")
                {
                    whereClause += " CostCentreID IN ( " + CCId + ")";
                }
                else if (SSId != "")
                {
                    whereClause += " DepartmentID IN ( " + SSId + ")";
                }
            }
            else
            {
                whereClause = "";
            }
        }
        catch (Exception ex)
        {
            Errorlabel.Text = ex.Message;
        }
        return whereClause;
    }

    /// <summary>
    /// Fill global contorl with multiple dependency.
    /// </summary>
    /// <param name="CustomControlNode"></param>
    /// <param name="SSId"></param>
    /// <returns></returns>
    public void FillMControls()
    {
        DataSet GlobalDataSet = new DataSet();
        string controlIdofDB = "";
        string ControlName = "";
        string GlobalDataArray = "";
        string ElementName = "";
        string dependentId = "";
        string title = "";
        string CCId = "";
        string SSId = "";
        string type = "DropDown";

        try
        {
            LoadXMLFile();
            XmlNodeList rootNodeList = xmldoc.SelectNodes("FORMS/GlobalMControl");

            for (int iParentNode = 0; iParentNode < rootNodeList.Count; iParentNode++)
            {
                XmlNode CustomControlNode = (XmlNode)rootNodeList[iParentNode];

                if (CustomControlNode != null)
                {
                    for (int iChildNodes = 0; iChildNodes < CustomControlNode.ChildNodes.Count; iChildNodes++)
                    {
                        ElementName = CustomControlNode.ChildNodes[iChildNodes].LocalName;
                        if (ElementName == "CostCentres")
                        {
                            XmlNodeList CCNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iCC = 0; iCC < CCNames.Count; iCC++)
                            {
                                CCId += CCNames.Item(iCC).Attributes["Id"].Value + ",";
                            }
                        }
                        else if (ElementName == "SkillSets")
                        {
                            XmlNodeList SSNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iSS = 0; iSS < SSNames.Count; iSS++)
                            {
                                SSId += SSNames.Item(iSS).Attributes["Id"].Value + ",";
                            }
                        }
                        else if (ElementName == "DependentID")
                        {
                            dependentId = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                        else if (ElementName == "FieldID")
                        {
                            ControlName = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                        else if (ElementName == "ControlID")
                        {
                            controlIdofDB = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                        else if (ElementName == "Title")
                        {
                            title = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                        else if (ElementName == "Type")
                        {
                            type = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                    }

                    SSId = SSId.Substring(0, SSId.Length - 1);
                    CCId = CCId.Substring(0, CCId.Length - 1);

                    objForms.CostCentreID = CCId;
                    objForms.SkillSetID = SSId;
                    objForms.ControlID = Convert.ToInt32(controlIdofDB);

                    DataSet GlobalDataDataSet = new DataSet();
                    GlobalDataDataSet = objForms.SelectGlobalControlData(GlobalDataDataSet);
                    AttachData(GlobalDataDataSet, ControlName, "Text", "DataStoreID");

                    //For child controls of global control.
                    objForms.FieldName = dependentId;
                    int childControlID = objForms.GetGlobalControlID();
                    if (childControlID != 0)
                    {
                        objForms.ControlID = childControlID;
                        GlobalDataSet = objForms.SelectGlobalControlData(GlobalDataSet);
                        SSId = "";
                        CCId = "";
                    }

                    GlobalDataArray = " var ItemArray" + ControlName + "= new Array(" + GlobalDataSet.Tables[0].Rows.Count + ");\n";
                    for (int i = 0; i < GlobalDataSet.Tables[0].Rows.Count; i++)
                    {
                        GlobalDataArray += "ItemArray" + ControlName + "[" + i + "] = new Array('" + GlobalDataSet.Tables[0].Rows[i]["DependentID"].ToString() + "','" + GlobalDataSet.Tables[0].Rows[i]["DataStoreID"].ToString() + "','" + GlobalDataSet.Tables[0].Rows[i]["Text"].ToString() + "');\n";
                        //GlobalDataArray += "ItemArray" + GlobalDataSet.Tables[0].Rows[i]["ControlID"].ToString() + "[" + i + "] = new Array('" + GlobalDataSet.Tables[0].Rows[i]["DependentID"].ToString() + "','" + GlobalDataSet.Tables[0].Rows[i]["DataStoreID"].ToString() + "','" + GlobalDataSet.Tables[0].Rows[i]["Text"].ToString() + "');\n";
                    }

                    ContentPlaceHolder ControlHldr = (ContentPlaceHolder)this.Page.Master.FindControl("ContentPlaceHolder1");
                    Control ctrl = ControlHldr.FindControl(ControlName);

                    if (type == "DropDown")
                    {
                        DropDownList ddlCtrl = new DropDownList();
                        ddlCtrl = (DropDownList)ctrl;
                        //function PopulateGlobalData(FromControl, ToControl, ArrName)
                        ddlCtrl.Attributes.Add("onchange", "PopulateGlobalData('" + ControlName + "', '" + dependentId + "', ItemArray" + ControlName + ",'DropDownList')");
                    }
                    else if (type == "ListBox") //For ListBox Control.
                    {
                        ListBox lbCtrl = new ListBox();
                        lbCtrl = (ListBox)ctrl;
                        lbCtrl.Attributes.Add("onchange", "PopulateGlobalData('" + ControlName + "', '" + dependentId + "', ItemArray" + ControlName + ",'ListBox')");
                    }

                    RegisterClientScriptBlock("GlobalDataArray" + ControlName + "", "<script language='javascript'>" + GlobalDataArray.ToString() + "</script>");
                    GlobalDataArray = "";

                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// Fill global control with no dependency.
    /// </summary>
    public void FillSControls()
    {
        string controlIdofDB = "";
        string ElementName = "";
        string ControlName = "";
        string CCId = "";
        string SSId = "";

        try
        {
            LoadXMLFile();
            XmlNodeList rootNodeList = xmldoc.SelectNodes("FORMS/GlobalSControl");

            for (int iParentNode = 0; iParentNode < rootNodeList.Count; iParentNode++)
            {
                XmlNode CustomControlNode = (XmlNode)rootNodeList[iParentNode];

                if (CustomControlNode != null)
                {
                    for (int iChildNodes = 0; iChildNodes < CustomControlNode.ChildNodes.Count; iChildNodes++)
                    {
                        ElementName = CustomControlNode.ChildNodes[iChildNodes].LocalName;
                        if (ElementName == "CostCentres")
                        {
                            XmlNodeList CCNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iCC = 0; iCC < CCNames.Count; iCC++)
                            {
                                CCId += CCNames.Item(iCC).Attributes["Id"].Value + ",";
                            }
                        }
                        else if (ElementName == "SkillSets")
                        {
                            XmlNodeList SSNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iSS = 0; iSS < SSNames.Count; iSS++)
                            {
                                SSId += SSNames.Item(iSS).Attributes["Id"].Value + ",";
                            }
                        }
                        else if (ElementName == "FieldID")
                        {
                            ControlName = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                        else if (ElementName == "ControlID")
                        {
                            controlIdofDB = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                    }

                    SSId = SSId.Substring(0, SSId.Length - 1);
                    CCId = CCId.Substring(0, CCId.Length - 1);

                    objForms.CostCentreID = CCId;
                    objForms.SkillSetID = SSId;
                    objForms.ControlID = Convert.ToInt32(controlIdofDB);

                    DataSet GlobalDataDataSet = new DataSet();
                    GlobalDataDataSet = objForms.SelectGlobalControlData(GlobalDataDataSet);
                    AttachData(GlobalDataDataSet, ControlName, "Text", "DataStoreID");
                    SSId = "";
                    CCId = "";
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// Get custom control name from database and call handlers to bind them accordingly.
    /// </summary>
    private void BindCustomControl()
    {
        try
        {
            //Forms objForms = new Forms();
            //objForms.FormID = 1;
            //objForms.VersionID = 1;
            objForms.ControlType = "Custom";

            //Check if Custom controls is assigned to this form.
            DataSet objDataSet = new DataSet();
            objDataSet = objForms.GetCustomGlobalControls(objDataSet);

            if (objDataSet.Tables[0].Rows.Count > 0)
            {
                DataSet empDataSet = new DataSet();

                for (int iRowCount = 0; iRowCount < objDataSet.Tables[0].Rows.Count; iRowCount++)
                {
                    string ctrlName = objDataSet.Tables[0].Rows[iRowCount]["ControlName"].ToString() + objDataSet.Tables[0].Rows[iRowCount]["ControlDisplayType"].ToString();

                    string sqlWhere = "";
                    if (iRowCount == 0)  //for first custom control1.
                    {
                        //GenerateWhereClause(ctrlName);
                        SqlForCCOne(ctrlName);

                    }
                    else if (iRowCount == 1) //for second custom control2.
                    {
                        SqlForCCTwo(ctrlName);
                    }
                }
            }

        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// Handler for custom control One
    /// </summary>
    /// <param name="ctrlName"></param>
    /// <returns></returns>
    public void SqlForCCOne(string ctrlName)
    {
        string ElementName = "";
        string CCId = "";
        string SSId = "";
        string sqlQuery = "";
        string whereClause = "";
        string ControlName = "";
        try
        {
            LoadXMLFile();
            DataSet empDataSet = new DataSet();
            XmlNodeList rootNodeList = xmldoc.SelectNodes("FORMS/" + ctrlName + "");

            for (int iParentNode = 0; iParentNode < rootNodeList.Count; iParentNode++)
            {
                XmlNode CustomControlNode = (XmlNode)rootNodeList[iParentNode];

                if (CustomControlNode != null)
                {
                    for (int iChildNodes = 0; iChildNodes < CustomControlNode.ChildNodes.Count; iChildNodes++)
                    {
                        ElementName = CustomControlNode.ChildNodes[iChildNodes].LocalName;
                        if (ElementName == "FieldID")
                        {
                            ControlName = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                        if (ElementName == "CostCentres")
                        {
                            XmlNodeList CCNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iCC = 0; iCC < CCNames.Count; iCC++)
                            {
                                CCId += CCNames.Item(iCC).Attributes["Id"].Value + ",";
                            }
                        }
                        else if (ElementName == "SkillSets")
                        {
                            XmlNodeList SSNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iSS = 0; iSS < SSNames.Count; iSS++)
                            {
                                SSId += SSNames.Item(iSS).Attributes["Id"].Value + ",";
                            }
                        }
                    }

                    SSId = SSId.Substring(0, SSId.Length - 1);
                    CCId = CCId.Substring(0, CCId.Length - 1);

                    //if (CCId != "")
                    //{
                    //    whereClause += " CostCentreID IN ( " + CCId + ")";
                    //}
                    //if (SSId != "")
                    //{
                    //    if (whereClause != "")
                    //    {
                    //        whereClause += " AND DepartmentID IN ( " + SSId + ")";
                    //    }
                    //    else
                    //    {
                    //        whereClause += " DepartmentID IN ( " + SSId + ")";
                    //    }

                    //}

                    //if (whereClause != "")
                    //{
                    //    whereClause = " WHERE " + whereClause + " AND Status = 1 ";
                    //    sqlQuery = objForms.SqlQueryForCustomControlOne + whereClause;
                    //}
                    //else
                    //{
                    //    sqlQuery = objForms.SqlQueryForCustomControlOne;
                    //}

                    //sqlQuery = sqlQuery + " ORDER BY Firstname ";
                    //empDataSet = objForms.SelectEmployeesForCustomControl(empDataSet, sqlQuery);

                    empDataSet = objForms.SelectEmployeesForCustomControl(empDataSet, CCId, SSId);

                    AttachData(empDataSet, ControlName, "EmployeeName", "EmployeeNameWithID");

                    //Clear variables for next loop if any.
                    sqlQuery = "";
                    whereClause = "";
                    SSId = "";
                    CCId = "";
                }
                else
                {
                    CCId = "Control not found.";
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// Handler for custom control Two
    /// </summary>
    /// <param name="ctrlName"></param>
    /// <returns></returns>
    public void SqlForCCTwo(string ctrlName)
    {
        string ElementName = "";
        string CCId = "";
        string SSId = "";
        string location = "";
        string sqlQuery = "";
        string whereClause = "";
        string ControlName = "";
        try
        {
            LoadXMLFile();
            DataSet empDataSet = new DataSet();
            XmlNodeList rootNodeList = xmldoc.SelectNodes("FORMS/" + ctrlName + "");

            for (int iParentNode = 0; iParentNode < rootNodeList.Count; iParentNode++)
            {
                XmlNode CustomControlNode = (XmlNode)rootNodeList[iParentNode];

                if (CustomControlNode != null)
                {
                    for (int iChildNodes = 0; iChildNodes < CustomControlNode.ChildNodes.Count; iChildNodes++)
                    {
                        ElementName = CustomControlNode.ChildNodes[iChildNodes].LocalName;
                        if (ElementName == "FieldID")
                        {
                            ControlName = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                        if (ElementName == "CostCentres")
                        {
                            XmlNodeList CCNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iCC = 0; iCC < CCNames.Count; iCC++)
                            {
                                CCId += CCNames.Item(iCC).Attributes["Id"].Value + ",";
                            }
                        }
                        else if (ElementName == "SkillSets")
                        {
                            XmlNodeList SSNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iSS = 0; iSS < SSNames.Count; iSS++)
                            {
                                SSId += SSNames.Item(iSS).Attributes["Id"].Value + ",";
                            }
                        }
                        else if (ElementName == "Location")
                        {
                            XmlNodeList LocationNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iL = 0; iL < LocationNames.Count; iL++)
                            {
                                location += "'" + LocationNames.Item(iL).InnerText.Trim() + "',";
                            }
                        }
                    }

                    SSId = SSId.Substring(0, SSId.Length - 1);
                    CCId = CCId.Substring(0, CCId.Length - 1);
                    location = location.Substring(0, location.Length - 1);


                    //if (CCId != "")
                    //{
                    //    whereClause += " CostCentreID IN ( " + CCId + ")";
                    //}
                    //if (SSId != "")
                    //{
                    //    if (whereClause != "")
                    //    {
                    //        whereClause += " AND DepartmentID IN ( " + SSId + ")";
                    //    }
                    //    else
                    //    {
                    //        whereClause += " DepartmentID IN ( " + SSId + ")";
                    //    }
                    //}
                    //if (location != "")
                    //{
                    //    if (whereClause != "")
                    //    {
                    //        whereClause += " AND Location IN ( " + location + ")";
                    //    }
                    //    else
                    //    {
                    //        whereClause += " Location IN ( " + location + ")";
                    //    }
                    //}

                    //if (whereClause != "")
                    //{
                    //    whereClause = " WHERE " + whereClause + " AND Status = 1 ";

                    //    sqlQuery = objForms.SqlQueryForCustomControlOne + whereClause;

                    //}
                    //else
                    //{
                    //    sqlQuery = objForms.SqlQueryForCustomControlOne;
                    //}
                    //sqlQuery = sqlQuery + " ORDER BY Firstname ";
                    //empDataSet = objForms.SelectEmployeesForCustomControl(empDataSet, sqlQuery);

                    empDataSet = objForms.SelectEmployeesForCustomControl(empDataSet, CCId, SSId);

                    AttachData(empDataSet, ControlName, "EmployeeName", "EmployeeNameWithID");

                    //Clear variables for next loop if any.
                    sqlQuery = "";
                    whereClause = "";
                    SSId = "";
                    CCId = "";
                    location = "";
                }
                else
                {
                    CCId = "Control not found.";
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// function to generate array for global control if present.
    /// </summary>
    private void BindGlobalControl()
    {
        try
        {
            FillMControls();
            FillSControls();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// Get Global contorl ID from XML by passing Global control XML tag from database.
    /// </summary>
    /// <returns></returns>
    public string GetGlobalControlID(string xmlTagName)
    {
        string ElementName = "";
        string ControlID = "";

        try
        {
            LoadXMLFile();
            XmlNodeList rootNodeList = xmldoc.SelectNodes("FORMS/" + xmlTagName + "");

            for (int iParentNode = 0; iParentNode < rootNodeList.Count; iParentNode++)
            {
                XmlNode CustomControlNode = (XmlNode)rootNodeList[iParentNode];

                if (CustomControlNode != null)
                {
                    for (int iChildNodes = 0; iChildNodes < CustomControlNode.ChildNodes.Count; iChildNodes++)
                    {
                        ElementName = CustomControlNode.ChildNodes[iChildNodes].LocalName;
                        if (ElementName == "FieldID")
                        {
                            ControlID = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return ControlID;
    }

    /// <summary>
    /// Attach data to custom/global control.
    /// </summary>
    /// <param name="objDataSet"></param>
    /// <param name="ctrlName"></param>
    /// <param name="textField"></param>
    /// <param name="valueField"></param>    
    public void AttachData(DataSet objDataSet, string ctrlName, string textField, string valueField)
    {
        ContentPlaceHolder ControlHldr = (ContentPlaceHolder)this.Page.Master.FindControl("ContentPlaceHolder1");
        Control ctrl = ControlHldr.FindControl(ctrlName);
        try
        {
            if (ctrl is DropDownList)
            {
                DropDownList ddlCtrl = new DropDownList();
                ddlCtrl = (DropDownList)ctrl;
                ddlCtrl.DataSource = objDataSet;
                ddlCtrl.DataTextField = textField;
                ddlCtrl.DataValueField = valueField;
                ddlCtrl.DataBind();
                ddlCtrl.Items.Insert(0, "--Select--");
            }
            else if (ctrl is GridView)
            {
                GridView gvCtrl = new GridView();
                gvCtrl = (GridView)ctrl;
                gvCtrl.DataSource = objDataSet;
                gvCtrl.DataBind();
            }
            else if (ctrl is CheckBoxList)
            {
                //code for any CheckBoxList databind controls.
            }
            else if (ctrl is RadioButtonList)
            {

            }
            else if (ctrl is ListBox)
            {
                ListBox lbCtrl = new ListBox();
                lbCtrl = (ListBox)ctrl;
                lbCtrl.DataSource = objDataSet;
                lbCtrl.DataTextField = textField;
                lbCtrl.DataValueField = valueField;
                lbCtrl.DataBind();
            }
        }
        catch (Exception ex)
        {
            Errorlabel.Text = " Attach Data Error: " + ex.Message;
        }
    }

    /// <summary>
    /// Function to load XML file.
    /// </summary>
    private void LoadXMLFile()
    {
        xmlFileName = Server.MapPath("../XML/" + xmlFileNameHiddenField.Value);
        xmldoc = new XmlDocument();
        xmldoc.Load(xmlFileName);
    }

    /// <summary>
    /// Get XML with FromID and VersionID and display form with XSLT.
    /// </summary>
    /// <param name="fileName"></param>
    private void CreateForm(string fileName)
    {
        try
        {
            if (fileName != "")
            {
                // Load the data source
                //XPathDocument surveyDoc = new XPathDocument(Server.MapPath("ExSurvey.xml"));
                XPathDocument surveyDoc = new XPathDocument(Server.MapPath("../XML/" + fileName));

                // Load the xslt to do the transformations
                XslCompiledTransform transform = new XslCompiledTransform();
                //transform.Load(Server.MapPath("MakeControls.xsl"));
                transform.Load(Server.MapPath("../XSLT/XSLT_V1_Preview.xsl"));

                // Get the transformed result
                StringWriter sw = new StringWriter();
                transform.Transform(surveyDoc, null, sw);
                string result = sw.ToString();

                // remove the namespace attribute
                result = result.Replace("xmlns:asp=\"remove\"", "").Replace("xmlns:ajaxToolkit=\"remove\"", "").Replace("&lt;", "<").Replace("&gt;", ">");
                sw.Close();

                // parse the control(s) and add it to the page
                Control ctrl = Page.ParseControl(result);
                FormStructure.Controls.Add(ctrl);

                /* Code to validate xml with xsd */
                //XMLValidation objXMLValidation = new XMLValidation();

                //string XSDPath = Server.MapPath("..\\XSD\\XSD_v1.xsd");
                //string XMLPath = Server.MapPath("..\\XML\\XML_F1_v1.xml");
                //objXMLValidation.ValidatingProcess(XSDPath, XMLPath);

            }
            else
            {
                Errorlabel.Text = "Invalid XML FileName.";
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// Generate Array for dependent controls.
    /// </summary>
    /// <param name="RefObj"></param>
    /// <param name="ctrlType"></param>
    private void GetPrevRefData(string RefObj, string ctrlType)
    {
        string PrevCtrl = "";
        string FName = "";
        string IsManageable = "";
        bool isSuccess = false;
        string DependentId = "";
        string LabelText = "";

        if (!TempHoldDrpNames.ToUpper().Contains(RefObj.ToUpper()))
        {
            TempHoldDrpNames += RefObj + ",";

            try
            {
                LoadXMLFile();
                XmlNodeList rootNodeList = xmldoc.SelectNodes("FORMS/" + ctrlType);
                DropDownList ddlCtrl = new DropDownList();
                ListBox lbCtrl = new ListBox();

                for (int i = 0; i < rootNodeList.Count; i++)
                {
                    XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                    int countElements = 0;
                    PrevCtrl = "";
                    FName = "";
                    IsManageable = "";
                    isSuccess = false;
                    LabelText = "";

                    for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                    {
                        if (dropDownNode.ChildNodes[y].Name == "label")
                        {
                            LabelText = dropDownNode.ChildNodes[y].FirstChild.Value;
                        }
                        if (dropDownNode.ChildNodes[y].Name == "IsManageable")
                        {
                            IsManageable = dropDownNode.ChildNodes[y].InnerText.Trim();
                            countElements = countElements + 1;
                        }
                        if (dropDownNode.ChildNodes[y].Name == "FieldID")
                        {
                            FName = dropDownNode.ChildNodes[y].InnerText.Trim();
                            countElements = countElements + 1;
                        }
                        if (dropDownNode.ChildNodes[y].Name == "PrevRef")
                        {
                            PrevCtrl = dropDownNode.ChildNodes[y].InnerText.Trim();
                            countElements = countElements + 1;
                        }
                        if (dropDownNode.ChildNodes[y].Name == "DependentID")
                        {
                            DependentId = dropDownNode.ChildNodes[y].InnerText.Trim();
                            countElements = countElements + 1;
                        }

                        if ((IsManageable == "True") && (FName == RefObj))  //&& (PrevCtrl != "")
                        {
                            if (dropDownNode.ChildNodes[y].Name == "LISTITEMS")
                            {
                                ContentPlaceHolder ControlHldr = (ContentPlaceHolder)this.Page.Master.FindControl("ContentPlaceHolder1");
                                Control ctrl;
                                ctrl = ControlHldr.FindControl(RefObj);

                                if (ctrlType == "DropDownList")
                                {
                                    ddlCtrl = (DropDownList)ctrl;
                                    ddlCtrl.Items.Insert(0, "--Select--");
                                }
                                else if (ctrlType == "ListBox")
                                {
                                    lbCtrl = (ListBox)ctrl;
                                }


                                XmlNodeList listItems = dropDownNode.ChildNodes[y].ChildNodes;

                                // Creating an array. This will be used in javascript n registered via code
                                BasicArrayText += "var Array" + (FName).ToString() + " = new Array( " + listItems.Count + " );\n";

                                for (int l = 0; l < listItems.Count; l++)
                                {
                                    string dependentOn = "";
                                    string ListItemVal = "";
                                    string ListItemText = "";

                                    ListItemText = listItems.Item(l).InnerText;
                                    ListItemVal = listItems.Item(l).Attributes["Id"].Value;

                                    // if ((listItems.Item(l).Attributes.Item(1).InnerText == "") || (listItems.Item(l).Attributes.Item(1).InnerText == "0"))
                                    if ((listItems.Item(l).Attributes["DependentOn"].Value != "") || (listItems.Item(l).Attributes["DependentOn"].Value == "0"))
                                    {
                                        dependentOn = listItems.Item(l).Attributes["DependentOn"].Value;

                                        if ((dependentOn == "") || (dependentOn == null))
                                        {
                                            dependentOn = "";
                                        }
                                        BasicArrayText += "if (Array" + (FName).ToString() + "[" + dependentOn + "] ==null) "
                                                     + "Array" + (FName).ToString() + "[" + dependentOn + "] = new Array();\n";

                                        BasicArrayText += "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "]= new Array('" + ListItemText + "');\n";

                                    }

                                    if (PrevCtrl == "")
                                    {
                                        ListItem lst = new ListItem();
                                        lst.Text = ListItemText;
                                        lst.Value = ListItemVal + "," + ListItemText;

                                        if (ctrlType == "DropDownList")
                                        {
                                            ddlCtrl.Items.Add(lst);
                                        }
                                        else if (ctrlType == "ListBox")
                                        {
                                            lbCtrl.Items.Add(lst);
                                        }
                                    }
                                }
                                //Response.Write(CallTypeArrayText);
                                cnt = cnt + 1;
                                if (DependentId != "")
                                {
                                    if (ctrlType == "DropDownList")
                                    {
                                        ddlCtrl.Attributes.Add("onchange", "Populate('" + ddlCtrl.ID + "', '" + DependentId + "', Array" + DependentId + ",'" + ctrlType + "')");
                                    }
                                    else if (ctrlType == "ListBox")
                                    {
                                        lbCtrl.Attributes.Add("onchange", "Populate('" + lbCtrl.ID + "', '" + DependentId + "', Array" + DependentId + ",'" + ctrlType + "')");
                                    }
                                }

                                if (PrevCtrl != "")
                                {
                                    GetPrevRefData(PrevCtrl, ctrlType);
                                }
                            }
                            else
                            {
                                isSuccess = false;
                            }
                        }
                        else
                        {
                            if (countElements == 4)
                            {
                                y = dropDownNode.ChildNodes.Count;
                            }
                        }
                        if (isSuccess)
                        {
                            y = dropDownNode.ChildNodes.Count;
                            i = rootNodeList.Count;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Errorlabel.Text = ex.Message;
            }
        }
    }
}