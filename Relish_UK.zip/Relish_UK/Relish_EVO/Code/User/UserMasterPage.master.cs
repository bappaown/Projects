using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using H3GS.Web.Security;
using System.Xml.Linq;
using EVOLib;
using DAL;


public partial class User_UserMasterPage : System.Web.UI.MasterPage
{
	public string userName;
	protected void Page_Load(object sender, EventArgs e)
	{
		if (!IsPostBack)
		{
            ////Windows Authentication : Bappa
            //userName = PassportIdentity.Current.Employee.FullName;
            userName = HttpContext.Current.Request.Cookies["EVO"] != null ? HttpContext.Current.Request.Cookies["EVO"]["userFullName"] : string.Empty;
            ////End
            lblName.Text = "Welcome " + userName;
            this.Page.Title = "" + ConfigurationKeys.ApplicationName + " - " + ConfigurationKeys.ApplicationVersion;
		}
	}
}
