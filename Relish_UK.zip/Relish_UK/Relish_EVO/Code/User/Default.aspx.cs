﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Threading;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.XPath;
using System.Xml.Xsl;
using EVOLib;
using System.Collections.Generic;
using System.Xml.Linq;
using System.Web;
using System.Text;


public partial class _Default : EvoGeneral
{
    /// <summary>
    /// Declare private variables below.
    /// </summary>
    /// 

    #region declaration
    XmlDocument xmldoc;
    string xmlFileName;
    string BasicArrayText = "";
    string TempHoldDrpNames = "";
    int cnt = 0;
    string checkWrap = "";
    bool isWrap = false;
    string controlName = "";
    string controlValue = "";
    string preWrap = "";
    string postWrap = "";
    string wrapNotes = "";
    public string loginName = "";
    public string lineManager = "";
    public string salesCount = "";
    bool isScriptRetrieved = false;
    private int templateFormID;

    Forms objForms = new Forms();

    #endregion

    protected override void OnUnload(EventArgs e)
    {
        string a = PreserveTimeHiddenField.Value;

        base.OnUnload(e);
    }

    /// <summary>
	/// capture values from session object.
	/// </summary>
	/// <param name="e"></param>
	protected override void OnInit(EventArgs e)
    {
        if (!IsPostBack)
        {
            //Check if session has value if yes assign it to hidden fields.
            int frmID = ManageSession.FormID;
            int vrsnID = ManageSession.VersionID;
            string xmlFile = ManageSession.XmlFileName;
            string frmNme = ManageSession.FormName;
            string catName = ManageSession.CategoryName;
            string IsEditable = ManageSession.IsEditable;
            string IsScrabblePad = ManageSession.IsScrabblePad;
            int prevFormID = ManageSession.PreviousFormID;
            int prevVersionID = ManageSession.PreviousVersionID;
            string prevXmlFileName = ManageSession.PreviousXmlFileName;
            string prevFormName = ManageSession.PreviousFormName;
            string prevCategoryName = ManageSession.PreviousCategoryName;
            int transactionid = ManageSession.TransactionID;
            hfTransactionId.Value = Convert.ToString(transactionid);
            hfIsEditable.Value = IsEditable;
            hfIsScrabblePad.Value = IsScrabblePad;

            if (Session["TransIds"] != null)
            {
                hfTransIds.Value = Session["TransIds"].ToString();
                Session["TransIds"] = null;
            }
            else
            {
                hfTransIds.Value = "";
            }
            if (Session["PageIndex"] != null)
            {
                hfPageIndex.Value = Session["PageIndex"].ToString();
                Session["PageIndex"] = null;
            }
            else
            {
                hfPageIndex.Value = "";
            }
            if (frmID != 0)
            {
                FormIdHiddenField.Value = frmID.ToString();
            }
            else
            {
                Response.Redirect("../AccessDenied.aspx", true);
            }
            if (vrsnID != 0)
            {
                VersionIDHiddenField.Value = vrsnID.ToString();
            }
            else
            {
                Response.Redirect("../AccessDenied.aspx", true);
            }
            if (xmlFile != null)
            {
                xmlFileNameHiddenField.Value = xmlFile;
            }
            else
            {
                Response.Redirect("../AccessDenied.aspx", true);
            }
            if (frmNme != null)
            {
                frmNmeHiddenField.Value = frmNme;
            }
            else
            {
                Response.Redirect("../AccessDenied.aspx", true);
            }
            if (catName != null)
            {
                CatNameHiddenField.Value = catName;
            }
            else
            {
                Response.Redirect("../AccessDenied.aspx", true);
            }

            if (CatNameHiddenField.Value == "Call Logger" || prevCategoryName == "Call Logger")
            {
                string script = "";
                if (IsEditable.ToLower() == "true")
                {
                    if (Session["IsBack"] == null)
                    {
                        script = "<script language='javascript'>javascript:TransparentPage(true);</script>";
                    }
                    else if (Session["IsBack"] == "true")
                    {
                        script = "<script language='javascript'>javascript:TransparentPage(false);</script>";
                    }
                }
                else
                {
                    script = "<script language='javascript'>javascript:TransparentPage(false);</script>";
                }

                RegisterStartupScript("script", script);
            }
            else
            {
                TimerLayer5.Style.Add("display", "none");
                StartTimer.Visible = false;
                //imgWordWrapDiv.Style.Add("display", "none");
                //WrapTextDiv.Style.Add("display", "none");
            }

            //store the parent form details in the hidden fields
            hfPrevFormID.Value = prevFormID.ToString();
            hfPrevFormName.Value = prevFormName;
            hfPrevVersionID.Value = prevVersionID.ToString();
            hfPrevCategoryName.Value = prevCategoryName;
            hfPrevXmlFileName.Value = prevXmlFileName;

            if (Session["TimeTaken"] != null)
            {
                PreserveTimeHiddenField.Value = Session["TimeTaken"].ToString();
                Session["TimeTaken"] = null;
                ClientScript.RegisterStartupScript(this.GetType(), "script", "<script>javascript:ClosePopUp();GetShowHideControls(2);</script>");
            }
            if (Session["ddlstatus"] != null)
            {
                lblddlstatus.Text = Session["ddlstatus"].ToString();
                //RegisterStartupScript("script", "<script>javascript:checkforddl();</script>");
                if (lblddlstatus.Text == "")
                {
                    txtsearchvalue.Style.Value = "display:block";
                    ddlsearchvalue.Style.Value = "display:none";
                }
                else
                {
                    txtsearchvalue.Style.Value = "display:none";
                    ddlsearchvalue.Style.Value = "display:block";
                }
                Session["ddlstatus"] = null;
            }


            imgBackDiv.Visible = hfPrevFormID.Value != "0";
            if (IsScrabblePad.ToLower() == "true")
            {
                dvscr.Style.Value = "float: right; left: 84%; position: absolute;display:block;z-index: 99999";
            }
            else
            {
                dvscr.Style.Value = "display:none";
            }
            if (IsEditable.ToLower() == "true" && hfPrevFormID.Value == "0")
            {
                Filldata();
                //Is form is IsEditable then FormStructure details will be changed --Koshal Goswami
                FormStructure.Attributes.Add("Width", "1395px");
                FormStructure.Attributes.Add("top", "210px");
                //ContentPlaceHolder ctPlaceHolder = (ContentPlaceHolder)Master.FindControl("head");
                int grdheight = 0;
                if (grdTransDetails.DataSource != null)
                {
                    grdheight = 200;
                }
                int height = Convert.ToInt32(FormStructure.Style["Height"].ToString().Replace("px", ""));
                height = height + 220 + grdheight;
                dvWrapUpdate.Style.Value = "position: absolute; top: " + height.ToString() + "px";
                ContentPlaceHolder ctPlaceHolder = (ContentPlaceHolder)Master.FindControl("head");
                System.Web.UI.HtmlControls.HtmlTable lblModule = (System.Web.UI.HtmlControls.HtmlTable)Master.FindControl("tblmaster");
                lblModule.Height = (height - 100).ToString() + "px";
                dvsub.Style.Value = "display:block;background-color:#edf6fc;border:#d2eeff;margin-top:5px;width:99%;";
                //dvsub.Attributes.Add("class", "Dvcss");


            }
            else
            {
                dvsub.Style.Value = "display:none";
            }
        }

        else
        {
            ScriptManager.RegisterStartupScript(this, this.GetType(), "DisableTimerImage", "<script language='javascript'>DisableTimerImage();GetShowHideControls(2);</script>", false);

        }


        base.OnInit(e);
    }

    private void ActiveDeActiveControls(bool IsActive)
    {
        imgSave.Enabled = IsActive;
        imgWrap.Enabled = IsActive;
    }

    [System.Web.Services.WebMethod]
    public static string GetEmployeeManager(int employeeId)
    {
        string name = "";

        name = DataManagement.GetEmployeeManager(employeeId);
        return name;
    }




    public void Filldata()
    {
        try
        {


            string versionID = VersionIDHiddenField.Value;
            string formid = FormIdHiddenField.Value;
            DataSet dscontrol = new DataSet();
            Forms objform = new Forms();
            dscontrol = objform.GetControls(formid.ToString(), versionID.ToString());
            DataSet dstransdetails = new DataSet();
            if (hfTransIds.Value == "")
            {
                //dstransdetails = objform.GetTransDetails(formid.ToString(), versionID.ToString(), "");
            }
            else
            {
                if (hfTransIds.Value == "0")
                {
                    //if (Session["Transaction"] == null)
                    if (hfTransactionId.Value == "")
                    {
                        ClientScript.RegisterStartupScript(this.GetType(), "alert", "<script>javascript:alert('No record found');</script>");
                    }
                    //dstransdetails = objform.GetTransDetails(formid.ToString(), versionID.ToString(), "");

                }
                else
                {
                    char[] splitter = { '|' };
                    string[] transids = hfTransIds.Value.Split(splitter);

                    dstransdetails = objform.GetTransDetails(formid.ToString(), "0", transids[0].ToString(), transids[1].ToString());
                }
                Session["TransIds"] = null;

            }
            if (dstransdetails.Tables.Count > 0)
            {
                if (dstransdetails.Tables[0].Rows.Count > 0)
                {
                    grdTransDetails.DataSource = dstransdetails;

                    if (hfPageIndex.Value != "")
                    {
                        grdTransDetails.PageIndex = Convert.ToInt16(hfPageIndex.Value);
                    }



                    grdTransDetails.DataBind();

                    //grdTransDetails.Rows[0].Style.Value = "background-color:red";
                }
                else
                {
                    grdTransDetails.DataSource = null;
                    grdTransDetails.DataBind();
                }

            }
            else
            {
                grdTransDetails.DataSource = null;
                grdTransDetails.DataBind();
            }



            if (dscontrol.Tables.Count > 0)
            {
                if (dscontrol.Tables[0].Rows.Count > 0)
                {
                    ddlcontrollist.DataSource = dscontrol;
                    ddlcontrollist.DataTextField = "Alias";
                    ddlcontrollist.DataValueField = "Fieldid";
                    ddlcontrollist.DataBind();

                    ddlcontrollist.Items.Insert(0, new ListItem("--Select--", "-1"));

                    ddlcontrollist.SelectedValue = Session["Searchparam"].ToString();

                    chkmypen.Checked = Convert.ToBoolean(Session["MyTrans"].ToString());
                    //ClientScript.RegisterStartupScript(this.GetType(), "alert", "<script>javascript:GetControl();</script>",true);
                    if (lblddlstatus.Text != "")
                    {
                        string response = GetControlType(Session["Searchparam"].ToString(), formid.ToString(), versionID.ToString());
                        string[] ctype = response.Split(',');
                        string controltype = "";
                        if (ctype[1].ToLower() == "dropdown")
                        {
                            controltype = "DropDownList";
                        }
                        else
                        {
                            controltype = ctype[1];
                        }
                        string[] ddlvalueresult = null;
                        ddlvalueresult = FillControlList(ctype[0] + ctype[1], controltype, ctype[2]);
                        ddlsearchvalue.DataSource = ddlvalueresult;

                        ddlsearchvalue.DataBind();
                    }
                    if (lblddlstatus.Text != "")
                    {
                        ddlsearchvalue.SelectedValue = lblddlstatus.Text;
                    }
                    else
                    {
                        txtsearchvalue.Text = Session["Searchvalue"].ToString();
                    }
                    Session["MyTrans"] = null;
                    Session["Searchparam"] = null;
                    Session["Searchvalue"] = null;
                }
                else
                {
                    ddlcontrollist.DataSource = null;
                    ddlcontrollist.DataBind();
                }
            }
            else
            {
                ddlcontrollist.DataSource = null;
                ddlcontrollist.DataBind();
            }


        }
        catch (Exception ex)
        {

        }
    }

    /// <summary>
    /// Calls handlers for generating XSLT, Binding Custom Controls, Array for Controls, Array for dependent controls.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            frmNmeLabel.Text = frmNmeHiddenField.Value;
            objForms.FormID = Convert.ToInt32(FormIdHiddenField.Value);
            objForms.VersionID = Convert.ToInt32(VersionIDHiddenField.Value);

            CreateForm(xmlFileNameHiddenField.Value);

            if (!IsPostBack)
            {
                FormStructure.Visible = true;
                //SetValidations();
                GetDropDownNodes();
                BindCustomControl();
                BindGlobalControl();
                AddJavaScript();

                if (Session["Msg"] != null)
                {
                    Errorlabel.Text = Session["Msg"].ToString();
                    Session["Msg"] = null;
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "CopyClipBord", "<script language='javascript'>copy();</script>", false); // Commented FOR UK. WILL BE ACTIVE FOR IRL-- COMMENTED ON 28/07/2011
                }

                if (Session["IsUpdate"] != null)
                {
                    lblsave.Text = "Update";
                    Session["IsUpdate"] = null;
                }
                else
                {
                    lblsave.Text = "Save";
                }

                RestoreData();
                if (Session["FormVersion"] != null)
                {
                    Session["FormVersion"] = null;
                }
                if (Session["fieldDictionary"] != null)
                {
                    ViewState["fieldDictionary"] = Session["fieldDictionary"];
                    Session["fieldDictionary"] = null;
                }
                if (Session["scrolltop"] != null)
                {
                    hfscrolltop.Value = Session["scrolltop"].ToString();
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "GetScroll", "<script language='javascript'>GetDivPosition();</script>", false); // Commented FOR UK. WILL BE ACTIVE FOR IRL-- COMMENTED ON 28/07/2011
                    Session["scrolltop"] = null;
                }
                ClientScript.RegisterStartupScript(this.GetType(), "script", "<script>javascript:GetShowHideControls(0);</script>");

            }
            GetLoggedInDetails();

        }
        catch (Exception ex)
        {
            //Errorlabel.Text = "1 : " + ex.Message;
            if (Errorlabel.Text == "Length cannot be less than zero.\r\nParameter name: length")
            {
                Errorlabel.Text = "Please select Cost Centre and SkillSets for Custom/Global Controls.";
            }
        }
    }

    private void AddJavaScript()
    {
        WrapTextBox.Attributes.Add("onkeypress", "return CheckValidLength(document.getElementById('" + WrapTextBox.ClientID + "'),'999', false)");
        WrapTextBox.Attributes.Add("onpaste", "return CheckValidLength(document.getElementById('" + WrapTextBox.ClientID + "'),'999', false)");
    }

    private void SetValidations()
    {
        string Dependency = "";
        string ControlName = "";
        string DependentID = "";
        try
        {
            LoadXMLFile();
            string[] DependentCtrlArray = new string[1];
            DependentCtrlArray[0] = "TextBox";

            foreach (string ctrl in DependentCtrlArray)
            {
                XmlNodeList rootDropDownNodeList = xmldoc.SelectNodes("FORMS/" + ctrl);

                for (int iNodeDropDownCount = 0; iNodeDropDownCount < rootDropDownNodeList.Count; iNodeDropDownCount++)
                {
                    XmlNode CtrlNode = (XmlNode)rootDropDownNodeList[iNodeDropDownCount];

                    for (int iChildDropDownNode = 0; iChildDropDownNode < CtrlNode.ChildNodes.Count; iChildDropDownNode++)
                    {
                        string ControlType = CtrlNode.ChildNodes[iChildDropDownNode].LocalName;
                        if (ControlType == "FieldID")
                        {
                            ControlName = CtrlNode.ChildNodes[iChildDropDownNode].InnerText;
                        }
                        if (Dependency == "Dependency")
                        {
                            Dependency = CtrlNode.ChildNodes[iChildDropDownNode].InnerText;
                        }
                        if (DependentID == "DependentID")
                        {
                            DependentID = CtrlNode.ChildNodes[iChildDropDownNode].InnerText;
                        }

                        if (Dependency == "True")
                        {
                            //Code to validate here.
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
            //Errorlabel.Text = "Set Validations : " + ex.Message;
        }
    }

    /// <summary>
    /// Function to get all dependent controls and call handler for generating their array.
    /// </summary>
    private void GetDropDownNodes()
    {
        try
        {
            LoadXMLFile();

            //Dependent controls loop to generate array.
            string[] DependentCtrlArray = new string[2];
            DependentCtrlArray[0] = "DropDownList";
            DependentCtrlArray[1] = "ListBox";
            //DependentCtrlArray[2] = "RadioButtonList";
            //DependentCtrlArray[3] = "CheckBoxList";
            foreach (string ctrl in DependentCtrlArray)
            {
                XmlNodeList rootDropDownNodeList = xmldoc.SelectNodes("FORMS/" + ctrl);

                for (int iNodeDropDownCount = 0; iNodeDropDownCount < rootDropDownNodeList.Count; iNodeDropDownCount++)
                {
                    XmlNode CtrlNode = (XmlNode)rootDropDownNodeList[iNodeDropDownCount];

                    for (int iChildDropDownNode = 0; iChildDropDownNode < CtrlNode.ChildNodes.Count; iChildDropDownNode++)
                    {
                        string ControlType = CtrlNode.ChildNodes[iChildDropDownNode].LocalName;
                        if (ControlType == "FieldID")
                        {
                            string ControlName = CtrlNode.ChildNodes[iChildDropDownNode].InnerText;

                            GetPrevRefData(ControlName, ctrl);
                        }
                    }
                }


                //if (!IsStartupScriptRegistered("CallTypeArray"))
                //{

                //***				BasicArrayText = "";
                //}
            }
            Page.ClientScript.RegisterClientScriptBlock(this.GetType(), "CallTypeArray", BasicArrayText, true);
        }
        catch (Exception ex)
        {
            //Errorlabel.Text = " 2 : " + ex.Message;
            throw ex;
        }
    }

    /// <summary>
    /// Generate WHERE clause for cutom control and bind it from Employees table.
    /// </summary>
    private string GenerateWhereClause(string ctrlName)
    {
        //LoadXMLFile();
        string whereClause = " WHERE ";
        try
        {
            string CCId = "";
            string SSId = "";

            //CCId = GetCCIds(ctrlName, out SSId);
            //GetCCIds(ctrlName);
            if (CCId != "Control not found.")
            {
                if (CCId != "" && SSId != "")
                {
                    whereClause += " CostCentreID IN ( " + CCId + ") AND DepartmentID IN ( " + SSId + ")";
                }
                else if (CCId != "")
                {
                    whereClause += " CostCentreID IN ( " + CCId + ")";
                }
                else if (SSId != "")
                {
                    whereClause += " DepartmentID IN ( " + SSId + ")";
                }
            }
            else
            {
                whereClause = "";
            }
        }
        catch (Exception ex)
        {
            Errorlabel.Text = ex.Message;
        }
        return whereClause;
    }

    /// <summary>
    /// Fill global contorl with multiple dependency.
    /// </summary>
    /// <param name="CustomControlNode"></param>
    /// <param name="SSId"></param>
    /// <returns></returns>
    public void FillMControls()
    {
        DataSet GlobalDataSet = new DataSet();
        string controlIdofDB = "";
        string ControlName = "";
        string GlobalDataArray = "";
        string ElementName = "";
        string dependentId = "";
        string title = "";
        string CCId = "";
        string SSId = "";
        string type = "DropDown";
        try
        {
            LoadXMLFile();
            XmlNodeList rootNodeList = xmldoc.SelectNodes("FORMS/GlobalMControl");

            for (int iParentNode = 0; iParentNode < rootNodeList.Count; iParentNode++)
            {
                XmlNode CustomControlNode = (XmlNode)rootNodeList[iParentNode];

                if (CustomControlNode != null)
                {
                    for (int iChildNodes = 0; iChildNodes < CustomControlNode.ChildNodes.Count; iChildNodes++)
                    {
                        ElementName = CustomControlNode.ChildNodes[iChildNodes].LocalName;
                        if (ElementName == "CostCentres")
                        {
                            XmlNodeList CCNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iCC = 0; iCC < CCNames.Count; iCC++)
                            {
                                CCId += CCNames.Item(iCC).Attributes["Id"].Value + ",";
                            }
                        }
                        else if (ElementName == "SkillSets")
                        {
                            XmlNodeList SSNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iSS = 0; iSS < SSNames.Count; iSS++)
                            {
                                SSId += SSNames.Item(iSS).Attributes["Id"].Value + ",";
                            }
                        }
                        else if (ElementName == "DependentID")
                        {
                            dependentId = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                        else if (ElementName == "FieldID")
                        {
                            ControlName = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                        else if (ElementName == "ControlID")
                        {
                            controlIdofDB = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                        else if (ElementName == "Title")
                        {
                            title = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                        else if (ElementName == "Type")
                        {
                            type = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                    }

                    SSId = SSId.Substring(0, SSId.Length - 1);
                    CCId = CCId.Substring(0, CCId.Length - 1);

                    objForms.CostCentreID = CCId;
                    objForms.SkillSetID = SSId;
                    objForms.ControlID = Convert.ToInt32(controlIdofDB);

                    //Get Parent global control data.
                    DataSet GlobalDataDataSet = new DataSet();
                    GlobalDataDataSet = objForms.SelectGlobalControlData(GlobalDataDataSet);
                    AttachData(GlobalDataDataSet, ControlName, "Text", "DataStoreID");

                    //For child controls of global control.
                    objForms.FieldName = dependentId;
                    int childControlID = objForms.GetGlobalControlID();
                    if (childControlID != 0)
                    {
                        objForms.ControlID = childControlID;
                        GlobalDataSet = objForms.SelectGlobalControlData(GlobalDataSet);
                        SSId = "";
                        CCId = "";
                    }

                    //Remove blank space from title to avoid spaces in array name.
                    title = title.Replace(" ", "");
                    GlobalDataArray = " var ItemArray" + ControlName + "= new Array(" + GlobalDataSet.Tables[0].Rows.Count + ");\n";
                    for (int i = 0; i < GlobalDataSet.Tables[0].Rows.Count; i++)
                    {
                        GlobalDataArray += "ItemArray" + ControlName + "[" + i + "] = new Array('" + GlobalDataSet.Tables[0].Rows[i]["DependentID"].ToString() + "','" + GlobalDataSet.Tables[0].Rows[i]["DataStoreID"].ToString() + "','" + GlobalDataSet.Tables[0].Rows[i]["Text"].ToString() + "');\n";
                    }

                    ContentPlaceHolder ControlHldr = (ContentPlaceHolder)this.Page.Master.FindControl("ContentPlaceHolder1");
                    Control ctrl = ControlHldr.FindControl(ControlName);

                    if (type == "DropDown")
                    {
                        DropDownList ddlCtrl = new DropDownList();
                        ddlCtrl = (DropDownList)ctrl;
                        //function PopulateGlobalData(FromControl, ToControl, ArrName)
                        ddlCtrl.Attributes.Add("onchange", "PopulateGlobalData('" + ControlName + "', '" + dependentId + "', ItemArray" + ControlName + ",'DropDownList')");
                    }
                    else if (type == "ListBox") //For ListBox Control.
                    {
                        ListBox lbCtrl = new ListBox();
                        lbCtrl = (ListBox)ctrl;
                        lbCtrl.Attributes.Add("onchange", "PopulateGlobalData('" + ControlName + "', '" + dependentId + "', ItemArray" + ControlName + ",'ListBox')");
                    }
                    RegisterClientScriptBlock("GlobalDataArray" + ControlName + "", "<script language='javascript'>" + GlobalDataArray.ToString() + "</script>");
                    GlobalDataArray = "";
                }
            }
        }
        catch (Exception ex)
        {
            //Errorlabel.Text = "FillMControls" + ex.Message;
            throw ex;
        }
    }

    /// <summary>
    /// Fill global control with no dependency.
    /// </summary>
    public void FillSControls()
    {
        string controlIdofDB = "";
        string ElementName = "";
        string ControlName = "";
        string CCId = "";
        string SSId = "";

        try
        {
            LoadXMLFile();
            XmlNodeList rootNodeList = xmldoc.SelectNodes("FORMS/GlobalSControl");

            for (int iParentNode = 0; iParentNode < rootNodeList.Count; iParentNode++)
            {
                XmlNode CustomControlNode = (XmlNode)rootNodeList[iParentNode];

                if (CustomControlNode != null)
                {
                    for (int iChildNodes = 0; iChildNodes < CustomControlNode.ChildNodes.Count; iChildNodes++)
                    {
                        ElementName = CustomControlNode.ChildNodes[iChildNodes].LocalName;
                        if (ElementName == "CostCentres")
                        {
                            XmlNodeList CCNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iCC = 0; iCC < CCNames.Count; iCC++)
                            {
                                CCId += CCNames.Item(iCC).Attributes["Id"].Value + ",";
                            }
                        }
                        else if (ElementName == "SkillSets")
                        {
                            XmlNodeList SSNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iSS = 0; iSS < SSNames.Count; iSS++)
                            {
                                SSId += SSNames.Item(iSS).Attributes["Id"].Value + ",";
                            }
                        }
                        else if (ElementName == "FieldID")
                        {
                            ControlName = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                        else if (ElementName == "ControlID")
                        {
                            controlIdofDB = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                    }

                    SSId = SSId.Substring(0, SSId.Length - 1);
                    CCId = CCId.Substring(0, CCId.Length - 1);

                    objForms.CostCentreID = CCId;
                    objForms.SkillSetID = SSId;
                    objForms.ControlID = Convert.ToInt32(controlIdofDB);

                    DataSet GlobalDataDataSet = new DataSet();
                    GlobalDataDataSet = objForms.SelectGlobalControlData(GlobalDataDataSet);
                    AttachData(GlobalDataDataSet, ControlName, "Text", "DataStoreID");
                    SSId = "";
                    CCId = "";
                }
            }

        }
        catch (Exception ex)
        {
            //Errorlabel.Text = "FillSControls" + ex.Message;
            throw ex;
        }
    }

    /// <summary>
    /// Get custom control name from database and call handlers to bind them accordingly.
    /// </summary>
    private void BindCustomControl()
    {
        try
        {
            //Forms objForms = new Forms();
            //objForms.FormID = 1;
            //objForms.VersionID = 1;
            objForms.ControlType = "Custom";

            //Check if Custom controls is assigned to this form.
            DataSet objDataSet = new DataSet();
            objDataSet = objForms.GetCustomGlobalControls(objDataSet);

            if (objDataSet.Tables[0].Rows.Count > 0)
            {
                DataSet empDataSet = new DataSet();

                for (int iRowCount = 0; iRowCount < objDataSet.Tables[0].Rows.Count; iRowCount++)
                {
                    string ctrlName = objDataSet.Tables[0].Rows[iRowCount]["ControlName"].ToString() + objDataSet.Tables[0].Rows[iRowCount]["ControlDisplayType"].ToString();

                    string sqlWhere = "";
                    if (iRowCount == 0)  //for first custom control1.
                    {
                        //GenerateWhereClause(ctrlName);
                        SqlForCCOne(ctrlName);

                    }
                    else if (iRowCount == 1) //for second custom control2.
                    {
                        SqlForCCTwo(ctrlName);
                    }
                }
            }

        }
        catch (Exception ex)
        {
            //Errorlabel.Text = " 4 : " + ex.Message;
            throw ex;
        }
    }

    /// <summary>
    /// Handler for custom control One
    /// </summary>
    /// <param name="ctrlName"></param>
    /// <returns></returns>
    public void SqlForCCOne(string ctrlName)
    {
        string ElementName = "";
        string CCId = "";
        string SSId = "";
        string sqlQuery = "";
        string whereClause = "";
        string ControlName = "";
        try
        {
            LoadXMLFile();
            DataSet empDataSet = new DataSet();
            XmlNodeList rootNodeList = xmldoc.SelectNodes("FORMS/" + ctrlName + "");

            for (int iParentNode = 0; iParentNode < rootNodeList.Count; iParentNode++)
            {
                XmlNode CustomControlNode = (XmlNode)rootNodeList[iParentNode];

                if (CustomControlNode != null)
                {
                    for (int iChildNodes = 0; iChildNodes < CustomControlNode.ChildNodes.Count; iChildNodes++)
                    {
                        ElementName = CustomControlNode.ChildNodes[iChildNodes].LocalName;
                        if (ElementName == "FieldID")
                        {
                            ControlName = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                        if (ElementName == "CostCentres")
                        {
                            XmlNodeList CCNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iCC = 0; iCC < CCNames.Count; iCC++)
                            {
                                CCId += CCNames.Item(iCC).Attributes["Id"].Value + ",";
                            }
                        }
                        else if (ElementName == "SkillSets")
                        {
                            XmlNodeList SSNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iSS = 0; iSS < SSNames.Count; iSS++)
                            {
                                SSId += SSNames.Item(iSS).Attributes["Id"].Value + ",";
                            }
                        }
                    }

                    SSId = SSId.Substring(0, SSId.Length - 1);
                    CCId = CCId.Substring(0, CCId.Length - 1);

                    //if (CCId != "")
                    //{
                    //    whereClause += " CostCentreID IN ( " + CCId + ")";
                    //}
                    //if (SSId != "")
                    //{
                    //    if (whereClause != "")
                    //    {
                    //        whereClause += " AND DepartmentID IN ( " + SSId + ")";
                    //    }
                    //    else
                    //    {
                    //        whereClause += " DepartmentID IN ( " + SSId + ")";
                    //    }

                    //}

                    //if (whereClause != "")
                    //{
                    //    whereClause = " WHERE " + whereClause + " AND Status = 1 ";
                    //    sqlQuery = objForms.SqlQueryForCustomControlOne + whereClause;
                    //}
                    //else
                    //{
                    //    sqlQuery = objForms.SqlQueryForCustomControlOne;
                    //}

                    //sqlQuery = sqlQuery + " ORDER BY Firstname ";

                    //empDataSet = objForms.SelectEmployeesForCustomControl(empDataSet, sqlQuery);

                    empDataSet = objForms.SelectEmployeesForCustomControl(empDataSet, CCId, SSId);

                    AttachData(empDataSet, ControlName, "EmployeeName", "EmployeeNameWithID");

                    //Clear variables for next loop if any.
                    sqlQuery = "";
                    whereClause = "";
                    SSId = "";
                    CCId = "";
                }
                else
                {
                    CCId = "Control not found.";
                }
            }
        }
        catch (Exception ex)
        {
            //Errorlabel.Text = "SqlForCCOne : " + ex.Message;
            throw ex;
        }
    }

    /// <summary>
    /// Handler for custom control Two
    /// </summary>
    /// <param name="ctrlName"></param>
    /// <returns></returns>
    public void SqlForCCTwo(string ctrlName)
    {
        string ElementName = "";
        string CCId = "";
        string SSId = "";
        string location = "";
        string sqlQuery = "";
        string whereClause = "";
        string ControlName = "";
        try
        {
            LoadXMLFile();
            DataSet empDataSet = new DataSet();
            XmlNodeList rootNodeList = xmldoc.SelectNodes("FORMS/" + ctrlName + "");

            for (int iParentNode = 0; iParentNode < rootNodeList.Count; iParentNode++)
            {
                XmlNode CustomControlNode = (XmlNode)rootNodeList[iParentNode];

                if (CustomControlNode != null)
                {
                    for (int iChildNodes = 0; iChildNodes < CustomControlNode.ChildNodes.Count; iChildNodes++)
                    {
                        ElementName = CustomControlNode.ChildNodes[iChildNodes].LocalName;
                        if (ElementName == "FieldID")
                        {
                            ControlName = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                        if (ElementName == "CostCentres")
                        {
                            XmlNodeList CCNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iCC = 0; iCC < CCNames.Count; iCC++)
                            {
                                CCId += CCNames.Item(iCC).Attributes["Id"].Value + ",";
                            }
                        }
                        else if (ElementName == "SkillSets")
                        {
                            XmlNodeList SSNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iSS = 0; iSS < SSNames.Count; iSS++)
                            {
                                SSId += SSNames.Item(iSS).Attributes["Id"].Value + ",";
                            }
                        }
                        else if (ElementName == "Location")
                        {
                            XmlNodeList LocationNames = CustomControlNode.ChildNodes[iChildNodes].ChildNodes;
                            for (int iL = 0; iL < LocationNames.Count; iL++)
                            {
                                location += "'" + LocationNames.Item(iL).InnerText.Trim() + "',";
                            }
                        }
                    }

                    SSId = SSId.Substring(0, SSId.Length - 1);
                    CCId = CCId.Substring(0, CCId.Length - 1);
                    location = location.Substring(0, location.Length - 1);


                    //if (CCId != "")
                    //{
                    //    whereClause += " CostCentreID IN ( " + CCId + ")";
                    //}
                    //if (SSId != "")
                    //{
                    //    if (whereClause != "")
                    //    {
                    //        whereClause += " AND DepartmentID IN ( " + SSId + ")";
                    //    }
                    //    else
                    //    {
                    //        whereClause += " DepartmentID IN ( " + SSId + ")";
                    //    }
                    //}
                    //if (location != "")
                    //{
                    //    if (whereClause != "")
                    //    {
                    //        whereClause += " AND Location IN ( " + location + ")";
                    //    }
                    //    else
                    //    {
                    //        whereClause += " Location IN ( " + location + ")";
                    //    }
                    //}

                    //if (whereClause != "")
                    //{
                    //    whereClause = " WHERE " + whereClause + " AND Status = 1 ";

                    //    sqlQuery = objForms.SqlQueryForCustomControlOne + whereClause;

                    //}
                    //else
                    //{
                    //    sqlQuery = objForms.SqlQueryForCustomControlOne;
                    //}

                    //sqlQuery = sqlQuery + " ORDER BY Firstname ";

                    //empDataSet = objForms.SelectEmployeesForCustomControl(empDataSet, sqlQuery);

                    empDataSet = objForms.SelectEmployeesForCustomControl(empDataSet, CCId, SSId);

                    AttachData(empDataSet, ControlName, "EmployeeName", "EmployeeNameWithID");

                    //Clear variables for next loop if any.
                    sqlQuery = "";
                    whereClause = "";
                    SSId = "";
                    CCId = "";
                    location = "";
                }
                else
                {
                    CCId = "Control not found.";
                }
            }
        }
        catch (Exception ex)
        {
            //Errorlabel.Text = "SqlForCCTwo : " + ex.Message;
            throw ex;
        }
    }

    /// <summary>
    /// function to generate array for global control if present.
    /// </summary>
    private void BindGlobalControl()
    {
        try
        {
            FillMControls();
            FillSControls();
        }
        catch (Exception ex)
        {
            //Errorlabel.Text = "5 : " + ex.Message;
            throw ex;
        }
    }

    /// <summary>
    /// Get Global contorl ID from XML by passing Global control XML tag from database.
    /// </summary>
    /// <returns></returns>
    public string GetGlobalControlID(string xmlTagName)
    {
        string ElementName = "";
        string ControlID = "";

        try
        {
            LoadXMLFile();
            XmlNodeList rootNodeList = xmldoc.SelectNodes("FORMS/" + xmlTagName + "");

            for (int iParentNode = 0; iParentNode < rootNodeList.Count; iParentNode++)
            {
                XmlNode CustomControlNode = (XmlNode)rootNodeList[iParentNode];

                if (CustomControlNode != null)
                {
                    for (int iChildNodes = 0; iChildNodes < CustomControlNode.ChildNodes.Count; iChildNodes++)
                    {
                        ElementName = CustomControlNode.ChildNodes[iChildNodes].LocalName;
                        if (ElementName == "FieldID")
                        {
                            ControlID = CustomControlNode.ChildNodes[iChildNodes].InnerText.Trim();
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {
            //Errorlabel.Text = "6 : " + ex.Message;
            throw ex;
        }
        return ControlID;
    }

    /// <summary>
    /// Attach data to custom/global control.
    /// </summary>
    /// <param name="objDataSet"></param>
    /// <param name="ctrlName"></param>
    /// <param name="textField"></param>
    /// <param name="valueField"></param>    
    public void AttachData(DataSet objDataSet, string ctrlName, string textField, string valueField)
    {
        ContentPlaceHolder ControlHldr = (ContentPlaceHolder)this.Page.Master.FindControl("ContentPlaceHolder1");
        Control ctrl = ControlHldr.FindControl(ctrlName);
        try
        {
            if (ctrl is DropDownList)
            {
                DropDownList ddlCtrl = new DropDownList();
                ddlCtrl = (DropDownList)ctrl;
                ddlCtrl.DataSource = objDataSet;
                ddlCtrl.DataTextField = textField;
                ddlCtrl.DataValueField = valueField;
                ddlCtrl.DataBind();
                ddlCtrl.Items.Insert(0, "--Select--");
            }
            else if (ctrl is GridView)
            {
                GridView gvCtrl = new GridView();
                gvCtrl = (GridView)ctrl;
                gvCtrl.DataSource = objDataSet;
                gvCtrl.DataBind();
            }
            else if (ctrl is CheckBoxList)
            {
                //code for any CheckBoxList databind controls.
            }
            else if (ctrl is RadioButtonList)
            {

            }
            else if (ctrl is ListBox)
            {
                ListBox lbCtrl = new ListBox();
                lbCtrl = (ListBox)ctrl;
                lbCtrl.DataSource = objDataSet;
                lbCtrl.DataTextField = textField;
                lbCtrl.DataValueField = valueField;
                lbCtrl.DataBind();
            }
        }
        catch (Exception ex)
        {
            Errorlabel.Text = " Attach Data Error: " + ex.Message;
        }
    }

    /// <summary>
    /// Function to load XML file.
    /// </summary>
    private void LoadXMLFile()
    {
        xmlFileName = Server.MapPath("../XML/" + xmlFileNameHiddenField.Value);
        xmldoc = new XmlDocument();
        xmldoc.Load(xmlFileName);
    }

    /// <summary>
    /// Get XML with FromID and VersionID and display form with XSLT.
    /// </summary>
    /// <param name="fileName"></param>
    private void CreateForm(string fileName)
    {
        try
        {
            if (fileName != "")
            {
                // Load the data source
                //XPathDocument surveyDoc = new XPathDocument(Server.MapPath("ExSurvey.xml"));
                XPathDocument surveyDoc = new XPathDocument(Server.MapPath("../XML/" + fileName));

                // Load the xslt to do the transformations
                XslCompiledTransform transform = new XslCompiledTransform();
                //transform.Load(Server.MapPath("MakeControls.xsl"));
                transform.Load(Server.MapPath("../XSLT/XSLT_V1.xsl"));

                // Get the transformed result
                StringWriter sw = new StringWriter();
                transform.Transform(surveyDoc, null, sw);
                string result = sw.ToString();

                // remove the namespace attribute
                result = result.Replace("xmlns:asp=\"remove\"", "").Replace("xmlns:ajaxToolkit=\"remove\"", "").Replace("&lt;", "<").Replace("&gt;", ">");
                sw.Close();
                //if (hfIsEditable.Value.ToLower() == "true" && hfPrevFormID.Value =="0")
                //{
                //    result = settopforcontrol(result);
                //}
                // parse the control(s) and add it to the page
                result = result.Replace(@"SkinID=""""", @"SkinID=""tanew""");
                result = result.Replace(@"CssClass=""""", @"CssClass=""textareacss1""");
                Control ctrl = Page.ParseControl(result);

                FormStructure.Controls.Add(ctrl);


                //if (Session["IsBack"] != null && Session["IsBack"].ToString()=="true")
                //{
                //    Session["IsBack"] = null;
                //    if (Session["fieldDictionary"] != null)
                //    {
                //        Dictionary<string, string> fieldDictionary;
                //        fieldDictionary = (Dictionary<string, string>)Session["fieldDictionary"];

                //        DataSet formsDataSet = new DataSet();
                //        formsDataSet = objForms.GetFormsFieldsWithVersions(formsDataSet);

                //        if (formsDataSet.Tables[0].Rows.Count > 0)
                //        {
                //            for (int iRowCount = 0; iRowCount < formsDataSet.Tables[0].Rows.Count; iRowCount++)
                //            {
                //                string ctrlName = formsDataSet.Tables[0].Rows[iRowCount]["FieldName"].ToString() + formsDataSet.Tables[0].Rows[iRowCount]["FieldDisplayType"].ToString();
                //                string fieldType = formsDataSet.Tables[0].Rows[iRowCount]["FieldDisplayType"].ToString();

                //                if (fieldType == "DropDown" || fieldType == "ListBox")
                //                {
                //                    DropDownList ddl = (DropDownList)FormStructure.FindControl(ctrlName);
                //                    try
                //                    {
                //                        ddl.Items.FindByText(fieldDictionary[formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString()]).Selected = true;
                //                    }
                //                    catch (Exception ex)
                //                    { }
                //                }
                //                else if (fieldType == "TextBox")
                //                { 
                //                    TextBox tb=(TextBox)FormStructure.FindControl(ctrlName);
                //                    tb.Text=fieldDictionary[formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString()];
                //                }

                //            }

                //        }
                //    }
                //}

                /* Code to validate xml with xsd */
                //XMLValidation objXMLValidation = new XMLValidation();

                //string XSDPath = Server.MapPath("..\\XSD\\XSD_v1.xsd");
                //string XMLPath = Server.MapPath("..\\XML\\XML_F1_v1.xml");
                //objXMLValidation.ValidatingProcess(XSDPath, XMLPath);

            }
            else
            {
                Errorlabel.Text = "Invalid XML FileName.";
            }
        }
        catch (Exception ex)
        {
            //Errorlabel.Text = "3 : " + ex.Message;
            throw ex;
        }
    }

    protected void SaveButton_Clicked(object sender, ImageClickEventArgs e)
    {
        try
        {
            imgWrap.Enabled = false;
            //Capture the selected values of the controls and insert it in database.
            ProcessFieldResults();
        }
        catch (Exception ex)
        {
            Errorlabel.Text = ex.Message.ToString();
        }
    }

    private bool ValidateForm()
    {
        bool isValid = false;
        isValid = IsValidForm();

        return isValid;
    }

    private bool IsValidForm()
    {
        bool isValid = true;

        //ContentPlaceHolder ControlHldr = (ContentPlaceHolder)this.Page.Master.FindControl("ContentPlaceHolder1");
        //// THIS IS TO CHECK IF ALL THE MANDATORY FIELDS ARE ENTERED OR NOT.
        //Control parent = (Control)ControlHldr.FindControl("ctl02");

        //Control[] ctrl = FindControlRecursive(parent);
        //RequiredFieldValidator rfv = new RequiredFieldValidator();
        //foreach (Control control in ctrl)
        //{
        //    if (control != null)
        //    {
        //        rfv = (RequiredFieldValidator)parent.FindControl(control.ID);
        //        string text = Request["ctl00$ContentPlaceHolder1$" + rfv.ControlToValidate];

        //        if (text == null || text == "" || text == "--Select--")
        //        {
        //            isValid = false;
        //            //rfv.Style.Value = "visibility:visible";
        //            //rfv.Attributes.Add("style", "visibility:visible");
        //            rfv.Style.Add("visibility", "visible");
        //            Errorlabel.Text = "Please select all the mandatory fields";
        //            TimerLabel.Text = PreserveTimeHiddenField.Value;
        //        }
        //    }
        //}
        return isValid;
    }

    private Control[] FindControlRecursive(Control parent)
    {
        int cnt = 0;
        Control[] match = new Control[parent.Controls.Count];

        foreach (Control child in parent.Controls)
        {
            if (child is RequiredFieldValidator)
            {
                match.SetValue(child, cnt);
                cnt += 1;
            }
            ////else if (child.HasControls())
            ////{
            ////    //match = this.FindControlRecursive(child);
            ////    this.FindControlRecursive(child);
            ////}

            //if (match != null)
            //    break;
        }
        return match;
    }

    /// <summary>
    /// Function captures selected values of the controls and inserts it in database.
    /// </summary>
    private void ProcessFieldResults()
    {
        //Thread.Sleep(3000);
        //Forms objForms = new Forms();

        DataSet formsDataSet = new DataSet();

        Dictionary<string, string> fieldDictionary;

        if (ViewState["fieldDictionary"] == null)
        {
            fieldDictionary = new Dictionary<string, string>();
        }
        else
        {
            fieldDictionary = (Dictionary<string, string>)ViewState["fieldDictionary"];
        }


        try
        {
            //objForms.FormID = Convert.ToInt32(FormIdHiddenField.Value);
            //objForms.VersionID = Convert.ToInt32(VersionIDHiddenField.Value);
            formsDataSet = objForms.GetFormsFieldsWithVersions(formsDataSet, false);

            int TransactionID = 0;
            string controlValue = "";
            DataSet dsversion = new DataSet();
            int versionstatus = 0;
            //if (Session["Transaction"] != null) checked for hidden field values from properties 
            if (hfTransactionId.Value != "" && hfTransactionId.Value != "0")
            {

                //dsversion = objForms.GetVersionForTrans(Session["Transaction"].ToString());
                dsversion = objForms.GetVersionForTrans(hfTransactionId.Value);
                if (dsversion.Tables.Count > 0)
                {
                    if (dsversion.Tables[0].Rows.Count > 0)
                    {
                        if (Convert.ToInt32(dsversion.Tables[0].Rows[0]["VersionId"].ToString()) != Convert.ToInt32(VersionIDHiddenField.Value))
                        {
                            versionstatus = 1;
                            fieldDictionary = new Dictionary<string, string>();
                        }
                    }
                }
            }

            if (formsDataSet.Tables[0].Rows.Count > 0)
            {
                for (int iRowCount = 0; iRowCount < formsDataSet.Tables[0].Rows.Count; iRowCount++)
                {
                    string ctrlName = formsDataSet.Tables[0].Rows[iRowCount]["FieldNameNew"].ToString() + formsDataSet.Tables[0].Rows[iRowCount]["FieldDisplayType"].ToString();

                    //Return values from controls displayed.
                    controlValue = ReturnValue(ctrlName);

                    if (controlValue == null || controlValue == "")
                    {
                        controlValue = "Not Selected.";
                    }

                    if (Errorlabel.Text != "")
                    {
                        return;
                    }

                    //Store in the dictionary

                    if (versionstatus != 1)
                    {
                        if (fieldDictionary.ContainsKey(formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString()))
                        {
                            fieldDictionary[formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString()] = controlValue;
                        }
                        else
                        {
                            fieldDictionary.Add(formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString(), controlValue);
                        }
                    }
                    else
                    {

                        fieldDictionary.Add(formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString(), controlValue);
                    }

                    //int FormDetailsID = 0;

                    //if (iRowCount == 0)
                    //{
                    //    //check parent form transaction id exists
                    //    int tranid = ManageSession.TransactionID;
                    //    if (tranid > 0)
                    //    {
                    //        TransactionID = tranid;
                    //    }
                    //    else
                    //    {
                    //        //old code here
                    //        //objForms.FormID = 1;
                    //        //objForms.VersionID = 1;
                    //        objForms.UserID = RetrieveUserID(userName);
                    //        if (PreserveTimeHiddenField.Value == "")
                    //        {
                    //            PreserveTimeHiddenField.Value = "0";
                    //        }
                    //        objForms.TimeTaken = Convert.ToInt32(PreserveTimeHiddenField.Value);
                    //        objForms.AddedBy = userName;
                    //        TransactionID = objForms.GenerateTransationID(objSqlTransaction, out uniqueId);
                    //    }
                    //}

                    //objForms.FieldID = Convert.ToInt32(formsDataSet.Tables[0].Rows[iRowCount]["FieldID"]);
                    //objForms.DataCapture = controlValue;
                    //objForms.TransID = TransactionID;

                    //FormDetailsID = objForms.InsertFormDetails(objSqlTransaction);
                }



                if (templateFormID > 0) //check whether any template is assigned
                {
                    Session["FieldDictionary"] = fieldDictionary;
                    Session["TimeTaken"] = PreserveTimeHiddenField.Value;

                    DataRow rw = GetTemplateDetails(templateFormID).Rows[0];

                    //set parent form details for redirection from template back to parent
                    ManageSession.PreviousFormID = Convert.ToInt32(FormIdHiddenField.Value);
                    ManageSession.PreviousVersionID = Convert.ToInt32(VersionIDHiddenField.Value);
                    ManageSession.PreviousXmlFileName = xmlFileNameHiddenField.Value;
                    ManageSession.PreviousFormName = frmNmeHiddenField.Value;
                    ManageSession.PreviousCategoryName = CatNameHiddenField.Value;

                    //set the parameters for opening the template form
                    ManageSession.FormID = Convert.ToInt32(rw["FormID"]);
                    ManageSession.VersionID = Convert.ToInt32(rw["VersionID"]);
                    ManageSession.XmlFileName = Convert.ToString(rw["XMLFileName"]);
                    ManageSession.FormName = Convert.ToString(rw["FormName"]);
                    ManageSession.CategoryName = Convert.ToString(rw["CategoryName"]);
                    //ManageSession.TransactionID = Convert.ToInt32(TransactionID);
                    ManageSession.IsEditable = hfIsEditable.Value;
                    ManageSession.IsScrabblePad = hfIsScrabblePad.Value;
                    //redirect to template form
                    Response.Redirect("Default.aspx", false);
                }
                else
                {

                    SqlTransaction objSqlTransaction;
                    SqlConnection con = new SqlConnection(DAL.SqlHelper.GetConnectionString());
                    con.Open();
                    objSqlTransaction = con.BeginTransaction();
                    Int64 uniqueId = 0;

                    try
                    {
                        //Add the transaction details
                        objForms.FormID = hfPrevFormID.Value == "0" ? Convert.ToInt32(FormIdHiddenField.Value) : Convert.ToInt32(hfPrevFormID.Value);
                        objForms.VersionID = hfPrevVersionID.Value == "0" ? Convert.ToInt32(VersionIDHiddenField.Value) : Convert.ToInt32(hfPrevVersionID.Value);
                        objForms.UserID = RetrieveUserID(userName);
                        if (PreserveTimeHiddenField.Value == "")
                        {
                            PreserveTimeHiddenField.Value = "0";
                        }

                        objForms.TimeTaken = Convert.ToInt32(PreserveTimeHiddenField.Value);
                        objForms.AddedBy = userName;
                        //if (Session["Transaction"] != null)
                        if (hfTransactionId.Value != "")
                        {
                            //objForms.TransID = Convert.ToInt32(Session["Transaction"]);
                            objForms.TransID = Convert.ToInt32(hfTransactionId.Value);
                        }

                        TransactionID = objForms.GenerateTransationID(objSqlTransaction, out uniqueId);

                        //Add fields details
                        int FormDetailsID = 0;
                        foreach (KeyValuePair<string, string> kvp in fieldDictionary)
                        {
                            objForms.FieldID = kvp.Key;
                            objForms.DataCapture = kvp.Value;
                            objForms.TransID = TransactionID;

                            FormDetailsID = objForms.InsertFormDetails(objSqlTransaction);
                        }

                        objForms.SendMailForLogger(TransactionID.ToString(), objSqlTransaction);
                        objSqlTransaction.Commit();

                        //Added for sending mail when template is selected 
                        //added by koshal on 06-Aug-2014
                        if (hfPrevFormID.Value != "0")
                        {
                            objForms.EVOSendMailForTemplate(TransactionID);
                        }

                        //remove the data
                        Session["FieldDictionary"] = null;
                        Session["TimeTaken"] = null;
                        //Session["Transaction"] = null;
                        hfTransactionId.Value = "";
                        TimerLabel.Text = "";
                        //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "ResetForm", "<script language='javascript'>document.forms[0].reset();</script>", false);
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "ResetForm", "<script language='javascript'>ClearForm();</script>", false);

                        //ResetForm();
                        if (uniqueId > 0)
                        {
                            Errorlabel.Text = " Record Tagged Successfully. LogID : <span id='copytext'>" + uniqueId.ToString() + "</span>.";
                        }
                        else
                        {
                            Errorlabel.Text = " Record Tagged Successfully. LogID : <span id='copytext'>Error while generatting LogID</span>.";
                        }
                        ScriptManager.RegisterStartupScript(this, this.GetType(), "CopyClipBord", "<script language='javascript'>copy();</script>", false); // Commented FOR UK. WILL BE ACTIVE FOR IRL-- COMMENTED ON 28/07/2011

                        // System.Windows.Forms.Clipboard.SetText(TransactionID.ToString());                    
                        SalesCountLabel.Text = Convert.ToString(Convert.ToInt32(SalesCountLabel.Text) + 1);

                        Session["Msg"] = Errorlabel.Text;

                        ManageSession.FormID = hfPrevFormID.Value == "0" ? Convert.ToInt32(FormIdHiddenField.Value) : Convert.ToInt32(hfPrevFormID.Value);
                        ManageSession.VersionID = hfPrevFormID.Value == "0" ? Convert.ToInt32(VersionIDHiddenField.Value) : Convert.ToInt32(hfPrevVersionID.Value);
                        ManageSession.XmlFileName = hfPrevFormID.Value == "0" ? xmlFileNameHiddenField.Value : hfPrevXmlFileName.Value;
                        ManageSession.FormName = hfPrevFormID.Value == "0" ? frmNmeHiddenField.Value : hfPrevFormName.Value;
                        ManageSession.CategoryName = hfPrevFormID.Value == "0" ? CatNameHiddenField.Value : hfPrevCategoryName.Value;
                        ManageSession.IsEditable = hfIsEditable.Value;
                        ManageSession.IsScrabblePad = hfIsScrabblePad.Value;
                        if (hfTransactionId.Value != "")
                        {
                            ManageSession.TransactionID = Convert.ToInt32(hfTransactionId.Value);
                        }
                        //redirect to parent form
                        Response.Redirect("Default.aspx", false);

                        ////Restore the parent form details for redirecting from template form
                        //ManageSession.FormID = Convert.ToInt32(FormIdHiddenField.Value);
                        //ManageSession.VersionID = Convert.ToInt32(VersionIDHiddenField.Value);
                        //ManageSession.XmlFileName = xmlFileNameHiddenField.Value;
                        //ManageSession.FormName = frmNmeHiddenField.Value;
                        //ManageSession.CategoryName = CatNameHiddenField.Value;
                        //ManageSession.TransactionID = 0;
                        ////redirect to parent form
                        //Response.Redirect("Default.aspx", false);
                    }
                    catch (Exception ex)
                    {
                        objSqlTransaction.Rollback();
                        Errorlabel.Text = "Something went wrong.";
                        //Errorlabel.Text = ex.Message.ToString();
                    }
                    finally
                    {
                        if (CatNameHiddenField.Value == "Call Logger" && Errorlabel.Text != "Please select values.")
                        {
                            //ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "DisableDiv", "<script language='javascript'>TransparentPage();</script>", false);
                            ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "ShowTimer", "<script language='javascript'>continueTimer();</script>", false);
                        }
                    }
                }

            }

        }
        catch (Exception ex)
        {
            Errorlabel.Text = ex.Message.ToString();
        }
    }


    /// <summary>
    /// Returns value of the contorls on page.
    /// </summary>
    /// <returns></returns>
    public string ReturnValue(string ctrlName)
    {
        Errorlabel.Text = "";

        ContentPlaceHolder ControlHldr = (ContentPlaceHolder)this.Page.Master.FindControl("ContentPlaceHolder1");
        Control ctrl;

        System.Text.StringBuilder sb;
        sb = new System.Text.StringBuilder();
        string value = "";

        char[] splitter = { ',' };
        string[] DataText = new string[2];

        try
        {
            ctrl = ControlHldr.FindControl(ctrlName);

            if (ctrl != null)
            {
                value = Request["ctl00$ContentPlaceHolder1$" + ctrlName];
            }
            else
            {
                Errorlabel.Text = "Control " + ctrlName + " not found.";
                return Errorlabel.Text;
            }

            if (ctrl is TextBox)
            {
                value = Request["ctl00$ContentPlaceHolder1$" + ctrlName];
            }
            else if (ctrl is RadioButtonList)
            {
                // the selected item might be null
                if (((RadioButtonList)ctrl).SelectedItem != null)
                {
                    value = ((RadioButtonList)ctrl).SelectedItem.Text;
                }
            }
            else if (ctrl is DropDownList)
            {
                value = Request["ctl00$ContentPlaceHolder1$" + ctrlName];
                if (value != "--Select--" && value != null && value != "0")
                {
                    DataText = value.Split(splitter);
                    //value = DataText[1];
                    if (ctrlName.StartsWith("cc") == false)
                    {

                        value = DataText[1];
                    }
                    else
                    {

                        value = DataText[1] + " [" + DataText[0] + "]";
                    }
                    if (DataText.Length >= 4 && int.Parse(DataText[3]) > 0)
                        templateFormID = int.Parse(DataText[3]);
                }
                else
                {
                    value = "Not Selected.";
                }
            }
            else if (ctrl is CheckBoxList)
            {
                if (((CheckBoxList)ctrl).SelectedItem != null)
                {
                    for (int iCount = 0; iCount < ((CheckBoxList)ctrl).Items.Count; iCount++)
                    {
                        if (((CheckBoxList)ctrl).Items[iCount].Selected == true)
                        {
                            value += ((CheckBoxList)ctrl).Items[iCount].Text + ",";
                        }
                    }
                    value = value.Substring(0, value.Length - 1);
                }
            }
            else if (ctrl is ListBox)
            {
                value = Request["ctl00$ContentPlaceHolder1$" + ctrlName];
                if (value != "--Select--" && value != null)
                {
                    DataText = value.Split(splitter);
                    value = DataText[1];

                    if (DataText.Length >= 4 && int.Parse(DataText[3]) > 0)
                        templateFormID = int.Parse(DataText[3]);

                }
                else
                {
                    value = "Not Selected.";
                }
            }
            else if (ctrl is Label)
            {
                value = ((Label)ctrl).Text;
            }
            else if (ctrl is Button)
            {
                value = ((Button)ctrl).Text;
            }
            else
            {
                value = ctrlName + " Not Found.";
            }
        }
        catch (Exception ex)
        {
            //Errorlabel.Text = "ReturnValue : " + ex.Message;
            //throw ex;
        }
        return value;
    }

    /// <summary>
    /// Code to reset from after submitting.
    /// </summary>
    private void ResetForm()
    {
        try
        {
            LoadXMLFile();
            string ControlName = "";

            XmlNodeList controls = xmldoc.SelectNodes("FORMS");

            for (int elementCnt = 0; elementCnt < controls.Count; elementCnt++)
            {
                XmlNode propertyNode = (XmlNode)controls[elementCnt];

                for (int propCount = 0; propCount < propertyNode.ChildNodes.Count; propCount++)
                {
                    XmlNode property = (XmlNode)propertyNode.ChildNodes[propCount];
                    ControlName = property["FieldID"].InnerText.Trim();
                    ClearForm(ControlName);
                }
            }
        }
        catch (Exception ex)
        {
            //Errorlabel.Text = "Reset Value : " + ex.Message;
            throw ex;
        }
    }

    public void ClearForm(string ctrlName)
    {
        ContentPlaceHolder ControlHldr = (ContentPlaceHolder)this.Page.Master.FindControl("ContentPlaceHolder1");
        Control ctrl;

        try
        {
            ctrl = ControlHldr.FindControl(ctrlName);

            if (ctrl == null)
            {
                Errorlabel.Text = "Control " + ctrlName + " not found.";
                return;
            }

            if (ctrl is TextBox)
            {
                ((TextBox)ctrl).Text = "";
            }
            else if (ctrl is RadioButtonList)
            {
                ((RadioButtonList)ctrl).SelectedIndex = 0;
            }
            else if (ctrl is DropDownList)
            {
                ((DropDownList)ctrl).SelectedIndex = 0;
            }
            else if (ctrl is CheckBoxList)
            {
                ((CheckBoxList)ctrl).SelectedIndex = -1;
            }
            else if (ctrl is ListBox)
            {
                ((ListBox)ctrl).SelectedIndex = 0;
            }
            else if (ctrl is Label)
            {
                //Code.
            }
            else if (ctrl is Button)
            {
                //Code.
            }
            else
            {
                Errorlabel.Text = "Not a Control.";
            }
        }
        catch (Exception ex)
        {
            //Errorlabel.Text = "clear Form : " + ex.Message;
            throw ex;
        }
    }


    /// <summary>
    /// Generate Array for dependent controls.
    /// </summary>
    /// <param name="RefObj"></param>
    /// <param name="ctrlType"></param>
    private void GetPrevRefData(string RefObj, string ctrlType)
    {
        string PrevCtrl = "";
        string FName = "";
        string IsManageable = "";
        bool isSuccess = false;
        string DependentId = "";
        string LabelText = "";
        string FieldID = "";

        if (!TempHoldDrpNames.ToUpper().Contains(RefObj.ToUpper()))
        {
            TempHoldDrpNames += RefObj + ",";

            try
            {
                LoadXMLFile();
                XmlNodeList rootNodeList = xmldoc.SelectNodes("FORMS/" + ctrlType);
                DropDownList ddlCtrl = new DropDownList();
                ListBox lbCtrl = new ListBox();
                RadioButtonList rdCtrl = new RadioButtonList();
                CheckBoxList ckCtrl = new CheckBoxList();

                for (int i = 0; i < rootNodeList.Count; i++)
                {
                    XmlNode dropDownNode = (XmlNode)rootNodeList[i];

                    int countElements = 0;
                    PrevCtrl = "";
                    FName = "";
                    IsManageable = "";
                    isSuccess = false;
                    LabelText = "";
                    XmlNode xmlNode = dropDownNode.SelectSingleNode("FieldID");
                    if (xmlNode != null)
                    {
                        FieldID = xmlNode.InnerXml;
                    }

                    for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                    {
                        if (dropDownNode.ChildNodes[y].Name == "label")
                        {
                            LabelText = dropDownNode.ChildNodes[y].FirstChild.Value;
                        }
                        if (dropDownNode.ChildNodes[y].Name == "IsManageable")
                        {
                            IsManageable = dropDownNode.ChildNodes[y].InnerText.Trim();
                            countElements = countElements + 1;
                        }
                        if (dropDownNode.ChildNodes[y].Name == "FieldID")
                        {
                            FName = dropDownNode.ChildNodes[y].InnerText.Trim();
                            countElements = countElements + 1;
                        }
                        if (dropDownNode.ChildNodes[y].Name == "PrevRef")
                        {
                            PrevCtrl = dropDownNode.ChildNodes[y].InnerText.Trim();
                            countElements = countElements + 1;
                        }
                        if (dropDownNode.ChildNodes[y].Name == "DependentID")
                        {
                            DependentId = dropDownNode.ChildNodes[y].InnerText.Trim();
                            countElements = countElements + 1;
                        }

                        if ((IsManageable == "True") && (FName == RefObj))  //&& (PrevCtrl != "")
                        {
                            if (dropDownNode.ChildNodes[y].Name == "LISTITEMS")
                            {
                                ContentPlaceHolder ControlHldr = (ContentPlaceHolder)this.Page.Master.FindControl("ContentPlaceHolder1");
                                Control ctrl;
                                ctrl = ControlHldr.FindControl(RefObj);

                                if (ctrlType == "DropDownList")
                                {
                                    ddlCtrl = (DropDownList)ctrl;
                                    ddlCtrl.Items.Insert(0, "--Select--");
                                    ddlCtrl.Attributes.Add("Parentid", PrevCtrl);
                                }
                                else if (ctrlType == "ListBox")
                                {
                                    lbCtrl = (ListBox)ctrl;
                                    lbCtrl.Attributes.Add("Parentid", PrevCtrl);
                                }

                                XmlNodeList listItems = dropDownNode.ChildNodes[y].ChildNodes;

                                bool isUpdated = false;
                                XmlNodeList dataScript = xmldoc.SelectNodes("FORMS/DataScript");
                                int dsCount = dataScript.Count;
                                for (int iScriptNodeCount = 0; iScriptNodeCount < dataScript.Count; iScriptNodeCount++)
                                {
                                    XmlNode scriptNode = (XmlNode)dataScript[iScriptNodeCount];
                                    if (scriptNode.ChildNodes[iScriptNodeCount].Name == "IsUpdated")
                                    {
                                        isUpdated = Convert.ToBoolean(scriptNode.ChildNodes[iScriptNodeCount].InnerText.Trim());
                                    }
                                }

                                if (dsCount > 0 && isUpdated == true)
                                {
                                    if (isScriptRetrieved == false)
                                    {
                                        for (int iScriptNodeCount = 0; iScriptNodeCount < dataScript.Count; iScriptNodeCount++)
                                        {
                                            XmlNode scriptNode = (XmlNode)dataScript[iScriptNodeCount];
                                            if (scriptNode.LastChild.Name == "Array")
                                            {
                                                BasicArrayText = scriptNode.LastChild.InnerText.Trim();
                                                isScriptRetrieved = true;
                                            }
                                        }
                                    }

                                    //Create a DataTable
                                    DataTable DT = new DataTable();
                                    //Add columns
                                    DT.Columns.Add("Text", System.Type.GetType("System.String"));
                                    DT.Columns.Add("Value", System.Type.GetType("System.String"));
                                    if (PrevCtrl == "")
                                    {
                                        for (int l = 0; l < listItems.Count; l++)
                                        {
                                            string dependentOn = listItems.Item(l).Attributes["DependentOn"].Value;

                                            string ListItemVal = "";
                                            string ListItemText = "";
                                            string TemplateID = "0";

                                            ListItemText = listItems.Item(l).InnerText;
                                            ListItemVal = listItems.Item(l).Attributes["Id"].Value;



                                            if (listItems.Item(l).Attributes["Template"] != null && listItems.Item(l).Attributes["Template"].Value != "")
                                                TemplateID = listItems.Item(l).Attributes["Template"].Value;

                                            //ListItem lst = new ListItem();
                                            //lst.Text = ListItemText;
                                            //lst.Value = ListItemVal + "," + ListItemText + "," + dependentOn + "," + TemplateID;

                                            ListItemCollection listBoxData = new ListItemCollection();
                                            // Add items to the collection.
                                            listBoxData.Add(new ListItem(ListItemText, ListItemVal + "," + ListItemText + "," + dependentOn + "," + TemplateID + "," + PrevCtrl));

                                            //Loop through ListItemCollection
                                            foreach (ListItem item in listBoxData)
                                            {
                                                DataRow dr = DT.NewRow();
                                                dr["Text"] = item.Text;
                                                dr["Value"] = item.Value;
                                                DT.Rows.Add(dr);
                                            }
                                            var dv = DT.DefaultView;
                                            dv.Sort = "Text";

                                            DT = dv.ToTable();

                                            if (ctrlType == "DropDownList")
                                            {
                                                //ddlCtrl.Items.Add(lst);
                                                ddlCtrl.DataSource = DT;
                                                ddlCtrl.DataTextField = "Text";
                                                ddlCtrl.DataValueField = "Value";
                                                ddlCtrl.DataBind();
                                                ddlCtrl.Items.Insert(0, "--Select--");
                                                ddlCtrl.Attributes.Add("Parentid", PrevCtrl);
                                            }
                                            else if (ctrlType == "ListBox")
                                            {
                                                // lbCtrl.Items.Add(lst);
                                                lbCtrl.DataSource = DT;
                                                lbCtrl.DataTextField = "Text";
                                                lbCtrl.DataValueField = "Value";
                                                lbCtrl.DataBind();
                                                lbCtrl.Attributes.Add("Parentid", PrevCtrl);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        string parentid = "";
                                        parentid = GetParentId(PrevCtrl, ctrlType);
                                        for (int l = 0; l < listItems.Count; l++)
                                        {
                                            string dependentOn = listItems.Item(l).Attributes["DependentOn"].Value;
                                            if (parentid == dependentOn)
                                            {
                                                string ListItemVal = "";
                                                string ListItemText = "";
                                                string TemplateID = "0";

                                                ListItemText = listItems.Item(l).InnerText;
                                                ListItemVal = listItems.Item(l).Attributes["Id"].Value;

                                                if (listItems.Item(l).Attributes["Template"] != null && listItems.Item(l).Attributes["Template"].Value != "")
                                                    TemplateID = listItems.Item(l).Attributes["Template"].Value;

                                                //ListItem lst = new ListItem();
                                                //lst.Text = ListItemText;
                                                //lst.Value = ListItemVal + "," + ListItemText + ',' + dependentOn + ',' + TemplateID; //+ ',' + optionTooltip;

                                                ListItemCollection listBoxData = new ListItemCollection();
                                                // Add items to the collection.
                                                listBoxData.Add(new ListItem(ListItemText, ListItemVal + "," + ListItemText + "," + dependentOn + "," + TemplateID + "," + PrevCtrl));

                                                //Loop through ListItemCollection
                                                foreach (ListItem item in listBoxData)
                                                {
                                                    DataRow dr = DT.NewRow();
                                                    dr["Text"] = item.Text;
                                                    dr["Value"] = item.Value;
                                                    DT.Rows.Add(dr);
                                                }
                                                var dv = DT.DefaultView;
                                                dv.Sort = "Text";

                                                DT = dv.ToTable();

                                                if (ctrlType == "DropDownList")
                                                {
                                                    //ddlCtrl.Items.Add(lst);
                                                    ddlCtrl.DataSource = DT;
                                                    ddlCtrl.DataTextField = "Text";
                                                    ddlCtrl.DataValueField = "Value";
                                                    ddlCtrl.DataBind();
                                                    ddlCtrl.Items.Insert(0, "--Select--");
                                                    ddlCtrl.Attributes.Add("Parentid", PrevCtrl);
                                                }
                                                else if (ctrlType == "ListBox")
                                                {
                                                    // lbCtrl.Items.Add(lst);
                                                    lbCtrl.DataSource = DT;
                                                    lbCtrl.DataTextField = "Text";
                                                    lbCtrl.DataValueField = "Value";
                                                    lbCtrl.DataBind();
                                                    lbCtrl.Attributes.Add("Parentid", PrevCtrl);
                                                }
                                            }
                                        }
                                    }
                                }
                                else
                                {
                                    // Creating an array. This will be used in javascript n registered via code
                                    BasicArrayText += "var Array" + (FName).ToString() + " = new Array( " + listItems.Count + " );\n";

                                    //Create a DataTable
                                    DataTable DT = new DataTable();
                                    //Add columns
                                    DT.Columns.Add("Text", System.Type.GetType("System.String"));
                                    DT.Columns.Add("Value", System.Type.GetType("System.String"));

                                    for (int l = 0; l < listItems.Count; l++)
                                    {
                                        string dependentOn = listItems.Item(l).Attributes["DependentOn"].Value;
                                        string optionTooltip = "";
                                        if (listItems.Item(l).Attributes["OptionTooltip"] != null)
                                        {
                                            optionTooltip = listItems.Item(l).Attributes["OptionTooltip"].Value;
                                        }
                                        string ListItemVal = "";
                                        string ListItemText = "";
                                        string TemplateID = "0";

                                        ListItemText = listItems.Item(l).InnerText;
                                        ListItemVal = listItems.Item(l).Attributes["Id"].Value;

                                        if (listItems.Item(l).Attributes["Template"] != null && listItems.Item(l).Attributes["Template"].Value != "")
                                            TemplateID = listItems.Item(l).Attributes["Template"].Value;

                                        // if ((listItems.Item(l).Attributes.Item(1).InnerText == "") || (listItems.Item(l).Attributes.Item(1).InnerText == "0"))
                                        if ((listItems.Item(l).Attributes["DependentOn"].Value != "") || (listItems.Item(l).Attributes["DependentOn"].Value == "0"))
                                        {
                                            dependentOn = listItems.Item(l).Attributes["DependentOn"].Value;

                                            if ((dependentOn == "") || (dependentOn == null))
                                            {
                                                dependentOn = "";
                                            }
                                            BasicArrayText += "if (Array" + (FName).ToString() + "[" + dependentOn + "] ==null) "
                                                         + "Array" + (FName).ToString() + "[" + dependentOn + "] = new Array();\n";



                                            BasicArrayText += "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "]= new Array('" + ListItemText + "');\n";



                                            string wrapNote = "";
                                            if ((listItems.Item(l).Attributes["WrapNote"] != null))
                                            {
                                                if ((listItems.Item(l).Attributes["WrapNote"].Value.Trim() != ""))
                                                {
                                                    wrapNote = listItems.Item(l).Attributes["WrapNote"].Value.Trim();
                                                }
                                            }

                                            BasicArrayText += "if (Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].WN ==null) "
                                                     + "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].WN = '" + wrapNote + "';\n";

                                            BasicArrayText += "if (Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].OT ==null) "
                                                     + "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].OT = '" + optionTooltip + "';\n";

                                            // Added T for dependent template id (Added by Koshal 13-feb-2013)
                                            BasicArrayText += "if (Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].T ==null) "
                                                     + "Array" + (FName).ToString() + "[" + dependentOn + "][" + ListItemVal + "].T = '" + TemplateID + "';\n";



                                            //Response.Write(" array creating..." + BasicArrayText);
                                            //Response.End();
                                        }

                                        if (PrevCtrl == "")
                                        {
                                            //ListItem lst = new ListItem();
                                            //lst.Text = ListItemText;
                                            //lst.Value = ListItemVal + "," + ListItemText + ',' + dependentOn + ',' + TemplateID; //+ ',' + optionTooltip;


                                            // Create a new ListItemCollection.
                                            ListItemCollection listBoxData = new ListItemCollection();

                                            // Add items to the collection.
                                            listBoxData.Add(new ListItem(ListItemText, ListItemVal + "," + ListItemText + "," + dependentOn + "," + TemplateID + "," + PrevCtrl));

                                            //Loop through ListItemCollection
                                            foreach (ListItem item in listBoxData)
                                            {
                                                DataRow dr = DT.NewRow();
                                                dr["Text"] = item.Text;
                                                dr["Value"] = item.Value;
                                                DT.Rows.Add(dr);
                                            }
                                            var dv = DT.DefaultView;
                                            dv.Sort = "Text";

                                            DT = dv.ToTable();

                                            if (ctrlType == "DropDownList")
                                            {
                                                ddlCtrl.DataSource = DT;
                                                ddlCtrl.DataTextField = "Text";
                                                ddlCtrl.DataValueField = "Value";
                                                ddlCtrl.DataBind();
                                                ddlCtrl.Items.Insert(0, "--Select--");
                                                ddlCtrl.Attributes.Add("Parentid", PrevCtrl);
                                            }
                                            else if (ctrlType == "ListBox")
                                            {
                                                //lbCtrl.Items.Add(lst);
                                                lbCtrl.DataSource = DT;
                                                lbCtrl.DataTextField = "Text";
                                                lbCtrl.DataValueField = "Value";
                                                lbCtrl.DataBind();
                                                lbCtrl.Attributes.Add("Parentid", PrevCtrl);
                                            }
                                        }
                                        else
                                        {
                                            string parentid = "";
                                            parentid = GetParentId(PrevCtrl, ctrlType);
                                            if (parentid == dependentOn)
                                            {
                                                //ListItem lst = new ListItem();
                                                //lst.Text = ListItemText;
                                                //lst.Value = ListItemVal + "," + ListItemText + ',' + dependentOn + ',' + TemplateID; //+ ',' + optionTooltip;
                                                // Create a new ListItemCollection.
                                                ListItemCollection listBoxData = new ListItemCollection();

                                                // Add items to the collection.
                                                listBoxData.Add(new ListItem(ListItemText, ListItemVal + "," + ListItemText + "," + dependentOn + "," + TemplateID + "," + PrevCtrl));

                                                //Loop through ListItemCollection
                                                foreach (ListItem item in listBoxData)
                                                {
                                                    DataRow dr = DT.NewRow();
                                                    dr["Text"] = item.Text;
                                                    dr["Value"] = item.Value;
                                                    DT.Rows.Add(dr);
                                                }
                                                var dv = DT.DefaultView;
                                                dv.Sort = "Text";

                                                DT = dv.ToTable();

                                                if (ctrlType == "DropDownList")
                                                {
                                                    //ddlCtrl.Items.Add(lst);
                                                    ddlCtrl.DataSource = DT;
                                                    ddlCtrl.DataTextField = "Text";
                                                    ddlCtrl.DataValueField = "Value";
                                                    ddlCtrl.DataBind();
                                                    ddlCtrl.Items.Insert(0, "--Select--");
                                                    ddlCtrl.Attributes.Add("Parentid", PrevCtrl);
                                                }
                                                else if (ctrlType == "ListBox")
                                                {
                                                    //lbCtrl.Items.Add(lst);
                                                    lbCtrl.DataSource = DT;
                                                    lbCtrl.DataTextField = "Text";
                                                    lbCtrl.DataValueField = "Value";
                                                    lbCtrl.DataBind();
                                                    lbCtrl.Attributes.Add("Parentid", PrevCtrl);
                                                }
                                            }
                                        }

                                    }

                                    //RestoreData();
                                }



                                //Response.Write(CallTypeArrayText);
                                cnt = cnt + 1;
                                if (DependentId != "")
                                {
                                    if (ctrlType == "DropDownList")
                                    {
                                        //ddlCtrl.Attributes.Add("onchange", "Populate('" + ddlCtrl.ID + "', '" + DependentId + "', Array" + DependentId + ",'" + ctrlType + "','" + ddlCtrl.ID + "');ShowToolTip(this,Array" + FieldID + ");GetShowHideControls(1);ShowTemplatePopup(this);");
                                        int IsExists = 0;
                                        Forms objform = new Forms();
                                        IsExists = objform.EVOControlExistsForHidden(Convert.ToInt16(FormIdHiddenField.Value.ToString()), Convert.ToInt16(VersionIDHiddenField.Value.ToString()), ddlCtrl.ID);
                                        if (IsExists == 0)
                                        {
                                            ddlCtrl.Attributes.Add("onchange", "Populate('" + ddlCtrl.ID + "', '" + DependentId + "', Array" + DependentId + ",'" + ctrlType + "','" + ddlCtrl.ID + "');ShowToolTip(this,Array" + FieldID + ");ShowTemplatePopup(this);");
                                        }
                                        else
                                        {
                                            ddlCtrl.Attributes.Add("onchange", "Populate('" + ddlCtrl.ID + "', '" + DependentId + "', Array" + DependentId + ",'" + ctrlType + "','" + ddlCtrl.ID + "');ShowToolTip(this,Array" + FieldID + ");GetShowHideControls(1);ShowTemplatePopup(this);");
                                        }
                                        ddlCtrl.Attributes.Add("onclick", "Populate('" + ddlCtrl.ID + "', '" + DependentId + "', Array" + DependentId + ",'" + ctrlType + "','" + ddlCtrl.ID + "');ShowToolTip(this,Array" + FieldID + ");");
                                        ddlCtrl.Attributes.Add("onmouseout", "hidpop();");
                                    }
                                    else if (ctrlType == "ListBox")
                                    {
                                        //lbCtrl.Attributes.Add("onchange", "Populate('" + lbCtrl.ID + "', '" + DependentId + "', Array" + DependentId + ",'" + ctrlType + "','" + ddlCtrl.ID + "');ShowToolTip(this,Array" + FieldID + ");GetShowHideControls(1);ShowTemplatePopup(this);");
                                        int IsExists = 0;
                                        Forms objform = new Forms();
                                        IsExists = objform.EVOControlExistsForHidden(Convert.ToInt16(FormIdHiddenField.Value.ToString()), Convert.ToInt16(VersionIDHiddenField.Value.ToString()), lbCtrl.ID);
                                        if (IsExists == 0)
                                        {
                                            lbCtrl.Attributes.Add("onchange", "Populate('" + lbCtrl.ID + "', '" + DependentId + "', Array" + DependentId + ",'" + ctrlType + "','" + ddlCtrl.ID + "');ShowToolTip(this,Array" + FieldID + ");ShowTemplatePopup(this);");
                                        }
                                        else
                                        {
                                            lbCtrl.Attributes.Add("onchange", "Populate('" + lbCtrl.ID + "', '" + DependentId + "', Array" + DependentId + ",'" + ctrlType + "','" + ddlCtrl.ID + "');ShowToolTip(this,Array" + FieldID + ");GetShowHideControls(1);ShowTemplatePopup(this);");
                                        }
                                        lbCtrl.Attributes.Add("onclick", "Populate('" + lbCtrl.ID + "', '" + DependentId + "', Array" + DependentId + ",'" + ctrlType + "','" + ddlCtrl.ID + "');ShowToolTip(this,Array" + FieldID + ");");
                                        lbCtrl.Attributes.Add("onmouseout", "hidpop();");
                                    }
                                    //else if (ctrlType == "RadioButtonList")
                                    //{
                                    //    rdCtrl.Attributes.Add("oncheck", "GetShowHideControls(1);");
                                    //}
                                    //else if (ctrlType == "CheckBoxList")
                                    //{
                                    //    ckCtrl.Attributes.Add("oncheck", "GetShowHideControls(1);");
                                    //}
                                }
                                else
                                {
                                    if (ctrlType == "DropDownList")
                                    {
                                        //ddlCtrl.Attributes.Add("onchange", "ShowToolTip(this,Array" + FieldID + ");GetShowHideControls(1);ShowTemplatePopup(this);");
                                        int IsExists = 0;
                                        Forms objform = new Forms();
                                        IsExists = objform.EVOControlExistsForHidden(Convert.ToInt16(FormIdHiddenField.Value.ToString()), Convert.ToInt16(VersionIDHiddenField.Value.ToString()), ddlCtrl.ID);
                                        if (IsExists == 0)
                                        {
                                            ddlCtrl.Attributes.Add("onchange", "ShowToolTip(this,Array" + FieldID + ");ShowTemplatePopup(this);");
                                        }
                                        else
                                        {
                                            ddlCtrl.Attributes.Add("onchange", "ShowToolTip(this,Array" + FieldID + ");GetShowHideControls(1);ShowTemplatePopup(this);");
                                        }

                                        ddlCtrl.Attributes.Add("onclick", "ShowToolTip(this,Array" + FieldID + ");");
                                        ddlCtrl.Attributes.Add("onmouseout", "hidpop();");
                                    }
                                    else if (ctrlType == "ListBox")
                                    {
                                        //lbCtrl.Attributes.Add("onchange", "ShowToolTip(this,Array" + FieldID + ");GetShowHideControls(1);ShowTemplatePopup(this);");
                                        int IsExists = 0;
                                        Forms objform = new Forms();
                                        IsExists = objform.EVOControlExistsForHidden(Convert.ToInt16(FormIdHiddenField.Value.ToString()), Convert.ToInt16(VersionIDHiddenField.Value.ToString()), lbCtrl.ID);
                                        if (IsExists == 0)
                                        {
                                            lbCtrl.Attributes.Add("onchange", "ShowToolTip(this,Array" + FieldID + ");ShowTemplatePopup(this);");
                                        }
                                        else
                                        {
                                            lbCtrl.Attributes.Add("onchange", "ShowToolTip(this,Array" + FieldID + ");GetShowHideControls(1);ShowTemplatePopup(this);");
                                        }
                                        lbCtrl.Attributes.Add("onclick", "ShowToolTip(this,Array" + FieldID + ");");
                                        lbCtrl.Attributes.Add("onmouseout", "hidpop();");
                                    }
                                    //else if (ctrlType == "RadioButtonList")
                                    //{
                                    //    rdCtrl.Attributes.Add("oncheck", "GetShowHideControls(1);");
                                    //}
                                    //else if (ctrlType == "CheckBoxList")
                                    //{
                                    //    ckCtrl.Attributes.Add("oncheck", "GetShowHideControls(1);");
                                    //}
                                }

                                if (PrevCtrl != "")
                                {
                                    GetPrevRefData(PrevCtrl, ctrlType);
                                }
                            }
                            else
                            {
                                isSuccess = false;
                            }
                        }
                        else
                        {
                            if (countElements == 4)
                            {
                                y = dropDownNode.ChildNodes.Count;
                            }
                        }
                        if (isSuccess)
                        {
                            y = dropDownNode.ChildNodes.Count;
                            i = rootNodeList.Count;
                        }

                    }
                }
            }
            catch (Exception ex)
            {
                Errorlabel.Text = ex.Message;
            }
        }
    }

    private void RestoreData()
    {
        #region restore data

        if (Session["IsBack"] != null && Session["IsBack"].ToString() == "true")
        {
            ContentPlaceHolder ControlHldr = (ContentPlaceHolder)this.Page.Master.FindControl("ContentPlaceHolder1");
            Session["IsBack"] = null;
            if (Session["fieldDictionary"] != null)
            {
                Dictionary<string, string> fieldDictionary;
                fieldDictionary = (Dictionary<string, string>)Session["fieldDictionary"];

                DataSet formsDataSet = new DataSet();
                if (Session["FormVersion"] != null)
                {
                    objForms.VersionID = Convert.ToInt16(Session["FormVersion"].ToString());
                    //Session["FormVersion"] = null; 
                }
                formsDataSet = objForms.GetFormsFieldsWithVersions(formsDataSet, false);

                if (formsDataSet.Tables[0].Rows.Count > 0)
                {
                    for (int iRowCount = 0; iRowCount < formsDataSet.Tables[0].Rows.Count; iRowCount++)
                    {
                        string ctrlName = formsDataSet.Tables[0].Rows[iRowCount]["FieldNameNew"].ToString() + formsDataSet.Tables[0].Rows[iRowCount]["FieldDisplayType"].ToString();
                        string fieldType = formsDataSet.Tables[0].Rows[iRowCount]["FieldDisplayType"].ToString();

                        if (fieldType == "DropDown")
                        {
                            DropDownList ddl = (DropDownList)ControlHldr.FindControl(ctrlName);
                            try
                            {
                                ddl.Items.FindByText(fieldDictionary[formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString()].Replace(" [", "[")).Selected = true;
                            }
                            catch (Exception ex)
                            { }
                        }
                        else if (fieldType == "ListBox")
                        {
                            ListBox lstb = (ListBox)ControlHldr.FindControl(ctrlName);
                            try
                            {
                                lstb.Items.FindByText(fieldDictionary[formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString()]).Selected = true;
                            }
                            catch (Exception ex)
                            { }
                        }
                        else if (fieldType == "TextBox")
                        {
                            try
                            {
                                TextBox tb = (TextBox)ControlHldr.FindControl(ctrlName);
                                if (fieldDictionary[formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString()] != "Not Selected.")
                                    tb.Text = fieldDictionary[formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString()];
                            }
                            catch (Exception ex)
                            { }

                        }
                        if (fieldType == "CheckBox")
                        {
                            CheckBoxList chk = (CheckBoxList)ControlHldr.FindControl(ctrlName);
                            try
                            {
                                string[] chklist = fieldDictionary[formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString()].Split(',');

                                for (int i = 0; i <= chklist.Length - 1; i++)
                                {
                                    for (int j = 0; j <= chk.Items.Count - 1; j++)
                                    {
                                        if (chk.Items[j].Text == chklist[i])
                                        {
                                            chk.Items[j].Selected = true;
                                            break;
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            { }
                        }
                        if (fieldType == "RadioButton")
                        {
                            RadioButtonList rbl = (RadioButtonList)ControlHldr.FindControl(ctrlName);
                            try
                            {

                                rbl.Items.FindByText(fieldDictionary[formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString()]).Selected = true;
                            }
                            catch (Exception ex)
                            { }
                        }

                    }

                }
            }
        }
        #endregion
    }

    /// <summary>
    /// Generate wrap notes for controls in specified in xml.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>

    protected void imgWrap_Click(object sender, ImageClickEventArgs e)
    {
        //-------START Added by Sagar CR Client Requirement For Wrap Note Hits   
        objForms.UserID = RetrieveUserID(userName);
        objForms.InsertFormWrapNoteUsers();
        hdnIsWrapLogged.Value = "1";
        return;
        //-------END Added by Sagar CR Client Requirement For Wrap Note Hits   
        try
        {
            LoadXMLFile();
            Errorlabel.Text = "";

            //TextBox Controls
            XmlNodeList rootTextBoxNodeList = xmldoc.SelectNodes("FORMS/TextBox");

            for (int iNodeTextBoxCount = 0; iNodeTextBoxCount < rootTextBoxNodeList.Count; iNodeTextBoxCount++)
            {
                XmlNode CtrlNode = (XmlNode)rootTextBoxNodeList[iNodeTextBoxCount];

                for (int iChildTextBoxNode = 0; iChildTextBoxNode < CtrlNode.ChildNodes.Count; iChildTextBoxNode++)
                {
                    CollectWrapNotes(CtrlNode, iChildTextBoxNode);
                }
            }

            //DropDown Controls
            XmlNodeList rootDropDownNodeList = xmldoc.SelectNodes("FORMS/DropDownList");

            for (int iNodeDropDownCount = 0; iNodeDropDownCount < rootDropDownNodeList.Count; iNodeDropDownCount++)
            {
                XmlNode CtrlNode = (XmlNode)rootDropDownNodeList[iNodeDropDownCount];

                for (int iChildDropDownNode = 0; iChildDropDownNode < CtrlNode.ChildNodes.Count; iChildDropDownNode++)
                {
                    CollectWrapNotes(CtrlNode, iChildDropDownNode);
                }
            }

            //RadioButton Controls
            XmlNodeList rootRadioButtonNodeList = xmldoc.SelectNodes("FORMS/RadioButtonList");

            for (int iNodeRadioButtonCount = 0; iNodeRadioButtonCount < rootRadioButtonNodeList.Count; iNodeRadioButtonCount++)
            {
                XmlNode CtrlNode = (XmlNode)rootRadioButtonNodeList[iNodeRadioButtonCount];

                for (int iChildRadioButtonNode = 0; iChildRadioButtonNode < CtrlNode.ChildNodes.Count; iChildRadioButtonNode++)
                {
                    CollectWrapNotes(CtrlNode, iChildRadioButtonNode);
                }
            }

            //CheckBoxList Controls
            XmlNodeList rootCheckBoxNodeList = xmldoc.SelectNodes("FORMS/CheckBoxList");

            for (int iNodeCheckBoxCount = 0; iNodeCheckBoxCount < rootCheckBoxNodeList.Count; iNodeCheckBoxCount++)
            {
                XmlNode CtrlNode = (XmlNode)rootCheckBoxNodeList[iNodeCheckBoxCount];

                for (int iChildCheckBoxNode = 0; iChildCheckBoxNode < CtrlNode.ChildNodes.Count; iChildCheckBoxNode++)
                {
                    CollectWrapNotes(CtrlNode, iChildCheckBoxNode);
                }
            }

            //ListBox Controls
            XmlNodeList rootListBoxNodeList = xmldoc.SelectNodes("FORMS/ListBox");

            for (int iNodeListBoxCount = 0; iNodeListBoxCount < rootListBoxNodeList.Count; iNodeListBoxCount++)
            {
                XmlNode CtrlNode = (XmlNode)rootListBoxNodeList[iNodeListBoxCount];

                for (int iChildListBoxNode = 0; iChildListBoxNode < CtrlNode.ChildNodes.Count; iChildListBoxNode++)
                {
                    CollectWrapNotes(CtrlNode, iChildListBoxNode);
                }
            }

            if (wrapNotes != "")
            {
                Errorlabel.Text = "<b><u>Wrap Notes --> </u></b> " + wrapNotes;
            }
            else
            {
                Errorlabel.Text = "No Control is qualified for generating Wrap Notes.";
            }

            //Disable Timer Button after Wrap button is clicked.
            ScriptManager.RegisterStartupScript(this, this.GetType(), "DisableTimerImage", "<script language='javascript'>DisableTimerImage();</script>", false);

        }
        catch (Exception ex)
        {
            Errorlabel.Text = ex.Message;
        }
        finally
        {
            if (CatNameHiddenField.Value == "Call Logger")
            {
                TimerLabel.Text = PreserveTimeHiddenField.Value;
            }
        }
    }

    /// <summary>
    /// Collect all wrap notes from xml and controls.
    /// </summary>
    public void CollectWrapNotes(XmlNode CtrlNode, int iCount)
    {
        string controlType = CtrlNode.ChildNodes[iCount].LocalName;
        if (controlType == "IsWrap")
        {
            checkWrap = CtrlNode.ChildNodes[iCount].InnerText;
            if (checkWrap == "True")
            {
                isWrap = true;
            }
        }
        if (controlType == "FieldID")
        {
            controlName = CtrlNode.ChildNodes[iCount].InnerText;
            controlValue = ReturnValue(controlName);
        }

        if (controlType == "PreWrap")
        {
            preWrap = CtrlNode.ChildNodes[iCount].InnerText;
        }

        if (controlType == "PostWrap")
        {
            postWrap = CtrlNode.ChildNodes[iCount].InnerText;
        }

        if (iCount == CtrlNode.ChildNodes.Count - 1)
        {
            if (isWrap == true)
            {
                wrapNotes += preWrap + " <b>" + controlValue + "</b> " + postWrap + ". ";
                isWrap = false;
            }
        }
    }

    /// <summary>
    /// Capture the selected values of the controls and insert it in database.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void imgSave_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            if (ValidateForm())
            {
                ProcessFieldResults();
            }
            else
            {
                ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "ShowTimer", "<script language='javascript'>continueTimer();</script>", false);

            }
        }
        catch (Exception ex)
        {
            Errorlabel.Text = ex.Message.ToString();
        }
    }


    protected void imgBack_Click(object sender, ImageClickEventArgs e)
    {

        //Session["FieldDictionary"] = fieldDictionary;

        if (Errorlabel.Text.Contains("Record Tagged Successfully"))
        {
            Session["TimeTaken"] = null;
            Session["IsBack"] = null;
        }
        else
        {
            Session["TimeTaken"] = PreserveTimeHiddenField.Value;
            Session["IsBack"] = "true";
            Session["fieldDictionary"] = ViewState["fieldDictionary"];
        }
        //set the parameters for opening the template form
        ManageSession.FormID = Convert.ToInt32(hfPrevFormID.Value);
        ManageSession.VersionID = Convert.ToInt32(hfPrevVersionID.Value);
        ManageSession.XmlFileName = Convert.ToString(hfPrevXmlFileName.Value);
        ManageSession.FormName = Convert.ToString(hfPrevFormName.Value);
        ManageSession.CategoryName = Convert.ToString(hfPrevCategoryName.Value);
        ManageSession.IsEditable = hfIsEditable.Value;
        ManageSession.IsScrabblePad = hfIsScrabblePad.Value;
        //redirect to parent form
        Response.Redirect("Default.aspx", false);

    }

    /// <summary>
    /// Get employee details to display.
    /// </summary>
    public void GetLoggedInDetails()
    {
        DataSet empDetailsDataSet = new DataSet();
        try
        {
            string frmid = "";

            if (FormIdHiddenField.Value != null)
            {
                frmid = FormIdHiddenField.Value;
            }

            empDetailsDataSet = GetEmployeeInfo(userName, frmid);

            if (empDetailsDataSet.Tables[0].Rows.Count > 0)
            {
                loginName = empDetailsDataSet.Tables["EmpDetails"].Rows[0]["EmpName"].ToString();
                lineManager = empDetailsDataSet.Tables["EmpDetails"].Rows[0]["Boss1Name"].ToString();
                SalesCountLabel.Text = empDetailsDataSet.Tables["SalesCount"].Rows[0]["TransID"].ToString();
            }
            else
            {
                Errorlabel.Text = "Employee dosen't exist.";
            }
        }
        catch (Exception ex)
        {
            //Errorlabel.Text = "Employee Eroor: " + ex.Message;
            throw ex;
        }
    }

    public string GetParentId(string ParentControl, string controltype)
    {
        string parentid = "";
        string parentvalue = "";
        if (Session["IsBack"] != null && Session["IsBack"].ToString() == "true")
        {
            ContentPlaceHolder ControlHldr = (ContentPlaceHolder)this.Page.Master.FindControl("ContentPlaceHolder1");

            if (Session["fieldDictionary"] != null)
            {
                Dictionary<string, string> fieldDictionary;
                fieldDictionary = (Dictionary<string, string>)Session["fieldDictionary"];

                DataSet formsDataSet = new DataSet();
                if (Session["FormVersion"] != null)
                {
                    objForms.VersionID = Convert.ToInt16(Session["FormVersion"].ToString());

                }
                formsDataSet = objForms.GetFormsFieldsWithVersions(formsDataSet, false);

                if (formsDataSet.Tables[0].Rows.Count > 0)
                {
                    for (int iRowCount = 0; iRowCount < formsDataSet.Tables[0].Rows.Count; iRowCount++)
                    {
                        string ctrlName = formsDataSet.Tables[0].Rows[iRowCount]["FieldNameNew"].ToString() + formsDataSet.Tables[0].Rows[iRowCount]["FieldDisplayType"].ToString();
                        string fieldType = formsDataSet.Tables[0].Rows[iRowCount]["FieldDisplayType"].ToString();

                        if (controltype == "DropDownList" && fieldType == "DropDown")
                        {
                            DropDownList ddl = (DropDownList)ControlHldr.FindControl(ctrlName);
                            try
                            {

                                if (ctrlName == ParentControl)
                                {
                                    parentvalue = ddl.Items.FindByText(fieldDictionary[formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString()]).ToString();
                                    break;
                                }
                            }
                            catch (Exception ex)
                            { }
                        }
                        else if (controltype == "ListBox" && fieldType == "ListBox")
                        {
                            ListBox lstb = (ListBox)ControlHldr.FindControl(ctrlName);
                            try
                            {

                                if (ctrlName == ParentControl)
                                {
                                    parentvalue = lstb.Items.FindByText(fieldDictionary[formsDataSet.Tables[0].Rows[iRowCount]["FieldID"].ToString()]).ToString();
                                    break;
                                }
                            }
                            catch (Exception ex)
                            { }
                        }


                    }
                    XmlNodeList rootNodeList = xmldoc.SelectNodes("FORMS/" + controltype);
                    DropDownList ddlCtrl = new DropDownList();
                    ListBox lbCtrl = new ListBox();
                    for (int i = 0; i < rootNodeList.Count; i++)
                    {
                        string ctrlname = "";
                        XmlNode dropDownNode = (XmlNode)rootNodeList[i];
                        for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                        {
                            if (dropDownNode.ChildNodes[y].Name == "FieldID")
                            {
                                ctrlname = dropDownNode.ChildNodes[y].InnerText;
                            }

                            if (dropDownNode.ChildNodes[y].Name == "LISTITEMS" && ctrlname == ParentControl)
                            {
                                XmlNodeList listItems = dropDownNode.ChildNodes[y].ChildNodes;
                                for (int l = 0; l < listItems.Count; l++)
                                {
                                    if (parentvalue == listItems.Item(l).InnerText)
                                    {
                                        parentid = listItems.Item(l).Attributes["Id"].Value;
                                        break;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return parentid;
    }


    //public string settopforcontrol(string result)
    //{
    //    string[] stringSeparators = new string[] { "<Table" };
    //    string[] words;

    //    words = result.Split(stringSeparators, StringSplitOptions.None);
    //    for (int i = 0; i <= words.Length - 1; i++)
    //    {
    //        if (words[i].ToString().ToLower().Contains("style"))
    //        {
    //            string[] wordtop = words[i].ToString().Split('>');
    //            for (int j = 0; j <= wordtop.Length - 1; j++)
    //            {
    //                if (wordtop[j].ToString().ToLower().Contains("style"))
    //                {
    //                    string[] strtest = wordtop[j].Split(';');
    //                    for (int k = 0; k <= strtest.Length - 1; k++)
    //                    {
    //                        if (strtest[k].ToString().ToLower().Contains("top"))
    //                        {
    //                            string top = "";
    //                            top = strtest[k].Replace(":", "").Replace("px", "").Replace("top", "");
    //                            string newtop = "";
    //                            newtop = (Convert.ToInt16(top) + 200).ToString();

    //                            //Response.Write(top);
    //                            result = result.Replace(strtest[k], strtest[k].Replace(top, newtop));
    //                        }
    //                    }

    //                    //break;
    //                }
    //            }
    //        }

    //    }
    //    return result;

    //}





    //[System.Web.Services.WebMethod]
    //public static string Getreport(string FormId,string VersionId)
    //{

    //    ManageSession.FormID = Convert.ToInt16(FormId);
    //    ManageSession.VersionID = Convert.ToInt16(VersionId);
    //    return "";

    //}



    public string GetGridData(string FieldId, string FieldValue)//, GridView grdtransdetails)
    {
        string result = "";
        try
        {
            if (grdTransDetails == null)
            {
                grdTransDetails = new GridView();
            }
            DataSet dscontrol = new DataSet();
            Forms objform = new Forms();
            string Userid = "";
            if (chkmypen.Checked == true)
            {
                Userid = RetrieveUserID(userName).ToString();
            }
            else
            {
                Userid = "0";
            }
            if (FieldId == "-1")
            {
                FieldId = "";
            }

            dscontrol = objform.GetTransIds(FieldId, FieldValue, Userid, FormIdHiddenField.Value, VersionIDHiddenField.Value);
            if (dscontrol.Tables.Count > 0)
            {
                if (dscontrol.Tables[0].Rows.Count > 0)
                {
                    DataSet dstransdetails = new DataSet();
                    if (dscontrol.Tables[0].Rows[0]["TransIds"].ToString() != "" || dscontrol.Tables[0].Rows[0]["TransIdsArchived"].ToString() != "")
                    {
                        Session["TransIds"] = dscontrol.Tables[0].Rows[0]["TransIds"].ToString() + "|" + dscontrol.Tables[0].Rows[0]["TransIdsArchived"].ToString();
                    }
                    else
                    {
                        Session["TransIds"] = "0";
                    }


                }
            }
        }
        catch (Exception ex)
        {

        }

        return result;
    }

    protected void btnsearch_Click(object sender, EventArgs e)
    {
        try
        {
            // ScriptManager.RegisterClientScriptBlock(this, this.GetType(), "ShowTimer", "<script language='javascript'>continueTimer();</script>", false);
            // ClientScript.RegisterStartupScript(this.GetType(), "script", "<script>javascript:ClosePopUp();</script>");


            string result = "";

            if (lblddlstatus.Text != "")
            {
                result = GetGridData(ddlcontrollist.SelectedItem.Value, lblddlstatus.Text);
            }
            else
            {
                result = GetGridData(ddlcontrollist.SelectedItem.Value, txtsearchvalue.Text);
            }
            Session["ddlstatus"] = lblddlstatus.Text;
            Session["IsBack"] = "true";
            //Session["Transaction"] = Transid;
            Session["TimeTaken"] = PreserveTimeHiddenField.Value;
            Session["Searchparam"] = ddlcontrollist.SelectedItem.Value;
            Session["Searchvalue"] = txtsearchvalue.Text;
            Session["MyTrans"] = chkmypen.Checked;
            //Session["Transaction"] = null;
            hfTransactionId.Value = "";
            ManageSession.FormID = Convert.ToInt32(FormIdHiddenField.Value);
            ManageSession.VersionID = Convert.ToInt32(VersionIDHiddenField.Value);
            ManageSession.XmlFileName = Convert.ToString(xmlFileNameHiddenField.Value);
            ManageSession.FormName = Convert.ToString(frmNmeHiddenField.Value);
            ManageSession.CategoryName = Convert.ToString(CatNameHiddenField.Value);
            ManageSession.IsEditable = hfIsEditable.Value;
            ManageSession.IsScrabblePad = hfIsScrabblePad.Value;
            Response.Redirect("Default.aspx", true);

            if (result != "")
            {
                lblerror.Text = result;
            }


        }
        catch (Exception ex)
        {

        }
    }

    protected void grdTransDetails_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Select")
        {

            char[] splitter = { '|' };
            string[] Id = e.CommandArgument.ToString().Split(splitter);
            string versionID = Id[1];
            string formid = Id[0];
            string Transid = Id[2];
            string RowId = Id[3];

            DataSet formsDataSet = new DataSet();
            formsDataSet = (DataSet)ViewState["objDataSet"];
            try
            {
                Dictionary<string, string> fieldDictionary;
                fieldDictionary = new Dictionary<string, string>();

                DataSet dscontrol = new DataSet();
                Forms objform = new Forms();

                dscontrol = objform.GetFieldDetailsForTrans(Transid);

                if (dscontrol.Tables.Count > 0)
                {
                    if (dscontrol.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i <= dscontrol.Tables[0].Rows.Count - 1; i++)
                        {
                            fieldDictionary.Add(dscontrol.Tables[0].Rows[i]["FieldId"].ToString(), dscontrol.Tables[0].Rows[i]["DataCapture"].ToString());
                        }
                    }
                }

                Session["FormVersion"] = versionID;
                Session["fieldDictionary"] = fieldDictionary;
                Session["IsBack"] = "true";
                //Session["Transaction"] = Transid;
                hfTransactionId.Value = Transid;
                Session["TimeTaken"] = PreserveTimeHiddenField.Value;
                Session["TransIds"] = hfTransIds.Value;
                Session["PageIndex"] = hfPageIndex.Value;
                Session["RowId"] = RowId;
                Session["Searchparam"] = ddlcontrollist.SelectedItem.Value;
                //Session["Searchvalue"] = txtsearchvalue.Text;
                Session["MyTrans"] = chkmypen.Checked;
                Session["IsUpdate"] = true;

                if (lblddlstatus.Text != "")
                {
                    Session["Searchvalue"] = lblddlstatus.Text;
                    Session["ddlstatus"] = ddlsearchvalue.SelectedItem.Text;
                }
                else
                {
                    Session["Searchvalue"] = txtsearchvalue.Text;
                }
                Session["scrolltop"] = hfscrolltop.Value;
                ManageSession.FormID = Convert.ToInt32(FormIdHiddenField.Value);
                ManageSession.VersionID = Convert.ToInt32(VersionIDHiddenField.Value);
                ManageSession.XmlFileName = Convert.ToString(xmlFileNameHiddenField.Value);
                ManageSession.FormName = Convert.ToString(frmNmeHiddenField.Value);
                ManageSession.CategoryName = Convert.ToString(CatNameHiddenField.Value);
                ManageSession.IsEditable = hfIsEditable.Value;
                ManageSession.IsScrabblePad = hfIsScrabblePad.Value;
                ManageSession.TransactionID = Convert.ToInt32(hfTransactionId.Value);
                Response.Redirect("Default.aspx", true);

            }
            catch (Exception ex)
            {
                // ErrorLabel.Text = ex.Message;
            }
        }
    }

    //protected void btnadd_Click(object sender, EventArgs e)
    //{
    //    try
    //    {
    //        Session["IsBack"] = "true";
    //        Session["TimeTaken"] = PreserveTimeHiddenField.Value;
    //        Session["Transaction"] = null;
    //        ManageSession.FormID = Convert.ToInt32(FormIdHiddenField.Value);
    //        ManageSession.VersionID = Convert.ToInt32(VersionIDHiddenField.Value);
    //        ManageSession.XmlFileName = Convert.ToString(xmlFileNameHiddenField.Value);
    //        ManageSession.FormName = Convert.ToString(frmNmeHiddenField.Value);
    //        ManageSession.CategoryName = Convert.ToString(CatNameHiddenField.Value);
    //        ManageSession.IsEditable = hfIsEditable.Value;
    //        Response.Redirect("Default.aspx", true);
    //    }
    //    catch (Exception ex)
    //    { 

    //    }
    //}
    protected void btnreset_Click(object sender, EventArgs e)
    {
        try
        {
            Session["IsBack"] = "true";
            Session["TimeTaken"] = PreserveTimeHiddenField.Value;
            //Session["Transaction"] = null;
            Session["TransIds"] = null;
            Session["Searchparam"] = null;
            Session["Searchvalue"] = null;
            Session["MyTrans"] = null;
            Session["ddlstatus"] = null;
            hfTransactionId.Value = "";
            ManageSession.FormID = Convert.ToInt32(FormIdHiddenField.Value);
            ManageSession.VersionID = Convert.ToInt32(VersionIDHiddenField.Value);
            ManageSession.XmlFileName = Convert.ToString(xmlFileNameHiddenField.Value);
            ManageSession.FormName = Convert.ToString(frmNmeHiddenField.Value);
            ManageSession.CategoryName = Convert.ToString(CatNameHiddenField.Value);
            ManageSession.IsEditable = hfIsEditable.Value;
            ManageSession.IsScrabblePad = hfIsScrabblePad.Value;
            Response.Redirect("Default.aspx", true);
        }
        catch (Exception ex)
        {

        }
    }
    protected void grdTransDetails_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            Session["PageIndex"] = e.NewPageIndex;
            Session["IsBack"] = "true";
            //Session["Transaction"] = Transid;
            Session["TimeTaken"] = PreserveTimeHiddenField.Value;
            Session["Searchparam"] = ddlcontrollist.SelectedItem.Value;
            if (lblddlstatus.Text != "")
            {
                Session["Searchvalue"] = lblddlstatus.Text;
                Session["ddlstatus"] = ddlsearchvalue.SelectedItem.Text;
            }
            else
            {
                Session["Searchvalue"] = txtsearchvalue.Text;
            }
            Session["MyTrans"] = chkmypen.Checked;
            //Session["Transaction"] = null;
            hfTransactionId.Value = "";
            Session["TransIds"] = hfTransIds.Value;
            ManageSession.FormID = Convert.ToInt32(FormIdHiddenField.Value);
            ManageSession.VersionID = Convert.ToInt32(VersionIDHiddenField.Value);
            ManageSession.XmlFileName = Convert.ToString(xmlFileNameHiddenField.Value);
            ManageSession.FormName = Convert.ToString(frmNmeHiddenField.Value);
            ManageSession.CategoryName = Convert.ToString(CatNameHiddenField.Value);
            ManageSession.IsEditable = hfIsEditable.Value;
            ManageSession.IsScrabblePad = hfIsScrabblePad.Value;
            Response.Redirect("Default.aspx", true);
        }
        catch (Exception ex)
        {

        }
    }
    protected void grdTransDetails_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {
            e.Row.Cells[1].Visible = false;
            e.Row.Cells[2].Visible = false;
            e.Row.Cells[3].Visible = false;
        }

        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            e.Row.Cells[1].Visible = false;
            e.Row.Cells[2].Visible = false;
            e.Row.Cells[3].Visible = false;
            for (int i = 0; i <= e.Row.Cells.Count - 1; i++)
            {

                if (e.Row.Cells[i].Text.Length > 50)
                {
                    ViewState["Data" + i.ToString()] = e.Row.Cells[i].Text;
                    e.Row.Cells[i].Text = e.Row.Cells[i].Text.Substring(0, 50) + "…";
                    string tooltiptext = "";
                    int countdivided = 100;
                    int totaltooltiplen = ViewState["Data" + i.ToString()].ToString().Length / countdivided;
                    if (totaltooltiplen == 0)
                    {
                        tooltiptext = ViewState["Data" + i.ToString()].ToString();
                    }
                    else
                    {
                        for (int totallen = 0; totallen <= totaltooltiplen - 1; totallen++)
                        {
                            if (totallen == totaltooltiplen - 1)
                            {
                                if (tooltiptext == "")
                                {
                                    tooltiptext = ViewState["Data" + i.ToString()].ToString();
                                }
                                else
                                {
                                    tooltiptext = tooltiptext + " " + ViewState["Data" + i.ToString()].ToString();
                                }
                            }
                            else
                            {
                                if (tooltiptext == "")
                                {
                                    tooltiptext = ViewState["Data" + i.ToString()].ToString().Substring(0, countdivided);
                                }
                                else
                                {
                                    tooltiptext = tooltiptext + " " + ViewState["Data" + i.ToString()].ToString().Substring(0, countdivided);
                                }
                                ViewState["Data" + i.ToString()] = ViewState["Data" + i.ToString()].ToString().Remove(0, countdivided);
                            }
                        }
                    }
                    e.Row.Cells[i].ToolTip = tooltiptext; //ViewState["Data" + i.ToString()].ToString();
                    //e.Row.Cells[i].ToolTip.
                }
            }

            if (Session["RowId"] != null)
            {
                if (e.Row.RowIndex == Convert.ToInt16(Session["RowId"]))
                {

                    e.Row.Style.Value = "background-color: Red;color:white";
                    Session["RowId"] = null;
                }
            }
        }
    }



    [System.Web.Services.WebMethod]
    public static string GetControlType(string FieldId, string FormId, string VersionId)
    {
        string result = "";
        Forms objForms = new Forms();
        DataSet dscontrol = new DataSet();
        objForms.FieldID = FieldId;
        objForms.FormID = Convert.ToInt32(FormId);
        objForms.VersionID = Convert.ToInt32(VersionId);
        dscontrol = objForms.GetFormDetails(dscontrol);
        if (dscontrol.Tables.Count > 0)
        {
            if (dscontrol.Tables[0].Rows.Count > 0)
            {
                result = dscontrol.Tables[0].Rows[0]["FieldName"].ToString() + "," + dscontrol.Tables[0].Rows[0]["FieldDisplayType"].ToString() + "," + dscontrol.Tables[0].Rows[0]["XMLFileName"].ToString();
            }
        }
        return result;

    }


    [System.Web.Services.WebMethod]
    public static string[] FillControlList(string controlname, string controltype, string filepath)
    {
        string[] result = null;
        result = BindControlData(controlname, controltype, filepath);
        return result;

    }


    [System.Web.Services.WebMethod]
    public static string GetShowHideControlsMethod(string FieldNameValues, string FormId, string VersionId)
    {
        string result = "";
        Forms objForms = new Forms();
        DataSet dscontrol = new DataSet();
        dscontrol = objForms.GetShowHideControlsDS(FieldNameValues, FormId, VersionId);
        if (dscontrol.Tables.Count > 0)
        {
            if (dscontrol.Tables[0].Rows.Count > 0)
            {
                result = dscontrol.Tables[0].Rows[0]["ToHideAndShowControls"].ToString();
            }
        }
        return result;

    }



    public static string[] BindControlData(string controlname, string controltype, string filepath)
    {

        string[] arrcontrolvalue = null;
        try
        {
            XmlDocument doc;
            ReadNLoadFile(filepath, out doc);

            XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controltype);




            for (int i = 0; i < rootNodeList.Count; i++)
            {

                XmlNode dropDownNode = (XmlNode)rootNodeList[i];


                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if ((dropDownNode.ChildNodes[y].Name == "FieldID") && (dropDownNode.ChildNodes[y].InnerText == controlname))
                    {
                        for (int j = 0; j < dropDownNode.ChildNodes.Count; j++)
                        {

                            XmlNode ndListItems = dropDownNode.SelectSingleNode("LISTITEMS");

                            string ListItemText = "";


                            XmlNodeList listItems = ndListItems.ChildNodes;


                            arrcontrolvalue = new string[listItems.Count];

                            for (int l = 0; l < listItems.Count; l++)
                            {
                                ListItemText = listItems.Item(l).InnerText;

                                if (listItems.Item(l).Name == "LISTITEM")
                                {
                                    arrcontrolvalue[l] = ListItemText;

                                    //SelectedFieldsListBox.Items.Add(new ListItem(ListItemText, ListItemText));
                                }


                            }
                            break;
                        }
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }
        return arrcontrolvalue;
    }

    private static void ReadNLoadFile(string filepath, out XmlDocument doc)
    {
        string FileName = "";
        XDocument xmlDoc = new XDocument();
        FileName = HttpContext.Current.Request.MapPath(HttpContext.Current.Request.ApplicationPath) + "..\\XML\\" + filepath;
        //FileName = Server.MapPath("..\\XML\\" + filepath);
        doc = new XmlDocument();
        xmlDoc = XDocument.Load(FileName);
        doc.Load(FileName);

    }


    [System.Web.Services.WebMethod]
    public static string GetParentName(string controlname, string filepath)
    {
        string result = "";
        string controltype = "";
        if (controlname.Contains("DropDown"))
        {
            controltype = "DropDownList";
        }
        result = GetParentControlName(controlname, controltype, filepath);
        return result;

    }

    public static string GetParentControlName(string controlname, string controltype, string filepath)
    {

        string ParentControl = "";
        try
        {
            XmlDocument doc;
            ReadNLoadFile(filepath, out doc);

            XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controltype);

            int validation = 0;


            for (int i = 0; i < rootNodeList.Count; i++)
            {

                XmlNode dropDownNode = (XmlNode)rootNodeList[i];


                for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
                {
                    if ((dropDownNode.ChildNodes[y].Name == "FieldID") && (dropDownNode.ChildNodes[y].InnerText == controlname))
                    {
                        validation = 1;
                    }
                    if (validation == 1 && dropDownNode.ChildNodes[y].Name == "PrevRef")
                    {
                        ParentControl = dropDownNode.ChildNodes[y].InnerText;
                        break;
                    }
                }
            }
        }
        catch (Exception ex)
        {

        }
        return ParentControl;
    }

    //Logout Functionalily : Bappa
    protected void LogoutButton_Click(object sender, EventArgs e)
    {
        int AuthType = Convert.ToInt32(HttpContext.Current.Request.Cookies["EVO"]["AuthenticationType"]);
        Response.Cookies["EVO"].Expires = DateTime.Now.AddDays(-1);
        Session.Abandon();
        Response.Redirect("../LogOut.aspx");
    }
    //End
}

//left: 567px; top: -482px;