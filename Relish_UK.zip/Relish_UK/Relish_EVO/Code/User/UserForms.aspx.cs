using System;
using System.Data;
using System.Web.UI.WebControls;
using EVOLib;
using System.Collections.Generic;
using System.Web;

public partial class UserForms : EvoGeneral
{
    Forms objForms = new Forms();

    protected override void OnInit(EventArgs e)
    {
        frmNmeLabel.Text = "User Forms";
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindFormsAsPerUser();
        }
        Session["Transaction"] = null;
    }

    /// <summary>
    /// Get all forms names for the loggedIn user.
    /// </summary>
    public void BindFormsAsPerUser()
    {
        DataSet objDataSet = new DataSet();
        try
        {
            objForms.LoggedInUser = userName;
            objDataSet = objForms.GetFormsAsPerUser(objDataSet);

            if (objDataSet.Tables.Count > 0)
            {
                if (objDataSet.Tables[0].Rows.Count > 0)
                {
                    ViewState["objDataSet"] = objDataSet;

                    FormsForLoggedUserGridView.DataSource = objDataSet;
                    FormsForLoggedUserGridView.DataBind();
                }
                else
                {
                    ErrorLabel.Text = "forms are not been assigned for your skillset.";
                }
            }
            else
            {
                ErrorLabel.Text = "forms are not been assigned for your skillset.";
            }
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message;
        }
    }

    protected void FormsForLoggedUserGridView_RowCommand(object sender, GridViewCommandEventArgs e)
    {


        
        if (e.CommandName == "Select")
        {

            char[] splitter = { '|' };
            string[] Id = e.CommandArgument.ToString().Split(splitter);
            string versionID = Id[1];
            string formid = Id[0];
            DataSet formsDataSet = new DataSet();
            formsDataSet = (DataSet)ViewState["objDataSet"];
            try
            {
                DataRow[] formsDataRow = formsDataSet.Tables[0].Select("VersionID = " + versionID.ToString());
                if (formsDataRow.Length > 0)
                {
                    ManageSession.FormID = Convert.ToInt32(formsDataRow[0]["FormID"]);
                    ManageSession.VersionID = Convert.ToInt32(formsDataRow[0]["VersionID"]);
                    ManageSession.XmlFileName = Convert.ToString(formsDataRow[0]["XMLFileName"]);
                    ManageSession.FormName = Convert.ToString(formsDataRow[0]["FormName"]);
                    ManageSession.CategoryName = Convert.ToString(formsDataRow[0]["CategoryName"]);
                    ManageSession.IsEditable = Convert.ToString(formsDataRow[0]["IsEditable"]);
                    ManageSession.IsScrabblePad = Convert.ToString(formsDataRow[0]["IsScrabblePad"]);
                    Response.Redirect("Default.aspx", true);
                }
            }
            catch (Exception ex)
            {
                ErrorLabel.Text = ex.Message;
            }
        }
        
    }
    protected void FormsForLoggedUserGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        FormsForLoggedUserGridView.PageIndex = e.NewPageIndex;
        BindFormsAsPerUser();
    }


    protected void btnsearch_Click(object sender, EventArgs e)
    {
        //try
        //{
        //    DataSet dscontrol = new DataSet();
        //    Forms objform = new Forms();
        //    dscontrol = objform.GetTransIds(ddlcontrollist.SelectedItem.Value, txtsearchvalue.Text);
        //    if (dscontrol.Tables.Count > 0)
        //    {
        //        if (dscontrol.Tables[0].Rows.Count > 0)
        //        {
        //            DataSet dstransdetails = new DataSet();
        //            if (dscontrol.Tables[0].Rows[0]["TransIds"].ToString() != "")
        //            {
        //                dstransdetails = objform.GetTransDetails("0", "0", dscontrol.Tables[0].Rows[0]["TransIds"].ToString());
        //            }
        //            if (dstransdetails.Tables.Count > 0)
        //            {
        //                if (dstransdetails.Tables[0].Rows.Count > 0)
        //                {
        //                    grdTransDetails.DataSource = dstransdetails;
        //                    grdTransDetails.DataBind();
        //                }
        //                else
        //                {
        //                    grdTransDetails.DataSource = null;
        //                    grdTransDetails.DataBind();
        //                    lblerror.Text = "No record found";
        //                }
        //            }
        //            else
        //            {
        //                grdTransDetails.DataSource = null;
        //                grdTransDetails.DataBind();
        //                lblerror.Text = "No record found";
        //            }

        //        }
        //    }
        //}
        //catch (Exception ex)
        //{ 
        
        //}
    }
    protected void btnback_Click(object sender, EventArgs e)
    {
        tblmain.Style.Value = "display:block;width:100%";
        //dvsub.Style.Value = "display:none";
        //lblerror.Text = "";
    }
    protected void grdTransDetails_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Select")
        {

            char[] splitter = { '|' };
            string[] Id = e.CommandArgument.ToString().Split(splitter);
            string versionID = Id[1];
            string formid = Id[0];
            string Transid = Id[2];
            DataSet formsDataSet = new DataSet();
            formsDataSet = (DataSet)ViewState["objDataSet"];
            try
            {
                Dictionary<string, string> fieldDictionary;
                fieldDictionary = new Dictionary<string, string>();

                DataSet dscontrol = new DataSet();
                Forms objform = new Forms();

                dscontrol = objform.GetFieldDetailsForTrans(Transid);

                if (dscontrol.Tables.Count > 0)
                {
                    if (dscontrol.Tables[0].Rows.Count > 0)
                    {
                        for (int i = 0; i <= dscontrol.Tables[0].Rows.Count - 1; i++)
                        {
                            fieldDictionary.Add(dscontrol.Tables[0].Rows[i]["FieldId"].ToString(), dscontrol.Tables[0].Rows[i]["DataCapture"].ToString());
                        }
                    }
                }

                Session["fieldDictionary"] = fieldDictionary;
                Session["IsBack"] = "true";
                Session["Transaction"] = Transid;

                DataRow[] formsDataRow = formsDataSet.Tables[0].Select("VersionID = " + versionID.ToString());
                if (formsDataRow.Length > 0)
                {
                    ManageSession.FormID = Convert.ToInt32(formsDataRow[0]["FormID"]);
                    ManageSession.VersionID = Convert.ToInt32(formsDataRow[0]["VersionID"]);
                    ManageSession.XmlFileName = Convert.ToString(formsDataRow[0]["XMLFileName"]);
                    ManageSession.FormName = Convert.ToString(formsDataRow[0]["FormName"]);
                    ManageSession.CategoryName = Convert.ToString(formsDataRow[0]["CategoryName"]);

                    Response.Redirect("Default.aspx", true);
                }
            }
            catch (Exception ex)
            {
                ErrorLabel.Text = ex.Message;
            }
        }
    }
    protected void FormsForLoggedUserGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        //if (e.Row.RowType == DataControlRowType.DataRow)
        //{
        //    //Index have been changed from Cells[11] to Cells[12] because Preview is incorporated. Imran
        //    Label lblIsActive = (Label)e.Row.Cells[8].FindControl("lblIsEditable");
        //    if (lblIsActive.Text.ToLower() == "true")
        //    {
        //        LinkButton editButton = (LinkButton)e.Row.Cells[9].FindControl("UpdateLinkButton");
        //        editButton.Enabled = false;
        //    }
        //    else 
        //    {
        //        LinkButton editButton = (LinkButton)e.Row.Cells[9].FindControl("UpdateLinkButton");
        //        editButton.Visible = false;
        //    }
            
        //}
    }

    //Logout Functionalily : Bappa
    protected void LogoutButton_Click(object sender, EventArgs e)
    {
        int AuthType = Convert.ToInt32(HttpContext.Current.Request.Cookies["EVO"]["AuthenticationType"]);
        Response.Cookies["EVO"].Expires = DateTime.Now.AddDays(-1);
        Session.Abandon();
        Response.Redirect("../LogOut.aspx");
    }
    //End
}
