﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class UserAuthentication : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string CurrentUserName = System.Security.Principal.WindowsIdentity.GetCurrent().Name.ToString();
        CurrentUserName = CurrentUserName.ToUpper().Replace(ConfigurationSettings.AppSettings["DomainName"].ToString().ToUpper(), "");
        int AuthenticationType = 1;
        //DataSet dsAuthTypes = UserAuthDataStore.GetAuthenticationTypes();

        //if (dsAuthTypes != null)
        //{
        //    if (dsAuthTypes.Tables.Count > 0)
        //    {
        //        if (dsAuthTypes.Tables[0].Rows.Count > 0)
        //        {
        //            AuthenticationType = Convert.ToInt32(dsAuthTypes.Tables[0].Rows[0]["Id"]);
        //            if (AuthenticationType == 2) // CEAG
        //            {
        //                H3GS.Web.Security.PassportAuthentication.SignIn();
        //                CurrentUserName = H3GS.Web.Security.PassportIdentity.Current.Employee.LoginId;
        //                Response.Redirect("Admin/Default.aspx");
        //            }
        //        }
        //    }
        //}

        DataSet ds = UserAuthDataStore.AuthenticateUser(CurrentUserName);

        //bool IsValidUser = false;

        if (ds != null)
        {
            if (ds.Tables.Count > 0)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {

                    HttpCookie userCredentials = new HttpCookie("EVO");
                    userCredentials["AuthenticationType"] = AuthenticationType.ToString();
                    userCredentials["CurrentUserName"] = CurrentUserName;
                    userCredentials["userName"] = ds.Tables[0].Rows[0]["NTLogin"].ToString();
                    userCredentials["userType"] = ds.Tables[0].Rows[0]["RoleName"].ToString();
                    userCredentials["userEmailID"] = ds.Tables[0].Rows[0]["Email"].ToString();
                    userCredentials["userFullName"] = ds.Tables[0].Rows[0]["FirstName"].ToString() + " " + ds.Tables[0].Rows[0]["LastName"].ToString();
                    userCredentials["userDesignation"] = ds.Tables[0].Rows[0]["DesignationName"].ToString();
                    userCredentials["userEmployeeId"] = ds.Tables[0].Rows[0]["EmployeeID"].ToString();
                    //for departement name and id
                    userCredentials["userDeptID"] = ds.Tables[0].Rows[0]["DepartmentID"].ToString();
                    userCredentials["userDeptName"] = ds.Tables[0].Rows[0]["DepartmentName"].ToString();
                    //for CID - departement name and id
                    userCredentials["userCIDDeptID"] = ds.Tables[0].Rows[0]["DepartmentID"].ToString();
                    userCredentials["userCIDDeptName"] = ds.Tables[0].Rows[0]["DepartmentName"].ToString();
                    //Location
                    userCredentials["userLocation"] = ds.Tables[0].Rows[0]["Location"].ToString();
                    //Rep man
                    userCredentials["userBoss1ID"] = ds.Tables[0].Rows[0]["Boss1Id"].ToString();
                    userCredentials["userBoss1Name"] = ds.Tables[0].Rows[0]["Boss1Name"].ToString();
                    //Rev Man
                    userCredentials["userBoss2Id"] = ds.Tables[0].Rows[0]["Boss2Id"].ToString();
                    userCredentials["userBoss2Name"] = ds.Tables[0].Rows[0]["Boss2Name"].ToString();

                    Response.AppendCookie(userCredentials);

                    Response.Redirect("Admin/Default.aspx");
                    //IsValidUser = true;
                }
            }
        }

        //if (IsValidUser)
        //{
        //    Response.Redirect("Admin/Default.aspx");
        //}
        //else
        //{
        //    Response.Redirect("NotAuthorized.aspx", false);
        //    Response.End();
        //}
    }
}