using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using EVOLib;

public partial class AssignAdmin : System.Web.UI.Page
{
    protected int currentPageNumber = 1;
    private const int PAGE_SIZE = 10;
    protected void Page_Load(object sender, EventArgs e)
    {
    
        EvoGeneral objEvoGeneral = new EvoGeneral();
        EvoMain objEvoMain = new EvoMain();
        try
        {
            GetFileName();
           if (!IsPostBack)
            {               
                string NTName;
                NTName = objEvoGeneral.userName;
                objEvoMain.UserID = objEvoGeneral.RetrieveUserID(NTName);
                bool isValid = objEvoMain.GetSuperAdmin(objEvoMain.UserID);
                if (isValid == false)
                {
                    Response.Redirect("~/NotAuthorized .aspx", true);
                }
                FillCostCentreDDL();
                FillAdminDDL();
                FillGrid();
            }
            
        }
        catch (Exception ex)
        {

            ErrorMessageLabel.Text = "Page_Load" + ex.Message;
        }
        finally
        {
            objEvoGeneral = null;
            objEvoMain = null;
        }
       
    }  
    private void GetFileName()
    {      
         ImageButton imgSel = (ImageButton)Master.FindControl("Img1");
         imgSel.ImageUrl = "../Images/butt_assg_rol.jpg";
        
    }
    #region Methods
    private void FillCostCentreDDL()
    {
        AssignCostCentre ObjAssignCostCentre = new AssignCostCentre();
        try
        {

            FilterCostCenterDropDown.DataTextField = "CostCentre";
            FilterCostCenterDropDown.DataValueField = "CostCentreID";
            FilterCostCenterDropDown.DataSource = ObjAssignCostCentre.GetCentralCostCentre().Tables[0];
            FilterCostCenterDropDown.DataBind();
            ListItem item = new ListItem("Select", "0");
            FilterCostCenterDropDown.Items.Insert(0, item);

        }
        catch (Exception ex)
        {

            ErrorMessageLabel.Text = "FillCostCentreDDL" + ex.Message;
        }
        finally
        {
            ObjAssignCostCentre = null;
        }

    }
    private void FillAdminDDL()
    {
        AssignCostCentre ObjAssignCostCentre = new AssignCostCentre();
        try
        {
            DataSet dsAdmin = new DataSet();
            int costCentreId = int.Parse(FilterCostCenterDropDown.SelectedValue);
            string adminName = SearchTextBox.Text;
            dsAdmin = ObjAssignCostCentre.GetEmployeeDetails(costCentreId, adminName);

            if (dsAdmin != null)
            {
                if (dsAdmin.Tables.Count > 0)
                {
                    if (dsAdmin.Tables[0].Rows.Count > 0)
                    {
                        AdminDropdown.DataTextField = "EmployeeName";
                        AdminDropdown.DataValueField = "EmpUserID";
                        AdminDropdown.DataSource = dsAdmin;
                        AdminDropdown.DataBind();
                        //By default selection in Admin name field : Bappa
                        ListItem item = new ListItem("Select", "0");
                        AdminDropdown.Items.Insert(0, item);
                    }
                    else
                    {
                        AdminDropdown.Items.Clear();
                        AdminDropdown.Items.Insert(0, "No Admin Found.");

                    }
                }
                else
                {
                    AdminDropdown.Items.Clear();
                    AdminDropdown.Items.Insert(0, "No Admin Found.");
                }
            }
            else
            {
                AdminDropdown.Items.Clear();
                AdminDropdown.Items.Insert(0, "No Admin Found.");
            }

        }
        catch (Exception ex)
        {

            ErrorMessageLabel.Text = "FillAdminDDL" + ex.Message;
        }
        finally
        {
            ObjAssignCostCentre = null;
        }
    }
    /// <summary>
    /// This method is return the total number of pages.
    /// Created by santosh
    /// </summary>
    /// <param name="totalRows"></param>
    /// <returns></returns>
    private int CalculateTotalPages(double totalRows)
    {
        int totalPages = (int)Math.Ceiling(totalRows / PAGE_SIZE);
        return totalPages;
    }
    /// <summary>
    /// This method is used for fire event of page chaning 
    /// Created by santosh
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ChangePage(object sender, CommandEventArgs e)
    {
        ErrorMessageLabel.Text = "";
        MessageLabel.Text = "";     
        switch (e.CommandName)
        {
            case "Previous":
                currentPageNumber = Int32.Parse(lblCurrentPage.Text) - 1;
                break;

            case "Next":
                currentPageNumber = Int32.Parse(lblCurrentPage.Text) + 1;
                break;
        }

        FillGrid();
    }
    /// <summary>
    /// This method is used for get config record.
    /// </summary>     
    private void FillGrid()
    {
        SuperAssignAdmin ObjSuperAssignAdmin = new SuperAssignAdmin();
        try
        {
            AdminGridview.DataSource = ObjSuperAssignAdmin.GetAdminUserRights(currentPageNumber, PAGE_SIZE);
            AdminGridview.DataBind();
            double totalRows = (int)ObjSuperAssignAdmin.TotalRows;
            lblTotalPages.Text = CalculateTotalPages(totalRows).ToString();
            lblCurrentPage.Text = currentPageNumber.ToString();
            if (currentPageNumber == 1)
            {
                PreLinkButton.Enabled = false;


                if (Int32.Parse(lblTotalPages.Text) > 0)
                {
                    NextLinkButton.Enabled = true;
                }
                else
                    NextLinkButton.Enabled = false;

                if (currentPageNumber == Int32.Parse(lblTotalPages.Text))
                    NextLinkButton.Enabled = false;

            }

            else
            {
                PreLinkButton.Enabled = true;
                if (currentPageNumber == Int32.Parse(lblTotalPages.Text))
                    NextLinkButton.Enabled = false;
                else NextLinkButton.Enabled = true;
            }

        }
        catch (Exception ex)
        {

            ErrorMessageLabel.Text = "FillGrid" + ex.Message;
        }

    }
    #endregion

    #region Events   
    protected void AdminGridview_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        currentPageNumber = int.Parse(lblCurrentPage.Text);
        SuperAssignAdmin ObjSuperAssignAdmin = new SuperAssignAdmin();
        bool isStatus = false;
        try
        {
            int AdmUsrRightID = int.Parse(e.CommandArgument.ToString());
            if (e.CommandName == "CmdDelete")
            {
                ObjSuperAssignAdmin.AdminId = AdmUsrRightID;
                isStatus = ObjSuperAssignAdmin.DeleteAssignAdmin();
                if (isStatus == true)
                {
                    MessageLabel.Text = "Record deleted successfully";
                    FillGrid();
                }
            }
        }
        catch (Exception ex)
        {
            ErrorMessageLabel.Text = "AdminGridview_RowCommand" + ex.Message;
        }
        finally
        {
            ObjSuperAssignAdmin = null;
        }

    }
 
    protected void SearchImageButton_Click(object sender, ImageClickEventArgs e)
    {
        MessageLabel.Text = "";
        FillAdminDDL();
    }
    protected void AssignImageButton_Click(object sender, ImageClickEventArgs e)
    {
        //SuperAssignAdmin ObjSuperAssignAdmin = new SuperAssignAdmin();
        //string NTName = Request.ServerVariables["AUTH_USER"].Replace("3GLOBALSERVICES\\", "");
        //bool isStatus = false;
        //int roleId = 2;
        //try
        //{
        //    ObjSuperAssignAdmin.UserId = int.Parse(AdminDropdown.SelectedValue);
        //    ObjSuperAssignAdmin.RoleId = roleId;
        //    ObjSuperAssignAdmin.AddedBy = NTName;
        //    isStatus = ObjSuperAssignAdmin.AddAdmin();
        //    if (isStatus == true)
        //    {
        //        FillGrid();
        //        MessageLabel.Text = "Record added successfully";
        //        ErrorMessageLabel.Text = "";

        //    }
        //    else
        //    {
        //        ErrorMessageLabel.Text = "Duplicate record found";
        //        MessageLabel.Text = "";
        //    }

        //}
        //catch (Exception ex)
        //{
        //    ErrorMessageLabel.Text = "SubmitButton_Click" + ex.Message;
        //}
        //finally
        //{
        //    ObjSuperAssignAdmin = null;
        //}

    }
    #endregion
}

