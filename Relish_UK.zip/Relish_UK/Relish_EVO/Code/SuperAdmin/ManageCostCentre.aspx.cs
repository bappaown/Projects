using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
using EVOLib;
using H3GS.Web.Security;

public partial class ManageCostCentre : System.Web.UI.Page
{
    protected int currentPageNumber = 1;
    private const int PAGE_SIZE = 10;
    protected void Page_Load(object sender, EventArgs e)
    {
        EvoGeneral objEvoGeneral = new EvoGeneral();
        EvoMain objEvoMain = new EvoMain();
        try
        {
            GetFileName();
            if (!IsPostBack)
            {
                string NTName;
                NTName = objEvoGeneral.userName;
                objEvoMain.UserID = objEvoGeneral.RetrieveUserID(NTName);
                bool isValid = objEvoMain.GetSuperAdmin(objEvoMain.UserID);
                if (isValid == false)
                {
                    Response.Redirect("~/AccessDenied.aspx", true);
                }
                FillCostCentreDDL();
                FillCostCentreListBox();
                FillAdminDDL();
                FillGrid();

            }
            CheckGridRows();
            SubmitImageButton.Attributes.Add("onclick", "return Validate()");
            SearchImageButton.Attributes.Add("onclick", "return SearchValidate()");
        }
        catch (Exception ex)
        {

            ErrorMessageLabel.Text = "Page_Load" + ex.Message;
        }
        finally
        {
            objEvoGeneral = null;
            objEvoMain = null;
        }

    }

    private void GetFileName()
    {
        ImageButton imgSel = (ImageButton)Master.FindControl("Img5");
        imgSel.ImageUrl = "../Images/butt_assg_rol.jpg";

    }
    /// <summary>
    /// This method is used for check the grid view rows and set the paging.
    /// </summary>
    private void CheckGridRows()
    {
        if (CostCentreGridview.Rows.Count == 0)
        {
            PageLabel.Visible = false;
            lblCurrentPage.Visible = false;
            NumberLabel.Visible = false;
            lblTotalPages.Visible = false;
            PreLinkButton.Visible = false;
            NextLinkButton.Visible = false;
        }
        else
        {
            PageLabel.Visible = true;
            lblCurrentPage.Visible = true;
            NumberLabel.Visible = true;
            lblTotalPages.Visible = true;
            PreLinkButton.Visible = true;
            NextLinkButton.Visible = true;
        }
    }
    #region methods
    /// <summary>
    /// This method is used for Fill the cost centre DDL from Cntral Cost centre Table.
    /// </summary>
    private void FillCostCentreListBox()
    {
        try
        {
            AssignCostCentre ObjAssignCostCentre = new AssignCostCentre();
            DataSet ccDs = new DataSet();
            ccDs = ObjAssignCostCentre.GetCentralCostCentre();
            CCListBoxhidden.Value = ccDs.Tables[0].Rows[0].ToString();
            CCListBox.DataTextField = "CostCentre";
            CCListBox.DataValueField = "CostCentreID";
            CCListBox.DataSource = ccDs.Tables[0];
            CCListBox.DataBind();
        }
        catch (Exception ex)
        {

            ErrorMessageLabel.Text = "FillCostCentreListBox" + ex.Message;
        }
    }
    /// <summary>
    /// This method is return the total number of pages.
    /// Created by santosh
    /// </summary>
    /// <param name="totalRows"></param>
    /// <returns></returns>
    private int CalculateTotalPages(double totalRows)
    {
        int totalPages = (int)Math.Ceiling(totalRows / PAGE_SIZE);
        return totalPages;
    }
    /// <summary>
    /// This method is used for fire event of page chaning 
    /// Created by santosh
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ChangePage(object sender, CommandEventArgs e)
    {
        ErrorMessageLabel.Text = "";
        MessageLabel.Text = "";
        switch (e.CommandName)
        {
            case "Previous":
                currentPageNumber = Int32.Parse(lblCurrentPage.Text) - 1;
                break;

            case "Next":
                currentPageNumber = Int32.Parse(lblCurrentPage.Text) + 1;
                break;
        }

        FillGrid();
    }
    /// <summary>
    /// This method is used for Fill the cost centre DDL from Cntral Cost centre Table.
    /// </summary>
    private void FillCostCentreDDL()
    {
        try
        {
            AssignCostCentre ObjAssignCostCentre = new AssignCostCentre();
            FilterCostCenterDropDown.DataTextField = "CostCentre";
            FilterCostCenterDropDown.DataValueField = "CostCentreID";
            FilterCostCenterDropDown.DataSource = ObjAssignCostCentre.GetFilterCostCentre().Tables[0];
            FilterCostCenterDropDown.DataBind();
            ListItem item = new ListItem("Select", "0");
            FilterCostCenterDropDown.Items.Insert(0, item);

        }
        catch (Exception ex)
        {

            ErrorMessageLabel.Text = "FillCostCentreDDL" + ex.Message;
        }

    }
    /// <summary>
    /// This method is used for fill the data grid.
    /// </summary>
    private void FillGrid()
    {
        AssignCostCentre ObjAssignCostCentre = new AssignCostCentre();
        try
        {
            CostCentreGridview.DataSource = ObjAssignCostCentre.GetAdminCCRelation(currentPageNumber, PAGE_SIZE);
            CostCentreGridview.DataBind();
            double totalRows = (int)ObjAssignCostCentre.TotalRows;
            lblTotalPages.Text = CalculateTotalPages(totalRows).ToString();
            lblCurrentPage.Text = currentPageNumber.ToString();
            if (currentPageNumber == 1)
            {
                PreLinkButton.Enabled = false;
                if (Int32.Parse(lblTotalPages.Text) > 0)
                {
                    NextLinkButton.Enabled = true;
                }
                else
                    NextLinkButton.Enabled = false;

                if (currentPageNumber == Int32.Parse(lblTotalPages.Text))
                    NextLinkButton.Enabled = false;

            }
            else
            {
                PreLinkButton.Enabled = true;
                if (currentPageNumber == Int32.Parse(lblTotalPages.Text))
                    NextLinkButton.Enabled = false;
                else NextLinkButton.Enabled = true;
            }
        }
        catch (Exception ex)
        {
            ErrorMessageLabel.Text = "FillGrid" + ex.Message;
        }

    }
    /// <summary>
    /// This method is used for Fill the Admin Drop down.
    /// </summary>
    private void FillAdminDDL()
    {
        AssignCostCentre ObjAssignCostCentre = new AssignCostCentre();
        try
        {
            DataSet dsAdmin = new DataSet();
            int costCentreId = int.Parse(FilterCostCenterDropDown.SelectedValue);
            string adminName = SearchTextBox.Text.Trim();
            dsAdmin = ObjAssignCostCentre.GetEmployeeDetails(costCentreId, adminName);

            if (dsAdmin != null)
            {
                if (dsAdmin.Tables.Count > 0)
                {
                    if (dsAdmin.Tables[0].Rows.Count > 0)
                    {
                        AdminDropDown.DataTextField = "EmployeeName";
                        AdminDropDown.DataValueField = "EmpUserID";
                        AdminDropDown.DataSource = dsAdmin;
                        AdminDropDown.DataBind();
                        //By default selection in Admin name field : Bappa
                        ListItem item = new ListItem("Select", "0");
                        AdminDropDown.Items.Insert(0, item);
                    }
                    else
                    {
                        AdminDropDown.Items.Clear();
                        AdminDropDown.Items.Insert(0, "No Admin Found.");

                    }
                }
                else
                {
                    AdminDropDown.Items.Clear();
                    AdminDropDown.Items.Insert(0, "No Admin Found.");
                }
            }
            else
            {
                AdminDropDown.Items.Clear();
                AdminDropDown.Items.Insert(0, "No Admin Found.");
            }

        }
        catch (Exception ex)
        {

            ErrorMessageLabel.Text = "FillAdminDDL" + ex.Message;
        }
        finally
        {
            ObjAssignCostCentre = null;
        }
    }
    #endregion

    #region Events     

    protected void CostCentreGridview_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        currentPageNumber = int.Parse(lblCurrentPage.Text);
        AssignCostCentre ObjAssignCostCentre = new AssignCostCentre();
        SqlTransaction objSqlTransaction;
        SqlConnection objCon = new SqlConnection(DAL.SqlHelper.GetConnectionString());
        objCon.Open();
        objSqlTransaction = objCon.BeginTransaction();
        try
        {
            bool isStatus = false;
            int userId = int.Parse(e.CommandArgument.ToString());
            if (e.CommandName == "CmdDelete")
            {
                ObjAssignCostCentre.UserId = userId;
                isStatus = ObjAssignCostCentre.DeleteAdminCCR(objSqlTransaction);
                if (isStatus == true)
                {
                    objSqlTransaction.Commit();
                    FillGrid();
                    CheckGridRows();
                    MessageLabel.Text = "Record deleted successfully";
                }
                else
                {
                    objSqlTransaction.Rollback();
                    CheckGridRows();
                    MessageLabel.Text = "Record not deleted";
                }
            }
        }
        catch (Exception ex)
        {
            objSqlTransaction.Rollback();
            ErrorMessageLabel.Text = "Error during deleting the record " + ex.Message;
        }
        finally
        {
            if (objCon.State == ConnectionState.Open)
            {
                objCon.Close();
            }
            objCon = null;
            objSqlTransaction = null;
            ObjAssignCostCentre = null;
        }
    }

    protected void SearchImageButton_Click(object sender, ImageClickEventArgs e)
    {
        FillAdminDDL();
    }
    protected void SubmitImageButton_Click(object sender, ImageClickEventArgs e)
    {
        //added to clear labels so that it would not create confusion
        MessageLabel.Text = "";
        ErrorMessageLabel.Text = "";
        //
        SqlTransaction objSqlTransaction;
        SqlConnection objCon = new SqlConnection(DAL.SqlHelper.GetConnectionString());
        AssignCostCentre ObjAssignCostCentre = new AssignCostCentre();
        SuperAssignAdmin ObjSuperAssignAdmin = new SuperAssignAdmin();
        objCon.Open();
        objSqlTransaction = objCon.BeginTransaction();
        try
        {
            ////Windows Authentication : Bappa
            //string NTName = PassportIdentity.Current.Employee.LoginId; //Request.ServerVariables["AUTH_USER"].Replace("3GLOBALSERVICES\\", "");
            string NTName = HttpContext.Current.Request.Cookies["EVO"] != null ? HttpContext.Current.Request.Cookies["EVO"]["userName"] : string.Empty;
            ////End
            bool isStatus = false;
            int roleId = 2;
            ObjSuperAssignAdmin.UserId = int.Parse(AdminDropDown.SelectedValue);
            ObjSuperAssignAdmin.AdminUserLogin = ObjSuperAssignAdmin.RetrieveAdminUserLogin(ObjSuperAssignAdmin.UserId);
            ObjSuperAssignAdmin.RoleId = roleId;
            ObjSuperAssignAdmin.AddedBy = NTName;
            isStatus = ObjSuperAssignAdmin.AddAdmin(objSqlTransaction);
            if (ObjSuperAssignAdmin.AdminId == 0)
            {
                objSqlTransaction.Rollback();
                ErrorMessageLabel.Text = "User already exists as Sub-Admin.";
            }
            if (ObjSuperAssignAdmin.AdminId == 1)
            {
                for (int iLoop = 0; iLoop <= CCListBox.Items.Count - 1; iLoop++)
                {
                    // item selected 
                    if (CCListBox.Items[iLoop].Selected)
                    {
                        ObjAssignCostCentre.UserId = int.Parse(AdminDropDown.SelectedValue);
                        ObjAssignCostCentre.CCId = int.Parse(CCListBox.Items[iLoop].Value);
                        ObjAssignCostCentre.AddedBy = NTName;
                        isStatus = ObjAssignCostCentre.AddAdminCCR(objSqlTransaction);
                    }
                }

                if (isStatus == true)
                {
                    objSqlTransaction.Commit();
                    FillGrid();
                    CheckGridRows();
                    MessageLabel.Text = "Record added successfully";
                    ErrorMessageLabel.Text = "";

                }

            }
            if (ObjSuperAssignAdmin.AdminId == 2)
            {
                objSqlTransaction.Rollback();
                CheckGridRows();
                ErrorMessageLabel.Text = "User already exists as Admin";
            }

        }
        catch (Exception ex)
        {
            objSqlTransaction.Rollback();
            ErrorMessageLabel.Text = "Error during submitted the record " + ex.Message;
        }
        finally
        {
            if (objCon.State == ConnectionState.Open)
            {
                objCon.Close();
            }
            objCon = null;
            objSqlTransaction = null;
            ObjAssignCostCentre = null;
            ObjSuperAssignAdmin = null;
        }
    }
    #endregion
}



