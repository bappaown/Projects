﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using EVOLib;
using DAL;

public partial class SuperAdmin_ManageGlobalControls : EvoGeneral
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            //string NTName;
            userName = GetNTName();

            EvoMain objEvoMain = new EvoMain();
            objEvoMain.UserID = RetrieveUserID(userName);

            bool isValid = objEvoMain.GetSuperAdmin(objEvoMain.UserID);
            if (isValid == false)
            {
                Response.Redirect("~/AccessDenied.aspx", true);
            }
        }
        catch (Exception)
        {
            throw;
        }

        if (!Page.IsPostBack)
        {
            AddJavascript();
            FillGridGlobalControls();
        }
        AssignMainSettings();
    }
    EvoSuperAdminGlobalControls objGlobalControl = new EvoSuperAdminGlobalControls();

    private void AssignMainSettings()
    {
        ImageButton imgSel = (ImageButton)Master.FindControl("Img3");
        imgSel.ImageUrl = "../Images/butt_glo_con_rol.jpg";
    }

    private void AddJavascript()
    {
        // Response.Write(" txtVal : " + txtValue.ClientID);
        txtName.Attributes.Add("onkeyup", "return CheckFieldJunkChars('" + txtName.ClientID + "',50);");
        btnCreate.Attributes.Add("onclick", "return ValidateGlobalControl('" + txtName.ClientID + "', '" + drpControlType.ClientID + "','" + drpIsDependency.ClientID + "', '" + drpDepControl.ClientID + "')");
    }

    protected void drpControlType_SelectedIndexChanged(object sender, EventArgs e)
    {
        FilterData();
    }

    protected void drpIsDependency_SelectedIndexChanged(object sender, EventArgs e)
    {
        FilterData();
    }

    private void FilterData()
    {
        try
        {
            if (drpIsDependency.SelectedValue == "True")
            {
                drpDepControl.Items.Clear();

                objGlobalControl.ControlType = drpControlType.SelectedValue;
                DataSet ds;
                ds = objGlobalControl.GetParentGlobalControls();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    drpDepControl.DataSource = ds.Tables[0];
                    drpDepControl.DataTextField = "ControlName";
                    drpDepControl.DataValueField = "ControlId";
                    drpDepControl.DataBind();
                }
            }
            else
            {
                drpDepControl.Items.Clear();
            }

            ListItem lst = new ListItem("-- Select --", "0");
            drpDepControl.Items.Insert(0, lst);
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    protected void btnCreate_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            lblError.Text = "";
            lblSuccess.Text = "";
            gvGlobalControl.EditIndex = -1;

            objGlobalControl.ControlName = txtName.Text.Trim().Replace(" ", "_");
            objGlobalControl.ControlType = drpControlType.SelectedValue;
            objGlobalControl.DependentControlId = int.Parse(drpDepControl.SelectedValue);
            objGlobalControl.UserLogin = userName;

            if (objGlobalControl.InsertGlobalControl())
            {
                ClearFields();
                lblSuccess.Text = "The control added successfully";
            }
            else
            {
                lblError.Text = "Control already exists";
            }
            FillGridGlobalControls();
        }
        catch (Exception ex)
        {
            lblError.Text = "Could not add control " + ex.Message;
        }
    }

    private void ClearFields()
    {
        txtName.Text = "";
        drpDepControl.SelectedIndex = 0;
        drpIsDependency.SelectedIndex = 0;
        drpControlType.SelectedIndex = 0;
        lblError.Text = "";
        lblSuccess.Text = "";
    }

    private void FillGridGlobalControls()
    {
        try
        {
            gvGlobalControl.DataSource = null;
            gvGlobalControl.DataBind();

            DataSet ds;
            ds = objGlobalControl.GetGlobalControls();
            if (ds.Tables[0].Rows.Count > 0)
            {
                gvGlobalControl.DataSource = ds.Tables[0];
                gvGlobalControl.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblError.Text = "could not bind data " + ex.Message;
        }
    }

    protected void gvGlobalControl_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        lblError.Text = "";
        lblSuccess.Text = "";
        gvGlobalControl.EditIndex = -1;
        FillGridGlobalControls();
    }

    protected void gvGlobalControl_RowEditing(object sender, GridViewEditEventArgs e)
    {
        gvGlobalControl.EditIndex = e.NewEditIndex;

        FillGridGlobalControls();
    }

    protected void gvGlobalControl_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        string state = e.Row.RowState.ToString();

        if ((state == "Edit") || (state == "Alternate, Edit"))
        {
            TextBox txtBox = (TextBox)e.Row.Cells[0].FindControl("txtControlName");
            txtBox.Text = txtBox.Text.Replace("_", " ");
            txtBox.Attributes.Add("onkeypress", "return CheckFieldJunkChars('" + txtBox.ClientID + "',50);");
        }
    }

    protected void gvGlobalControl_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        try
        {
            int i = e.RowIndex;
            Label lblId = (Label)gvGlobalControl.Rows[i].Cells[0].FindControl("lblControlId");
            int CtrlId = int.Parse(lblId.Text);
            objGlobalControl.ControlId = CtrlId;

            //objGlobalControl.AccessRightId = AccessRightId;
            if (objGlobalControl.DeleteGlobalControl())
            {
                gvGlobalControl.EditIndex = -1;
                FillGridGlobalControls();
                lblSuccess.Text = "The record and its dependent control (if any) has been deleted successfully";
            }
            else
            {
                lblError.Text = "Could not delete record";
            }
        }
        catch (Exception ex)
        {
            lblError.Text = "Could not delete record" + ex.Message;
        }
    }

    protected void gvGlobalControl_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        try
        {
            lblSuccess.Text = "";
            lblError.Text = "";

            bool IsFullyValid = true;

            int i = e.RowIndex;
            Label lblId = (Label)gvGlobalControl.Rows[i].Cells[0].FindControl("lblControlId");
            int CtrlId = int.Parse(lblId.Text);

            TextBox txtControlName = (TextBox)gvGlobalControl.Rows[i].Cells[0].FindControl("txtControlName");

            if (txtControlName.Text.Trim() == "")
            {
                lblError.Text = "Please enter a Global Control Name";
                txtControlName.Focus();
                IsFullyValid = false;
            }
            else
            {
                string[] iChars = { "_", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "+", "=", "[", "]", "\",", "'", ";", ".", "/", "{", "}", "|", "<", ">", "?", ":", "~", "`", "-","£","\\", ",", "\""};

                for (int count = 0; count < iChars.Length; count++)
                {
                    if (txtControlName.Text.IndexOf(iChars[count]) != -1)
                    {
                        lblError.Text += @"Special Characters are not allowed. <br>";
                        IsFullyValid = false;
                        break;
                    }
                }
            }

            if (IsFullyValid)
            {
                objGlobalControl.ControlId = CtrlId;
                objGlobalControl.ControlName = txtControlName.Text.Trim().Replace(" ", "_");

                if (objGlobalControl.UpdateGlobalControl())
                {
                    gvGlobalControl.EditIndex = -1;
                    FillGridGlobalControls();
                    lblSuccess.Text = "The record has been updated successfully";
                }
                else
                {
                    lblError.Text = "Control Name already exists.";
                }
            }
        }
        catch (Exception ex)
        {
            lblError.Text = "Could not Update data " + ex.Message;
        }
    }

    //added for paging in datagrid
    protected void gvGlobalControl_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gvGlobalControl.PageIndex = e.NewPageIndex;
        FillGridGlobalControls();
    }
}