﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
using EVOLib;
using DAL;
using H3GS.Web.Security;

public partial class SuperAdmin_EVOSuperAdmin : System.Web.UI.MasterPage
{
    public string userName;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ////Windows Authentication : Bappa
            //userName = PassportIdentity.Current.Employee.FullName;
            userName = HttpContext.Current.Request.Cookies["EVO"] != null ? HttpContext.Current.Request.Cookies["EVO"]["userFullName"] : string.Empty;
            ////End
            lblName.Text = "Welcome " + userName;
            this.Page.Title = "" + ConfigurationKeys.ApplicationName + " - " + ConfigurationKeys.ApplicationVersion;
        }
    }

    protected void TopIcon1ImageBtn_Click(object sender, EventArgs e)
    {
        DestroySession();
        Response.Redirect("~/Admin/AdminFormDetails.aspx");
    }

    protected void TopIcon2ImageBtn_Click(object sender, EventArgs e)
    {
        DestroySession();
        Response.Redirect("~/Admin/ModifyFormDetails.aspx");
    }

    protected void TopIcon3ImageBtn_Click(object sender, EventArgs e)
    {
        DestroySession();
        Response.Redirect("~/Reports/ManageReports.aspx");
    }

    private void DestroySession()
    {
        ManageSession.FormID = 0;
        ManageSession.FormName = null;
        ManageSession.XmlFileName = null;
        ManageSession.CategoryID = 0;
        ManageSession.VersionID = 0;
        ManageSession.FormMode = null;
    }

    //added to redirect to specific page without 2-4 times clicking on tabs/image which was happening earlier
    protected void HomeImageButton_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("../Admin/Default.aspx");
    }

    //Logout Functionalily : Bappa
    protected void LogoutButton_Click(object sender, ImageClickEventArgs e)
    {
        int AuthType = Convert.ToInt32(HttpContext.Current.Request.Cookies["EVO"]["AuthenticationType"]);
        Response.Cookies["EVO"].Expires = DateTime.Now.AddDays(-1);
        Session.Abandon();
        Response.Redirect("../LogOut.aspx");
    }
    //End

    protected void Img5_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("ManageCostCentre.aspx");
    }

    protected void Img2_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("ConfigSetting.aspx");
    }

    protected void Img3_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("ManageGlobalControls.aspx");
    }

    protected void Img4_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("ManageGlobalControlData.aspx");
    }

    protected void Img1_Click(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("AssignAdmin.aspx");
    }
}
