﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using EVOLib;
using DAL;

public partial class SuperAdmin_ManageGlobalControlData : EvoGeneral
{
    string controlType = "";
    string selVal = "";
    int CtrlId;
    DataSet dsMain;
    //   bool isParentAvail;

    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            userName = GetNTName();

            EvoMain objEvoMain = new EvoMain();
            objEvoMain.UserID = RetrieveUserID(userName);

            bool isValid = objEvoMain.GetSuperAdmin(objEvoMain.UserID);
            if (isValid == false)
            {
                Response.Redirect("~/AccessDenied.aspx", true);
            }
        }
        catch (Exception)
        {
            throw;
        }

        if (!Page.IsPostBack)
        {
            AssignMainSettings();
            FillCostCentres();
            AddJavascript();
        }
    }

    EvoSuperAdminGlobalControls objGlobalControl = new EvoSuperAdminGlobalControls();
    
    private void AddJavascript()
    {
        // Response.Write(" txtVal : " + txtValue.ClientID);
        txtValue.Attributes.Add("onkeyup", "return CheckFieldJunkChars('" + txtValue.ClientID + "',0);");
        txtValue.Attributes.Add("onkeydown", "return CheckFieldJunkChars('" + txtValue.ClientID + "',0);");
        btnAdd.Attributes.Add("onclick", "return ValidateGlobalControlData('" + btnAdd.ClientID + "',0);");
        btnUpdate.Attributes.Add("onclick", "return ValidateGlobalControlData('" + btnUpdate.ClientID + "',0);");
        // btnCreate.Attributes.Add("onclick", "return ValidateGlobalControl('" + txtValue.ClientID + "', '" + drpControlType.ClientID + "','" + drpIsDependency.ClientID + "', '" + drpDepControl.ClientID + "')");
    }
    
    private void AssignMainSettings()
    {
        ImageButton imgSel = (ImageButton)Master.FindControl("Img4");
        imgSel.ImageUrl = "../Images/butt_mang_rol.jpg";
    }

    /// <summary>
    /// Function to get selected control type
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void lnkBtnDropDown_Click(object sender, CommandEventArgs e)
    {
        ClearMessages();
        ClearControls();
        lblControlData.Text = "Selected Control Data";
        lstBoxParent.Visible = true;
        drpCostCentre.SelectedIndex = 0;
        lstSkillSet.Items.Clear();
        controlType = e.CommandArgument.ToString();
        objGlobalControl.ControlType = controlType;
        hidSelectedControl.Value = controlType;
        BindDropdowns(controlType);
        //EnableActionButtons();
        GetSelectedControlTd();
    }

    /// <summary>
    ///  Function to highlight selected Control type
    /// </summary>
    private void GetSelectedControlTd()
    {
        DeselectControlTd();
        if (controlType == "DropDown")
        {
            lnkBtnDropDown.BackColor = System.Drawing.Color.SkyBlue;
        }
        if (controlType == "ListBox")
        {
            lnkBtnListBox.BackColor = System.Drawing.Color.SkyBlue;
        }
    }

    /// <summary>
    /// Function to bind the drpFrom as per the control selected. Eg. If DropDown is seletced all the Dropdown global controls will be bind
    /// </summary>
    /// <param name="ctrlType"></param>
    private void BindDropdowns(string ctrlType)
    {
        lblErr.Text = "";
        lblSuccess.Text = "";

        try
        {
            // Empty control
            drpFrom.Items.Clear();
            DataSet ds;
            ds = objGlobalControl.GetAllGlobalControls();
            if (ds.Tables[0].Rows.Count > 0)
            {
                drpFrom.DataSource = ds.Tables[0];
                drpFrom.DataTextField = "ControlName";
                drpFrom.DataValueField = "ControlId";
                drpFrom.DataBind();
            }
        }
        catch (Exception ex)
        {
            throw;
        }
        drpFrom.Items.Insert(0, "-- Select --");
    }

    /// <summary>
    ///  Clearing all the existing messages
    /// </summary>
    private void ClearMessages()
    {
        lblErr.Text = "";
        lblSuccess.Text = "";
        lblSelCtrl.Text = "Selected Control Data";
        hidIsParentAvail.Value = "";

        lblChildControl.Text = "";
        txtValue.Text = "";
    }

    private void ClearControls()
    {
        ddlCtrlChild.Items.Clear();
        ddlCtrlParent.Items.Clear();
        ddlCtrlChild.Visible = false;
        ddlCtrlParent.Visible = false;

        lstBoxChild.Items.Clear();
        lstBoxParent.Items.Clear();
        lstBoxChild.Visible = false;
        lstBoxParent.Visible = false;
    }

    private void DeselectControlTd()
    {
        lnkBtnListBox.BackColor = System.Drawing.Color.Transparent;
        lnkBtnDropDown.BackColor = System.Drawing.Color.Transparent;
        //lnkBtnRadioButton.BackColor = System.Drawing.Color.Transparent;
        //lnkBtnCheckBox.BackColor = System.Drawing.Color.Transparent;
    }

    /// <summary>
    ///  function to Fill Coste centres
    /// </summary>
    private void FillCostCentres()
    {
        lblErr.Text = "";
        lblSuccess.Text = "";

        try
        {
            DataSet ds;
            ds = objGlobalControl.GetCostCentres();
            if (ds.Tables[0].Rows.Count > 0)
            {
                drpCostCentre.DataSource = ds.Tables[0];
                drpCostCentre.DataTextField = "CostCentre";
                drpCostCentre.DataValueField = "CostCentreId";
                drpCostCentre.DataBind();
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = "Could not load cost centres " + ex.Message;
        }
        drpCostCentre.Items.Insert(0, "-- Select --");
    }

    protected void drpFrom_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ClearMessages();
            drpCostCentre.SelectedIndex = 0;
            lstSkillSet.Items.Clear();
            lstBoxParent.Items.Clear();
            lstBoxChild.Items.Clear();
            lstBoxChild.Visible = false;
            ddlCtrlParent.Items.Clear();
            ddlCtrlChild.Items.Clear();
            ddlCtrlChild.Visible = false;
            lblControlData.Text = "Selected Control Data";

            ////if ((drpFrom.SelectedIndex <= 0) || (drpCostCentre.SelectedIndex <= 0) || (lstSkillSet.SelectedIndex <= 0))
            ////{ }
            ////else
            ////{
            ////    ClearMessages();
            ////    GetData();
            ////}
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }
    }

    protected void lstSkillSet_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ClearMessages();
            if (ValidateForm())
            {
                GetData();
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = ex.Message;
        }
    }

    private bool ValidateForm()
    {
        bool isValid = true;
        if (drpFrom.SelectedIndex <= 0)
        {
            lblErr.Text = "Please select control";
            drpFrom.Focus();
            isValid = false;
        }
        else if (drpCostCentre.SelectedIndex <= 0)
        {
            lblErr.Text = "Please select cost centre";
            drpCostCentre.Focus();
            isValid = false;
        }
        else if (lstSkillSet.SelectedIndex < 0)
        {
            lblErr.Text = "Please select Skillset";
            lstSkillSet.Focus();
            isValid = false;
        }
        return isValid;
    }

    private void GetSelectedSkillSets()
    {
        //**tdControls.InnerHtml = "";

        for (int i = 0; i < lstSkillSet.Items.Count; i++)
        {
            if (lstSkillSet.Items[i].Selected)
            {
                if (selVal != "")
                {
                    selVal += ", " + lstSkillSet.Items[i].Value;
                }
                else
                {
                    selVal += lstSkillSet.Items[i].Value;
                    // i = lstSkillSet.Items.Count;
                }
            }
        }
    }

    private void GetData()
    {
        //if ((drpFrom.SelectedIndex <= 0) || (drpCostCentre.SelectedIndex <= 0) || (lstSkillSet.SelectedIndex <= 0))
        //{
        //}
        //else
        //{
        //lblErr.Text = "";
        //lblSuccess.Text = "";

        if (ValidateForm())
        {
            ClearControls();

            CtrlId = int.Parse(drpFrom.SelectedValue);
            objGlobalControl.ControlId = CtrlId;
            dsMain = objGlobalControl.GetControlDetails();
            DropDownList ddlCtrl = new DropDownList();
            ListBox lstCtrl = new ListBox();

            GetSelectedSkillSets();
            objGlobalControl.SkillSetId = selVal;
            objGlobalControl.CostCentreId = int.Parse(drpCostCentre.SelectedValue);

            if (dsMain.Tables[0].Rows.Count > 0)
            {
                int ParentId = int.Parse(dsMain.Tables[0].Rows[0]["DependentControlId"].ToString());
                string ctrlName = dsMain.Tables[0].Rows[0]["ControlName"].ToString();

                controlType = hidSelectedControl.Value;

                if (ParentId > 0)
                {
                    //isParentAvail = true;
                    hidIsParentAvail.Value = "yes";
                    DataSet dsPrnt;
                    objGlobalControl.ControlId = ParentId;
                    dsPrnt = objGlobalControl.GetControlDetails();
                    FillData(dsPrnt, "Parent", false);
                }
                else
                {
                    objGlobalControl.ControlId = CtrlId;
                    FillData(dsMain, "Child", false);
                }
            }
            //}
        }
    }

    private void FillData(DataSet dsParent, string type, bool isFromParent)
    {
        //lblErr.Text = "";
        //lblSuccess.Text = "";

        if (dsParent.Tables[0].Rows.Count > 0)
        {
            string ctrlParentName = dsParent.Tables[0].Rows[0]["ControlName"].ToString();
            int ctrlParentId = int.Parse(dsParent.Tables[0].Rows[0]["ControlId"].ToString());

            DataSet dsParentData;
            dsParentData = objGlobalControl.GetSelectedControlData();
            if (!isFromParent)
            {
                lblControlData.Text = ctrlParentName;

                if (controlType == "DropDown")
                {
                    lstBoxChild.Visible = false;
                    lstBoxParent.Visible = false;

                    if (type == "Parent")
                    {
                        ddlCtrlParent.Visible = true;
                        ddlCtrlParent.Items.Clear();

                        if (dsParentData.Tables[0].Rows.Count > 0)
                        {
                            ddlCtrlParent.DataSource = dsParentData.Tables[0];
                            ddlCtrlParent.DataTextField = "Text";
                            ddlCtrlParent.DataValueField = "DataStoreId";
                            ddlCtrlParent.DataBind();

                            objGlobalControl.ControlId = CtrlId;
                            FillData(dsMain, "Child", true);
                        }
                        else
                        {
                            lblErr.Text = "No data found in parent control " + ctrlParentName + ". Please select parent control and fill up data first";
                            ddlCtrlParent.Visible = false;
                            lblControlData.Text = "";
                        }
                        ListItem lst = new ListItem("-- Select --", "0");
                        ddlCtrlParent.Items.Insert(0, lst);
                    }
                    else
                    {
                        ddlCtrlChild.Visible = true;
                        ddlCtrlChild.Items.Clear();
                        if (dsParentData.Tables[0].Rows.Count > 0)
                        {
                            ddlCtrlChild.DataSource = dsParentData.Tables[0];
                            ddlCtrlChild.DataTextField = "Text";
                            ddlCtrlChild.DataValueField = "DataStoreId";
                            ddlCtrlChild.DataBind();
                        }
                        else
                        {
                            lblErr.Text = "No data found in control " + ctrlParentName + ". Please fill up";
                        }
                        ListItem lst = new ListItem("-- Select --", "0");
                        ddlCtrlChild.Items.Insert(0, lst);
                    }
                }
                else if (controlType == "ListBox")
                {
                    ddlCtrlChild.Visible = false;
                    ddlCtrlParent.Visible = false;

                    if (type == "Parent")
                    {
                        lstBoxParent.Visible = true;
                        lstBoxParent.Items.Clear();
                        if (dsParentData.Tables[0].Rows.Count > 0)
                        {
                            lstBoxParent.DataSource = dsParentData.Tables[0];
                            lstBoxParent.DataTextField = "Text";
                            lstBoxParent.DataValueField = "DataStoreId";
                            lstBoxParent.DataBind();

                            objGlobalControl.ControlId = CtrlId;
                            FillData(dsMain, "Child", true);
                        }
                        else
                        {
                            lblErr.Text = "No data found in parent control " + ctrlParentName + ". Please select parent control and fill up data first";
                            lstBoxParent.Visible = false;
                            lblControlData.Text = "";
                        }
                    }
                    else
                    {
                        lstBoxChild.Visible = true;
                        lstBoxChild.Items.Clear();
                        if (dsParentData.Tables[0].Rows.Count > 0)
                        {
                            lstBoxChild.DataSource = dsParentData.Tables[0];
                            lstBoxChild.DataTextField = "Text";
                            lstBoxChild.DataValueField = "DataStoreId";
                            lstBoxChild.DataBind();
                        }
                        else
                        {
                            lblErr.Text = "No data found in control " + ctrlParentName + ". Please fill up.";
                        }
                    }
                }
            }
            else
            {
                lblChildControl.Text = "  " + ctrlParentName + "  ";
                if (controlType == "DropDown")
                {
                    ddlCtrlChild.Visible = true;
                    ListItem lst = new ListItem("-- Select --", "0");
                    ddlCtrlChild.Items.Insert(0, lst);
                }
                else if (controlType == "ListBox")
                {
                    lstBoxChild.Visible = true;
                }
            }
        }
    }

    protected void lstBoxParent_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            txtValue.Text = "";
            lstBoxChild.Items.Clear();
            GetDropDownChildControlData();
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    protected void ddlCtrlParent_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ddlCtrlChild.Items.Clear();
            txtValue.Text = "";
            GetDropDownChildControlData();
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    protected void ddlCtrlChild_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            txtValue.Text = ddlCtrlChild.SelectedItem.Text;
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    protected void lstBoxChild_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            txtValue.Text = lstBoxChild.SelectedItem.Text;
        }
        catch (Exception ex)
        {
            throw;
        }
    }

    private void GetDropDownChildControlData()
    {
        DataSet dsChildControl;
        bool IsValid = true;

        if (hidSelectedControl.Value == "DropDown")
        {
            ddlCtrlChild.Items.Clear();
            if (ddlCtrlParent.SelectedIndex > 0)
            {
                objGlobalControl.DependentControlId = Convert.ToInt32(ddlCtrlParent.SelectedValue);
            }
            else
            {
                objGlobalControl.DependentControlId = 0;
                IsValid = false;
            }
        }
        else
        {
            lstBoxChild.Items.Clear();
            if (lstBoxParent.SelectedIndex >= 0)
            {
                objGlobalControl.DependentControlId = Convert.ToInt32(lstBoxParent.SelectedValue);
            }
            else
            {
                objGlobalControl.DependentControlId = 0;
                IsValid = false;
            }
        }

        if (IsValid)
        {
            objGlobalControl.CostCentreId = Convert.ToInt32(drpCostCentre.SelectedValue);
            GetSelectedSkillSets();
            objGlobalControl.SkillSetId = selVal;
            dsChildControl = objGlobalControl.GetChildGlobalControlData();

            if (dsChildControl.Tables[0].Rows.Count > 0)
            {
                if (hidSelectedControl.Value == "DropDown")
                {
                    ddlCtrlChild.Items.Clear();

                    ddlCtrlChild.DataSource = dsChildControl.Tables[0];
                    ddlCtrlChild.DataTextField = "Text";
                    ddlCtrlChild.DataValueField = "DataStoreId";
                    ddlCtrlChild.DataBind();
                    ListItem lst = new ListItem("-- Select --", "0");
                    ddlCtrlChild.Items.Insert(0, lst);
                }
                else
                {
                    lstBoxChild.DataSource = dsChildControl.Tables[0];
                    lstBoxChild.DataTextField = "Text";
                    lstBoxChild.DataValueField = "DataStoreId";
                    lstBoxChild.DataBind();
                }
            }
            else
            {
                ddlCtrlChild.Items.Clear();
                ListItem lst = new ListItem("-- Select --", "0");
                ddlCtrlChild.Items.Insert(0, lst);
            }
        }
    }

    /// <summary>
    /// Filling the skillsets as per the cost centre selected
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void drpCostCentre_SelectedIndexChanged(object sender, EventArgs e)
    {
        try
        {
            ClearMessages();

            lstSkillSet.Items.Clear();
            lstBoxParent.Items.Clear();
            lstBoxChild.Items.Clear();
            ddlCtrlParent.Items.Clear();
            ddlCtrlChild.Items.Clear();

            DataSet ds;
            if (drpCostCentre.SelectedIndex > 0)
            {
                objGlobalControl.CostCentreId = int.Parse(drpCostCentre.SelectedValue);
                ds = objGlobalControl.GetCostCentresSkillsets();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    lstSkillSet.DataSource = ds.Tables[0];
                    lstSkillSet.DataTextField = "DepartmentName";
                    lstSkillSet.DataValueField = "DepartmentId";
                    lstSkillSet.DataBind();
                }
            }
            else
            {
                lblErr.Text = "Please select Cost centre";
            }
        }
        catch (Exception ex)
        {
            lblErr.Text = "Could not load cost centres " + ex.Message;
        }
    }

    // Adding item to control
    protected void btnAdd_Click(object sender, ImageClickEventArgs e)
    {
        lblErr.Text = "";
        lblSuccess.Text = "";

        bool IsFullyValid = true;
        if (ValidateForm())
        {
            if (hidIsParentAvail.Value == "yes")
            {
                if (hidSelectedControl.Value == "DropDown")
                {
                    if (ddlCtrlParent.SelectedIndex <= 0)
                    {
                        lblErr.Text = "Please select Parent control";
                        ddlCtrlParent.Focus();
                        IsFullyValid = false;
                    }
                }
                else
                {
                    if (lstBoxParent.SelectedIndex < 0)
                    {
                        lblErr.Text = "Please select Parent control";
                        lstBoxParent.Focus();
                        IsFullyValid = false;
                    }
                }
            }
            else
            {
                objGlobalControl.DependentControlId = 0;
            }

            if (txtValue.Text == "")
            {
                lblErr.Text = "Please enter a value in the List Item box";  // Earlier it was put by Imran --> "Please enter text";
                txtValue.Focus();
                IsFullyValid = false;
                GetData();
            }
            else
            {
                string[] iChars = { "_", "!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "+", "=", "[", "]", "\",", "'", ";", ".", "/", "{", "}", "|", "<", ">", "?", ":", "~", "`", "-", "£" };

                for (int count = 0; count < iChars.Length; count++)
                {
                    if (txtValue.Text.IndexOf(iChars[count]) != -1)
                    {
                        lblErr.Text += @"Special Characters _!@#$%^&*()+=[]\\\';,./{}|\:<>?~`-£ are not Allowed. <br>";
                        IsFullyValid = false;
                        break;
                    }
                }
            }

            if (IsFullyValid)
            {
                string SkillSetString = "";

                for (int i = 0; i < lstSkillSet.Items.Count; i++)
                {
                    if (lstSkillSet.Items[i].Selected)
                    {
                        SkillSetString += lstSkillSet.Items[i].Value + ",";
                    }
                }

                if (hidIsParentAvail.Value == "yes")
                {
                    if (hidSelectedControl.Value == "DropDown")
                    {
                        objGlobalControl.DependentControlId = Convert.ToInt32(ddlCtrlParent.SelectedValue);
                    }
                    else
                    {
                        objGlobalControl.DependentControlId = Convert.ToInt32(lstBoxParent.SelectedValue);
                    }
                }
                objGlobalControl.ControlId = Convert.ToInt32(drpFrom.SelectedValue);
                objGlobalControl.CostCentreId = Convert.ToInt32(drpCostCentre.SelectedValue);
                objGlobalControl.SkillSetId = SkillSetString;
                objGlobalControl.ControlName = txtValue.Text.Trim();
                objGlobalControl.UserLogin = userName;

                if (objGlobalControl.InsertGlobalControlData())
                {
                    lblSuccess.Text = "Data Added successfully";
                }
                else
                {
                    lblErr.Text = "Data already exists";
                }

                if (hidIsParentAvail.Value == "yes")
                {
                    GetDropDownChildControlData();
                }
                else
                {
                    GetData();
                }
                if (hidSelectedControl.Value == "DropDown")
                {
                    ddlCtrlChild.SelectedIndex = 0;
                }
                else
                {
                    lstBoxChild.SelectedIndex = 0;
                }
                txtValue.Text = "";
            }
        }
    }

    // Updating item 
    protected void btnUpdate_Click(object sender, ImageClickEventArgs e)
    {
        lblErr.Text = "";
        lblSuccess.Text = "";

        bool IsFullyValid = true;

        if (ValidateForm())
        {
            if (hidSelectedControl.Value == "DropDown")
            {
                if (hidIsParentAvail.Value == "yes")
                {
                    if (ddlCtrlParent.SelectedIndex <= 0)
                    {
                        lblErr.Text = "Please select Parent Control";
                        IsFullyValid = false;
                    }
                }

                if (ddlCtrlChild.SelectedIndex <= 0)
                {
                    lblErr.Text = "Please Select the option in the List";
                    IsFullyValid = false;
                }
                else
                {
                    objGlobalControl.DataStoreId = Convert.ToInt32(ddlCtrlChild.SelectedValue);
                }
            }
            else
            {
                if (hidIsParentAvail.Value == "yes")
                {
                    if (lstBoxParent.SelectedIndex < 0)
                    {
                        lblErr.Text = "Please select Parent Control";
                        IsFullyValid = false;
                    }
                }

                if (lstBoxChild.SelectedIndex < 0)
                {
                    lblErr.Text = "Please Select the option in the List";
                    IsFullyValid = false;
                }
                else
                {
                    objGlobalControl.DataStoreId = Convert.ToInt32(lstBoxChild.SelectedValue);
                }
            }
            if (txtValue.Text.Trim() == "")
            {
                lblErr.Text = "Please enter a value in the List Item box";
                txtValue.Focus();
                IsFullyValid = false;
                //GetData();
            }
            else
            {
                string[] iChars = { "%", "^", "[", "]", "\",", "/", "{", "}", "|", "<", ">", "#", "'", "," };

                for (int count = 0; count < iChars.Length; count++)
                {
                    if (txtValue.Text.IndexOf(iChars[count]) != -1)
                    {
                        lblErr.Text += @"Special Characters %^[]\,/,{}|\<>#^', are not Allowed. <br>";
                        IsFullyValid = false;
                        break;
                    }
                }
            }
            if (IsFullyValid)
            {
                objGlobalControl.ControlName = txtValue.Text.Trim();
                objGlobalControl.CostCentreId = Convert.ToInt32(drpCostCentre.SelectedValue);
                objGlobalControl.ControlId = Convert.ToInt32(drpFrom.SelectedValue);
               
                if (objGlobalControl.UpdateGlobalControlData())
                {
                    lblSuccess.Text = "Data Updated Successfully";
                }
                else
                {
                    lblErr.Text = "Option already exists. ";
                }

                if (hidIsParentAvail.Value == "yes")
                {
                    GetDropDownChildControlData();
                }
                else
                {
                    GetData();
                }
                if (hidSelectedControl.Value == "DropDown")
                {
                    ddlCtrlChild.SelectedIndex = 0;
                }
                else
                {
                    lstBoxChild.SelectedIndex = 0;
                }
                txtValue.Text = "";
            }
        }
    }

    // deleting item
    protected void btnDelete_Click(object sender, ImageClickEventArgs e)
    {
        lblErr.Text = "";
        lblSuccess.Text = "";

        bool IsFullyValid = true;

        if (ValidateForm())
        {
            if (hidSelectedControl.Value == "DropDown")
            {
                if (hidIsParentAvail.Value == "yes")
                {
                    if (ddlCtrlParent.SelectedIndex <= 0)
                    {
                        lblErr.Text = "Please select Parent Control";
                        IsFullyValid = false;
                    }
                }

                if (ddlCtrlChild.SelectedIndex <= 0)
                {
                    lblErr.Text = "Please select an option from the list";
                    IsFullyValid = false;
                }
                else
                {
                    objGlobalControl.ControlId = Convert.ToInt32(ddlCtrlChild.SelectedValue);
                }
            }
            else
            {
                if (hidIsParentAvail.Value == "yes")
                {
                    if (lstBoxParent.SelectedIndex < 0)
                    {
                        lblErr.Text = "Please select Parent Control";
                        IsFullyValid = false;
                    }
                }

                if (lstBoxChild.SelectedIndex < 0)
                {
                    lblErr.Text = "Please select an option from the list";
                    IsFullyValid = false;
                }
                else
                {
                    objGlobalControl.ControlId = Convert.ToInt32(lstBoxChild.SelectedValue);
                }
            }
            if (IsFullyValid)
            {
                objGlobalControl.ControlName = txtValue.Text.Trim();
                objGlobalControl.CostCentreId = Convert.ToInt16(drpCostCentre.SelectedValue);
                string SkillSetString = "";

                for (int i = 0; i < lstSkillSet.Items.Count; i++)
                {
                    if (lstSkillSet.Items[i].Selected)
                    {
                        SkillSetString += lstSkillSet.Items[i].Value + ",";
                    }
                }
                objGlobalControl.SkillSetId = SkillSetString;

                if (objGlobalControl.DeleteGlobalControlData())
                {
                    lblSuccess.Text = "Data Deleted Successfully";
                }
                else
                {
                    lblErr.Text = "Data could not be deleted";
                }

                if (hidIsParentAvail.Value == "yes")
                {
                    GetDropDownChildControlData();
                }
                else
                {
                    GetData();
                }
                if (hidSelectedControl.Value == "DropDown")
                {
                    ddlCtrlChild.SelectedIndex = -1;
                }
                else
                {
                    lstBoxChild.SelectedIndex = -1;
                }
                txtValue.Text = "";
            }
        }
    }
}