using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using EVOLib;
using H3GS.Web.Security;

public partial class ConfigSetting : System.Web.UI.Page
{
    protected int currentPageNumber = 1;
    private const int PAGE_SIZE = 10;
    protected void Page_Load(object sender, EventArgs e)
    {
        EvoGeneral objEvoGeneral = new EvoGeneral();
        EvoMain objEvoMain = new EvoMain();
        try
        {
            GetFileName();
            if (!IsPostBack)
            {
                string NTName;
                NTName = objEvoGeneral.userName;
                objEvoMain.UserID = objEvoGeneral.RetrieveUserID(NTName);
                bool isValid = objEvoMain.GetSuperAdmin(objEvoMain.UserID);
                if (isValid == false)
                {
                    Response.Redirect("~/NotAuthorized .aspx", true);
                }
                FillGrid();
            }
            CheckGridRows();
            SubmitImageButton.Attributes.Add("onclick", "return SubmitValidation();");
        }
        catch (Exception ex)
        {

            ErrorMessageLabel.Text = "Page_Load" + ex.Message;
        }
        finally
        {
            objEvoGeneral = null;
            objEvoMain = null;
        }

    }
    /// <summary>
    /// This method is used for check the grid view rows and set the paging.
    /// </summary>
    private void CheckGridRows()
    {
        if (ConfigSettingGridview.Rows.Count == 0)
        {
            PageLabel.Visible = false;
            lblCurrentPage.Visible = false;
            NumberLabel.Visible = false;
            lblTotalPages.Visible = false;
            PreLinkButton.Visible = false;
            NextLinkButton.Visible = false;
        }
        else
        {
            PageLabel.Visible = true;
            lblCurrentPage.Visible = true;
            NumberLabel.Visible = true;
            lblTotalPages.Visible = true;
            PreLinkButton.Visible = true;
            NextLinkButton.Visible = true;
        }
    }

    private void GetFileName()
    {
        ImageButton imgSel = (ImageButton)Master.FindControl("Img2");
        imgSel.ImageUrl = "../Images/butt_conf_rol.jpg";

    }
    #region Methods
    /// <summary>
    /// Strucute of grid column position.
    /// </summary>
    private struct GridPosition
    {
        public const int CONFIGID = 0;
        public const int TITLE = 1;
        public const int VALUE = 2;
        public const int EDIT = 3;
    }
    /// <summary>
    /// This method is return the total number of pages.
    /// Created by santosh
    /// </summary>
    /// <param name="totalRows"></param>
    /// <returns></returns>
    private int CalculateTotalPages(double totalRows)
    {

        int totalPages = (int)Math.Ceiling(totalRows / PAGE_SIZE);
        return totalPages;
    }
    /// <summary>
    /// This method is used for fire event of page chaning 
    /// Created by santosh
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void ChangePage(object sender, CommandEventArgs e)
    {

        switch (e.CommandName)
        {
            case "Previous":
                currentPageNumber = Int32.Parse(lblCurrentPage.Text) - 1;
                break;

            case "Next":
                currentPageNumber = Int32.Parse(lblCurrentPage.Text) + 1;
                break;
        }
        MessageLabel.Text = "";
        ErrorMessageLabel.Text = "";
        FillGrid();
    }

    /// <summary>
    /// This method is used for get config record.
    /// </summary>     
    private void FillGrid()
    {
        AdminConfigSetting ObjAdminConfigSetting = new AdminConfigSetting();
        try
        {
            ConfigSettingGridview.DataSource = ObjAdminConfigSetting.GetAdminConfigDetail(currentPageNumber, PAGE_SIZE);
            ConfigSettingGridview.DataBind();
            double totalRows = (int)ObjAdminConfigSetting.TotalRows;
            lblTotalPages.Text = CalculateTotalPages(totalRows).ToString();
            lblCurrentPage.Text = currentPageNumber.ToString();
            if (currentPageNumber == 1)
            {
                PreLinkButton.Enabled = false;

                if (Int32.Parse(lblTotalPages.Text) > 0)
                {
                    NextLinkButton.Enabled = true;
                }
                else
                    NextLinkButton.Enabled = false;
                if (currentPageNumber == Int32.Parse(lblTotalPages.Text))
                    NextLinkButton.Enabled = false;

            }
            else
            {
                PreLinkButton.Enabled = true;

                if (currentPageNumber == Int32.Parse(lblTotalPages.Text))
                    NextLinkButton.Enabled = false;
                else NextLinkButton.Enabled = true;
            }
        }
        catch (Exception ex)
        {

            ErrorMessageLabel.Text = "FillGrid" + ex.Message;
        }

    }
    private void FormClear()
    {
        TitleTextBox.Text = "";
        ValueTextBox.Text = "";

    }
    #endregion

    #region Events

    protected void ConfigSettingGridview_RowEditing(object sender, GridViewEditEventArgs e)
    {
        ConfigSettingGridview.EditIndex = e.NewEditIndex;
        currentPageNumber = int.Parse(lblCurrentPage.Text);
        FillGrid();
    }
    protected void ConfigSettingGridview_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
    {
        ConfigSettingGridview.EditIndex = -1;
        currentPageNumber = int.Parse(lblCurrentPage.Text);
        ErrorMessageLabel.Text = "";
        FillGrid();
    }
    protected void ConfigSettingGridview_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        currentPageNumber = int.Parse(lblCurrentPage.Text);
        bool isStatus = false;
        Label configIDLabel = (Label)ConfigSettingGridview.Rows[e.RowIndex].Cells[GridPosition.CONFIGID].FindControl("ConfigIdLabel");
        AdminConfigSetting ObjAdminConfigSetting = new AdminConfigSetting();
        try
        {
            ObjAdminConfigSetting.ConfigId = int.Parse(configIDLabel.Text);
            isStatus = ObjAdminConfigSetting.DeleteConfig();
            if (isStatus == true)
            {
                FillGrid();
                CheckGridRows();
                MessageLabel.Text = "Record deleted successfully";
                ErrorMessageLabel.Text = "";
            }

        }
        catch (Exception ex)
        {

            ErrorMessageLabel.Text = "ConfigSettingGridview_RowDeleting" + ex.Message;
        }
        finally
        {
            ObjAdminConfigSetting = null;
        }
    }
    protected void ConfigSettingGridview_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        currentPageNumber = int.Parse(lblCurrentPage.Text);
        Label configIDLabel = (Label)ConfigSettingGridview.Rows[e.RowIndex].Cells[GridPosition.CONFIGID].FindControl("ConfigIdLabel");
        Label TitleLabel = (Label)ConfigSettingGridview.Rows[e.RowIndex].Cells[GridPosition.TITLE].FindControl("TitleLabel");
        TextBox valueTextBox = (TextBox)ConfigSettingGridview.Rows[e.RowIndex].Cells[GridPosition.VALUE].FindControl("ValueTextBox");
        bool isStatus = false;
        AdminConfigSetting ObjAdminConfigSetting = new AdminConfigSetting();
        try
        {
            ObjAdminConfigSetting.ConfigId = int.Parse(configIDLabel.Text);
            ObjAdminConfigSetting.ConfigName = TitleLabel.Text.Trim();
            ObjAdminConfigSetting.ConfigValue = int.Parse(valueTextBox.Text.Trim());
            ObjAdminConfigSetting.UserAllowed = 5;
            isStatus = ObjAdminConfigSetting.UpdateConfig();
            if (isStatus == true)
            {
                ConfigSettingGridview.EditIndex = -1;
                FillGrid();
                CheckGridRows();
                MessageLabel.Text = "Record updated successfully";
            }
            else
            {
                ErrorMessageLabel.Text = "Duplicate Record Found";
            }
        }
        catch (Exception ex)
        {

            ErrorMessageLabel.Text = "ConfigSettingGridview_RowUpdating" + ex.Message;
        }
        finally
        {
            ObjAdminConfigSetting = null;
        }

    }
    #endregion

    protected void SubmitImageButton_Click(object sender, ImageClickEventArgs e)
    {
        ////Windows Authentication : Bappa
        //string NTName = PassportIdentity.Current.Employee.LoginId; //Request.ServerVariables["AUTH_USER"].Replace("3GLOBALSERVICES\\", "");
        string NTName = HttpContext.Current.Request.Cookies["EVO"] != null ? HttpContext.Current.Request.Cookies["EVO"]["userName"] : string.Empty;
        ////End
        AdminConfigSetting ObjAdminConfigSetting = new AdminConfigSetting();
        try
        {
            bool isStatus = false;
            ObjAdminConfigSetting.ConfigName = TitleTextBox.Text.Trim();
            ObjAdminConfigSetting.ConfigValue = Convert.ToInt32(ValueTextBox.Text.Trim());
            ObjAdminConfigSetting.AddedBy = NTName;
            ObjAdminConfigSetting.UserAllowed = 5;
            isStatus = ObjAdminConfigSetting.AddConfig();
            if (isStatus == true)
            {
                FillGrid();
                FormClear();
                CheckGridRows();
                MessageLabel.Text = "Record added successfully";
                ErrorMessageLabel.Text = "";
            }
            else
            {
                CheckGridRows();
                ErrorMessageLabel.Text = "Duplicate data found";
                MessageLabel.Text = "";
            }
        }
        catch (Exception ex)
        {
            ErrorMessageLabel.Text = "SubmitButton_Click" + ex.Message;
        }
        finally
        {
            ObjAdminConfigSetting = null;
        }


    }
}

