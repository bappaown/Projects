using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using EVOLib;

public partial class Reports_ManageReports : EvoGeneral
{
    Forms objForms = new Forms();
    Reports objReports = new Reports();

    protected void Page_Load(object sender, EventArgs e)
    {

        //added to get cache cleared so that radio butoon is not selected when coming back to screen
        Response.AppendHeader("Cache-Control", "no-store");
        //

        if (!IsPostBack)
        {
            String DashBoard = ConfigurationManager.AppSettings["DashBoardAdmin"].ToString();
            if (DashBoard.Contains(userName))
            {
                linkDashBoard.Visible = true;
            }
            else
            {
                linkDashBoard.Visible = false;
            }
            if (Request.QueryString["type"] != null)
            {
                chkIsDtms.Checked = true;
            }
            
            
            BindFormsGrid();
            PendingRptImageButton.Style.Value  = "display:none";
        }
    }

    protected override void OnInit(EventArgs e)
    {
        ActivateDeActivateControls();
    }
    private void ActivateDeActivateControls()
    {
        Label lblModule = (Label)Master.FindControl("lblModule");
        lblModule.Text = "Manage Reports";
        ImageButton imgHome = (ImageButton)Page.FindControl("ctl00$imgHome");
        imgHome.Click += new ImageClickEventHandler(HomeButton_Clicked);
    }

    protected void HomeButton_Clicked(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("../Admin/Default.aspx", true);
    }

    public void BindFormsGrid()
    {
        DataSet EmpDataSet = new DataSet();
        try
        {
            EmpDataSet = RetrieveEmployeeDetails(userName);
            if (EmpDataSet.Tables[0].Rows.Count > 0)
            {
                DataSet objDataSet = new DataSet();
                int EmpUserID = Convert.ToInt32(EmpDataSet.Tables[0].Rows[0]["EmpUserID"]);
                objReports.UserID = EmpUserID;
                objReports.Module = "Reports";
                objReports.FormID = 0;
                string reporttype = "0";
                if (chkIsDtms.Checked == true)
                {
                    reporttype = "1";
                }
                objDataSet = objReports.GetFormsForReports(objDataSet, reporttype);
                ViewState["FormsDataSet"] = objDataSet;

                FormsGridView.DataSource = objDataSet;
                FormsGridView.DataBind();
            }
            else
            {
                Response.Redirect("../AccessDenied.aspx", true);
            }
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message.ToString();
        }
    }

    protected void SearchImageButton_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            ErrorLabel.Text = "";
            DataSet objDataSet = new DataSet();
            objDataSet = (DataSet)ViewState["FormsDataSet"];

            if (FormNameTextBox.Text != "")
            {
                string FormName = FormNameTextBox.Text;

                objDataSet.Tables[0].DefaultView.RowFilter = "FormName Like '%" + FormName + "%'";
                if (objDataSet.Tables[0].DefaultView.Count > 0)
                {
                    FormsGridView.DataSource = objDataSet.Tables[0].DefaultView;
                    FormsGridView.DataBind();
                }
                else
                {
                    FormsGridView.DataSource = null;
                    FormsGridView.DataBind();
                    ErrorLabel.Text = "No Records Found.";
                }
            }
            else
            {
                FormsGridView.DataSource = objDataSet;
                FormsGridView.DataBind();
            }
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message.ToString();
        }
    }

    protected void DataDumpImageButton_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            RedirectPage("DataDumpReport.aspx");
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message;
        }
    }
    protected void CustomRptImageButton_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            RedirectPage("CustomRealtimeReport.aspx");
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message.ToString();
        }
    }

    //-------START Added by Sagar CR Client Requirement For Wrap Note Hits   
    protected void WrapNotesRptImageButton_Click(object sender, EventArgs e)
    {
        try
        {
            RedirectPage("WrapNoteUserHitsReport.aspx");
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message.ToString();
        }
    }
    //-------END Added by Sagar CR Client Requirement For Wrap Note Hits   

    protected void ArchivedRptImageButton_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            RedirectPage("ArchivedReport.aspx");
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message.ToString();
        }
    }

    public void RedirectPage(string PageName)
    {
        try
        {
            RadioButton objRadioButton = new RadioButton();
            for (int iRowCount = 0; iRowCount < FormsGridView.Rows.Count; iRowCount++)
            {
                objRadioButton = (RadioButton)FormsGridView.Rows[iRowCount].Cells[5].FindControl("rdbGVRow");
                if (objRadioButton.Checked == true)
                {
                    DataKey dtKey = FormsGridView.DataKeys[iRowCount];
                    ManageSession.FormID = Convert.ToInt32(FormsGridView.DataKeys[iRowCount].Values["FormID"]);
                    ManageSession.VersionID = Convert.ToInt32(FormsGridView.DataKeys[iRowCount].Values["VersionID"]);
                    Response.Redirect("../Reports/" + PageName, true);
                }
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void FormsGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        try
        {
            FormsGridView.PageIndex = e.NewPageIndex;
            BindFormsGrid();
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message;
        }
    }
    protected void PendingRptImageButton_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            RedirectPage("ViewLogReport.aspx");
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message.ToString();
        }
    }
    protected void FormsGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            Label lblIsActive = (Label)e.Row.Cells[7].FindControl("lblIsEditable");
           
                RadioButton rdgvrow = (RadioButton)e.Row.Cells[8].FindControl("rdbGVRow");
                rdgvrow.InputAttributes.Add("onmousedown", "javascript:Showhide(" + lblIsActive.Text.ToLower() + ")");
            

        }
    }
    protected void chkIsDtms_CheckedChanged(object sender, EventArgs e)
    {
        BindFormsGrid();        
    }
}
