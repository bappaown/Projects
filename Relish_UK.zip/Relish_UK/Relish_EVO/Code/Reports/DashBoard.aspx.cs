using System;
using System.Data;
using System.Configuration;
using System.Collections;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using DAL;
using EVOLib;

public partial class Reports_DashBoard : System.Web.UI.Page
{
    Reports objReports = new Reports();
    double totalCount = 0;
    double captureCount = 0;
    double userCount = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            BindDashBoard();
        }
    }

    protected void BindDashBoard()
    {
        try
        {
            DataSet objDataSet = new DataSet();
            objDataSet = objReports.GetDashBoardReport(objDataSet);

            if (objDataSet.Tables[0].Rows.Count > 0)
            {
                DashBoardGridView.DataSource = objDataSet;
                DashBoardGridView.DataBind();
            }
        }
        catch (Exception ex)
        {
            InfoLabel.Text = ex.Message;
        }
    }
    protected void DashBoardGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            totalCount += Convert.ToDouble(e.Row.Cells[2].Text);
            captureCount += Convert.ToDouble(e.Row.Cells[3].Text);
            userCount += Convert.ToDouble(e.Row.Cells[4].Text);
        }

        if (e.Row.RowType == DataControlRowType.Footer)
        {
            e.Row.Cells[1].Text = "Total";
            e.Row.Cells[1].Style.Add("Text-Align", "Right");
            e.Row.Cells[2].Text = totalCount.ToString();
            e.Row.Cells[2].Style.Add("Text-Align", "Right");
            e.Row.Cells[3].Text = captureCount.ToString();
            e.Row.Cells[3].Style.Add("Text-Align", "Right");
            e.Row.Cells[4].Text = userCount.ToString();
            e.Row.Cells[4].Style.Add("Text-Align", "Right");
        }
    }
}
