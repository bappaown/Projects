﻿using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using EVOLib;

 /*
  * Craeted By: Sagar Suseelan
  * Date :  20-July-2011
  * Purpose :  To retrieve report of users who used Wrap functionality - CR
 */

public partial class Reports_WrapNotesUserHitsReport : System.Web.UI.Page
{
    Reports objReports = new Reports();
    int totalCount = 0;
    int index = 0;

    protected override void OnInit(EventArgs e)
    {
        if (!IsPostBack)
        {
            //Check if session has value if yes assign it to hidden fields.
            int frmID = ManageSession.FormID;

            if (frmID != 0)
            {
                FormIdHiddenField.Value = frmID.ToString();
            }
            else
            {
                Response.Redirect("../AccessDenied.aspx", true);
            }
        }

        ActivateDeActivateControls();
        base.OnInit(e);
    }

    private void ActivateDeActivateControls()
    {
        Label lblModule = (Label)Master.FindControl("lblModule");
        lblModule.Text = "Wrap Note User Hits Report";
        int cnt = Master.Controls.Count;
        ImageButton imgHome = (ImageButton)Page.FindControl("ctl00$imgHome");
        imgHome.Click += new ImageClickEventHandler(HomeButton_Clicked);
    }

    protected void HomeButton_Clicked(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("../Admin/Default.aspx", true);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            StDateTextBox.Attributes.Add("onClick", "javascript:ShowCalendar(this,1900,2030,'dd/mmm/yyyy');");
            EdDateTextBox.Attributes.Add("onClick", "javascript:ShowCalendar(this,1900,2030,'dd/mmm/yyyy');");

            string stDate = StDateTextBox.ClientID.ToString();
            string edDate = EdDateTextBox.ClientID.ToString();
            StartDateImage.Attributes.Add("onClick", "javascript:ShowCalendar(" + stDate + ",1900,2030,'dd/mmm/yyyy');");
            EndDateImageButton.Attributes.Add("onClick", "javascript:ShowCalendar(" + edDate + ",1900,2030,'dd/mmm/yyyy');");

            StDateTextBox.Value = DateTime.Now.ToString("dd-MMM-yyyy");
            EdDateTextBox.Value = DateTime.Now.ToString("dd-MMM-yyyy");
        }
    }

    protected void SubmitImageButton_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            DateTime startDate;
            DateTime endDate;
            startDate = Convert.ToDateTime(StDateTextBox.Value);
            endDate = Convert.ToDateTime(EdDateTextBox.Value);

            string fromHours = "00";
            string toHours = "00";
            if (FromDropDownList.SelectedIndex > 0)
            {
                fromHours = FromDropDownList.SelectedItem.Text;
            }

            if (ToDropDownList.SelectedIndex > 0)
            {
                toHours = ToDropDownList.SelectedItem.Value;
            }

            //if ((Convert.ToInt16(fromHours) > Convert.ToInt16(toHours)) || fromHours == toHours)
            //{
            //    throw new Exception("Start time cannot be greater than or equal to End time.");
            //    return;
            //}

            string frmHoursFormat = "dd-MMM-yyyy " + fromHours + ":00:00";
            string toHoursFormat = "dd-MMM-yyyy " + toHours + ":59:59";

            DataSet objDataSet = new DataSet();
            objReports.FormID = Convert.ToInt32(FormIdHiddenField.Value);
            objReports.UserID = 0;
            objReports.Module = "FormVersions";
            objReports.StDate = Convert.ToDateTime(startDate).ToString(frmHoursFormat);
            objReports.EndDate = Convert.ToDateTime(endDate).ToString(toHoursFormat);
            //objDataSet = objReports.GetWrapNoteUserHitsReport(objDataSet);
            objDataSet = objReports.GetFormsForReports(objDataSet, "0");
            if (objDataSet.Tables[0].Rows.Count > 0)
            {
                DataDumpGridView.DataSource = objDataSet;
                DataDumpGridView.DataBind();
                ErrorLabel.Text = "";
            }
            else
            {
                ErrorLabel.Text = "No Records Found.";
            }
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message;
        }
    }

    protected void DataDumpGridView_RowCommand(object sender, GridViewCommandEventArgs e)
    {
        if (e.CommandName == "Excel")
        {
            DateTime startDate;
            DateTime endDate;

            char[] splitter = { '|' };
            string[] Id = e.CommandArgument.ToString().Split(splitter);
            int formId = Convert.ToInt32(Id[0]);
            int versionID = Convert.ToInt32(Id[1]);

            System.IO.StringWriter oStringWriter = new System.IO.StringWriter();
            System.Web.UI.HtmlTextWriter oHtmlTextWriter = new System.Web.UI.HtmlTextWriter(oStringWriter);

            try
            {
                //this.EnableViewState = false;

                DataSet objDataSet = new DataSet();
                startDate = Convert.ToDateTime(StDateTextBox.Value);
                endDate = Convert.ToDateTime(EdDateTextBox.Value);

                string fromHours = "00";
                string toHours = "00";
                string fromMin = "00";
                string toMin = "00";

                if (FromDropDownList.SelectedIndex > 0)
                {
                    fromHours = FromDropDownList.SelectedItem.Text;
                }
                if (FromMinuteDropDownList.SelectedIndex > 0)
                {
                    fromMin = FromMinuteDropDownList.SelectedItem.Text;
                }

                if (ToDropDownList.SelectedIndex > 0)
                {
                    toHours = ToDropDownList.SelectedItem.Value;
                }
                if (ToMinuteDropDownList.SelectedIndex > 0)
                {
                    toMin = ToMinuteDropDownList.SelectedItem.Text;
                }

                string frmHoursFormat = "dd-MMM-yyyy " + fromHours + ":" + fromMin + ":00";
                string toHoursFormat = "dd-MMM-yyyy " + toHours + ":" + toMin + ":00";

                objReports.FormID = formId;
                objReports.VersionID = versionID;
                objReports.StDate = Convert.ToDateTime(startDate).ToString(frmHoursFormat);
                objReports.EndDate = Convert.ToDateTime(endDate).ToString(toHoursFormat);
                objDataSet = objReports.GetWrapNoteUserHitsReport(objDataSet);

                if (objDataSet.Tables.Count > 0)
                {
                    if (objDataSet.Tables[0].Rows.Count == 0)
                    {
                        ErrorLabel.Text = "Data not found for the selected date/time range.";
                        return;
                    }
                }
                else
                {
                    ErrorLabel.Text = "Data not found for the selected date/time range";
                    return;
                }

                //Commented by Sagar
                //ExcelHelper.ToExcel(objDataSet, "EVO_WrapNoteUserHits_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xls", Page.Response);

                //Commented by Imran.

                GridView objGridView = new GridView();
                objGridView.DataSource = objDataSet;
                objGridView.ShowFooter = true;

                objGridView.RowDataBound += new GridViewRowEventHandler(objGridView_RowDataBound);
                objGridView.DataBind();

                objGridView.RenderControl(oHtmlTextWriter);
                //Response.Write(oStringWriter.ToString());
                Response.Write("<style>.text { mso-number-format:\\@; } </style>" + oStringWriter.ToString());
                Response.AddHeader("Content-disposition", "attachment;filename=EVO_WrapNoteUserHits_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xls");
                Response.ContentType = "application/vnd.ms-excel";
                Response.Charset = "UTF-8";
                Response.End();
                ErrorLabel.Text = "";
            }
            catch (Exception ex)
            {
                ErrorLabel.Text = ex.Message;
            }
            finally
            {
                oHtmlTextWriter.Close();
                oStringWriter.Close();
            }
        }
    }


    protected void objGridView_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        if (e.Row.RowType == DataControlRowType.Header)
        {
            for (int i = 0; i < e.Row.Cells.Count; i++)
            {
                if (e.Row.Cells[i].Text.StartsWith("#"))
                {
                    e.Row.Cells[i].Text = e.Row.Cells[i].Text.Replace("#", "");
                    index = i;
                }
            }
        }
        if (e.Row.RowType == DataControlRowType.DataRow)
        {
            totalCount = totalCount + Convert.ToInt32(e.Row.Cells[index].Text);  
        }
        if (e.Row.RowType == DataControlRowType.Footer)
        {
            e.Row.Cells[index - 1].HorizontalAlign = HorizontalAlign.Right;
            e.Row.Cells[index - 1].Style.Add(HtmlTextWriterStyle.FontWeight, "Bold");
            e.Row.Cells[index - 1].Text = "Total Hit Count  : ";

            e.Row.Cells[index].HorizontalAlign = HorizontalAlign.Right;
            e.Row.Cells[index].Style.Add(HtmlTextWriterStyle.FontWeight, "Bold");
            e.Row.Cells[index].Text = totalCount.ToString();    
        }

    }
}



