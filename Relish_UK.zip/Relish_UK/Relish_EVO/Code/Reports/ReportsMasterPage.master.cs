using System;
using EVOLib;
using H3GS.Web.Security;
using System.Web;


public partial class Reports_ReportsMasterPage : System.Web.UI.MasterPage
{
    public string userName;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            ////Windows Authentication : Bappa
            //userName = PassportIdentity.Current.Employee.FullName;
            userName = HttpContext.Current.Request.Cookies["EVO"] != null ? HttpContext.Current.Request.Cookies["EVO"]["userFullName"] : string.Empty;
            ////End
            lblName.Text = "Welcome " + userName;
            this.Page.Title = "" + ConfigurationKeys.ApplicationName + " - " + ConfigurationKeys.ApplicationVersion;
        }
    }

    protected void TopIcon1ImageBtn_Click(object sender, EventArgs e)
    {
        DestroySession();
        Response.Redirect("~/Admin/AdminFormDetails.aspx");
    }

    protected void TopIcon2ImageBtn_Click(object sender, EventArgs e)
    {
        DestroySession();
        Response.Redirect("~/Admin/ModifyFormDetails.aspx");
    }

    protected void TopIcon3ImageBtn_Click(object sender, EventArgs e)
    {
        DestroySession();
        Response.Redirect("~/Reports/ManageReports.aspx");
    }

    //Logout Functionalily : Bappa
    protected void LogoutButton_Click(object sender, EventArgs e)
    {
        int AuthType = Convert.ToInt32(HttpContext.Current.Request.Cookies["EVO"]["AuthenticationType"]);
        Response.Cookies["EVO"].Expires = DateTime.Now.AddDays(-1);
        Session.Abandon();
        Response.Redirect("../LogOut.aspx");
    }
    //End

    private void DestroySession()
    {
        ManageSession.FormID = 0;
        ManageSession.FormName = null;
        ManageSession.XmlFileName = null;
        ManageSession.CategoryID = 0;
        ManageSession.VersionID = 0;
        ManageSession.FormMode = null;
    }
}
