using System;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using EVOLib;
using System.Xml;
using System.Xml.Linq;

public partial class Reports_ViewLogReport :EvoGeneral //System.Web.UI.Page
{
    Reports objReports = new Reports();
    Forms objForms = new Forms();
    XmlDocument doc;
    string FileName;
    XDocument xmlDoc = new XDocument();

    protected override void OnInit(EventArgs e)
    {
        if (!IsPostBack)
        {
            //Check if session has value if yes assign it to hidden fields.
            int frmID = ManageSession.FormID;

            if (frmID != 0)
            {
                FormIdHiddenField.Value = frmID.ToString();
            }
            else
            {
                Response.Redirect("../AccessDenied.aspx", true);
            }
        }

        ActivateDeActivateControls();
        base.OnInit(e);
    }

    /// <summary>
    /// Add event handler to master controls.
    /// </summary>
    private void ActivateDeActivateControls()
    {
        Label lblModule = (Label)Master.FindControl("lblModule");
        lblModule.Text = "View Log Report";
        int cnt = Master.Controls.Count;
        ImageButton imgHome = (ImageButton)Page.FindControl("ctl00$imgHome");
        imgHome.Click += new ImageClickEventHandler(HomeButton_Clicked);
    }

    protected void HomeButton_Clicked(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("../Admin/Default.aspx", true);
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            StDateTextBox.Attributes.Add("onClick", "javascript:ShowCalendar(this,1900,2030,'dd/mmm/yyyy');");
            EdDateTextBox.Attributes.Add("onClick", "javascript:ShowCalendar(this,1900,2030,'dd/mmm/yyyy');");
            ExportImageButton.Attributes.Add("onClick", "javascript:return Validate();");

            string stDate = StDateTextBox.ClientID.ToString();
            string edDate = EdDateTextBox.ClientID.ToString();
            StartDateImage.Attributes.Add("onClick", "javascript:ShowCalendar(" + stDate + ",1900,2030,'dd/mmm/yyyy');");
            EndDateImageButton.Attributes.Add("onClick", "javascript:ShowCalendar(" + edDate + ",1900,2030,'dd/mmm/yyyy');");

            StDateTextBox.Value = DateTime.Now.ToString("dd-MMM-yyyy");
            EdDateTextBox.Value = DateTime.Now.ToString("dd-MMM-yyyy");
            Binddata();
        }
    }

    /// <summary>
    /// Get all Version Names which falls under selected Form Name/Call Logger irrespective of Date range selected.
    /// </summary>
    /// <param name="sender"></param>
    /// <param name="e"></param>
    protected void Binddata()
    {
        try
        {
            
            DataSet objDataSet = new DataSet();
            objReports.FormID = Convert.ToInt32(FormIdHiddenField.Value);
            objReports.UserID = 0;
            objReports.Module = "FormVersionsViewLog";
            objReports.StDate = null;
            objReports.EndDate = null;
            objDataSet = objReports.GetFormsForReports(objDataSet, "0");
            if (objDataSet.Tables[0].Rows.Count > 0)
            {
                ViewLogGridView.DataSource = objDataSet;
                ViewLogGridView.DataBind();
                ErrorLabel.Text = "";
            }
            else
            {
                ErrorLabel.Text = "No Records Found.";
            }
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message;
        }
    }

    

    protected void ViewLogGridView_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            VersionIDHiddenField.Value = Convert.ToString(ViewLogGridView.DataKeys[e.NewEditIndex].Values["VersionID"]);
            GetFieldNames();
            ErrorLabel.Text = "";
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message;
        }
    }

    public void GetFieldNames()
    {
        DataSet objDataSet = new DataSet();
        try
        {
            SelectedFieldsListBox.Items.Clear();
            objForms.FormID = Convert.ToInt32(FormIdHiddenField.Value);
            objForms.VersionID = Convert.ToInt32(VersionIDHiddenField.Value);
            objDataSet = objForms.GetFormsFieldsWithVersions(objDataSet, false);

            if (objDataSet.Tables[0].Rows.Count > 0)
            {
                BindListBox(objDataSet, AllFieldsListBox, "Alias", "FieldID");
            }
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message;
        }
    }

    protected void ViewLogGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        ViewLogGridView.PageIndex = e.NewPageIndex;
        Binddata();
        
    }

    public void BindListBox(DataSet objDataSet, ListBox objListBox, string textField, string valueField)
    {
        try
        {
            objListBox.DataSource = objDataSet;
            objListBox.DataTextField = textField;
            objListBox.DataValueField = valueField;
            objListBox.DataBind();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
    protected void AllFieldsListBox_SelectedIndexChanged(object sender, EventArgs e)
    {
         DataSet objDataSet = new DataSet();
         try
         {
             ErrorLabel.Text = "";
             SelectedFieldsListBox.Items.Clear();
             string controlname = "";
             string controltype = "";
             string filepath = "";
             objForms.FieldID = AllFieldsListBox.SelectedItem.Value;
             objForms.FormID = Convert.ToInt32(FormIdHiddenField.Value);
             objForms.VersionID = Convert.ToInt32(VersionIDHiddenField.Value);
             objDataSet = objForms.GetFormDetails(objDataSet);
             if (objDataSet.Tables.Count > 0)
             {
                 if (objDataSet.Tables[0].Rows.Count > 0)
                 {
                     controlname = objDataSet.Tables[0].Rows[0]["FieldName"].ToString() + objDataSet.Tables[0].Rows[0]["FieldDisplayType"].ToString();
                     filepath = objDataSet.Tables[0].Rows[0]["XMLFileName"].ToString();
                     if (objDataSet.Tables[0].Rows[0]["FieldDisplayType"].ToString() == "DropDown")
                     {
                         controltype = "DropDownList";
                     }
                     else
                     {
                         controltype = objDataSet.Tables[0].Rows[0]["FieldDisplayType"].ToString();
                     }

                     if (controltype == "DropDownList" || controltype == "ListBox")
                     {
                         BindControlData(controlname, controltype, filepath);
                     }
                 }
             }
         }
         catch (Exception ex)
         {
             ErrorLabel.Text = ex.Message;
         }
    }

    public void BindControlData(string controlname, string controltype, string filepath)
    {
        ReadNLoadFile(filepath);

        XmlNodeList rootNodeList = doc.SelectNodes("FORMS/" + controltype);




        for (int i = 0; i < rootNodeList.Count; i++)
        {

            XmlNode dropDownNode = (XmlNode)rootNodeList[i];


            for (int y = 0; y < dropDownNode.ChildNodes.Count; y++)
            {
                if ((dropDownNode.ChildNodes[y].Name == "FieldID") && (dropDownNode.ChildNodes[y].InnerText == controlname))
                {
                    for (int j = 0; j < dropDownNode.ChildNodes.Count; j++)
                    {

                        XmlNode ndListItems = dropDownNode.SelectSingleNode("LISTITEMS");
                       
                        string ListItemText = "";
                       
                       
                        XmlNodeList listItems = ndListItems.ChildNodes;

                        for (int l = 0; l < listItems.Count; l++)
                        {
                            ListItemText = listItems.Item(l).InnerText;

                            if (listItems.Item(l).Name == "LISTITEM")
                            {
                                //SelectedFieldsListBox.Attributes.Add(listItems.Item(l).InnerText, listItems.Item(l).InnerText);
                                SelectedFieldsListBox.Items.Add(new ListItem(ListItemText, ListItemText));
                            }
                            
                            //SelectedFieldsListBox.DataBind();
                        }
                        break;
                    }
                }
            }
        }
    }

    private void ReadNLoadFile(string filepath)
    {
        FileName = Server.MapPath("..\\XML\\" + filepath);
        doc = new XmlDocument();
        xmlDoc = XDocument.Load(FileName);
        doc.Load(FileName);

    }
    protected void ExportImageButton_Click(object sender, ImageClickEventArgs e)
    {
        
        System.IO.StringWriter oStringWriter = new System.IO.StringWriter();
        System.Web.UI.HtmlTextWriter oHtmlTextWriter = new System.Web.UI.HtmlTextWriter(oStringWriter);
        
        try
        {
            //this.EnableViewState = false;

         
            if (AllFieldsListBox.Items.Count == 0)
            {
                ErrorLabel.Text = "Please select version.";
                return;
            }
            //if (AllFieldsListBox.SelectedItem == null)
            //{
            //    ErrorLabel.Text = "Please select version.";
            //    return;
            //}
           

            DateTime startDate;
            DateTime endDate;
            startDate = Convert.ToDateTime(StDateTextBox.Value);
            endDate = Convert.ToDateTime(EdDateTextBox.Value);

            string fromHours = "00";
            string toHours = "00";
            string fromMin = "00";
            string toMin = "00";

            if (FromDropDownList.SelectedIndex > 0)
            {
                fromHours = FromDropDownList.SelectedItem.Text;
            }
            if (FromMinuteDropDownList.SelectedIndex > 0)
            {
                fromMin = FromMinuteDropDownList.SelectedItem.Text;
            }

            if (ToDropDownList.SelectedIndex > 0)
            {
                toHours = ToDropDownList.SelectedItem.Value;
            }
            if (ToMinuteDropDownList.SelectedIndex > 0)
            {
                toMin = ToMinuteDropDownList.SelectedItem.Text;
            }

            string frmHoursFormat = "dd-MMM-yyyy " + fromHours + ":" + fromMin + ":00";
            string toHoursFormat = "dd-MMM-yyyy " + toHours + ":" + toMin + ":00";

            Reports objReports = new Reports();
            DataSet objDataSet = new DataSet();
            objReports.FormID = Convert.ToInt32(FormIdHiddenField.Value);
            objReports.VersionID = Convert.ToInt32(VersionIDHiddenField.Value);
            if (AllFieldsListBox.SelectedItem != null)
            {
                objReports.ColumnName = AllFieldsListBox.SelectedItem.Text;
            }
            else
            {
                objReports.ColumnName = "";
            }
            if (SelectedFieldsListBox.SelectedItem == null)
            {
                objReports.ColumnValue = "";
            }
            else
            {
                objReports.ColumnValue = SelectedFieldsListBox.SelectedItem.Text;
            }
            objReports.StDate = Convert.ToDateTime(startDate).ToString(frmHoursFormat);
            objReports.EndDate = Convert.ToDateTime(endDate).ToString(toHoursFormat);
            objDataSet = objReports.GetViewLogReport(objDataSet,userName);

            if (objDataSet.Tables.Count > 0)
            {
                if (objDataSet.Tables[0].Rows.Count == 0)
                {
                    ErrorLabel.Text = "Data not found.";
                    return;
                }
            }
            else
            {
                ErrorLabel.Text = "Data not found.";
                return;
            }
            DataTable dt = new DataTable();
            dt = objDataSet.Tables[0].Copy();
            int transid = 0;
            int rowcount = 0;
            int totaltimetaken = 0;
            for (int i = 0; i <= objDataSet.Tables[0].Rows.Count ; i++)
            {
                if (transid == 0)
                {
                    transid = Convert.ToInt32(objDataSet.Tables[0].Rows[i]["TransactionID"].ToString());
                }
                if (i != objDataSet.Tables[0].Rows.Count)
                {
                    if (transid == Convert.ToInt32(objDataSet.Tables[0].Rows[i]["TransactionID"].ToString()))
                    {
                        totaltimetaken = totaltimetaken + Convert.ToInt32(objDataSet.Tables[0].Rows[i]["timetaken"].ToString());
                    }

                    //else
                    //{
                    //    totaltimetaken = Convert.ToInt32(objDataSet.Tables[0].Rows[i]["timetaken"].ToString());
                    //}

                    if (transid != Convert.ToInt32(objDataSet.Tables[0].Rows[i]["TransactionID"].ToString()))
                    {
                        DataRow dr = dt.NewRow();
                        dr["FormName"] = "Total Time Taken";
                        dr["TimeTaken"] = totaltimetaken.ToString();
                        //dt.Rows.Add(dr);

                        dt.Rows.InsertAt(dr, i + rowcount);
                        rowcount = rowcount + 1;
                        totaltimetaken = Convert.ToInt32(objDataSet.Tables[0].Rows[i]["timetaken"].ToString());

                    }

                    transid = Convert.ToInt32(objDataSet.Tables[0].Rows[i]["TransactionID"].ToString());
                }
                else
                {
                    DataRow dr = dt.NewRow();
                    dr["FormName"] = "Total Time Taken";
                    dr["TimeTaken"] = totaltimetaken.ToString();
                    //dt.Rows.Add(dr);

                    dt.Rows.InsertAt(dr, i + rowcount);
                }

            }
            ExcelHelper.ToExcel(dt, "EVO_ViewLogReport_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xls", Page.Response);
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }
}
