using System;
using System.Data;
using System.Web.UI;
using System.Web.UI.WebControls;
using EVOLib;

public partial class Reports_CustomRealtimeReport : EvoGeneral
{
    Forms objForms = new Forms();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            StDateTextBox.Attributes.Add("onClick", "javascript:ShowCalendar(this,1900,2030,'dd/mmm/yyyy');");
            EdDateTextBox.Attributes.Add("onClick", "javascript:ShowCalendar(this,1900,2030,'dd/mmm/yyyy');");

            TeamRightImageButton.Attributes.Add("onClick", "javascript:return CheckListBoxIsSelected('" + AllTeamsListBox.ID + "','team');");
            TeamLeftImageButton.Attributes.Add("onClick", "javascript:return CheckListBoxIsSelected('" + SelectedTeamListBox.ID + "','team/s to remove');");
            FieldRightImageButton.Attributes.Add("onClick", "javascript:return CheckListBoxIsSelected('" + AllFieldsListBox.ID + "','field');");
            FieldLeftImageButton.Attributes.Add("onClick", "javascript:return CheckListBoxIsSelected('" + SelectedFieldsListBox.ID + "','field/s to remove');");
            ExportImageButton.Attributes.Add("onClick", "javascript:return Validate();");

            string stDate = StDateTextBox.ClientID.ToString();
            string edDate = EdDateTextBox.ClientID.ToString();
            StartDateImage.Attributes.Add("onClick", "javascript:ShowCalendar(" + stDate + ",1900,2030,'dd/mmm/yyyy');");
            EndDateImageButton.Attributes.Add("onClick", "javascript:ShowCalendar(" + edDate + ",1900,2030,'dd/mmm/yyyy');");

            StDateTextBox.Value = DateTime.Now.ToString("dd-MMM-yyyy");
            EdDateTextBox.Value = DateTime.Now.ToString("dd-MMM-yyyy");

            BindForms();
            BindTeamListBox();
        }
    }

    protected override void OnInit(EventArgs e)
    {
        if (!IsPostBack)
        {
            //Check if session has value if yes assign it to hidden fields.
            int frmID = ManageSession.FormID;
            int vrsnID = ManageSession.VersionID;

            if (frmID != 0 && vrsnID != 0)
            {
                FormIdHiddenField.Value = frmID.ToString();
                //VersionIDHiddenField.Value = vrsnID.ToString();
            }
            else
            {
                Response.Redirect("../AccessDenied.aspx", true);
            }
        }

        ActivateDeActivateControls();
        base.OnInit(e);
    }

    private void ActivateDeActivateControls()
    {
        Label lblModule = (Label)Master.FindControl("lblModule");
        lblModule.Text = "Custom Realtime Report";
        int cnt = Master.Controls.Count;
        ImageButton imgHome = (ImageButton)Page.FindControl("ctl00$imgHome");
        imgHome.Click += new ImageClickEventHandler(HomeButton_Clicked);
    }

    protected void HomeButton_Clicked(object sender, ImageClickEventArgs e)
    {
        Response.Redirect("../Admin/Default.aspx", true);
    }

    public void GetFieldNames()
    {
        DataSet objDataSet = new DataSet();
        try
        {
            objForms.FormID = Convert.ToInt32(FormIdHiddenField.Value);
            objForms.VersionID = Convert.ToInt32(VersionIDHiddenField.Value);
            objDataSet = objForms.GetFormsFieldsWithVersions(objDataSet,true);

            if (objDataSet.Tables[0].Rows.Count > 0)
            {
                //BindListBox(objDataSet, AllFieldsListBox, "Alias", "FieldID");
                BindListBox(objDataSet, AllFieldsListBox, "Alias", "Alias");
            }
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message;
        }
    }

    public void BindListBox(DataSet objDataSet, ListBox objListBox, string textField, string valueField)
    {
        try
        {
            objListBox.DataSource = objDataSet;
            objListBox.DataTextField = textField;
            objListBox.DataValueField = valueField;
            objListBox.DataBind();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    public void BindTeamListBox()
    {
        AllTeamsListBox.Items.Clear();
        AllTeamsListBox.Items.Insert(0, "Advisor");
        AllTeamsListBox.Items.Insert(1, "Team Coach");
        AllTeamsListBox.Items.Insert(2, "Team Leader");
        AllTeamsListBox.Items.Insert(3, "Team Operations Manager");
        AllTeamsListBox.Items.Insert(4, "Contact Centre Manager");
    }

    /// <summary>
    /// Add selected items from left listbox to right listbox.
    /// </summary>
    /// <param name="rListBox"></param>
    /// <param name="lListBox"></param>
    public void MoveItemsToRight(ListBox rListBox, ListBox lListBox)
    {
        bool iSExist = false;

        try
        {
            if (rListBox.SelectedIndex > -1)
            {
                for (int iRowCount = 0; iRowCount < rListBox.Items.Count; iRowCount++)
                {
                    if (rListBox.Items[iRowCount].Selected == true)
                    {
                        if (lListBox.Items.Count > 0)
                        {
                            for (int iCount = 0; iCount < lListBox.Items.Count; iCount++)
                            {
                                if (lListBox.Items[iCount].Text == rListBox.Items[iRowCount].Text)
                                {
                                    iSExist = true;
                                    break;
                                }
                            }
                        }

                        if (iSExist == false)
                        {
                            lListBox.Items.Add(rListBox.Items[iRowCount].Text);
                        }
                        else
                        {
                            iSExist = false;
                        }
                    }
                }
            }
            else
            {
                ErrorLabel.Text = "Please select Item/s to move to right.";
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    /// <summary>
    /// Remove Items from right listbox.
    /// </summary>
    public void RemoveItemsFromRight(ListBox rListBox)
    {
        try
        {
            if (rListBox.Items.Count > 0)
            {
                for (int iRowCount = 0; iRowCount < rListBox.Items.Count; iRowCount++)
                {
                    if (rListBox.Items[iRowCount].Selected == true)
                    {
                        rListBox.Items.Remove(rListBox.Items[iRowCount]);
                        iRowCount--;
                    }
                }
            }
            else
            {
                ErrorLabel.Text = "Please select item/s to remove.";
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void TeamRightImageButton_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            MoveItemsToRight(AllTeamsListBox, SelectedTeamListBox);
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message;
        }
    }

    protected void TeamLeftImageButton_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            RemoveItemsFromRight(SelectedTeamListBox);
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message;
        }
    }

    protected void FieldRightImageButton_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            MoveItemsToRight(AllFieldsListBox, SelectedFieldsListBox);
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message;
        }
    }

    protected void FieldLeftImageButton_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            RemoveItemsFromRight(SelectedFieldsListBox);
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message;
        }
    }

    protected void ExportImageButton_Click(object sender, ImageClickEventArgs e)
    {
        try
        {
            ErrorLabel.Text = "";
            GetSelectedItems();
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message;
        }
    }

    public void GetSelectedItems()
    {
        System.IO.StringWriter oStringWriter = new System.IO.StringWriter();
        System.Web.UI.HtmlTextWriter oHtmlTextWriter = new System.Web.UI.HtmlTextWriter(oStringWriter);

        try
        {
            //this.EnableViewState = false;

            if (SelectedTeamListBox.Items.Count == 0)
            {
                ErrorLabel.Text = "Please add Teams.";
                return;
            }
            if (SelectedFieldsListBox.Items.Count == 0)
            {
                ErrorLabel.Text = "Please add Fields.";
                return;
            }

            string team = "";
            string teams = "";
            string fields = "";
            string colHead = "";

            for (int iTeamCount = 0; iTeamCount < SelectedTeamListBox.Items.Count; iTeamCount++)
            {
                team = SelectedTeamListBox.Items[iTeamCount].Value;
                if (team == "Advisor")
                {
                    teams += "EmployeeID,FirstName +' '+LastName AS EmpName,";
                    colHead += "EmployeeID,EmpName,";
                }
                if (team == "Team Coach")
                {
                    teams += "TCEmpId, (CASE WHEN ET.TCEmpName = '' THEN 'NA' ELSE ET.TCEmpName END) AS TCEmpName,";
                    colHead += "TCEmpId, TCEmpName,";
                }
                else if (team == "Team Leader")
                {
                    teams += "TLEmpId, TLEmpName,";
                    colHead += "TLEmpId, TLEmpName,";
                }
                else if (team == "Team Operations Manager")
                {
                    teams += "TOMEmpId, TOMEmpName,";
                    colHead += "TOMEmpId, TOMEmpName,";

                }
                else if (team == "Contact Centre Manager")
                {
                    teams += "CCMEmpId, CCMEmpName,";
                    colHead += "CCMEmpId, CCMEmpName,";
                }
            }

            for (int iFieldCount = 0; iFieldCount < SelectedFieldsListBox.Items.Count; iFieldCount++)
            {
                fields += "[" + SelectedFieldsListBox.Items[iFieldCount].ToString() + "],";
            }

            if (teams != "")
            {
                teams = teams.Substring(0, teams.Length - 1);
            }

            fields = fields.Substring(0, fields.Length - 1);
            colHead = colHead.Substring(0, colHead.Length - 1);

            DateTime startDate;
            DateTime endDate;
            startDate = Convert.ToDateTime(StDateTextBox.Value);
            endDate = Convert.ToDateTime(EdDateTextBox.Value);

            string fromHours = "00";
            string toHours = "00";
            string fromMin = "00";
            string toMin = "00";

            if (FromDropDownList.SelectedIndex > 0)
            {
                fromHours = FromDropDownList.SelectedItem.Text;
            }
            if (FromMinuteDropDownList.SelectedIndex > 0)
            {
                fromMin = FromMinuteDropDownList.SelectedItem.Text;
            }

            if (ToDropDownList.SelectedIndex > 0)
            {
                toHours = ToDropDownList.SelectedItem.Value;
            }
            if (ToMinuteDropDownList.SelectedIndex > 0)
            {
                toMin = ToMinuteDropDownList.SelectedItem.Text;
            }

            string frmHoursFormat = "dd-MMM-yyyy " + fromHours + ":" + fromMin + ":00";
            string toHoursFormat = "dd-MMM-yyyy " + toHours + ":" + toMin + ":00";

            Reports objReports = new Reports();
            DataSet objDataSet = new DataSet();
            objReports.FormID = Convert.ToInt32(FormIdHiddenField.Value);
            objReports.VersionID = Convert.ToInt32(VersionIDHiddenField.Value);
            objReports.ColumnName = fields;
            objReports.TeamName = teams;
            objReports.ColHeaders = colHead;
            objReports.StDate = Convert.ToDateTime(startDate).ToString(frmHoursFormat);
            objReports.EndDate = Convert.ToDateTime(endDate).ToString(toHoursFormat);
            objReports.IsGMT = (rdlTimeFormat.SelectedValue == "GMT");
            objDataSet = objReports.GetCustomRealtimeReport(objDataSet,userName);

            if (objDataSet.Tables.Count > 0)
            {
                if (objDataSet.Tables[0].Rows.Count == 0)
                {
                    ErrorLabel.Text = "Data not found for the selected date range.";
                    return;
                }
            }
            else
            {
                ErrorLabel.Text = "Data not found for the selected date range";
                return;
            }

            ExcelHelper.ToExcel(objDataSet, "EVO_CustomRealtimeReport_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xls", Page.Response);

            //Commented by Imran.

            //GridView objGridView = new GridView();
            //objGridView.DataSource = objDataSet;
            //objGridView.DataBind();

            //objGridView.RenderControl(oHtmlTextWriter);
            //Response.Write(oStringWriter.ToString());

            //Response.AddHeader("Content-disposition", "attachment;filename=EVO_CustomRealtimeReport_" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xls");
            //Response.ContentType = "application/vnd.ms-excel";
            //Response.Charset = "UTF-8";
            //Response.End();
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void BindForms()
    {
        try
        {
            DataSet objDataSet = new DataSet();
            Reports objReports = new Reports();
            objReports.FormID = Convert.ToInt32(FormIdHiddenField.Value);
            objReports.UserID = 0;
            objReports.Module = "FormVersions";
            objReports.StDate = null;
            objReports.EndDate = null;
            objDataSet = objReports.GetFormsForReports(objDataSet, "0");
            if (objDataSet.Tables[0].Rows.Count > 0)
            {
                FormVersionGridView.DataSource = objDataSet;
                FormVersionGridView.DataBind();
            }
            else
            {
                ErrorLabel.Text = "No Record Found.";
                ExportImageButton.Visible = false;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }
    }

    protected void ClearFields()
    {
        try
        {
            SelectedFieldsListBox.Items.Clear();
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message;
        }
    }

    protected void FormVersionGridView_RowEditing(object sender, GridViewEditEventArgs e)
    {
        try
        {
            VersionIDHiddenField.Value = Convert.ToString(FormVersionGridView.DataKeys[e.NewEditIndex].Values["VersionID"]);
            VersionNameLabel.Text = " Version Name: " + Convert.ToString(FormVersionGridView.DataKeys[e.NewEditIndex].Values["VersionName"]);
            GetFieldNames();
            ClearFields();
            ErrorLabel.Text = "";
        }
        catch (Exception ex)
        {
            ErrorLabel.Text = ex.Message;
        }
    }

    protected void FormVersionGridView_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        FormVersionGridView.PageIndex = e.NewPageIndex;
        BindForms();
        ClearFields();
    }
}

