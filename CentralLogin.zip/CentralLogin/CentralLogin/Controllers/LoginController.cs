﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using AuthenticationAPI;
using System.Data;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;

namespace CentralLogin.Controllers
{
    public class LoginController : ApiController
    {
        DataEntity db = new DataEntity();

        // GET: api/Login
        public IEnumerable<string> Get()
        {
            return new string[] { "value1", "value2" };
        }

        // GET: api/Login/5
        public string Post(string Login, string Password, string connection)
        {
            var emp = db.Employee.Where(x => x.login == Login && x.password == Password).ToList();
            var json = JsonConvert.SerializeObject(emp, Formatting.Indented);

            //DataSet ds = new DataSet();
            //ds = UserAuth.AuthenticateLogin(Login, Password, connection);
            //string json = JsonConvert.SerializeObject(ds.Tables[0], Formatting.Indented);

            return json;
        }

        // POST: api/Login
        public bool Post([FromBody]JObject value)
        {
            bool result = false;
            string center = (string)value["costCentre"];
            var costCentre = db.CostCentres.Where(x => x.CostCentre == center).SingleOrDefault() == null ? 0 : db.CostCentres.Where(x => x.CostCentre == center).SingleOrDefault().CostCentreID;
            var UserId = db.CentralMain.DefaultIfEmpty().Max(r => r == null ? 0 : r.EmpUserID) + 1;

            Employees emp = new Employees();
            emp.employeeID = (int)value["employeeID"];
            emp.dateOfJoining = (DateTime)value["dateOfJoining"];
            emp.dateProductive = null;
            emp.firstName = (string)value["firstName"];
            emp.middleName = (string)value["middleName"];
            emp.lastName = (string)value["lastName"];
            emp.gender = "";
            emp.dateOfBirth = (DateTime)value["dateOfBirth"];
            emp.currentAddress1 = "";
            emp.currentAddress2 = "";
            emp.currentAddress3 = "";
            emp.area = "";
            emp.landmark = "";
            emp.currentAddressCity = "";
            emp.currentAddressPin = "";
            emp.telephoneNumber1 = "";
            emp.permanentAddress1 = "";
            emp.permanentAddress2 = "";
            emp.permanentAddress3 = "";
            emp.permanentAddressCity = "";
            emp.permanentAddressPin = "";
            emp.telephoneNumber2 = "";
            emp.mobileNumber = "";
            emp.loginWinset = null;
            emp.loginCCAA = null;
            emp.band = 0;
            emp.designationID = 0;
            emp.departmentID = 0;
            emp.email = (string)value["email"];
            emp.login = (string)value["login"];
            emp.status = 1;
            emp.password = (string)value["password"];
            emp.bossid = 0;
            emp.priviledge = 7;
            emp.costCentre = (string)value["costCentre"];
            emp.Location = (string)value["Location"];
            emp.leaves = null;
            emp.presentstatus = null;
            emp.transportaccesslevel = null;
            emp.natureWork = "X24";
            emp.partTimer = false;
            emp.QL = null;
            emp.PrevJoiningDate = null;
            emp.Master = null;
            emp.whenentered = DateTime.Now;



            Central_Employee_Main main = new Central_Employee_Main();
            main.EmpUserID = (long)UserId;
            main.EmployeeID = (int)value["employeeID"];
            main.FirstName = (string)value["firstName"];
            main.LastName = (string)value["lastName"];
            main.DesignationID = 0;
            main.CostCentreID = (byte)costCentre;
            main.DepartmentID = null;
            main.BossUserID = 0;
            main.BossID = 0;
            main.Login = (string)value["login"];
            main.Password = (string)value["password"];
            main.Email = (string)value["email"];
            main.Location = (string)value["Location"];
            main.Band = "0";
            main.Status = true;
            main.LastUpdated = DateTime.Now;
            main.LastUsedComputer = null;
            main.IsLoggedIn = null;


            db.Database.Initialize(true);

            db.Employee.Add(emp);
            db.CentralMain.Add(main);

            int res = db.SaveChanges();

            if (res > 0)
                result = true;


            //AuthProperties auth = new AuthProperties();
            //auth.employeeID = (string)value["employeeID"];
            //auth.dateOfJoining = (DateTime)value["dateOfJoining"];
            //auth.firstName = (string)value["firstName"];
            //auth.middleName = (string)value["middleName"];
            //auth.lastName = (string)value["lastName"];
            //auth.dateOfBirth = (DateTime)value["dateOfBirth"];
            //auth.email = (string)value["email"];
            //auth.login = (string)value["login"];
            //auth.password = (string)value["password"];
            //auth.costCentre = (string)value["costCentre"];
            //auth.Location = (string)value["Location"];
            //auth.connection = (string)value["connection"];

            //bool result = UserAuth.AddUserDetails(auth);

            return result;
        }

        // PUT: api/Login/5
        public void Put(int id, [FromBody]string value)
        {
        }

        // DELETE: api/Login/5
        public void Delete(int id)
        {
        }
    }
}
