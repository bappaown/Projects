﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthenticationAPI
{
    public class AuthProperties
    {
        public string employeeID { get; set; }
        public DateTime dateOfJoining { get; set; }
        public string firstName { get; set; }
        public string middleName { get; set; }
        public string lastName { get; set; }
        public DateTime dateOfBirth { get; set; }
        public string email { get; set; }
        public string login { get; set; }
        public string password { get; set; }
        public string costCentre { get; set; }
        public string Location { get; set; }
        public string connection { get; set; }
    }
}
