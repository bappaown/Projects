﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AuthenticationAPI
{
    public class Central_Employee_Main
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Int64 EmpUserID { get; set; }
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public Int16? DesignationID { get; set; }
        public byte? CostCentreID { get; set; }
        public int? DepartmentID { get; set; }
        public Int64? BossUserID { get; set; }
        public int? BossID { get; set; }
        public string Login { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string Location { get; set; }
        public string Band { get; set; }
        public Boolean Status { get; set; }
        public DateTime? LastUpdated { get; set; }
        public string LastUsedComputer { get; set; }
        public Boolean? IsLoggedIn { get; set; }
    }
}
