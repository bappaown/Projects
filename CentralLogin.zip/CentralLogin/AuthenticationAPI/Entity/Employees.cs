﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AuthenticationAPI
{
    public class Employees
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int employeeID { get; set; }
        public DateTime? dateOfJoining { get; set; }
        public DateTime? dateProductive { get; set; }
        public string firstName { get; set; }
        public string middleName { get; set; }
        public string lastName { get; set; }
        public string gender { get; set; }
        public DateTime? dateOfBirth { get; set; }
        public string currentAddress1 { get; set; }
        public string currentAddress2 { get; set; }
        public string currentAddress3 { get; set; }
        public string area { get; set; }
        public string landmark { get; set; }
        public string currentAddressCity { get; set; }
        public string currentAddressPin { get; set; }
        public string telephoneNumber1 { get; set; }
        public string permanentAddress1 { get; set; }
        public string permanentAddress2 { get; set; }
        public string permanentAddress3 { get; set; }
        public string permanentAddressCity { get; set; }
        public string permanentAddressPin { get; set; }
        public string telephoneNumber2 { get; set; }
        public string mobileNumber { get; set; }
        public Int16? loginWinset { get; set; }
        public string loginCCAA { get; set; }
        public Int16 band { get; set; }
        public Int16? designationID { get; set; }
        public Int16? departmentID { get; set; }
        public string email { get; set; }
        public string login { get; set; }
        public Int16 status { get; set; }
        public string password { get; set; }
        public int? bossid { get; set; }
        public Int16 priviledge { get; set; }
        public string costCentre { get; set; }
        public string Location { get; set; }
        public Boolean? leaves { get; set; }
        public Boolean? presentstatus { get; set; }
        public decimal? transportaccesslevel { get; set; }
        public string natureWork { get; set; }
        public Boolean partTimer { get; set; }
        public string QL { get; set; }
        public DateTime? PrevJoiningDate { get; set; }
        [Column("_Master")]
        public Guid? Master { get; set; }
        public DateTime? whenentered { get; set; }
    }
}
