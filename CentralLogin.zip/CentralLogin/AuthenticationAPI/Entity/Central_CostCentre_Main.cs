﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace AuthenticationAPI
{
    public class Central_CostCentre_Main
    {
        [Key]
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public Byte CostCentreID { get; set; }
        public string CostCentre { get; set; }
        public string Location { get; set; }
        public Int64 AddedBy { get; set; }
        public DateTime AddedWhen { get; set; }
    }
}
