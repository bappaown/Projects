﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;

namespace AuthenticationAPI
{
    public static class UserAuth
    {
        //private UserAuth() { }

        public static DataSet AuthenticateLogin(string Login, string Password, string connection)
        {
            DataSet ds = new DataSet();
            try
            {
                DataCarrier carrier = new DataCarrier(connection);

                string commandText = "Proc_AuthenticateLogin";

                SqlParameter[] param = new SqlParameter[2];
                param[0] = new SqlParameter("@Login", Login);
                param[1] = new SqlParameter("@Password", Password);
                ds = carrier.ExecuteDataset(commandText, param);
            }
            catch (Exception)
            {
                //throw ex;
            }
            return ds;
        }


        public static bool AddUserDetails(AuthProperties value)
        {
            bool result = false;
            try
            {
                DataCarrier carrier = new DataCarrier(value.connection);

                string spName = "Proc_InsertUserDetails";

                SqlParameter[] parameters = new SqlParameter[11];
                parameters[0] = new SqlParameter("@employeeID", value.employeeID);
                parameters[1] = new SqlParameter("@dateOfJoining", value.dateOfJoining);
                parameters[2] = new SqlParameter("@firstName", value.firstName);
                parameters[3] = new SqlParameter("@middleName", value.middleName);
                parameters[4] = new SqlParameter("@lastName", value.lastName);
                parameters[5] = new SqlParameter("@dateOfBirth", value.dateOfBirth);
                parameters[6] = new SqlParameter("@email", value.email);
                parameters[7] = new SqlParameter("@login", value.login);
                parameters[8] = new SqlParameter("@password", value.password);
                parameters[9] = new SqlParameter("@costCentre", value.costCentre);
                parameters[10] = new SqlParameter("@Location", value.Location);
                result = carrier.ExecuteNonQuery(spName, parameters);
            }
            catch (Exception)
            {
                //throw ex;
            }
            return result;
        }

    }
}