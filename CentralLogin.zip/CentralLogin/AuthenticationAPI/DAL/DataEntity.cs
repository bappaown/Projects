﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AuthenticationAPI
{
    public class DataEntity : DbContext
    {
        public DataEntity() : base("constr")
        {
            Database.SetInitializer<DataEntity>(new CreateDatabaseIfNotExists<DataEntity>());
        }
        public DbSet<Employees> Employee { get; set; }
        public DbSet<Central_Employee_Main> CentralMain { get; set; }
        public DbSet<Central_CostCentre_Main> CostCentres { get; set; }
        
        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            //modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
            base.OnModelCreating(modelBuilder);
        }

    }
}
