﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;

namespace AuthenticationAPI
{
    public class DataCarrier
    {
        string connectionString;
        /// <summary>
        /// This parameterize constructor used for initialize connection with DB
        /// </summary>
        /// /// <param name="connection">parameter as connection string</param>
        /// <returns></returns>
        public DataCarrier(string connection)
        {
            connectionString = ConfigurationManager.ConnectionStrings[connection].ToString();
        }

        /// <summary>
        /// This method used for fetch data
        /// </summary>
        /// <param name="spName">Store procedure Name</param>
        /// <param name="parameters">parameters as Dictionary<string, string></param>
        /// <returns></returns>
        public DataSet ExecuteDataset(string spName, SqlParameter[] parameters)
        {
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    DataSet ds = new DataSet();
                    using (SqlCommand sqlCmd = new SqlCommand(spName, sqlCon))
                    {
                        sqlCmd.CommandTimeout = 300;
                        sqlCmd.CommandType = CommandType.StoredProcedure;
                        if (parameters != null)
                        {
                            foreach (SqlParameter paramName in parameters)
                            {
                                sqlCmd.Parameters.Add(paramName);
                            }
                        }

                        SqlDataAdapter sqlDa = new SqlDataAdapter();
                        sqlCon.Open();
                        sqlDa.SelectCommand = sqlCmd;
                        sqlDa.Fill(ds);
                    }
                    return ds;
                }
            }
            catch (Exception)
            {
                throw;
            }
        }

        /// <summary>
        /// This method used for post data
        /// </summary>
        /// <param name="spName">Store procedure Name</param>
        /// <param name="parameters">parameters as Dictionary<string, string></param>
        /// <returns></returns>
        public bool ExecuteNonQuery(string spName, SqlParameter[] parameters)
        {
            bool status = false;
            try
            {
                using (SqlConnection sqlCon = new SqlConnection(connectionString))
                {
                    DataSet ds = new DataSet();
                    SqlCommand sqlCmd = new SqlCommand(spName, sqlCon);
                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    if (parameters != null)
                    {
                        foreach (SqlParameter paramName in parameters)
                        {
                            sqlCmd.Parameters.Add(paramName);
                        }
                    }
                    sqlCon.Open();
                    int count = sqlCmd.ExecuteNonQuery();
                    if (count > 0)
                        status = true;
                    sqlCmd.Dispose();
                }
            }
            catch (Exception)
            {
                throw;
            }
            return status;
        }

    }
}
