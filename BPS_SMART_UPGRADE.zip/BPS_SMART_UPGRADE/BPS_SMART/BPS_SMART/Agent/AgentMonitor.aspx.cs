﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;
using BSAT.DAL;
using BSAT.BLL;
using BSAT.Entity;
using System.Web.Services;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using Newtonsoft.Json;

namespace BPS_SMART.Agent
{
    public partial class AgentMonitor : System.Web.UI.Page
    {
        public static string empUserId = string.Empty;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                Employee oEmp = new Employee();
                AdminMaster master = (AdminMaster)(Page.Master);
                oEmp = master.IsUserAthenticate();
                empUserId = oEmp.EmpUserId;
                hdnEmpUserId.Value = oEmp.EmpUserId;
                //ViewState["empUserId"] = oEmp.EmpUserId;
                //hdnEmpUserId.Value = (HttpContext.Current.Request.Cookies["SMART"] == null) ? string.Empty : HttpContext.Current.Request.Cookies["SMART"]["EmpUserId"].ToString();

                FillScheduleCodeListBox();
                BindProjectList();
            }
        }

        private void FillScheduleCodeListBox()
        {
            DataSet ds = new DataSet();
            ds = new LogSheetController().GetScheduleCode();

            DataRow dr = ds.Tables[0].NewRow();
            dr["Description"] = "SignOn";
            ds.Tables[0].Rows.Add(dr);

            DataView dv = ds.Tables[0].DefaultView;
            dv.Sort = "Description";
            DataTable sortDt = dv.ToTable();

            ddlScheduleCode.DataSource = sortDt;
            ddlScheduleCode.DataTextField = "Description";
            ddlScheduleCode.DataValueField = "CodeNumber";
            ddlScheduleCode.DataBind();
            //ddlScheduleCode.Items.Insert(0, new ListItem("Select", "0"));

            ListItem selectedListItem = ddlScheduleCode.Items.FindByText("Blank Idle");
            if (selectedListItem != null)
                selectedListItem.Selected = true;
        }

        protected void BindProjectList()
        {
            DataSet dsPrjct = new DataSet();
            dsPrjct = new ReportsController().BindProjectList();
            ddlProject.DataSource = dsPrjct.Tables[0];
            ddlProject.DataTextField = "ProjectList";
            ddlProject.DataValueField = "ID";
            ddlProject.DataBind();
            ddlProject.Items.Insert(0, new ListItem("Select", "0"));
        }

        [WebMethod]
        public static string GetSessionId()
        {
            string SessionId = string.Empty;
            string empUserID = empUserId;
            //string empUserID = ViewState["empUserId"].ToString();
            //string empUserID = (HttpContext.Current.Request.Cookies["SMART"] == null) ? string.Empty : HttpContext.Current.Request.Cookies["SMART"]["EmpUserId"].ToString();
            DataSet odrEmp = null;
            SqlParameter[] oParam = null;
            oParam = new SqlParameter[1];
            oParam[0] = new SqlParameter("@EmpUserID", empUserID);

            odrEmp = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "proc_GetSessionId", oParam);
            if (odrEmp != null)
            {
                if (odrEmp.Tables[0].Rows.Count > 0)
                {
                    SessionId = odrEmp.Tables[0].Rows[0][0].ToString();
                }
            }

            return SessionId;
        }

        [WebMethod]
        public static string GetStatusHistory(int sessionId)
        {
            string js = string.Empty;
            //        string getStatusHistoryQry = "SELECT CodeDescription AS Activity,PD.ProjectName," +
            //"SUBSTRING (CONVERT(varchar,LogStartTime,13), 0,21) AS StartDateTime,SUBSTRING (CONVERT(varchar,LogEndTime,13), 0,21) AS EndDateTime," +
            //"CONVERT(varchar,LogStartTime,108) AS StartTime,CONVERT(varchar,LogEndTime,108)AS EndTime," +
            //"CONVERT(varchar(6), DATEDIFF(second, LogStartTime, LogEndTime)/3600) + ':' + RIGHT('0' + CONVERT(varchar(2), (DATEDIFF(second, LogStartTime, LogEndTime) % 3600) / 60), 2) + ':' + RIGHT('0' + CONVERT(varchar(2), DATEDIFF(second, LogStartTime, LogEndTime) % 60), 2) AS TotalTime " +
            // " FROM LogSheet LS  WITH (nolock) left Join ProjectDetails PD " +
            //"on Convert(int,LS.ProjectName)=PD.ID WHERE (SessionId =" + sessionId + ") ORDER BY  LogSheetId DESC";

            DataSet dsStatusHistory = new DataSet();
            SqlParameter[] oParam = null;
            oParam = new SqlParameter[1];
            oParam[0] = new SqlParameter("@SessionId", sessionId);
            try
            {
                dsStatusHistory = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "proc_Get_GetStatusHistory", oParam);
                //dsStatusHistory = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, getStatusHistoryQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            if (dsStatusHistory.Tables[0].Rows.Count > 0)
            {
                js = JsonConvert.SerializeObject(dsStatusHistory.Tables[0]);
            }

            return js;
        }

        [WebMethod]
        public static DataSet IsUserAlreadySignedIn(int empUserId)
        {
            string pcName = "";
            bool result = false;
            int rowsAffected = 0;
            string strQry = "";

            //string getEmpUserIdQry = "SELECT SessionId, PCName FROM SessionMaster WITH (nolock) WHERE EmpUserId =" + empUserId + " AND SignOutTime IS NULL";
            DataSet dsIsUserSignedIn = new DataSet();
            SqlParameter[] oParam = null;
            oParam = new SqlParameter[1];
            oParam[0] = new SqlParameter("@EmpUserId", empUserId);
            try
            {
                dsIsUserSignedIn = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "proc_IsUserAlreadySignedIn", oParam);
                //dsIsUserSignedIn = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, getEmpUserIdQry);

                if (dsIsUserSignedIn.Tables.Count > 0)
                {
                    if (dsIsUserSignedIn.Tables[0].Rows.Count > 0)
                    {
                        try
                        {
                            for (int sessionCount = 0; sessionCount < dsIsUserSignedIn.Tables[0].Rows.Count; sessionCount++)
                            {
                                //strQry = "Update SessionMaster WITH (ROWLOCK) SET " +
                                //        " SignOutTime = getdate() " +
                                //        " Where SessionId = '" + dsIsUserSignedIn.Tables[0].Rows[sessionCount]["SessionId"].ToString() + "'";
                                SqlParameter[] aParam = null;
                                aParam = new SqlParameter[1];
                                aParam[0] = new SqlParameter("@SessionId", dsIsUserSignedIn.Tables[0].Rows[sessionCount]["SessionId"].ToString());

                                rowsAffected = int.Parse(SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "proc_UpdateSessionMaster", aParam).ToString());
                                //rowsAffected = int.Parse(SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.Text, strQry).ToString());

                                if (rowsAffected > 0)
                                {
                                    //string updateQry = "Update LogSheet WITH (ROWLOCK) SET " +
                                    //             " LogEndTime = getdate() " +
                                    //             " Where SessionId = " + int.Parse(dsIsUserSignedIn.Tables[0].Rows[sessionCount]["SessionId"].ToString()) + " AND LogEndTime IS NULL";

                                    SqlParameter[] eParam = null;
                                    eParam = new SqlParameter[1];
                                    eParam[0] = new SqlParameter("@SessionId", dsIsUserSignedIn.Tables[0].Rows[sessionCount]["SessionId"].ToString());

                                    rowsAffected = int.Parse(SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "proc_UpdateLogSheet", eParam).ToString());
                                    //rowsAffected = int.Parse(SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.Text, updateQry).ToString());
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsIsUserSignedIn;
        }

        [WebMethod]
        public static bool SignOutUser(int sessionId)
        {
            string pcName = "";
            bool result = false;
            int rowsAffected = 0;
            string strQry = "";
            string logQuitQry = "";

            try
            {

                //strQry = "Update SessionMaster WITH (ROWLOCK) SET " +
                //        " SignOutTime = getdate() " +
                //        " Where SessionId = '" + sessionId + "'";

                //rowsAffected = int.Parse(SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.Text, strQry).ToString());

                SqlParameter[] aParam = null;
                aParam = new SqlParameter[1];
                aParam[0] = new SqlParameter("@SessionId", sessionId);

                rowsAffected = int.Parse(SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "proc_UpdateSessionMaster", aParam).ToString());
                if (rowsAffected > 0)
                {
                    result = true;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }


            return result;
        }

        [WebMethod]
        public static bool SignOutUserFromLogsheet(int sessionId)
        {
            string pcName = "";
            bool result = false;
            int rowsAffected = 0;
            string strQry = "";
            string logQuitQry = "";

            try
            {

                //strQry = "Update LogSheet WITH (ROWLOCK) SET " +
                //        " LogEndTime = getdate() " +
                //        " Where SessionId = '" + sessionId + "' AND LogEndTime IS NULL";

                //rowsAffected = int.Parse(SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.Text, strQry).ToString());
                SqlParameter[] eParam = null;
                eParam = new SqlParameter[1];
                eParam[0] = new SqlParameter("@SessionId", sessionId);

                rowsAffected = int.Parse(SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "proc_UpdateLogSheet", eParam).ToString());

                if (rowsAffected > 0)
                {
                    result = true;
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }


            return result;
        }



        [WebMethod]
        public static bool CheckAndInsertLogSheetEntryNew(int sessionId, int empUserId, int codeNumber, string codeDesc, bool isIdle, string projectName, string subDepartment)
        {
            int rowsAffected = 0;
            bool insertResult = false;
            bool updateResult = false;
            bool finalResult = false;
            string insertLogSheetQry = "";
            string selectQry = "";
            string selectQryForProductiveFlag = "";
            string updateQry = "";

            bool isProductive = false;

            //selectQry = "SELECT LogSheetId FROM LogSheet WITH (nolock) WHERE SessionId = " + sessionId + " AND LogEndTime IS NULL";
            DataSet dsPrevLog = new DataSet();

            //selectQryForProductiveFlag = "SELECT IsProjectDependant FROM ScheduleCode WITH (nolock) WHERE CodeNumber = " + codeNumber + " ";
            DataSet dsCodeProductive = new DataSet();
            try
            {
                SqlParameter[] oParam = null;
                oParam = new SqlParameter[1];
                oParam[0] = new SqlParameter("@SessionId", sessionId);
                dsPrevLog = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "proc_GerLogSheetId", oParam);
                //dsPrevLog = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, selectQry);

                SqlParameter[] aParam = null;
                aParam = new SqlParameter[1];
                aParam[0] = new SqlParameter("@CodeNumber", codeNumber);
                dsCodeProductive = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "proc_GerProjectDependant", aParam);
                //dsCodeProductive = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, selectQryForProductiveFlag);

                if (dsCodeProductive.Tables.Count > 0)
                {
                    if (dsCodeProductive.Tables[0].Rows.Count > 0)
                    {
                        isProductive = Convert.ToBoolean(dsCodeProductive.Tables[0].Rows[0][0].ToString());
                    }
                }

                if (dsPrevLog.Tables.Count > 0)
                {
                    if (dsPrevLog.Tables[0].Rows.Count > 0)
                    {
                        try
                        {
                            for (int sessionCount = 0; sessionCount < dsPrevLog.Tables[0].Rows.Count; sessionCount++)
                            {
                                //updateQry = "Update LogSheet WITH (ROWLOCK) SET " +
                                //        " LogEndTime = getdate() " +
                                //        " Where LogSheetId = " + int.Parse(dsPrevLog.Tables[0].Rows[0]["LogSheetId"].ToString()) + "";

                                //rowsAffected = int.Parse(SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.Text, updateQry).ToString());
                                SqlParameter[] eParam = null;
                                eParam = new SqlParameter[1];
                                eParam[0] = new SqlParameter("@LogSheetId", dsPrevLog.Tables[0].Rows[0]["LogSheetId"].ToString());

                                rowsAffected = int.Parse(SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "proc_UpdateLogSheetById", eParam).ToString());

                                if (rowsAffected > 0)
                                {
                                    updateResult = true;
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            //throw ex;
                        }

                        if (updateResult)
                        {
                            //insertLogSheetQry = "INSERT INTO LogSheet (SessionId, " +
                            //         " EmpUserId, CodeNumber, CodeDescription, CodeId, IsIdle,ProjectName,SubDepartment,IsProductive) VALUES " +
                            //         "(" + sessionId + ", " +
                            //         "" + empUserId + ", " +
                            //         "" + codeNumber + ", " +
                            //          "'" + codeDesc + "', " +
                            //          "" + codeNumber + ", " +
                            //            "'" + isIdle + "', " +
                            //              "'" + projectName + "', " +
                            //               "'" + subDepartment + "', " +
                            //          "'" + isProductive + "')";

                            try
                            {
                                SqlParameter[] sParam = null;
                                sParam = new SqlParameter[8];
                                sParam[0] = new SqlParameter("@SessionId", sessionId);
                                sParam[1] = new SqlParameter("@EmpUserId", empUserId);
                                sParam[2] = new SqlParameter("@CodeNumber", codeNumber);
                                sParam[3] = new SqlParameter("@CodeDesc", codeDesc);
                                sParam[4] = new SqlParameter("@isIdle", isIdle);
                                sParam[5] = new SqlParameter("@ProjectName", projectName);
                                sParam[6] = new SqlParameter("@SubDepartment", subDepartment);
                                sParam[7] = new SqlParameter("@isProductive", isProductive);

                                rowsAffected = int.Parse(SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "proc_InsertDataInLogSheet", sParam).ToString());

                                //rowsAffected = int.Parse(SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.Text, insertLogSheetQry).ToString());

                                if (rowsAffected > 0)
                                {
                                    insertResult = true;
                                    finalResult = true;
                                }
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                            }
                        }
                    }
                    else
                    {
                        //insertLogSheetQry = "INSERT INTO LogSheet (SessionId, " +
                        //             " EmpUserId, CodeNumber, CodeDescription, CodeId, IsIdle,ProjectName,SubDepartment,IsProductive) VALUES " +
                        //             "(" + sessionId + ", " +
                        //             "" + empUserId + ", " +
                        //             "" + codeNumber + ", " +
                        //              "'" + codeDesc + "', " +
                        //              "" + codeNumber + ", " +
                        //               "'" + isIdle + "', " +
                        //                "'" + projectName + "', " +
                        //              "'" + subDepartment + "', " +
                        //              "'" + isProductive + "')";

                        try
                        {

                            SqlParameter[] sParam = null;
                            sParam = new SqlParameter[8];
                            sParam[0] = new SqlParameter("@SessionId", sessionId);
                            sParam[1] = new SqlParameter("@EmpUserId", empUserId);
                            sParam[2] = new SqlParameter("@CodeNumber", codeNumber);
                            sParam[3] = new SqlParameter("@CodeDesc", codeDesc);
                            sParam[4] = new SqlParameter("@isIdle", isIdle);
                            sParam[5] = new SqlParameter("@ProjectName", projectName);
                            sParam[6] = new SqlParameter("@SubDepartment", subDepartment);
                            sParam[7] = new SqlParameter("@isProductive", isProductive);

                            rowsAffected = int.Parse(SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "proc_InsertDataInLogSheet", sParam).ToString());

                            //rowsAffected = int.Parse(SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.Text, insertLogSheetQry).ToString());

                            if (rowsAffected > 0)
                            {
                                insertResult = true;
                                finalResult = true;
                            }
                        }
                        catch (Exception ex)
                        {
                            throw ex;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }


            return finalResult;
        }
    }
}