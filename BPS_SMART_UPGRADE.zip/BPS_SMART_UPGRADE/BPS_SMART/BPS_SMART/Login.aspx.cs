﻿using BSAT.Entity;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BPS_SMART
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogIn_Click(object sender, EventArgs e)
        {
            string ntLogin = txtUserId.Text;
            string strPassword = TxtPassword.Text;
            string Platform = "";
            BpsLogin RC = null;
            Employee emp = new Employee();
            try
            {
                if (ntLogin == string.Empty)
                {
                    lblmsg.Text = "Please Enter UserId.";
                }
                else if (strPassword == string.Empty)
                {
                    lblmsg.Text = "Please Enter Password.";
                }
                else
                {
                    RC = new BpsLogin();
                    emp = RC.GetEmployeeDetails(ntLogin, strPassword, Platform);
                    string msg = emp.ErrorMessage;

                    if (msg == "Success")
                    {
                        HttpCookie userCredentials = new HttpCookie("SMART");
                        userCredentials["Employee"] = EnryptString(emp.EmpUserId + '|' + emp.EmpName + '|' + emp.RoleID);
                        //userCredentials["EmpUserId"] = emp.EmpUserId;
                        //userCredentials["EmpName"] = emp.EmpName;
                        //userCredentials["RoleID"] = emp.RoleID.ToString();
                        userCredentials.Expires = DateTime.Now.AddHours(12);
                        if (!HttpContext.Current.Response.IsRequestBeingRedirected)
                            Response.AppendCookie(userCredentials);

                        if (emp.RoleID == (int)Role.Admin || emp.RoleID == (int)Role.SuperAdmin)
                        {
                            Response.Redirect("Admin/BSATMonitor.aspx");
                        }
                        else
                        {
                            Response.Redirect("Agent/AgentMonitor.aspx");
                        }
                    }
                    else
                    {
                        lblmsg.Text = "Invalid Credential.";
                        Response.Write(msg);
                    }
                }
            }
            finally
            {
                RC = null;
            }
        }

        public string EnryptString(string strEncrypted)
        {
            byte[] b = System.Text.ASCIIEncoding.ASCII.GetBytes(strEncrypted);
            string encrypted = Convert.ToBase64String(b);
            return encrypted;
        }
    }
}