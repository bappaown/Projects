﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for LogSheet
/// </summary>
/// 
namespace BSAT.Entity
{
    public class LogSheet
    {
        public LogSheet()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        public int CodeId { get; set; }
        public int LogSheetId { get; set; }
        public int SessionId { get; set; }
        public int EmpUserId { get; set; }
        public string EmpName { get; set; }
        public string  TimeSpent { get; set; }
        public string TotalSecondSpent { get; set; }
        public int CodeNumber { get; set; }
        public string CodeDescription { get; set; }
        public string LogStartTime { get; set; }
        public string LogEndTime { get; set; }
        public int LoginWinset { get; set; }
        public string  PCName { get; set; }
        public string DeptName { get; set; }
        public string ProjectName { get; set; }
        public string SubDepartment { get; set; }
        public bool  IsIdle { get; set; }

    }
}
