﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace BSAT.Entity
{
    public enum UserType
    {
        Admin, SuperAdmin, GeneralUser
    }

    public enum Role
    {
        Admin = 1,
        SuperAdmin = 2,
        Agent = 3
        

    }

    /// <summary>
    /// Summary description for CommonEnums
    /// </summary>
    public class CommonEnums
    {
        public CommonEnums()
        {
            //
            // TODO: Add constructor logic here
            //
        }


    }
}