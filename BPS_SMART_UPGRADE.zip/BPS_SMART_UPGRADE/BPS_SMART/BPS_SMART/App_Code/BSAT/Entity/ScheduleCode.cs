﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for ScheduleCode
/// </summary>
public class ScheduleCode
{
	public ScheduleCode()
	{
		//
		// TODO: Add constructor logic here
		//
	}
	public int ScheduleCodeId { get; set; }
	public int CodeNumber { get; set; }
	public string CodeDescription { get; set; }
	public bool IsIdle { get; set; }
	public bool IsDeleted { get; set; }
    public string MaxDuration { get; set; }
    public string subDepartment { get; set; }
	public int AddedBy { get; set; }
	public int ModifiedBy { get; set; }
    public bool IsProjectDependent { get; set; }
    public string Flag { get; set; }
}
