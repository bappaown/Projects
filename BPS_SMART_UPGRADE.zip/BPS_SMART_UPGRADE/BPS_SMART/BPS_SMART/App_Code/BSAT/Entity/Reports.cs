﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

/// <summary>
/// Summary description for Reports
/// </summary>
/// 
namespace BSAT.Entity
{
    public class Reports
    {
        public Reports()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        public string Date { get; set; }

        public string LogInTime { get; set; }
        public string LogOutTime { get; set; }
        public string SignOnDuration { get; set; }
        public string AvailableTime { get; set; }
        public string BoActivitytime { get; set; }
        public string InBoundTime { get; set; }
        public string OutBoundTime { get; set; }
        public string IdleTime { get; set; }
        public string Occupancy { get; set; }
        public int WinsetID { get; set; }
        public string EmpID { get; set; }
        public string EmpName { get; set; }
        public string Department { get; set; }

        public string ActivityStartTime { get; set; }
        public string ActivityEndTime { get; set; }
        public string DurationOfActivity { get; set; }
        public string ActivityCode { get; set; }
        public string ActivityDescription { get; set; }
        public string IsIdle { get; set; }

        public int ReportingManagerID { get; set; }
        public string ReportingManager { get; set; }
        public int ReviewingManagerID { get; set; }
        public string ReviewingManager { get; set; }


    }
}
