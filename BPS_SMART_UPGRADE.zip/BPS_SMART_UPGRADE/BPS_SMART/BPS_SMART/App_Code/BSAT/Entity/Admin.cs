﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

namespace BSAT.Entity
{
    /// <summary>
    /// Summary description for Admin
    /// </summary>
    public class Admin
    {
        public Admin()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public int AdminId { get; set; }
        public int EmpUserId { get; set; }
        public bool Role { get; set; }
        public bool IsAdmin { get; set; }
        public bool IsUser { get; set; }
        public bool IsDeleted { get; set; }
        public int AddedBy { get; set; }
        public int ModifiedBy { get; set; }
        public int SubDeptID { get; set; }
    }
}