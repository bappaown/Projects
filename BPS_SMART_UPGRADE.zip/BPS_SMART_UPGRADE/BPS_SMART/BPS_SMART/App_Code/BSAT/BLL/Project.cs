﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using BSAT.DAL;
using System.Data.SqlClient;

/// <summary>
/// Summary description for Project
/// </summary>
public class Project
{
    public Project()
    {

    }

    public DataSet GetCostCentre()
    {
        DataSet dsCostCentre = null;
        try
        {
            string strQry = "select * from Central_CostCentre_Main";
            dsCostCentre = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, strQry);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return dsCostCentre;
    }

    public DataSet GetProjectList()
    {
        DataSet dsCostCentre = null;
        try
        {
            string strQry = "proc_ProjectDetails_GetList";
            dsCostCentre = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, strQry);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return dsCostCentre;
    }

    public DataSet GetSubDepartmentList()
    {
        DataSet dsCostCentre = null;
        try
        {
            string strQry = "select * from SubDepartment where Active=1 order by Name";
            dsCostCentre = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, strQry);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return dsCostCentre;
    }

    public int InsertProject(int ID, string costCentre, string projectName, string subDepartment, int CreatedBy, bool IsActive, string Flag)
    {
        int result = 0;
        object rowsAffected = 0;
        string strQry = string.Empty;

        try
        {
            SqlParameter[] oParams;
            oParams = new SqlParameter[7];
            oParams[0] = new SqlParameter("@ID", ID);
            oParams[1] = new SqlParameter("@costCentre", costCentre);
            oParams[2] = new SqlParameter("@projectName", projectName);
            oParams[3] = new SqlParameter("@subDepartment", subDepartment);
            oParams[4] = new SqlParameter("@CreatedBy", CreatedBy);
            oParams[5] = new SqlParameter("@IsActive", IsActive);
            oParams[6] = new SqlParameter("@Flag", Flag);
            strQry = "proc_ProjectDetails_Insert";
            rowsAffected = SqlHelper.ExecuteScalar(SqlHelper.ConnectionString(), CommandType.StoredProcedure, strQry, oParams);
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return Convert.ToInt32(rowsAffected);
    }

    public bool DeleteProjectDetails(int ID)
    {
        bool result = false;
        int rowsAffected = 0;
        string strQry = "";
        try
        {
            strQry = "delete from ProjectDetails where ID = " + ID + ";";
            strQry += "delete from ProjectSubDeptMapping where ProjectID = " + ID + ";";

            rowsAffected = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.Text, strQry);
            if (rowsAffected > 0)
            {
                result = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return result;
    }
}