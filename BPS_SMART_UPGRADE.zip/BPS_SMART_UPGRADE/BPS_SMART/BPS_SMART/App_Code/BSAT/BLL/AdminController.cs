﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using BSAT.Entity;
using BSAT.DAL;

namespace BSAT.BLL
{
    /// <summary>
    /// Summary description for Admin
    /// </summary>
    public class AdminController
    {
        public AdminController()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public DataSet GetAdmins()
        {
            DataSet dsAdmins = null;
            try
            {
                //string strQry = "Select AdminId, Admin.[Role] as RoleValue, CASE WHEN (Admin.[Role] = 'True') THEN 'Yes' ELSE 'No' END AS [ROLE]," +
                //                "CASE WHEN (Admin.IsAdmin = 'True') THEN 'Yes' ELSE 'No' END AS IsAdmin," +
                //                "CASE WHEN (Admin.IsUser = 'True') THEN 'Yes' ELSE 'No' END AS IsUser," +
                //                "CEM.EmpUserId, CEM.FirstName + ' ' + CEM.LastName + ' - ' + Convert(varchar, CEM.EmployeeId) AS EmpName" +
                //                " from Admin INNER JOIN Central_Employee_Main CEM ON CEM.EmpUserId = Admin.EmpUserId WHERE Admin.IsDeleted <> 1 Order By EmpName";
                string strQry = "Select SD.Name as SubDeptName, AdminId, Admin.[Role] as RoleValue, Admin.IsAdmin as AdminValue, Admin.IsUser as UserValue," +
                                "CASE WHEN (Admin.[Role] = 'True') THEN 'Yes' ELSE 'No' END AS [ROLE]," +
                                "CASE WHEN (Admin.IsAdmin = 'True') THEN 'Yes' ELSE 'No' END AS IsAdminCase," +
                                "CASE WHEN (Admin.IsUser = 'True') THEN 'Yes' ELSE 'No' END AS IsUserCase, Admin.IsAdmin as IsAdminCase, Admin.IsUser as IsUserCase," +
                                "CEM.EmpUserId, CEM.FirstName + ' ' + CEM.LastName + ' - ' + Convert(varchar, CEM.EmployeeId) AS EmpName" +
                                " from Admin, Central_Employee_Main CEM, SubDepartment SD where CEM.EmpUserId = Admin.EmpUserId " +
                                "and  Admin.SubDeptID = SD.ID and Admin.IsDeleted <> 1 Order By EmpName";
                dsAdmins = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsAdmins;
        }

        public bool AdminExists(Admin admin)
        {
            bool result = false;
            int rowsAffected = 0;
            string strQry = "";

            try
            {
                if (admin.AdminId == 0)
                {
                    strQry = "SELECT COUNT(*) from Admin  WHERE EmpUserId = " + admin.EmpUserId + " AND IsDeleted = 0";
                }
                else
                {
                    strQry = "SELECT COUNT(*) from Admin  WHERE EmpUserId = " + admin.EmpUserId + " AND IsDeleted = 0 AND AdminId <> " + admin.AdminId;
                }


                rowsAffected = Convert.ToInt32(SqlHelper.ExecuteScalar(SqlHelper.ConnectionString(), CommandType.Text, strQry).ToString());
                if (rowsAffected > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        public bool InsertAdmin(Admin admin)
        {
            bool result = false;
            int rowsAffected = 0;
            string strQry = "";

            try
            {
                if (admin.AdminId == 0)
                {
                    strQry = "INSERT into Admin (EmpUserId, Role, IsAdmin, IsUser, AddedBy, SubDeptID) " +
                        "Values(" + admin.EmpUserId + ",'" + admin.Role + "','" + admin.IsAdmin + "','" + admin.IsUser + "'," + admin.AddedBy + "," + admin.SubDeptID + ")";
                }
                else
                {
                    strQry = "Update Admin SET " +
                        " Role = '" + admin.Role + "'," +
                        " IsAdmin = '" + admin.IsAdmin + "'," +
                        " IsUser = '" + admin.IsUser + "'," +
                        " SubDeptID = '" + admin.SubDeptID + "'," +
                        " ModifiedBy =" + admin.ModifiedBy + "," +
                        " ModifiedWhen = getdate()" +
                        " Where AdminId = " + admin.AdminId;
                }
                rowsAffected = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.Text, strQry);
                if (rowsAffected > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        public bool DeleteAdmin(Admin admin)
        {
            bool result = false;
            int rowsAffected = 0;
            string strQry = "";

            try
            {
                strQry = "Update Admin SET " +
                        " IsDeleted = 'True'," +
                        " ModifiedBy =" + admin.ModifiedBy + "," +
                        " ModifiedWhen = getdate()" +
                        " Where AdminId = " + admin.AdminId;

                rowsAffected = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.Text, strQry);
                if (rowsAffected > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        public DataSet GetSubDept()
        {
            DataSet dsAdmins = null;
            try
            {
                string strQry = "Select * from SubDepartment";
                dsAdmins = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsAdmins;
        }
    }

}