﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Collections;
using System.Collections.Generic;
using BSAT.DAL;
using BSAT.Entity;
using System.Data.SqlClient;

/// <summary>
/// Summary description for ScheduleCodeController
/// </summary>
public class ScheduleCodeController
{
    public ScheduleCodeController()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public DataSet GetScheduleCodes()
    {
        string strQry;
        DataSet dsScheduleCodes = null;
        try
        {
            //strQry = "Select CodeId, CodeNumber, Description, CASE WHEN (IsIdle = 'True') THEN 'Yes' ELSE 'No' END AS IsIdle," +
            //    "IsIdle as isIdleValue, MaxDuration, CASE WHEN (IsProjectDependant = 'True') THEN 'Yes' ELSE 'No' END AS IsProjectDependant ,isnull(IsProjectDependant,0) as IsProjectDependantValue " +
            //     "from ScheduleCode WHERE IsDeleted <> 1 Order By CodeNumber";
            strQry = "proc_ScheduleCode_GetList";
            dsScheduleCodes = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, strQry);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return dsScheduleCodes;

    }
    /// <summary>
    /// This method is used for Get schedule code as per the code number.
    /// </summary>
    /// <returns></returns>
    public DataSet GetScheduleCodesByCodeId(int codeId)
    {
        string strQry;
        DataSet dsScheduleCodes = null;
        try
        {
            strQry = "Select CodeId, CodeNumber, Description, CASE WHEN (IsIdle = 'True') THEN 'Yes' ELSE 'No' END AS IsIdle, " +
                "IsIdle as isIdleValue, MaxDuration " +
                "from ScheduleCode " +
                "WHERE CodeId=" + codeId + "  AND  IsDeleted =0 " +
                " Order By CodeNumber";
            dsScheduleCodes = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, strQry);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return dsScheduleCodes;

    }

    public bool ScheduleCodeExists(ScheduleCode scheduleCode)
    {
        bool result = false;
        int rowsAffected = 0;
        string strQry = "";

        try
        {
            if (scheduleCode.ScheduleCodeId == 0)
            {
                strQry = "SELECT COUNT(*) from ScheduleCode WHERE CodeNumber = " + scheduleCode.CodeNumber + " AND IsDeleted = 0";
            }
            else
            {
                strQry = "SELECT COUNT(*) from ScheduleCode  WHERE CodeNumber = " + scheduleCode.CodeNumber + "AND IsDeleted = 0 AND CodeId <> " + scheduleCode.ScheduleCodeId;
            }
            // AND Description = '" + scheduleCode.CodeDescription + 

            rowsAffected = Convert.ToInt32(SqlHelper.ExecuteScalar(SqlHelper.ConnectionString(), CommandType.Text, strQry).ToString());
            if (rowsAffected > 0)
            {
                result = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return result;
    }

    public bool ScheduleDescriptionExists(ScheduleCode scheduleCode)
    {
        bool result = false;
        int rowsAffected = 0;
        string strQry = "";

        try
        {
            if (scheduleCode.ScheduleCodeId == 0)
            {
                strQry = "SELECT COUNT(*) from ScheduleCode WHERE Description = '" + scheduleCode.CodeDescription + "' AND IsDeleted = 0";
            }
            else
            {
                strQry = "SELECT COUNT(*) from ScheduleCode  WHERE Description = '" + scheduleCode.CodeDescription + "' AND IsDeleted = 0 AND CodeId <> " + scheduleCode.ScheduleCodeId;
            }


            rowsAffected = Convert.ToInt32(SqlHelper.ExecuteScalar(SqlHelper.ConnectionString(), CommandType.Text, strQry).ToString());
            if (rowsAffected > 0)
            {
                result = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return result;
    }

    public int InsertScheduleCode(ScheduleCode scheduleCode)
    {
        int result = 0;
        //int rowsAffected = 0;
        string strQry = string.Empty;
        DataSet ds = new DataSet();

        try
        {
            SqlParameter[] oParams;
            oParams = new SqlParameter[9];
            oParams[0] = new SqlParameter("@codeNumber", scheduleCode.CodeNumber);
            oParams[1] = new SqlParameter("@description", scheduleCode.CodeDescription);
            oParams[2] = new SqlParameter("@isIdle", scheduleCode.IsIdle);
            oParams[3] = new SqlParameter("@isProjectDependent", scheduleCode.IsProjectDependent);
            oParams[4] = new SqlParameter("@maxDuration", scheduleCode.MaxDuration);
            oParams[5] = new SqlParameter("@subDepartment", scheduleCode.subDepartment);
            oParams[6] = new SqlParameter("@addedBy", scheduleCode.AddedBy);
            oParams[7] = new SqlParameter("@Flag", scheduleCode.Flag);
            oParams[8] = new SqlParameter("@codeID", scheduleCode.ScheduleCodeId);
            strQry = "proc_ScheduleCode_Insert";
            ds = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, strQry, oParams);

            result = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return result;
    }

    public bool DeleteScheduleCode(ScheduleCode scheduleCode)
    {
        bool result = false;
        int rowsAffected = 0;
        string strQry = "";

        try
        {
            strQry = "delete from ScheduleCode where CodeId = " + scheduleCode.ScheduleCodeId + ";";
            strQry += "delete from ScheduleCodeSubDeptMapping where ScheduleCodeID = " + scheduleCode.ScheduleCodeId + ";";

            rowsAffected = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.Text, strQry);
            if (rowsAffected > 0)
            {
                result = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return result;
    }

}
