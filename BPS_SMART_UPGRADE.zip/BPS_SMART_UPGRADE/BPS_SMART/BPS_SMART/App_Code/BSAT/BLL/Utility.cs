﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using BSAT.DAL;
using BSAT.Entity;
using System.Data.SqlClient;

namespace BSAT.BLL
{

    public static class MyExtensions
    {
        public static string Replace(this String str)
        {
            return str.Replace("'", "''").Trim();
        }
    }


    /// <summary>
    /// Summary description for Utility
    /// </summary>
    /// 
    public class Utility : Admin
    {

        public Utility()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public DataSet GetCostCentreList()
        {
            DataSet dsCostCentre = null;
            try
            {
                string strQry = "Select CostCentreId, CostCentre from Central_CostCentre_Main where CostCentreId=4 ORDER BY CostCentre";//CostCentreId=1 ORDER BY CostCentre
                dsCostCentre = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsCostCentre;
        }

        public DataSet GetDepartmentList(int costCentreId)
        {
            DataSet dsDepartment = null;
            try
            {
                string strQry = "Select DepartmentId, DepartmentName from dbo.Central_Department_Main where costcentreId= " + costCentreId + " Order By DepartmentName";
                dsDepartment = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsDepartment;
        }

        public DataSet GetDesignationList(int costCentreId, string departmentIds)
        {
            DataSet dsDesignation = null;
            try
            {
                string strQry = "Select Distinct(CEM.DesignationId), DES.Name  " +
                                "from Central_Employee_Main CEM " +
                                "INNER JOIN Designations DES ON CEM.DesignationId = DES.Id " +
                                "where  Status =1 AND costcentreId= " + costCentreId + " AND DepartmentID IN (" + departmentIds + ") Order By DES.Name";
                dsDesignation = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsDesignation;
        }

        public DataSet GetEmployeeList(int costCentreId, string departmentIds, string designationIds)
        {
            DataSet dsEmployee = null;
            try
            {
                string strQry = "Select CEM.EmpUserId, CEM.FirstName + ' ' + CEM.LastName + ' - ' + Convert(varchar, CEM.EmployeeId) AS EmpName " +
                                "from Central_Employee_Main CEM " +
                                "INNER JOIN Designations DES ON CEM.DesignationId = DES.Id " +
                                "where  Status =1 AND costcentreId= " + costCentreId + " AND DepartmentID IN (" + departmentIds + ") AND DesignationID IN (" + designationIds + ") Order By EmpName";
                dsEmployee = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsEmployee;
        }

        /// <summary>
        /// This method will return the type of User
        /// </summary>
        /// <param name="admin"></param>
        /// <returns></returns>
        public bool AdminExists(Admin admin)
        {
            bool result = false;
            int rowsAffected = 0;
            string strQry = "";

            try
            {
                if (admin.AdminId == 0)
                {
                    strQry = "SELECT COUNT(*) from Admin  WHERE EmpUserId = " + admin.EmpUserId + " AND IsDeleted = 0";
                }
                else
                {
                    strQry = "SELECT COUNT(*) from Admin  WHERE EmpUserId = " + admin.EmpUserId + " AND IsDeleted = 0 AND AdminId <> " + admin.AdminId;
                }


                rowsAffected = Convert.ToInt32(SqlHelper.ExecuteScalar(SqlHelper.ConnectionString(), CommandType.Text, strQry).ToString());
                if (rowsAffected > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }

        /// <summary>
        /// This methos is used for check user is super admin
        /// Created by santosh
        /// </summary>
        /// <param name="admin"></param>
        /// <returns></returns>
        public UserType UserIs(int empUserId)
        {            
            string strQry = string.Empty;
            int rowsAffected = 0;
            bool isSuperAdmin;
            UserType userType;

            strQry = "SELECT Count(*) from Admin  WHERE EmpUserId = " + empUserId + " AND IsDeleted = 0  and (Role=1 or IsAdmin=1)";
            rowsAffected = Convert.ToInt32(SqlHelper.ExecuteScalar(SqlHelper.ConnectionString(), CommandType.Text, strQry).ToString());

            if (rowsAffected > 0)
            {
                strQry = "SELECT [Role] from Admin  WHERE EmpUserId = " + empUserId + " AND IsDeleted = 0";
                isSuperAdmin = Convert.ToBoolean(SqlHelper.ExecuteScalar(SqlHelper.ConnectionString(), CommandType.Text, strQry).ToString());
                userType = isSuperAdmin == true ? UserType.SuperAdmin : UserType.Admin;
            }
            else
            {
                userType = UserType.GeneralUser;

            }
            return userType;
        }


        public static DataSet GetCostCentre()
        { 
            DataSet dt = (SqlHelper.ExecuteDataset(GetConnectionString(), CommandType.StoredProcedure, "proc_GetCostCentre"));
            return dt;
        }

        public static string GetConnectionString()
        {
            //return System.Configuration.ConfigurationManager.AppSettings["ConStr"];
            string strCon= System.Configuration.ConfigurationManager.AppSettings["ConnectionString"];
            return strCon;
        }




        public static DataTable GetCCReport(string StartDate, string EndDate, string CostCentre)
        {

            SqlParameter[] parameters = new SqlParameter[]
            {
            new SqlParameter("@FromDate", StartDate),
            new SqlParameter("@ToDate", EndDate),
            new SqlParameter("@CostCentre", CostCentre)
           
            };
            DataTable dt = (SqlHelper.ExecuteDataset(GetConnectionString(), CommandType.StoredProcedure, "proc_GetCostCentreWiseReport", parameters)).Tables[0];
            return dt;
        }




    }
}