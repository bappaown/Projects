﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using BSAT.DAL;
using System.Data.SqlClient;

/// <summary>
/// Summary description for SubDepartment
/// </summary>
public class SubDepartment
{
    public SubDepartment()
    {

    }

    public DataSet GetSubDepartmentList()
    {
        DataSet dsCostCentre = null;
        try
        {
            string strQry = "SELECT ID,Name,CASE WHEN (Active = '1')	THEN 'Yes' ELSE 'No' END AS Active,	Active AS ActiveValue FROM SubDepartment WHERE Active =1 ORDER BY Name";
            dsCostCentre = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, strQry);
        }
        catch (Exception ex)
        {
            throw ex;
        }
        return dsCostCentre;
    }

    public int InsertSubDepartment(int id, string name, bool isActive, int createdBy, string flag)
    {
        int result = 0;
        int rowsAffected = 0;
        string strQry = string.Empty;
        DataSet ds = new DataSet();
        try
        {
            SqlParameter[] oParams;
            oParams = new SqlParameter[5];
            oParams[0] = new SqlParameter("@id", id);
            oParams[1] = new SqlParameter("@name", name);
            oParams[2] = new SqlParameter("@isActive", isActive);
            oParams[3] = new SqlParameter("@createdBy", createdBy);
            oParams[4] = new SqlParameter("@flag", flag);
            strQry = "proc_SubDepartment_Insert";
            ds = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, strQry, oParams);

            result = Convert.ToInt32(ds.Tables[0].Rows[0][0].ToString());
        }
        catch (Exception ex)
        {

        }

        return result;
    }

    public bool DeleteSubDepartment(int id, int createdBy)
    {
        bool result = false;
        int rowsAffected = 0;
        string strQry = "";
        try
        {
            strQry = "update SubDepartment set Active=0," + "ModifiedBy=" + createdBy + ",ModifiedDate=getdate() where ID =" + id;

            rowsAffected = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.Text, strQry);
            if (rowsAffected > 0)
            {
                result = true;
            }
        }
        catch (Exception ex)
        {
            throw ex;
        }

        return result;
    }
}