﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Collections.Generic;
using BSAT.Entity;
using BSAT.DAL;

namespace BSAT.BLL
{
    /// <summary>
    /// Summary description for ReportsController
    /// </summary>
    public class ReportsController : Reports
    {
        public ReportsController()
        {
            //
            // TODO: Add constructor logic here
            //
        }

    

        public DataSet GetActivityReports(string loginStartTime, string loginEndTime, string DepartmentName, string EmployeeName)
        {
            DataSet dsreport = null;
            try
            {
                SqlParameter[] oParams;
                oParams = new SqlParameter[4];
                oParams[0] = new SqlParameter("@LoginStart", loginStartTime);
                oParams[1] = new SqlParameter("@LogInEnd", loginEndTime);
                oParams[2] = new SqlParameter("@DepartmentId", DepartmentName);
                oParams[3] = new SqlParameter("@EmpID", EmployeeName);
                string strQry = "proc_GetActivityReport_ASD";// "proc_GetActivityReport";

                dsreport = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, strQry, oParams);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsreport;
        }

        public DataSet GetCostCentreReports(string loginStartTime, string loginEndTime, string projectList, string employeeList)
        {
            DataSet dsreport = null;
            try
            {
                SqlParameter[] oParams;
                oParams = new SqlParameter[4];
                oParams[0] = new SqlParameter("@projectID", projectList);
                oParams[1] = new SqlParameter("@empUserID", employeeList);
                oParams[2] = new SqlParameter("@startDate", loginStartTime);
                oParams[3] = new SqlParameter("@endDate", loginEndTime);
                string strQry = "proc_GetCostCenterReport_ASD";

                dsreport = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, strQry, oParams);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsreport;
        }

        public DataSet GetEODReports(string loginStartTime, string loginEndTime, string DepartmentName, string EmployeeName)
        {
            DataSet dsreport = null;


            try
            {
                SqlParameter[] oParams;
                oParams = new SqlParameter[4];
                oParams[0] = new SqlParameter("@Start", loginStartTime);
                oParams[1] = new SqlParameter("@End", loginEndTime);
                oParams[2] = new SqlParameter("@DepartmentId", DepartmentName);
                oParams[3] = new SqlParameter("@EmpID", EmployeeName);
                string strQry = "proc_GetEODReport_ASD";//"proc_GetEODReport";

                dsreport = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, strQry, oParams);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsreport;
        }

        public DataSet GetDepartment()
        {
            DataSet dsreport = null;
            try
            {
                string strQry = "proc_SubDepartment_Select"; //"proc_GetDepartments";

                dsreport = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsreport;
        }

        public DataSet BindProjectList()
        {
            DataSet dsreport = null;
            try
            {
                string strQry = "proc_ProjectDetails_GetListForReport";

                dsreport = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, strQry);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsreport;
        }

        public DataSet BindAdmin_AllUsers(string userID)
        {
            DataSet dsreport = null;
            try
            {
                SqlParameter[] oParams;
                oParams = new SqlParameter[1];
                oParams[0] = new SqlParameter("@userID", userID);
                string strQry = "proc_Admin_GetAllUsers";

                dsreport = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, strQry, oParams);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsreport;
        }

        public DataSet GetEmpList_As_Dept(string DepartmentID, string userID)
        {
            DataSet dsreport = null;
            try
            {
                SqlParameter[] oParams;
                oParams = new SqlParameter[2];
                oParams[0] = new SqlParameter("@subDeptID", DepartmentID);
                oParams[1] = new SqlParameter("@userID", userID);
                string strQry = "proc_GetEmployeeList";//"proc_GetEODReport";

                dsreport = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, strQry, oParams);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsreport;
        }
    }
}