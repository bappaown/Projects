﻿using BPS_SMART;
using BSAT.DAL;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;

/// <summary>
/// Summary description for ExceptionDataStore
/// </summary>
public class ExceptionDataStore
{
    public static string ConnectionString = SqlHelper.ConnectionString(); //ConfigurationManager.ConnectionStrings["ConnectionString"].ToString();
    public static void LogException(Exception ex)
    {
        Employee oEmp = new Employee();
        if (HttpContext.Current.Request.Cookies["SMART"] != null)
        {
            string Employee = DecryptString(HttpContext.Current.Request.Cookies["SMART"]["Employee"].ToString());
            oEmp.EmpUserId = Employee.Split('|')[0];
        }


        using (SqlConnection myConnection = new SqlConnection(ConnectionString))
        {
            using (SqlCommand objSQLcommand = new SqlCommand())
            {
                objSQLcommand.CommandType = System.Data.CommandType.StoredProcedure;
                objSQLcommand.CommandText = "sp_ExceptionLogging";
                objSQLcommand.Connection = myConnection;

                objSQLcommand.Parameters.Add("@UserId", SqlDbType.BigInt);
                objSQLcommand.Parameters["@UserId"].Value = oEmp.EmpUserId;

                objSQLcommand.Parameters.Add("@ExceptionSource", SqlDbType.VarChar);
                objSQLcommand.Parameters["@ExceptionSource"].Value = "SMART";

                objSQLcommand.Parameters.Add("@ExceptionType", SqlDbType.VarChar);
                objSQLcommand.Parameters["@ExceptionType"].Value = "Error";

                objSQLcommand.Parameters.Add("@Description", SqlDbType.VarChar);
                objSQLcommand.Parameters["@Description"].Value = ex.Message;

                objSQLcommand.Parameters.Add("@LongDescription", SqlDbType.VarChar);
                objSQLcommand.Parameters["@LongDescription"].Value = ex.StackTrace.ToString();

                objSQLcommand.Parameters.Add("@ExceptionURL", SqlDbType.VarChar);
                objSQLcommand.Parameters["@ExceptionURL"].Value = "";

                myConnection.Open();
                objSQLcommand.ExecuteScalar();
                myConnection.Close();
            }
        }
    }

    public static string DecryptString(string encrString)
    {
        byte[] b;
        string decrypted;
        try
        {
            b = Convert.FromBase64String(encrString);
            decrypted = System.Text.ASCIIEncoding.ASCII.GetString(b);
        }
        catch (FormatException fe)
        {
            decrypted = "";
        }
        return decrypted;
    }
}