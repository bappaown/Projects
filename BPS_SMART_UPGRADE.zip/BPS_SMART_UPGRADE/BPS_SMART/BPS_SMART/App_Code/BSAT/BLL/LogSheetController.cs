﻿using System;
using System.Data;
using System.Configuration;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using System.Data.SqlClient;
using System.Collections.Generic;
using BSAT.Entity;
using BSAT.DAL;

namespace BSAT.BLL
{
    /// <summary>
    /// Summary description for LogSheetController
    /// </summary>
    public class LogSheetController : LogSheet
    {
        public LogSheetController()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        public IEnumerable<LogSheet> GetFiltersUsers(int empUserID, int filterTypeId)
        {
            SqlParameter[] oParams;
            oParams = new SqlParameter[2];
            oParams[0] = new SqlParameter("@EmpUserID", empUserID);
            oParams[1] = new SqlParameter("@FilterTypeId", filterTypeId);
            string procName = "proc_GetFiltersUsers_New";//proc_GetFiltersUsers
            using (IDataReader reader = SqlHelper.ExecuteReader(
                SqlHelper.ConnectionString(),
                CommandType.StoredProcedure,
                procName, oParams
                ))
            {
                while (reader.Read())
                    yield return new LogSheet
                    {
                        EmpUserId = Convert.ToInt32(reader["EmpUserID"]),
                        EmpName = Convert.ToString(reader["EmpName"])
                    };
            }
        }

        public IEnumerable<LogSheet> GetOnlineLoginUserDetails(int filterTypeId, string filterIds,string empUserID)
        {
            SqlParameter[] oParams;
            oParams = new SqlParameter[3];
            oParams[0] = new SqlParameter("@FilterTypeId", filterTypeId);
            oParams[1] = new SqlParameter("@FilterIds", filterIds);
            oParams[2] = new SqlParameter("@EmpUserID", empUserID);

            using (IDataReader reader = SqlHelper.ExecuteReader(
                SqlHelper.ConnectionString(),
                CommandType.StoredProcedure,
                "proc_GetOnlineLoginUserDetails_New", oParams
                ))
            {
                while (reader.Read())
                {
                    yield return new LogSheet
                    {
                        CodeId = Convert.ToInt32(reader["CodeId"]),
                        EmpUserId = Convert.ToInt32(reader["EmpUserID"]),
                        EmpName = Convert.ToString(reader["EmpName"]),
                        CodeDescription = Convert.ToString(reader["CodeDescription"]),
                        CodeNumber = Convert.ToInt32(reader["CodeNumber"]),
                        LogSheetId = Convert.ToInt32(reader["LogSheetId"]),
                        LogStartTime = Convert.ToString(reader["LogStartTime"]),
                        TimeSpent = Convert.ToString(reader["TimeSpent"]),
                        TotalSecondSpent = Convert.ToString(reader["TotalSpentSecond"]),
                        PCName = Convert.ToString(reader["PCName"]),
                        IsIdle = Convert.ToBoolean(reader["IsIdle"]),
                        DeptName = Convert.ToString(reader["DeptName"]),
                        ProjectName = reader["ProjectName"] == DBNull.Value ? "N/A" : Convert.ToString(reader["ProjectName"]),
                        SubDepartment = Convert.ToString(reader["SubDepartment"]),
                        LoginWinset = reader["LoginWinset"] == DBNull.Value ? 0 : Convert.ToInt32(reader["LoginWinset"])
                    };
                }
            }
        }

        public DataSet GetFilters()
        {
            DataSet dsFilters = null;
            try
            {
                string spName = "proc_GetFilters";
                dsFilters = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, spName);
                if (dsFilters != null && dsFilters.Tables[0].Rows.Count > 0)
                {
                    return dsFilters;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// This method is used for get record code as per code number
        /// </summary>
        /// <param name="codeNo"></param>
        /// <returns></returns>
        public DataSet GetScheduleCodes(int CodeNumber)
        {
            string strQry;
            DataSet dsScheduleCodes = null;
            try
            {
                // strQry = "SELECT MaxDuration FROM ScheduleCode WHERE  CodeId =" + codeId + "";
                //dsScheduleCodes = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.Text, strQry);
                SqlParameter[] oParams;
                oParams = new SqlParameter[1];
                oParams[0] = new SqlParameter("@CodeNumber", CodeNumber);
                string procName = "spGetScheduleCodes";//proc_GetFiltersUsers
                 dsScheduleCodes = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, procName, oParams);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return dsScheduleCodes;
        }

        /// <summary>
        /// This method is used for get max duration login time.
        /// </summary>
        /// <returns></returns>
        public DataSet GetMaxLoginDuration()
        {
            string strQury;
            DataSet dsMaxTimeDuration = null;
            try
            {
               //strQury = "Select MaxLoginDuration From Configuration WHERE MaxLoginDurationStatus =1";
                dsMaxTimeDuration = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "spGetMaxLoginDuration");
            }
            catch (Exception ex)
            {

                throw ex;
            }
            return dsMaxTimeDuration;
        }

        public DataSet GetConfigRefreshTime(int codeNumber)
        {
            DataSet dsConfigdetails = null;
            try
            {
                string commandText = "";
                //if (codeNumber == 0)
                //{
                //    commandText = "SELECT RefreshRate,DefaultCodeNumber,SC.Description,MaxLoginDuration," +
                //                   " CASE " +
                //                   " WHEN MaxLoginDurationStatus  = 1 THEN 'Active' " +
                //                   " WHEN MaxLoginDurationStatus = 0 THEN 'Inactive' " +
                //                   " ELSE '' " +
                //                   " END AS [Status],MaxLoginDurationStatus " +
                //                   " FROM Configuration " +
                //                  " INNER JOIN ScheduleCode SC ON Configuration.DefaultCodeNumber =SC.CodeId ";
                //}
                //else
                //{
                //    commandText = " SELECT RefreshRate,DefaultCodeNumber,SC.Description,MaxLoginDuration," +
                //                   " CASE " +
                //                   " WHEN MaxLoginDurationStatus  = 1 THEN 'Active' " +
                //                   " WHEN MaxLoginDurationStatus  = 0 THEN 'Inactive' " +
                //                   " ELSE '' " +
                //                   " END AS [Status],MaxLoginDurationStatus " +
                //                   " FROM Configuration " +
                //                   " INNER JOIN ScheduleCode SC ON Configuration.DefaultCodeNumber =SC.CodeId " +
                //                   " WHERE SC.IsDeleted=0 AND Configuration.DefaultCodeNumber=" + codeNumber + "";
                //}

                SqlParameter[] oParams;
                oParams = new SqlParameter[1];
                oParams[0] = new SqlParameter("@CodeNumber", codeNumber);
                string procName = "spGetConfigRefreshTime";


                dsConfigdetails = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, procName,oParams);

                if (dsConfigdetails != null && dsConfigdetails.Tables[0].Rows.Count > 0)
                {
                    return dsConfigdetails;
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool UpdateConfiguration(int code, int refreshRate, int updatedby, string updatedwhen, int maxLoginDuration, bool maxLoginStatus)
        {
            bool result = false;
            
            return result;
        }

        /// <summary>
        /// This method is used for log off the current login users.
        /// </summary>
        /// <param name="empUser"></param>
        /// <returns></returns>
        public bool LogOffUsers(int empUser)
        {
            bool result = false;
            int rowsaffected = 0;
            int returnValue = 0;
            try
            {
                string spName = "proc_logOffUsers";
                SqlParameter[] parameters = new SqlParameter[2];
                parameters[0] = new SqlParameter("@EmpUserID", empUser);
                parameters[1] = new SqlParameter("@Return", returnValue);
                parameters[1].Direction = ParameterDirection.Output;
                rowsaffected = SqlHelper.ExecuteNonQuery(SqlHelper.ConnectionString(), CommandType.StoredProcedure, spName, parameters);
                returnValue = int.Parse(parameters[1].Value.ToString());
                if (returnValue > 0)
                {
                    result = true;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }

        /// <summary>
        /// This method is used to get role of current user.
        /// </summary>
        /// <param name="empUser"></param>
        /// <returns></returns>
        public object GetUserRole(int empUserId)
        {
            string strQry;
            object userRole = null;
            try
            {
                // strQry = "SELECT Role FROM Admin WHERE EmpUserID=" + empUserId;
                SqlParameter[] oParams;
                oParams = new SqlParameter[1];
                oParams[0] = new SqlParameter("@empUserId", empUserId);
                userRole = SqlHelper.ExecuteScalar(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "spGetGetUserRole",oParams );
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return userRole;
        }

        public DataSet GetScheduleCode()
        {
            string strQry;
            DataSet userRole = null;
            try
            {
               // strQry = "select distinct * from ScheduleCode where IsDeleted = 0 order by Description";
                userRole = SqlHelper.ExecuteDataset(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "spGetScheduleCode");
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return userRole;
        }
    }
}
