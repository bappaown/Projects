﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using BSAT.BLL;
using BSAT.Entity;
using System.Reflection;
using System.Collections;


namespace BPS_SMART.Admin
{
    public partial class BSATMonitor : System.Web.UI.Page
    {
        string empUserID = string.Empty;
        int RoleID;
        #region Properties

        private IEnumerable<LogSheet> LogSheetDetails
        {
            get { return Session["LogSheetDetails"] as IEnumerable<LogSheet>; }
            set { Session["LogSheetDetails"] = value; }
        }

        private string SortExpression
        {
            get { return Convert.ToString(this.ViewState["SortExpression"]); }
            set { this.ViewState["SortExpression"] = value; }
        }

        private SortDirection SortDirection
        {
            get
            {
                if (this.ViewState["SortDirection"] == null)
                    this.ViewState["SortDirection"] = SortDirection.Ascending;

                return (SortDirection)this.ViewState["SortDirection"];
            }
            set { this.ViewState["SortDirection"] = value; }
        }

        #endregion

        #region Events


        protected void Page_Load(object sender, EventArgs e)
        {
            try
            {

                lblMessage.Text = "";
                //  empUserID = (HttpContext.Current.Request.Cookies["SMART"] == null) ? string.Empty : HttpContext.Current.Request.Cookies["SMART"]["EmpUserId"].ToString();



                if (!IsPostBack)
                {
                    Employee oEmp = new Employee();
                    AdminMaster master = (AdminMaster)(Page.Master);
                    oEmp = master.IsUserAthenticate();
                    empUserID = oEmp.EmpUserId;
                    RoleID = oEmp.RoleID;

                    LogSheetController objLogSheetController = new LogSheetController();
                    GetModuleName();

                    FillFilterUsersListBox();
                    FillScheduleCodeListBox();

                    BindFilterType();

                    FillGrid();
                    DataSet dsConfigDetails = new DataSet();

                    dsConfigDetails = objLogSheetController.GetConfigRefreshTime(0);

                    if (dsConfigDetails.Tables[0].Rows.Count > 0)
                    {
                        int refreshTime = Convert.ToInt32(dsConfigDetails.Tables[0].Rows[0]["RefreshRate"].ToString());
                        lblRefreshTimeSetting.Text = refreshTime.ToString();
                    }
                    hdnAsc.Value = "ASC";
                }

                this.RegisterStartupScripts();

                if (gvEmployeeStatus.Rows.Count == 0)
                {
                    lblMessage.Text = "No Records Found";
                }
                else
                {
                    lblMessage.Text = "";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void GetModuleName()
        {
            //ContentPlaceHolder ctPlaceHolder = (ContentPlaceHolder)Master.FindControl("cpMain");
            //Label lblModule = (Label)Master.FindControl("lblModule");
            //lblModule.Text = "Admin - Smart Monitor";
        }

        protected void imgBtnSubmit_Click(object sender, EventArgs e)
        {
            try
            {

                FillGrid();
                FillFilterUsersListBox();
                SetViewState();

                if (gvEmployeeStatus.Rows.Count == 0)
                {
                    //  lblMessage.Text = "No Records Found";
                }
                else
                {
                    // lblMessage.Text = "";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void imgBtnSCode_Click(object sender, EventArgs e)
        {
            try
            {

                DataSet dsActual = new DataSet();
                DataSet dsNew = new DataSet();
                List<StatusCount> lstStatus = new List<StatusCount>();
                lstStatus = (List<StatusCount>)ViewState["ScheduleCode_DS"];
                DataTable SCTable = new DataTable();
                DataTable SCTable_New = new DataTable();
                SCTable = Test.ToDataTable(lstStatus);
                SCTable_New.Columns.Add("Status");
                SCTable_New.Columns.Add("Count");
                //SCTable_New.Columns.Add("CodeID");

                foreach (ListItem li in lbScheduleCode.Items)
                {
                    if (li.Selected)
                    {
                        DataRow drSCodes = SCTable_New.NewRow();
                        drSCodes["Status"] = li.Text;
                        drSCodes["Count"] = SCTable.Select("Status LIKE '%" + li.Text + "%'")[0].ItemArray[1];
                        SCTable_New.Rows.Add(drSCodes);
                    }
                }

                rptrStatusSummary.DataSource = SCTable_New;
                rptrStatusSummary.DataBind();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void ddlViewFilterType_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                FillFilterUsersListBox();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void btnRefresh_Click(object sender, EventArgs e)
        {
            try
            {
                FillGrid();
                FillFilterUsersListBox();
                SetViewState();
                if (gvEmployeeStatus.Rows.Count == 0)
                {
                    lblMessage.Text = "No Records Found";
                }
                else
                {
                    lblMessage.Text = "";
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void gvEmployeeStatus_RowCreated(object sender, GridViewRowEventArgs e)
        {
            ImageButton imgbtnLogOff;
            try
            {
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    imgbtnLogOff = (ImageButton)(e.Row.Cells[7].FindControl("gvImgbtnLogOff"));
                    imgbtnLogOff.CommandArgument = e.Row.RowIndex.ToString();
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                imgbtnLogOff = null;
            }
        }

        protected void gvEmployeeStatus_RowCommand(object sender, GridViewCommandEventArgs e)
        {
            LogSheetController objLogSheetController = new LogSheetController();
            ImageButton imgBtnLogOffBtn = null;
            Label lblEmpUserId = null;
            int currentIndex = 0;
            int empUserId = 0;
            GridViewRow oCurrentRow;
            try
            {
                if (e.CommandName == "CmdLogOff")
                {
                    currentIndex = Convert.ToInt32(e.CommandArgument);
                    oCurrentRow = gvEmployeeStatus.Rows[currentIndex];
                    imgBtnLogOffBtn = (ImageButton)oCurrentRow.Cells[7].FindControl("gvImgbtnLogOff");
                    lblEmpUserId = (Label)oCurrentRow.Cells[7].FindControl("gvlblEmpUserId");
                    empUserId = Convert.ToInt32(lblEmpUserId.Text);
                    if (objLogSheetController.LogOffUsers(empUserId))
                    {
                        FillGrid();
                        FillFilterUsersListBox();
                        SetViewState();
                        lblMessage.Text = "User logged off successfully.";
                        lblMessage.Style.Add("color", "green");

                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        protected void gvEmployeeStatus_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            DataSet dsScheduleCode = new DataSet();
            ImageButton imgbtnLogOff = (ImageButton)e.Row.Cells[7].FindControl("gvImgbtnLogOff");
            try
            {

                int codeNumber = 0;
                string timeDuration = "";
                int empUserId = 0;
                LogSheetController objLogSheetController = new LogSheetController();
                Label lblTtlSecondSpentSpent = (Label)e.Row.Cells[6].FindControl("lblTtlSecondSpentSpent");
                Label lblCodeId = (Label)e.Row.Cells[6].FindControl("lblCodeId");
                Label gvlblEmpUserId = (Label)e.Row.Cells[8].FindControl("gvlblEmpUserId");
                string deptName = "";
                if (e.Row.RowType == DataControlRowType.DataRow)
                {
                    codeNumber = Convert.ToInt32(lblCodeId.Text);
                    empUserId = Convert.ToInt32(gvlblEmpUserId.Text);
                    dsScheduleCode = objLogSheetController.GetScheduleCodes(codeNumber);
                    if (dsScheduleCode.Tables[0].Rows.Count > 0)
                    {
                        timeDuration = dsScheduleCode.Tables[0].Rows[0]["MaxDuration"].ToString();
                    }
                    TimeSpan ts = TimeSpan.Parse(timeDuration);
                    int totalSeconds = Convert.ToInt32(ts.TotalSeconds);
                    int spentTimeInSceond = Convert.ToInt32(lblTtlSecondSpentSpent.Text);
                    if (spentTimeInSceond > totalSeconds)
                    {
                        e.Row.ForeColor = Color.Red;
                    }
                    if (totalSeconds == 0)
                    {
                        e.Row.Style.Add("color", "#000000");
                    }


                    // if ((new Utility().UserIs(Convert.ToInt32(empUserID)) != UserType.SuperAdmin)) // && (new Utility().UserIs(Convert.ToInt32(empUserID)) != UserType.Admin))
                    if (RoleID != (int)Role.SuperAdmin)
                    {
                        imgbtnLogOff.Attributes.Add("onclick", "return AlertMessage()");
                        //  imgbtnLogOff.Visible = false;


                    }
                    else
                    {
                        imgbtnLogOff.Attributes.Add("onclick", "return confirm('Are you sure you want to log off this user?')");
                        // imgbtnLogOff.Visible = true;
                    }

                    // New column add Santosh 
                    // Start.
                    deptName = e.Row.Cells[2].Text;
                    if (e.Row.Cells[2].Text.Length > 15)
                    {
                        e.Row.Cells[2].Text = e.Row.Cells[2].Text.Substring(0, 15) + "..";
                        e.Row.Cells[2].ToolTip = deptName;
                    }
                    else
                    {
                        e.Row.Cells[2].ToolTip = deptName;
                    }
                    // End
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                dsScheduleCode = null;
            }
        }

        protected void gvEmployeeStatus_Sorting(object sender, GridViewSortEventArgs e)
        {
            try
            {
                this.SortExpression = e.SortExpression;

                if (this.SortDirection == e.SortDirection)
                    this.SortDirection = SortDirection.Descending;
                else
                    this.SortDirection = e.SortDirection;

                this.FillGrid();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region Private Methods

        private void SetViewState()
        {
            if (ViewState["Dropdown"] != null && ViewState["LBValues"] != null)
            {
                ddlViewFilterType.SelectedValue = ViewState["Dropdown"].ToString();
                string userValues = ViewState["LBValues"].ToString();
                if (userValues != "")
                {
                    string[] split = userValues.Split(',');
                    for (int i = 0; i < split.Length; i++)
                    {
                        int selectedIndex = lbFiltersUsers.Items.IndexOf(lbFiltersUsers.Items.FindByValue(split[i].ToString()));
                        if (selectedIndex >= 0)
                            lbFiltersUsers.Items.FindByValue(split[i].ToString()).Selected = true;
                    }
                }
            }
        }

        private void RegisterStartupScripts()
        {
            ScriptManager.RegisterStartupScript(
                    this,
                    this.GetType(),
                    "Sortable",
                    "$(\"#sortable\"). sortable();",
                    true
                );
        }

        private void BindFilterType()
        {
            object userRole = new LogSheetController().GetUserRole(Convert.ToInt32(empUserID));// H3GS.Web.Security.PassportIdentity.Current.Employee.UserId);
            if (!Convert.ToBoolean(userRole))
            {
                ListItem removeItem = ddlViewFilterType.Items.FindByValue("4");
                ddlViewFilterType.Items.Remove(removeItem);
            }
        }

        private void FillFilterUsersListBox()
        {
            int userID = Convert.ToInt32(empUserID);// H3GS.Web.Security.PassportIdentity.Current.Employee.UserId;
            int filterTypeId = Convert.ToInt32(ddlViewFilterType.SelectedValue);
            lbFiltersUsers.DataSource = new LogSheetController().GetFiltersUsers(userID, filterTypeId);
            lbFiltersUsers.DataTextField = "EmpName";
            lbFiltersUsers.DataValueField = "EmpUserID";
            lbFiltersUsers.DataBind();
        }

        private void FillScheduleCodeListBox()
        {
            DataSet ds = new DataSet();
            ds = new LogSheetController().GetScheduleCode();

            DataRow dr = ds.Tables[0].NewRow();
            dr["Description"] = "SignOn";
            ds.Tables[0].Rows.Add(dr);

            DataView dv = ds.Tables[0].DefaultView;
            dv.Sort = "Description";
            DataTable sortDt = dv.ToTable();

            lbScheduleCode.DataSource = sortDt;
            lbScheduleCode.DataTextField = "Description";
            lbScheduleCode.DataValueField = "CodeNumber";
            lbScheduleCode.DataBind();
        }

        private void FillGrid()
        {
            int filterTypeId = Convert.ToInt32(ddlViewFilterType.SelectedValue);
            string filtersUserIds = string.Empty;
            string concateFiltersIDs = string.Empty;
            string concateFiltersIDsNotSelected = string.Empty;

            //  string empUserID =empUserID;// H3GS.Web.Security.PassportIdentity.Current.Employee.UserId.ToString();

            if (lbFiltersUsers.Items.Count > 0)
            {
                for (int iLoop = 0; iLoop <= lbFiltersUsers.Items.Count - 1; iLoop++)
                {
                    if (lbFiltersUsers.Items[iLoop].Selected)
                    {
                        concateFiltersIDs += lbFiltersUsers.Items[iLoop].Value + ",";
                    }
                    else
                    {
                        concateFiltersIDsNotSelected += lbFiltersUsers.Items[iLoop].Value + ",";
                    }
                }
                if (concateFiltersIDs != "")
                {
                    concateFiltersIDs = concateFiltersIDs.Substring(0, concateFiltersIDs.Length - 1);
                }
                if (concateFiltersIDsNotSelected != "")
                {
                    concateFiltersIDsNotSelected = concateFiltersIDsNotSelected.Substring(0, concateFiltersIDsNotSelected.Length - 1);
                }
            }

            if (concateFiltersIDs == "" || concateFiltersIDs.Length <= 0)
            {
                filtersUserIds = concateFiltersIDsNotSelected;
            }
            else
            {
                filtersUserIds = concateFiltersIDs;
            }

            ViewState["Dropdown"] = filterTypeId;
            ViewState["LBValues"] = filtersUserIds;

            IEnumerable<LogSheet> logSheetList = new LogSheetController().GetOnlineLoginUserDetails(filterTypeId, filtersUserIds, empUserID);

            this.BindStatusList(logSheetList);

            switch (this.SortExpression)
            {
                case "EmpName":
                    logSheetList = logSheetList.OrderBy(ls => ls.EmpName);
                    break;
                case "CodeNumber":
                    logSheetList = logSheetList.OrderBy(ls => ls.CodeNumber);
                    break;
                case "CodeDescription":
                    logSheetList = logSheetList.OrderBy(ls => ls.CodeDescription);
                    break;
                case "LogStartTime":
                    logSheetList = logSheetList.OrderBy(ls => ls.LogStartTime);
                    break;
                case "LoginWinset":
                    logSheetList = logSheetList.OrderBy(ls => ls.LoginWinset);
                    break;
                case "TimeSpent":
                    logSheetList = logSheetList.OrderBy(ls => ls.TimeSpent);
                    break;
                case "PCName":
                    logSheetList = logSheetList.OrderBy(ls => ls.PCName);
                    break;
                case "DeptName":
                    logSheetList = logSheetList.OrderBy(ls => ls.DeptName);
                    break;
                default:

                    logSheetList = logSheetList.OrderBy(ls => ls.LogStartTime);
                    break;
            }

            if (this.SortDirection == SortDirection.Descending)
                logSheetList = logSheetList.Reverse();


            gvEmployeeStatus.DataSource = logSheetList;//.ToList();
            gvEmployeeStatus.DataBind();
        }

        private void BindStatusList(IEnumerable<LogSheet> ls)
        {
            DataSet ds = new DataSet();
            ds = new LogSheetController().GetScheduleCode();
            //ViewState["ScheduleCode_DS"] = ds;
            StatusCount[] statusList = new StatusCount[ds.Tables[0].Rows.Count + 1];
            //List<StatusCount> lstStatus = new List<StatusCount>();
            for (int i = 0; i <= ds.Tables[0].Rows.Count; i++)
            {

                if (i == ds.Tables[0].Rows.Count)
                {
                    statusList[i] = new StatusCount { Status = "SignOn", Count = ls.Count(), CodeNumber = 0 };
                    break;
                }
                statusList[i] = new StatusCount { Status = ds.Tables[0].Rows[i]["Description"].ToString().Trim(), Count = 0, CodeNumber = Convert.ToInt64(ds.Tables[0].Rows[i]["CodeNumber"]) };
            }
            //ViewState["ScheduleCode_DS"] = statusList;
            //lstStatus = statusList.ToList();

            var summary = from x in ls
                          group x by (x.IsIdle ? "Blank Idle" : x.CodeDescription) into g
                          select new { Status = g.Key, Count = g.Count() };

            List<StatusCount> lstStatus = (from x in statusList
                                           join a in summary on x.Status equals a.Status into ax
                                           from a in ax.DefaultIfEmpty()
                                           select new StatusCount
                                           {
                                               Status = (a == null ? x.Status : a.Status),
                                               Count = (a == null ? x.Count : a.Count)
                                           }).ToList();

            //List<StatusCount> lstStatus = statusSummary.ToList();
            ViewState["ScheduleCode_DS"] = lstStatus;
            //this.rptrStatusSummary.DataSource = lstStatus;
            //this.rptrStatusSummary.DataBind();
        }

        [Serializable]
        public struct StatusCount
        {
            public string Status { get; set; }
            public int Count { get; set; }
            public long CodeNumber { get; set; }
        }

        #endregion


    }

    public static class Test
    {
        public static DataTable ToDataTable<T>(this IEnumerable<T> collection)
        {
            DataTable dt = new DataTable("DataTable");
            Type t = typeof(T);
            PropertyInfo[] pia = t.GetProperties();

            //Inspect the properties and create the columns in the DataTable
            foreach (PropertyInfo pi in pia)
            {
                Type ColumnType = pi.PropertyType;
                if ((ColumnType.IsGenericType))
                {
                    ColumnType = ColumnType.GetGenericArguments()[0];
                }
                dt.Columns.Add(pi.Name, ColumnType);
            }

            //Populate the data table
            foreach (T item in collection)
            {
                DataRow dr = dt.NewRow();
                dr.BeginEdit();
                foreach (PropertyInfo pi in pia)
                {
                    if (pi.GetValue(item, null) != null)
                    {
                        dr[pi.Name] = pi.GetValue(item, null);
                    }
                }
                dr.EndEdit();
                dt.Rows.Add(dr);
            }
            return dt;
        }


    }

}
