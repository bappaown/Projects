﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using BSAT.BLL;
using BSAT.Entity;
using System.Reflection;
using System.Globalization;

namespace BPS_SMART.Admin
{
    public partial class AdminReports : System.Web.UI.Page
    {
        string empUserID = string.Empty;
        public static DataSet _dsEODReport = new DataSet();
       public static  DataSet _dsActivityReport = new DataSet();

        private bool _renderingGridForExport = false;

        #region Properties

        private IEnumerable<Reports> Report
        {
            get { return Session["Report"] as IEnumerable<Reports>; }
            set { Session["Report"] = value; }
        }

        #endregion

        #region Events

        protected void Page_Load(object sender, EventArgs e)
        {
            try {

                Employee oEmp = new Employee();
                AdminMaster master = (AdminMaster)(Page.Master);
                oEmp = master.IsUserAthenticate();
                empUserID = oEmp.EmpUserId;


                imgBtnSubmit.Attributes.Add("onclick", "return Validateform();");
            tbStartDate.Attributes.Add("readonly", "readonly");
            tbEndDate.Attributes.Add("readonly", "readonly");
            GetModuleName();
            if (Request.QueryString["PS"] != null)
            {
                if (Request.QueryString["PS"] == "1")
                {
                    Response.Redirect("AdminReports.aspx");
                }
            }
              
                if (!IsPostBack)
            {
                BindDepartment();
                BindProjectList();
                BindAdmin_AllUsers();
            }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        private void GetModuleName()
        {
            //ContentPlaceHolder ctPlaceHolder = (ContentPlaceHolder)Master.FindControl("cpMain");
            //Label lblModule = (Label)Master.FindControl("lblModule");
            //lblModule.Text = "Admin - Reports";
        }

        protected void BindDepartment()
        {
            DataSet dsdept = new DataSet();
            dsdept = new ReportsController().GetDepartment();
            lbDepartment.DataSource = dsdept.Tables[0];
            lbDepartment.DataTextField = "Name";
            lbDepartment.DataValueField = "ID";
            lbDepartment.DataBind();

            foreach (ListItem item in lbDepartment.Items)
                item.Attributes["title"] = item.Text;
        }

        protected void BindProjectList()
        {
            DataSet dsPrjct = new DataSet();
            dsPrjct = new ReportsController().BindProjectList();
            lbProjectist.DataSource = dsPrjct.Tables[0];
            lbProjectist.DataTextField = "ProjectList";
            lbProjectist.DataValueField = "ID";
            lbProjectist.DataBind();
        }

        protected void BindAdmin_AllUsers()
        {
            DataSet dsAdmin_AllUsers = new DataSet();
            string userID = empUserID;// H3GS.Web.Security.PassportIdentity.Current.Employee.UserId.ToString();
            dsAdmin_AllUsers = new ReportsController().BindAdmin_AllUsers(userID);
            lbEmployeeList.DataSource = dsAdmin_AllUsers.Tables[0];
            lbEmployeeList.DataTextField = "EmpName";
            lbEmployeeList.DataValueField = "EmpUserId";
            lbEmployeeList.DataBind();
        }

        protected void imgBtnSubmit_Click(object sender, EventArgs e)
        {

            //CultureInfo cl = new CultureInfo("yyyy-MM-dd");
            try
            {
                _dsEODReport = null;
                _dsActivityReport = null;

                string reportType = ddlReportType.Value;
                string startTime = tbStartDate.Text;
                string endTime = tbEndDate.Text;
                string startCostCentreTime = txtCostCentreStart.Text;
                string endCostCentreTime = txtCostCentreEnd.Text;
                string startHH = "00"; // ddlStartDateHH.Value;
                string startMM = "00";// ddlStartDateMM.Value;
                string endHH = "23"; //ddlEndDateHH.Value;
                string endMM = "59";// ddlEndDateMM.Value;
                string loginStart = "";
                string loginEnd = "";
                string departmentSelected = "";
                string departmentNotSelected = "";
                string employeeSelected = "";
                string employeeNotSelected = "";
                string projectSelected = "";
                string projectNotSelected = "";
                string employeeListSelected = "";
                string employeeListNotSelected = "";

                if (lbDepartment.Items.Count > 0)
                {
                    for (int i = 0; i < lbDepartment.Items.Count; i++)
                    {
                        if (lbDepartment.Items[i].Selected)
                        {
                            if (departmentSelected != "")
                            {
                                departmentSelected = departmentSelected + "," + lbDepartment.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                            else
                            {
                                departmentSelected = departmentSelected + "," + lbDepartment.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                        }
                        else
                        {
                            if (departmentNotSelected != "")
                            {
                                departmentNotSelected = departmentNotSelected + "," + lbDepartment.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                            else
                            {
                                departmentNotSelected = departmentNotSelected + "," + lbDepartment.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                        }
                    }
                }

                if (lbEmployee.Items.Count > 0)
                {
                    for (int i = 0; i < lbEmployee.Items.Count; i++)
                    {
                        if (lbEmployee.Items[i].Selected)
                        {
                            if (employeeSelected != "")
                            {
                                employeeSelected = employeeSelected + "," + lbEmployee.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                            else
                            {
                                employeeSelected = employeeSelected + "," + lbEmployee.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                        }
                        else
                        {
                            if (employeeNotSelected != "")
                            {
                                employeeNotSelected = employeeNotSelected + "," + lbEmployee.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                            else
                            {
                                employeeNotSelected = employeeNotSelected + "," + lbEmployee.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                        }
                    }
                }

                //Project List
                if (lbProjectist.Items.Count > 0)
                {
                    for (int i = 0; i < lbProjectist.Items.Count; i++)
                    {
                        if (lbProjectist.Items[i].Selected)
                        {
                            if (projectSelected != "")
                            {
                                projectSelected = projectSelected + "," + lbProjectist.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                            else
                            {
                                projectSelected = projectSelected + "," + lbProjectist.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                        }
                        else
                        {
                            if (projectNotSelected != "")
                            {
                                projectNotSelected = projectNotSelected + "," + lbProjectist.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                            else
                            {
                                projectNotSelected = projectNotSelected + "," + lbProjectist.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                        }
                    }
                }

                //EmployeeList
                if (lbEmployeeList.Items.Count > 0)
                {
                    for (int i = 0; i < lbEmployeeList.Items.Count; i++)
                    {
                        if (lbEmployeeList.Items[i].Selected)
                        {
                            if (employeeListSelected != "")
                            {
                                employeeListSelected = employeeListSelected + "," + lbEmployeeList.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                            else
                            {
                                employeeListSelected = employeeListSelected + "," + lbEmployeeList.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                        }
                        else
                        {
                            if (employeeListNotSelected != "")
                            {
                                employeeListNotSelected = employeeListNotSelected + "," + lbEmployeeList.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                            else
                            {
                                employeeListNotSelected = employeeListNotSelected + "," + lbEmployeeList.Items[i].Value;//lbDepartment.Items[i].Value;
                            }
                        }
                    }
                }

                string departmentName, employeeName, projectList, employeeList = "";
                if (departmentSelected == "" || departmentSelected.Length <= 0)
                {
                    departmentName = departmentNotSelected;
                }
                else
                {
                    departmentName = departmentSelected;
                }

                if (employeeSelected == "" || employeeSelected.Length <= 0)
                {
                    employeeName = employeeNotSelected;
                }
                else
                {
                    employeeName = employeeSelected;
                }
                //ProjectList
                if (projectSelected == "" || projectSelected.Length <= 0)
                {
                    projectList = projectNotSelected;
                }
                else
                {
                    projectList = projectSelected;
                }
                //EmployeeList
                if (employeeListSelected == "" || employeeListSelected.Length <= 0)
                {
                    employeeList = employeeListNotSelected;
                }
                else
                {
                    employeeList = employeeListSelected;
                }

                //if (reportType == "EOD Report")
                //{
                //    loginStart = startTime + " 05:30 AM";
                //    loginEnd = endTime + " 05:30 AM"; ;
                //}
                if (reportType == "EOD Report")
                {
                    loginStart = startTime + " 00:00 ";
                    loginEnd = endTime + " 23:59 ";
                }
                else if (reportType == "Activity Report")
                {
                    loginStart = startTime + " " + startHH + ":" + startMM;
                    loginEnd = endTime + " " + endHH + ":" + endMM;
                }
                else
                {
                    loginStart = startCostCentreTime;
                    loginEnd = endCostCentreTime;
                }
                this.EnableViewState = false;
                System.IO.StringWriter oStringWriter = new System.IO.StringWriter();
                System.Web.UI.HtmlTextWriter oHtmlTextWriter = new System.Web.UI.HtmlTextWriter(oStringWriter);

                if (reportType == "EOD Report")
                {

                    _renderingGridForExport = true;
                    _dsEODReport = new ReportsController().GetEODReports(loginStart, loginEnd, departmentName, employeeName);
                    // gvEod.DataSource = new ReportsController().GetEODReports(loginStart, loginEnd, departmentName, employeeName);

                    gvEODReports.DataSource = _dsEODReport;
                    gvEODReports.DataBind();

                    if (gvEODReports.Rows.Count == 0)
                    {
                        lblMessage.Text = "No Records Found";
                        btnExportExcel.Visible = false;
                    }
                    else
                    {
                        btnExportExcel.Visible = true;
                        //gvEod.RenderControl(oHtmlTextWriter);
                        //Response.Write(oStringWriter.ToString());
                        //_renderingGridForExport = false;
                        //Response.AddHeader("Content-disposition", "attachment;filename=EOD_Report" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xls");
                        //Response.ContentType = "application/vnd.ms-excel";
                        //Response.Charset = "UTF-8";
                        //Response.End();
                    }
                }
                else if (reportType == "Activity Report")
                {
                    _renderingGridForExport = true;

                 
                    _dsActivityReport = new ReportsController().GetActivityReports(loginStart, loginEnd, departmentName, employeeName);

                    gvActivityReports.DataSource = _dsActivityReport;
                    gvActivityReports.DataBind();

                    lbDepartment.DataBind();
                    if (gvActivityReports.Rows.Count == 0)
                    {
                        btnExportExcel.Visible = false;
                        lblMessage.Text = "No Records Found";
                    }
                    else
                    {
                        btnExportExcel.Visible = true;
                        //gvActivity.RenderControl(oHtmlTextWriter);
                        //Response.Write(oStringWriter.ToString());
                        //_renderingGridForExport = false;
                        //Response.AddHeader("Content-disposition", "attachment;filename=Activity_Report" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xls");
                        //Response.ContentType = "application/vnd.ms-excel";
                        //Response.Charset = "UTF-8";
                        //Response.End();
                    }
                }

                BindDepartment();
                BindAdmin_AllUsers();

            }
            catch (System.Threading.ThreadAbortException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {

            }
        }

        public override void VerifyRenderingInServerForm(Control control)
        {
            if (_renderingGridForExport == false)
                base.VerifyRenderingInServerForm(control);
        }

        protected void lbDepartment_SelectedIndexChanged(object sender, EventArgs e)
        {
            try {
                lbDepartment.DataBind();
            DataSet dsEmployee = new DataSet();
            string DeptID = string.Empty;
            string userID = empUserID;// H3GS.Web.Security.PassportIdentity.Current.Employee.UserId.ToString();
            foreach (ListItem items in lbDepartment.Items)
            {
                if (items.Selected)
                {
                    DeptID = DeptID + items.Value + ",";
                }
            }
            dsEmployee = new ReportsController().GetEmpList_As_Dept(DeptID, userID);
            lbEmployee.DataSource = dsEmployee.Tables[0];
            lbEmployee.DataTextField = "EmpName";
            lbEmployee.DataValueField = "EmpUserID";
            lbEmployee.DataBind();
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        #endregion

        #region Methods

        private void FormClear()
        {
            tbStartDate.Text = "";
            tbEndDate.Text = "";
            ddlStartDateHH.SelectedIndex = 0;
            ddlStartDateMM.SelectedIndex = 0;
            ddlEndDateHH.SelectedIndex = 0;
            ddlEndDateMM.SelectedIndex = 0;
            lblMessage.Text = "";
            ddlReportType.SelectedIndex = 0;
        }

        #endregion

        protected void btnExportExcel_Click(object sender, EventArgs e)
        {
            
            GridView gvEod = null;
            GridView gvActivity = null;
            string reportType = ddlReportType.Value;
            try
            {

                System.IO.StringWriter oStringWriter = new System.IO.StringWriter();
                System.Web.UI.HtmlTextWriter oHtmlTextWriter = new System.Web.UI.HtmlTextWriter(oStringWriter);
                _renderingGridForExport = true;

                if (reportType == "EOD Report")
                {
                   gvEod = new GridView();
                    gvEod.DataSource = _dsEODReport;
                    gvEod.DataBind();
                    if (_dsEODReport.Tables[0].Rows.Count > 0)
                    {
                        gvEod.RenderControl(oHtmlTextWriter);
                        Response.Write(oStringWriter.ToString());

                        Response.AddHeader("Content-disposition", "attachment;filename=EOD_Report" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xls");
                        Response.ContentType = "application/vnd.ms-excel";
                        Response.Charset = "UTF-8";
                        Response.End();
                    }
                }
                else
                {
                    gvActivity = new GridView();
                  
                    gvActivity.DataSource = _dsActivityReport;
                    gvActivity.DataBind();
                    if (_dsActivityReport.Tables[0].Rows.Count > 0)
                    {
                       
                        gvActivity.RenderControl(oHtmlTextWriter);
                        Response.Write(oStringWriter.ToString());
                        _renderingGridForExport = false;
                        Response.AddHeader("Content-disposition", "attachment;filename=Activity_Report" + DateTime.Now.ToString("dd-MMM-yyyy") + ".xls");
                        Response.ContentType = "application/vnd.ms-excel";
                        Response.Charset = "UTF-8";
                        Response.End();
                    }
                }
            }
            catch (System.Threading.ThreadAbortException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                gvEod = null;
                gvActivity = null;
            }
        }

       
    }
}