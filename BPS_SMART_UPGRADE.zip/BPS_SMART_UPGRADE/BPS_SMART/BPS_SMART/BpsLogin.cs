﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Web;
using System.DirectoryServices;
using System.DirectoryServices.AccountManagement;

/// <summary>
/// Summary description for BpsLogin
/// </summary>
public class BpsLogin
{
    public BpsLogin()
    {
        //
        // TODO: Add constructor logic here
        //
    }

    public static string GetDomainName(string usernameDomain)
    {
        if (string.IsNullOrEmpty(usernameDomain))
        {
            throw (new ArgumentException("Argument can't be null.", "usernameDomain"));
        }
        if (usernameDomain.Contains("\\"))
        {
            int index = usernameDomain.IndexOf("\\");
            return usernameDomain.Substring(0, index);
        }
        else if (usernameDomain.Contains("@"))
        {
            int index = usernameDomain.IndexOf("@");
            return usernameDomain.Substring(index + 1);
        }
        else if (usernameDomain.Contains("/"))
        {
            int index = usernameDomain.IndexOf("/");
            return usernameDomain.Substring(0, index);
        }
        else
        {
            return "";
        }
    }

    /// <summary>
    /// Parses the string to pull the user name out.
    /// </summary>
    /// <param name="usernameDomain">The string to parse that must contain the username in either the domain\username or UPN format username@domain</param>
    /// <returns>The username or the string if no domain is found.</returns>
    public static string GetUsername(string usernameDomain)
    {
        if (string.IsNullOrEmpty(usernameDomain))
        {
            throw (new ArgumentException("Argument can't be null.", "usernameDomain"));
        }
        if (usernameDomain.Contains("\\"))
        {
            int index = usernameDomain.IndexOf("\\");
            return usernameDomain.Substring(index + 1);
        }
        else if (usernameDomain.Contains("@"))
        {
            int index = usernameDomain.IndexOf("@");
            return usernameDomain.Substring(0, index);
        }
        else if (usernameDomain.Contains("/"))
        {
            int index = usernameDomain.IndexOf("/");
            return usernameDomain.Substring(index + 1);
        }
        else
        {
            return usernameDomain;
        }
    }
    /// <summary>
    /// Get the details of the employee who's ntLogin is passed.
    /// </summary>
    /// <param name="ntLogin">ntLogin of the user who's details needs to be retrived.</param>
    /// <returns>Employee object containing employee details.</returns>
    [DllImport("ADVAPI32.dll", EntryPoint = "LogonUserW", SetLastError = true, CharSet = CharSet.Auto)]
    public static extern bool LogonUser(string lpszUsername, string lpszDomain, string lpszPassword, int dwLogonType, int dwLogonProvider, ref IntPtr phToken);
    public Employee GetEmployeeDetails(string ntLogin, string strPassword, string Platform)
    {
        Employee oEmp = new Employee();
        String error = "Success";
        //SearchResult LDAPresult = null;

        DirectoryEntry entry = null;
        bool isValid;
        try
        {


            //isValid = empAuth.ValidateLoginOTP(ntLogin, strPassword, Platform);

            string domainName = GetDomainName(ntLogin); // Extract domain name form provide DomainUsername e.g Domainname\Username
            string userName = GetUsername(ntLogin);  // Extract user name from provided DomainUsername e.g Domainname\Username
            IntPtr token = IntPtr.Zero;

            isValid = LogonUser(userName, domainName, strPassword, 2, 0, ref token);

            if (isValid)
            {


                PrincipalContext principalContext = new PrincipalContext(ContextType.Domain, domainName);
                UserPrincipal user = UserPrincipal.FindByIdentity(principalContext, userName);
                entry = user.GetUnderlyingObject() as DirectoryEntry;
                if (user != null)
                {


                    ActiveDs.IADsUser native = (ActiveDs.IADsUser)entry.NativeObject;
                    DateTime dtAcctPwdexpire = native.PasswordExpirationDate;

                    string empID = user.EmployeeId;
                    CentralEmployeeMainStrore cs = new CentralEmployeeMainStrore();
                    oEmp = cs.GetDetail(empID);
                    string usertoken = null;
                    usertoken = null;//new DatabaseTokenBuilder().BuildToken(oEmp.EmployeeId, oEmp.EmpUserId, Platform, dtAcctPwdexpire);//send password expire datetime
                    oEmp.Token = usertoken;
                    oEmp.Login = ntLogin;

                }
                if (oEmp.EmployeeId == "0")
                {
                    oEmp.ErrorMessage = "User not found.";
                }
                else
                {
                    oEmp.ErrorMessage = error;
                }

                entry.Close();
                entry.Dispose();
            }
            else
            {


                ///DirectoryEntry entry = new DirectoryEntry();

                //entry1.RefreshCache();


                PrincipalContext principalContext = new PrincipalContext(ContextType.Domain, domainName);
                UserPrincipal user = UserPrincipal.FindByIdentity(principalContext, userName);
                entry = user.GetUnderlyingObject() as DirectoryEntry;

                ActiveDs.IADsUser native = (ActiveDs.IADsUser)entry.NativeObject;


                DateTime dtAcctPwdexpire = native.PasswordExpirationDate;
                DateTime dtAcctPwdChange = native.PasswordLastChanged;
                DateTime dtNow = DateTime.Now;
                if (dtNow > dtAcctPwdexpire)
                {
                    oEmp.ErrorMessage = "Your password is expired.";
                }
                else if (native.IsAccountLocked)
                {
                    oEmp.ErrorMessage = "Your account is locked.";
                }
                else if (native.AccountDisabled)
                {
                    oEmp.ErrorMessage = "Your account is disabled.";
                }

                else
                {
                    oEmp.ErrorMessage = "Incorrect Username/Password.";

                }
                entry.Close();
                entry.Dispose();
                oEmp.EmployeeId = "0";
                oEmp.EmpUserId = "0";
                oEmp.EmpName = "";
                oEmp.EmpNameWithId = "";
                oEmp.DepartmentId = 0;
                oEmp.Department = "";
                oEmp.DesignationId = 0;
                oEmp.Designation = "";
                oEmp.CostCentreId = 0;
                oEmp.CostCentre = "";
                oEmp.EmailId = "";
                oEmp.Location = "";
                oEmp.Message = "Invalid";


            }

        }
        catch (Exception ex)
        {


            oEmp.EmployeeId = "0";
            oEmp.EmpUserId = "0";
            oEmp.EmpName = "";
            oEmp.EmpNameWithId = "";
            oEmp.DepartmentId = 0;
            oEmp.Department = "";
            oEmp.DesignationId = 0;
            oEmp.Designation = "";
            oEmp.CostCentreId = 0;
            oEmp.CostCentre = "";
            oEmp.EmailId = "";
            oEmp.Location = ""; // + result + Marshal.GetLastWin32Error().ToString();
            oEmp.Message = "Invalid";
            oEmp.ErrorMessage = "Authentication Failed.";
            //oEmp.msg = ex.InnerException.ToString()+"--"+ex.Message.ToString();

        }




        return oEmp;
    }
    /// <summary>
    /// Parses the string to pull the domain name out.
    /// </summary>
    /// <param name="usernameDomain">The string to parse that must contain the domain in either the domain\username or UPN format username@domain</param>
    /// <returns>The domain name or "" if not domain is found.</returns>


}