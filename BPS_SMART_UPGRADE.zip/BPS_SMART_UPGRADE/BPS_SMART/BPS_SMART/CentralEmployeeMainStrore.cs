﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using BSAT.DAL;
/// <summary>
/// Summary description for CentralEmployeeMainStrore
/// </summary>
public class CentralEmployeeMainStrore
{
    public CentralEmployeeMainStrore()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    public Employee GetDetail(string ntLogin)
    {
        SqlDataReader odrEmp = null;
        SqlParameter[] oParam = null;
        Employee oEmp = new Employee();
        try
        {
            oParam = new SqlParameter[1];
            //oParam[0] = new SqlParameter("@Status", true);
            oParam[0] = new SqlParameter("@NTLogin", ntLogin == null || ntLogin == string.Empty ? null : ntLogin);
            //oParam[2] = new SqlParameter("@EmpUserId", empUserId == null || empUserId == "0" ? null : empUserId.ToString());

            odrEmp = SqlHelper.ExecuteReader(SqlHelper.ConnectionString(), CommandType.StoredProcedure, "proc_Get_CentralEmployees_BPS", oParam);

            oEmp = new Employee();
            oEmp.Message = "Invalid";

            if (odrEmp.HasRows)
            {

                while (odrEmp.Read())
                {
                    oEmp.EmployeeId = Convert.ToString(odrEmp["EmployeeId"]);
                    oEmp.EmpUserId = Convert.ToString(odrEmp["EmpUserId"]);
                    oEmp.EmpName = odrEmp["EmpName"].ToString();
                    oEmp.EmpNameWithId = odrEmp["EmployeeID"].ToString();
                    oEmp.DepartmentId = Convert.ToInt32(odrEmp["DepartmentID"]);
                    oEmp.DesignationId = Convert.ToInt32(odrEmp["DesignationID"]);
                    oEmp.CostCentreId = Convert.ToInt16(odrEmp["CostCentreID"]);
                    oEmp.CostCentre = odrEmp["CostCentreID"].ToString();
                    oEmp.EmailId = odrEmp["Email"].ToString();
                    oEmp.Location = odrEmp["Location"].ToString();
                    oEmp.RoleID = Convert.ToInt16(odrEmp["RoleID"]);
                    oEmp.Message = "Success";
                }


            }
            else
            {
                oEmp.EmployeeId = "0";
                oEmp.EmpUserId = "0";
                oEmp.EmpName = "";
                oEmp.EmpNameWithId = "";
                oEmp.DepartmentId = 0;
                oEmp.Department = "";
                oEmp.DesignationId = 0;
                oEmp.Designation = "";
                oEmp.CostCentreId = 0;
                oEmp.CostCentre = "";
                oEmp.EmailId = "";
                oEmp.Location = "";
                oEmp.Message = "Invalid";

            }


        }
        catch (Exception ex)
        {

        }
        finally
        {
            if (odrEmp != null)
                odrEmp.Dispose();
        }
        return oEmp;
    }

}