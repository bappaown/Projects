﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Xml.Linq;
//using BSAT.BLL;
//using BSAT.Entity;

namespace BPS_SMART
{
    public partial class AdminMaster : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
              
            }
        }

        public Employee IsUserAthenticate()
        {
            Employee oEmp = new Employee();
            if (Request.Cookies["SMART"] == null)
            {
                Response.Redirect("../Login.aspx");
            }
            else
            {
                string Employee = DecryptString(Request.Cookies["SMART"]["Employee"].ToString());
                oEmp.EmpUserId = Employee.Split('|')[0];
                oEmp.EmpName = Employee.Split('|')[1];
                oEmp.RoleID = Convert.ToInt16(Employee.Split('|')[2]);
                lblName.Text = Employee.Split('|')[1].ToString();


            }
            return oEmp;
        }

        public string DecryptString(string encrString)
        {
            byte[] b;
            string decrypted;
            try
            {
                b = Convert.FromBase64String(encrString);
                decrypted = System.Text.ASCIIEncoding.ASCII.GetString(b);
            }
            catch (FormatException fe)
            {
                decrypted = "";
            }
            return decrypted;
        }


        protected void imhLogout_Click(object sender, ImageClickEventArgs e)
        {
            if (Request.Cookies["SMART"] != null)
            {
                Response.Cookies["SMART"].Expires = DateTime.Now.AddDays(-1);
            }
            Response.Redirect("../Login.aspx");
        }
    }
}