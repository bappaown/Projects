﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

/// <summary>
/// Summary description for Employee
/// </summary>
public class Employee
{
    public Employee()
    {
        //
        // TODO: Add constructor logic here
        //
    }
    #region Public Properties

    public string LoginID { get; set; }

    public string EmployeeId { get; set; }

    public string EmpUserId { get; set; }

    public int DepartmentId { get; set; }

    public string Department { get; set; }

    public int DesignationId { get; set; }

    public string Designation { get; set; }

    public short CostCentreId { get; set; }

    public string CostCentre { get; set; }

    public string EmailId { get; set; }

    public string EmpName { get; set; }

    public string EmpNameWithId { get; set; }

    public string Location { get; set; }

    public string Message { get; set; }

    public string Token { get; set; }

    public string ErrorMessage { get; set; }

    public bool IsExist { get; set; }

    public string Login { get; set; }

    public string IMEI { get; set; }

    public string OTP { get; set; }
    //[DataMember]
    //public DateTime OTPDateCreated { get; set; }

    public string OTPDateCreated { get; set; }

    public bool IsRegistered { get; set; }
    //[DataMember]
    //public bool IsActive { get; set; }

    public bool ReRegistered { get; set; }

    public string msg { get; set; }

    public bool Success { get; set; }

    public bool IsConfirmed { get; set; }

    public string platform { get; set; }

    public string DevicePlatform { get; set; }

    public bool IsAdmin { get; set; }

    public bool IsUser { get; set; }

    public int RoleID { get; set; }
    #endregion
}